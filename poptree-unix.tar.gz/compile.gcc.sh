gcc poptree.c -o poptree -lm
gcc postree.c -o postree -lm
gcc cnvdat.c -o cnvdat -lm
gcc cnvtre.c -o cnvtre -lm

