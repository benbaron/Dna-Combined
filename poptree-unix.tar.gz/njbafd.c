#include <stdio.h>
#include <math.h>
/* #include <malloc.h>*/
#include <string.h>
#include <stdlib.h>
#define NSYM 4
#define NDIST 4
#define ERR stdout
#define ACU  0.000000000001
typedef struct nodc {
   char childio[3];
   int childn[3];
 } Nodc;

extern int dflg;

extern char *distop[NDIST];

int *ivector(int );
double *dvector(int);
double **dmatrix(int,int);
char **cmatrix(int, int );
char *cvector(int);
float **fmatrix(int, int);
float ***f3matrix(int, int* , int);
float **f2matrix(int,int*);
void free_fmatrix(float**,int);
int **imatrix(int,int);
int *ivector(int);
Nodc **nvector(int);
long *lvector(int);
float ran1(long*);
int dflg;

int *ivector( n)
int n;
{
int *vp;

	vp = (int *)malloc((unsigned) n*sizeof(int));
	if( !vp ) {
		 fprintf(ERR,"memory allocation error\n");
		 fprintf(ERR,"integer vector[%d]\n",n);
		 exit(1);
	  }
	 return(vp);
}
long *lvector( n)
int n;
{
long *vp;

	vp = (long *)malloc((unsigned) n*sizeof(long));
	if( !vp ) {
		 fprintf(ERR,"memory allocation error\n");
		 fprintf(ERR,"integer vector[%d]\n",n);
		 exit(1);
	  }
	 return(vp);
}
char *cvector(n)
int n;
{
char *vp;

	vp = (char *)malloc((unsigned) n*sizeof(char));
	if( !vp ) {
		 fprintf(ERR,"memory allocation error\n");
		 fprintf(ERR,"char vector[%d]\n",n);
		 exit(1);
	  }
	 return(vp);
}

double *dvector(n)
int n;
{
double *vp;

	vp = (double *)malloc((unsigned) n*sizeof(double));
	if( !vp ) {
		 fprintf(ERR,"memory allocation error\n");
		 fprintf(ERR,"double vector[%d]\n",n);
		 exit(1);
	  }
	 return(vp);
}

int **imatrix(n1,n2)
int n1,n2;
{
int i,**ip;

 ip = (int **) malloc((unsigned ) n1*sizeof(int*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	ip[i] = (int *) malloc((unsigned) n2*sizeof(int));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
	 exit(1);

  }
 }

  return(ip);

}


float **f2matrix(n1,n2)
int n1,*n2;
{
int i;
float **ip;

/* printf("n1=%d\n",n1); */
 ip = (float **) malloc((unsigned ) n1*sizeof(float *) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
/*   printf("n2[%d]=%d\n",i,n2[i]); */
	ip[i] = (float *) malloc((unsigned) n2[i]*sizeof(float ));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
	 exit(1);

  }
 }

  return(ip);

}




float **fmatrix(n1,n2)
int n1,n2;
{
int i;
float **ip;

 ip = (float **) malloc((unsigned ) n1*sizeof(float*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 float matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	ip[i] = (float *) malloc((unsigned) n2*sizeof(float));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) float matrix %d %d\n",i,n1,n2);
	 exit(1);

  }
 }

  return(ip);

}




float ***f3matrix(nloci,nalle,npop)
int nloci,npop,*nalle;
{
int i;
float ***ip, **fmatrix(int n1, int n2);

/*
 printf("nloci %d npop %d\n",nloci,npop);
 for(i=0; i<nloci ; i++){
	printf("nallele=%d\n",nalle[i]);
 }
*/

 ip = (float ***) malloc((unsigned ) nloci*sizeof(float**) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 float 3matrix %d\n",nloci);
	 exit(1);
  }
 for(i=0; i<nloci ; i++){
	  ip[i] = fmatrix(nalle[i],npop);
/*     printf("i=%d nalle %d\n",i,nalle[i]);

	  for(j=0; j<nalle[i] ; j++){
		 for(k=0; k < npop ; k++) ip[i][j][k]=0.0;
	  }
*/
	  if( !ip[i] ) {
			 fprintf(ERR,"memory allocation error\n");
			 fprintf(ERR,"step2(i=%d) float3 matrix %d %d\n",i,nloci,nalle[i]);
			 exit(1);
	}
	}




  return(ip);

}




char **cmatrix(n1,n2)
int n1,n2;
{
int i;
char **ip;

 ip = (char **) malloc((unsigned ) n1*sizeof(char*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	ip[i] = (char *) malloc((unsigned) n2*sizeof(char));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
	 exit(1);

  }
 }

  return(ip);

}


double **dmatrix(n1,n2)
int n1,n2;
{
int i;
double **ip;

 ip = (double **) malloc((unsigned ) n1*sizeof(double*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	ip[i] = (double *) malloc((unsigned) n2*sizeof(double));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) double matrix %d %d\n",i,n1,n2);
	 exit(1);

  }
 }

  return(ip);

}



double **dmatrixf(n1,n2)
int n1,*n2;
{
int i;
double **ip;

 ip = (double **) malloc((unsigned ) n1*sizeof(double*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	ip[i] = (double *) malloc((unsigned) n2[i]*sizeof(double));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) double matrixf %d %d\n",i,n1,n2[i]);
	 exit(1);

  }
 }

  return(ip);

}


Nodc **nvector(n)
int n;
{
int i;
Nodc **ip;

 ip = (Nodc **) malloc((unsigned ) n*sizeof(Nodc*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"Nodc step1 %d\n",n);
	 exit(1);
  }
 for(i=0; i<n ; i++){
	ip[i] = (Nodc *) malloc(sizeof(Nodc));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) Tnode %d\n",i,n);
	 exit(1);

  }
 }

  return(ip);

}


void free_ivector(v)
int *v;
{
	free((char*) v );
	return ;
 }
void free_lvector(v)
long *v;
{
	free((char*) v );
	return ;
 }

void free_dvector(v)
double *v;
{
	free((char*) v );
	return ;
 }


void free_cvector(v)
char *v;
{
   free((char*) v );
   return ;
 }


void free_cmatrix(m,n1)
char **m;
int n1;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}

void free_imatrix(m,n1)
int  **m;
int n1;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}


void free_fmatrix(m,n1)
float  **m;
int n1;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}

void free_f3matrix(m,n1,n2)
float  ***m;
int n1, *n2;
{
int i;
void free_fmatrix(float **m, int n1);

    for(i=n1-1 ; i >= 0 ; i-- ){
       free_fmatrix(m[i],n2[i]);
       free((char *) (m[i]));
     }
    free((char *) m);
}
void free_dmatrix(m,n1)
double  **m;
int n1;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}


void free_nvector(ip,n)
Nodc **ip;
int n;
{
int i;


 for(i=n-1; i >=0 ; i--){
   free((char*) ip[i]);
 }
 free((char *)ip); 
  return ;
				 
}

int checkloci(fpi,nloci,npop)
FILE *fpi;
int *nloci,*npop;
{
int cw,fc;
char bf[100],bf1[20];
int clearbf(char *);
extern int dflg;

/* flg  0   initial
		  1   file name
        2   file name end
        3   sequence
   flg1 1   comment
 */

   fc=0;
	clearbf(bf);
	for( ; ; ){
    cw = getc(fpi);
    if( cw == '\n') break;
    bf[fc]=cw;
    fc++;
  }
  
	sscanf(bf,"%d %s",npop,bf1);
	if( strcmp(bf1,"populations") != 0 ){
     printf("invalid format first line\n");
     exit(1);
   }


	fc=0;
	cw =0;

   *nloci=0;
   for( ; ; ){
      cw=getc(fpi);
      if( cw == EOF ) break;
      if( cw == '@' ) (*nloci)++;
    }
    return(0);
}




checkflal(fpi,nloci,nallele,maxnm,npop)
FILE *fpi;
int nloci,*nallele,*maxnm,npop;
{
int flg1,nc,na,nw,i,cw;
char bf[100];
extern int dflg;

/* flg  0   initial
		  1   file name
		  2   file name end
		  3   sequence
	flg1 1   comment
 */
	*maxnm=0;
	nc=0;
	flg1=0;
	na=0;
	for(i=0; i<nloci ; i++) nallele[i]=0;
		 nc=0;
		 flg1=0;
		 for( ; ; ){
			 cw = getc(fpi);
			 switch(flg1){
				 case 0: if( cw == ' ' || cw == '\t') break;
							if( cw == '\n' ) break;
							bf[nc]=cw;
							nc++;
							flg1=1;
							break;
				 case 1: if( cw == ' ' || cw == '\t' ){
								 flg1=2;
								 bf[nc]=0;
								 sscanf(bf,"%d",&nw);
								 na++;
								 nc=0;
								 break;
				 }
							  if( cw == '\n' ) {
									printf("invalid format\n");
									exit(1);
			 }
							  bf[nc]=cw;
							  nc++;
							  break;
		  case 2: if( cw == ' ' || cw == '\t' || cw == '\n' ) {
							 flg1 = 0;
							 if( nc > *maxnm ) *maxnm = nc;
							 if( na == npop) {
								 flg1=3;
								 break;
				 }
			 }
							bf[nc] = cw;
							nc++;
							break;

		  }
				 if( flg1 == 3) break;

	}


nc=0;
for( ; ; ){
		  cw = getc(fpi);
		  if( cw == '@' )           nc++;
		  if( cw == '*' )       nallele[nc-1]++;
		  if( cw == EOF ) break;
		}

	 return(0);
}


getal(fpi,dop,nloci,nallele,popname,allelef,samplesz,npop,fstep)
FILE *fpi;
int dop,nloci,*nallele,npop;
float ***allelef,**samplesz,**fstep;
char **popname;
{
int cw,flg,nc,na,nw,nl,np,nloci1,i,j,k;
char bf[100];
float fw;
extern int dflg;

/* flg  0   initial
		  1   file name
		  2   file name end
		  3   sequence
	flg1 1   comment
 */



  for(i=0; i< nloci ; i++){
	 for(j=0; j<nallele[i] ; j++){
		 for(k=0; k<npop ; k++){
		 allelef[i][j][k]= -1.;
			}
  }
  }
	nc=0;
	flg = 0;
	cw =0;
	na=0; nl=0;
	nloci1=0;
	 for( ; ; ){
			 cw = getc(fpi);
			 if( cw == '\n' ) nl++;
			 if( cw == EOF ) break;
			 if( dflg == 1 ) {
				  printf(" flg=%d cw=%c",flg,cw); fflush(stdout);
		 }
			 switch(flg){
				 case 0:
							if( cw == '\n' ){
								 flg=1;

				 }
							break;
				 case 1:  if( cw == ' ' || cw == '\t' || cw == '\n' ) break;
							 bf[0]= cw;
							 nc=1;
							 flg=2;
							 break;
				 case 2:  if( cw == ' ' || cw == '\t' || cw == '\n' ) {
								 flg=3;
								 bf[nc]=0;
								 sscanf(bf,"%d",&nw);
								 na++;
								 if( na != nw ){
								  printf("na=%d nw=%d\n",na,nw);
								  exit(1);
			}
				 }
							  bf[nc]=cw;
							  nc++;
							  break;
		  case 3: if( cw == ' ' || cw == '\t' || cw == '\n' ) break;
							popname[na-1][0]=cw;
							nc=1;
							flg=4;
							break;
				 case 4: if( cw == ' ' || cw == '\t' || cw == '\n' ) {
							  flg = 1;
							  if( na == npop ) flg=5;
							  break;
			  }
							popname[na-1][nc]=cw;
							nc++;
							break;
				 case 5: if( cw == '@' ) {
							  nloci1++;
							  na=0;
							  flg=6;
							}
							break;
				 case 6:   if( cw == '\n') {
									flg= 11;
									break;
			 }
								  if( cw == '*' )  {
								  flg=7;
								  na++;
								  np=0;
								  break;
								}
								if( cw == '#' ) {
									flg = 9;
									np=0;
								}
								break;
				 case 11:  if( cw == ' ' || cw == '\t' || cw == '\n') break;
							  if( cw == '*' )  {
										 printf("format error: no step number\n");
										 exit(1);
					  }
								bf[0]=cw;
								nc=1;
/*                        printf("flg=11 cw=%c\n",cw); */
								flg = 12;
								break;
				  case 12: if ( cw == '*' ) {
								 bf[nc]=0;
								 if( dop >= 2 ){
								  sscanf(bf,"%f",&fw);
/*                         printf("iw=%d na=%d nloci=%d\n",fw,na,nloci1); fflush(stdout); */
								 fstep[nloci1-1][na]=fw;
								 }
								 flg =7;
								 na++;
								 np=0;
								 break;
							  }
							  if( cw == ' ' || cw == '\t' || cw == '\n') break;
							  bf[nc]=cw;
							  nc++;
							  break;

				  case 7:  if( cw == ' ' || cw == '\t' || cw == '\n') break;
							  bf[0]=cw;
							  nc=1;
							  flg=8;
							  break;
				  case 8:  if( cw == ' ' || cw == '\t' || cw == '\n') {
								 bf[nc]=0;
								 sscanf(bf,"%f",&fw);
								 if( dflg == 1 ){
										 printf("nloci=%d na=%d np=%d fw=%f nc=%d\n",nloci1,na,np,fw,nc); fflush(stdout);
				  }
								 allelef[nloci1-1][na-1][np]=fw;
/*                         printf("allele\n"); fflush(stdout);  */
								 np++;
								 if( np == npop ){
/*                             printf("na=%d nallele[nloci-1]=%d\n",na,nallele[nloci-1]); */}
								 if( np == npop && na < nallele[nloci1-1] ){
									flg=11;
									break;
								 }
								 if( np == npop && na ==  nallele[nloci1-1] ){
									flg=6;
									break;
								 }
								 flg=7;
								 break;
				 }
							  bf[nc]=cw;
							  nc++;
								 break;
			 case 9: if( cw == ' ' || cw == '\t' || cw == '\n') break;
							  bf[0]=cw;
							  flg = 10;
							  nc=1;
							  break;
			 case 10: if( cw == ' ' || cw == '\t' || cw == '\n') {
									bf[nc]=0;
									sscanf(bf,"%f",&fw);
									samplesz[nloci1-1][np]=fw;
/*                           printf("loci %d pop=%d bf=%s fw=%f\n",nloci1,np,bf,fw);*/

									np++;
									flg=9;
									if( np == npop ) flg=5;
									break;
								 }
								 bf[nc]=cw;
								 nc++;
								 break;
			}
	}


	 return(0);
}



clearbf(bf)
char *bf;
{
int i;

for(i=0; i<100 ; i++) bf[i]=0;

return(0);
}


hetero(fpo,napop,apop,nloci,allelefrq, samplesz,nallele,heteroz,popname)

int napop, *apop,nloci,*nallele;

float ***allelefrq,**samplesz;

char **popname;

double *heteroz;

FILE *fpo;

{

int i,j,k,l,nc,n1,n2;

double js1,gst,dst1,hs1,gst1,jkl,jx,jxa;
double dw,sx;


	fprintf(fpo,"   %d otus\n",napop);
	for(i=0; i<napop ; i++){
	  fprintf(fpo,"%d %s\n",i+1,popname[apop[i]]);
	 }
	 fflush(fpo);
 for(i=0; i<napop ; i++) heteroz[i] = 0.0;
 fprintf(fpo,"Heterozygosity and Gst\n");
 fprintf(fpo,"Locus");

 for(i=0; i< napop ; i++) {
	fprintf(fpo," ");
	nc = strlen(popname[apop[i]]);
	if( nc >= 5 ){
		for(j=0; j<5 ; j++ ) fprintf(fpo,"%c",popname[apop[i]][j]);
		}else{
		for(j=0; j< nc ; j++ ) fprintf(fpo,"%c",popname[apop[i]][j]);
		for(j=0; j< 5-nc ; j++ ) fprintf(fpo," ");
 }
 }
 fprintf(fpo,"  Gst\n");
 gst = 0.;
 for(i=0; i< nloci ; i++){
	 fprintf(fpo,"%5d",i+1); fflush(fpo);
	 nc = i;
	 dst1 = 0.;
	 jkl=0.;
	 dw = 0.;
	 for(j=0; j< nallele[nc] ; j++){
		for(k=0; k< napop ; k++){
			n1 = apop[k];
			dw += allelefrq[nc][j][n1]*allelefrq[nc][j][n1];
			for(l=k+1; l< napop ; l++ ) {
			  n2 = apop[l];
			  jkl += allelefrq[nc][j][n1]*allelefrq[nc][j][n2];
			 }

		 }
	 }


	 dst1 = (dw*(double)((napop-1))- jkl*2.)/((double)(napop*napop));

	 js1 = dw/(double)napop;
	 for(j=0; j<napop ; j++){
		jx = 0.0;
		jxa = 0.0;
		n1 = apop[j];
		sx = samplesz[nc][n1];
		for(k=0; k< nallele[nc] ; k++){
			jxa += allelefrq[nc][k][n1]*allelefrq[nc][k][n1];
		 }
		 jx =  (jxa*sx-1.0)/(sx-1.0);


		 heteroz[j] += 1.0 - jx;
/*

		 if( jx <= 0.0+ACU ){

			printf("jx=%f jxa=%f sx=%f\n",jx,jxa,sx);
		 }
*/
		 fprintf(fpo," %5.3f",1.0-jx);  fflush(stdout);
	 }
	 hs1 = 1. - js1;
/*	fprintf(fpo," hs1=%f dst1=%f\n",hs1,dst1);fflush(stdout);   */
	 gst1 = dst1/(hs1+dst1);
	 gst += gst1;
	 fprintf(fpo," %5.3f\n",gst1);  fflush(fpo);
  }
 fprintf(fpo,"ave. ");
for(i=0; i<napop ; i++){
 heteroz[i] /= nloci;
 fprintf(fpo," %5.3f", heteroz[i]);  fflush(fpo);
}
gst /= nloci;
fprintf(fpo," %5.3f\n",gst);  fflush(fpo);
return(0);

}

njr(nseq,dist,node,branch0,otu,spair,sw,st,dcm,rij,seed1)
int nseq,**node/*[MAXOTU-2][3]*/;
long *seed1;
int *otu/*[MAXOTU]*/,**spair/*[MAXOTU*(MAXOTU-1)/2][2]*/,*sw/*[MAXOTU*(MAXOTU-1)/2]*/;
double *st/*[MAXOTU*(MAXOTU-1)/2]*/,*dcm/*[MAXOTU]*/,*rij/*[MAXOTU]*/;
double **dist/*[MAXOTU][MAXOTU]*/,**branch0/*[MAXOTU][3]*/;
{
int i,j,k,l,nsc,cyc,scnt,n1,n2,n3,nsm,nsw,rn;
double dw,sm,ds;
extern int dflg;


  nsc=nseq;

  for(i=0; i<nseq-2 ; i++){
    for(j=0; j<3 ; j++) node[i][j]=0;
  }
  for(i=0; i<nseq; i++) otu[i]=i+1;
  for(cyc=0; cyc<nseq-3; cyc++){
     scnt=0;
     ds=nsc-2;
     for(i=0; i<nsc ; i++){
        rij[i]=0.0;
        for(k=0; k<nsc ; k++){
             if( i < k ) rij[i] += dist[i][k];
             if( i > k ) rij[i] += dist[k][i];
         }
      }
     for(i=0; i<nsc-1; i++){
          for(j=i+1; j<nsc; j++){
          st[scnt]=dist[i][j]*ds-rij[i]-rij[j];
          spair[scnt][0]=i;
          spair[scnt][1]=j;
          if( scnt == 0 ) {
             sm=st[0];
             nsm = 0;
	   }else{
            if( st[scnt] < sm ){
               sm = st[scnt];
               nsm = scnt;
	     }
	  }
          scnt++;
	}
      }
      sw[0]=nsm;
      nsw=1;
      for(i=0; i<scnt ; i++){
         if( i == nsm ) continue;
         dw = st[i]-sm;
         if( dw < 0.0 ) dw *= -1.0;
         if( dw <= ACU ) {
           sw[nsw]=i;
           nsw++;
         }
       }
       if( nsw > 1 ){
          rn= ran1(seed1)*(float)nsw;
/*          rn = random()%nsw; */
          nsm = sw[rn];
	}
      n1=spair[nsm][0];
      n2=spair[nsm][1];
      node[cyc][0]=otu[n1];
      node[cyc][1]=otu[n2];
      dcm[cyc]=dist[n1][n2];
      branch0[cyc][0]=dist[n1][n2]/2.0+(rij[n1]-rij[n2])/(2.0*ds);
      branch0[cyc][1]=dist[n1][n2]/2.0+(rij[n2]-rij[n1])/(2.0*ds);
      if( otu[n1] > nseq ){
         n3=otu[n1]-nseq-1;
         branch0[cyc][0] -= dcm[n3]/2.0;
       }
      if( otu[n2] > nseq ){
         n3=otu[n2]-nseq-1;
         branch0[cyc][1] -= dcm[n3]/2.0;
       }
      for(k=0; k<nsc; k++) {
          if( k == n1 || k == n2 ) continue;
          if( n1 < k && n2 < k ) dist[n1][k] = (dist[n1][k] + dist[n2][k])/2.0;
          if( n1 < k && n2 > k ) dist[n1][k] = (dist[n1][k] + dist[k][n2])/2.0;
          if( n1 > k && n2 < k ) dist[k][n1] = (dist[k][n1] + dist[n2][k])/2.0;
          if( n1 > k && n2 > k ) dist[k][n1] = (dist[k][n1] + dist[k][n2])/2.0;
	}
      otu[n1]=nseq+cyc+1;
      for(k=n2; k<nsc-1; k++) otu[k]=otu[k+1];

      for(k=0; k< n2 ; k++){
         for(l=n2+1 ; l< nsc ; l++)  dist[k][l-1] = dist[k][l];
       }
       for(k=n2+1 ; k<nsc-1 ; k++){
         for(l=k+1 ; l<nsc ; l++) dist[k-1][l-1] =dist[k][l];
       }

   
     

/*      for(k=0; k<nsc ; k++){
        for(l=n2; l<nsc-1; l++){
           dist[k][l] =dist[k][l+1];
	 }
       }
      for(k=0; k<nsc ; k++){
         for(l=n2; l<nsc-1 ; l++){
           dist[l][k] =dist[l+1][k];
         }
       }
*/
       nsc--;
   
}

cyc=nseq-3;
 branch0[cyc][0]=(dist[0][1]+dist[0][2]-dist[1][2])/2.0;
 branch0[cyc][1]=(dist[0][1]-dist[0][2]+dist[1][2])/2.0;
 branch0[cyc][2]=(-dist[0][1]+dist[0][2]+dist[1][2])/2.0;
 for(i=0; i<3 ; i++){
   node[cyc][i]=otu[i];
   if( otu[i] > nseq ){
         n3=otu[i]-nseq-1;
         branch0[cyc][i] -= dcm[n3]/2.0;
       }
 }

 return(0);
}
           
njt(nseq,dist,node,branch0,otu,spair,st,dcm,rij)
int nseq,**node/*[MAXOTU-2][3]*/;
int *otu/*[MAXOTU]*/,**spair/*[MAXOTU*(MAXOTU-1)/2][2]*/;
double *st/*[MAXOTU*(MAXOTU-1)/2]*/,*dcm/*[MAXOTU]*/,*rij/*[MAXOTU]*/;
double **dist/*[MAXOTU][MAXOTU]*/,**branch0/*[MAXOTU][3]*/;
{
int i,j,k,l,nsc,cyc,scnt,n1,n2,n3,nsm;
double sm,ds;

float ran1();

  nsc=nseq;

  for(i=0; i<nseq-2 ; i++){
    for(j=0; j<3 ; j++) node[i][j]=0;
  }
  for(i=0; i<nseq; i++) otu[i]=i+1;
  for(cyc=0; cyc<nseq-3; cyc++){
     scnt=0;
     ds=nsc-2;
     for(i=0; i<nsc ; i++){
        rij[i]=0.0;
        for(k=0; k<nsc ; k++){
             if( i < k ) rij[i] += dist[i][k];
             if( i > k ) rij[i] += dist[k][i];
         }
      }
     for(i=0; i<nsc-1; i++){
          for(j=i+1; j<nsc; j++){
          st[scnt]=dist[i][j]*ds-rij[i]-rij[j];
          spair[scnt][0]=i;
          spair[scnt][1]=j;
          if( scnt == 0 ) {
             sm=st[0];
				 nsm = 0;
	   }else{
            if( st[scnt] < sm ){
               sm = st[scnt];
               nsm = scnt;
	     }
	  }
          scnt++;
	}
      }
/*
      sw[0]=nsm;
      nsw=1;
      for(i=0; i<scnt ; i++){
         if( i == nsm ) continue;
         dw = st[i]-sm;
         if( dw < 0.0 ) dw *= -1.0;
         if( dw <= ACU ) {
           (*tief)++;
           sw[nsw]=i;
           nsw++;
         }
       }
       if( nsw > 1 ){
          rn = random()%nsw;
          nsm = sw[rn];
	}
*/
      n1=spair[nsm][0];
      n2=spair[nsm][1];
      node[cyc][0]=otu[n1];
      node[cyc][1]=otu[n2];
      dcm[cyc]=dist[n1][n2];
      branch0[cyc][0]=dist[n1][n2]/2.0+(rij[n1]-rij[n2])/(2.0*ds);
      branch0[cyc][1]=dist[n1][n2]/2.0+(rij[n2]-rij[n1])/(2.0*ds);
      if( otu[n1] > nseq ){
         n3=otu[n1]-nseq-1;
         branch0[cyc][0] -= dcm[n3]/2.0;
       }
      if( otu[n2] > nseq ){
         n3=otu[n2]-nseq-1;
         branch0[cyc][1] -= dcm[n3]/2.0;
       }
      for(k=0; k<nsc; k++) {
          if( k == n1 || k == n2 ) continue;
          if( n1 < k && n2 < k ) dist[n1][k] = (dist[n1][k] + dist[n2][k])/2.0;
          if( n1 < k && n2 > k ) dist[n1][k] = (dist[n1][k] + dist[k][n2])/2.0;
          if( n1 > k && n2 < k ) dist[k][n1] = (dist[k][n1] + dist[n2][k])/2.0;
          if( n1 > k && n2 > k ) dist[k][n1] = (dist[k][n1] + dist[k][n2])/2.0;
	}
      otu[n1]=nseq+cyc+1;
      for(k=n2; k<nsc-1; k++) otu[k]=otu[k+1];

      for(k=0; k< n2 ; k++){
         for(l=n2+1 ; l< nsc ; l++)  dist[k][l-1] = dist[k][l];
       }
       for(k=n2+1 ; k<nsc-1 ; k++){
         for(l=k+1 ; l<nsc ; l++) dist[k-1][l-1] =dist[k][l];
       }

   
     

       nsc--;
   
}

cyc=nseq-3;
 branch0[cyc][0]=(dist[0][1]+dist[0][2]-dist[1][2])/2.0;
 branch0[cyc][1]=(dist[0][1]-dist[0][2]+dist[1][2])/2.0;
 branch0[cyc][2]=(-dist[0][1]+dist[0][2]+dist[1][2])/2.0;
 for(i=0; i<3 ; i++){
   node[cyc][i]=otu[i];
   if( otu[i] > nseq ){
         n3=otu[i]-nseq-1;
         branch0[cyc][i] -= dcm[n3]/2.0;
       }
 }

 return(0);
}


#define Width  80

#define DPRE    3

prdist(fpo,napop, apop, dist )

FILE *fpo;

int napop,*apop;

double **dist;

{

double dw;

int i, j, k,l, n,iw,ia,nt,na,n1,n2;

char b[10],cw,b1[10];



  fprintf(fpo,"\n\nDistance matrix\n");

  dw = -99999.0;

  for(i=0; i< napop ; i++){

	for(j=i+1; j< napop ; j++){

	  if( dw < dist[i][j] ) dw = dist[i][j];

	}

  }



  iw = dw;

  for(i=0; ;){

	 iw /= 10;

	 if( iw == 0 ) break;

	 i++;

  }

  ia = i+1+DPRE+1;

  cw = '%';

  for(i=0; i< 10 ; i++ ){

	 b[i]=b1[i]=0;

	 }

	 sprintf(b," %c%d.%df",cw,ia,DPRE);

	 sprintf(b1," %c%dd",cw,ia);

  n = Width / (ia+1);

  nt = (napop-1)/n;

  na = (napop-1)%n;

  for(i=0; i< nt+1 ; i++){

	 if( i == 0 ) n1 = 0;

	 else n1 = i*n;

	 if( i == nt ) n2 = i*n+na;

	 else n2 = (i+1)*n;

	 fprintf(fpo,"     ");

	 for(k=n1+1; k<=n2 ; k++) fprintf(fpo,b1,apop[k]+1);

	 fprintf(fpo,"\n");



	 for(j=0; j< n2 ; j++){

		fprintf(fpo,"%5d",apop[j]+1);

		for(k=n1+1; k<=n2 ; k++){

		 if( j >= k ) {

			  for(l=0; l< ia+1 ; l++) fprintf(fpo," ");

		 }else{

		  fprintf(fpo,b,dist[j][k]);

		 }

		}

		fprintf(fpo,"\n");

	 }



  }



  return(0);

 }


njtndp(nseq,node,nodes,ncn)
int nseq,**node/*[MAXOTU-1][3]*/;
Nodc **nodes/*[MAXOTU-2]*/;
char *ncn/*[MAXOTU-2]*/;
{
int i,j,k,nc,flg;
extern int dflg;


for(i=0; i<nseq-2 ; i++){
   nc=2;
   ncn[i]=0;
   if( i == nseq-3 ) nc=3;
   for(j=0; j<nc ; j++) {
      if( node[i][j] <= nseq ){
          nodes[i]->childn[j]=node[i][j];
          nodes[i]->childio[j]= 0;
          continue;
	}
        nodes[i]->childn[j]=node[i][j]-nseq;
        nodes[i]->childio[j]= 1;
    }
}
for(i=0; i<nseq-3; i++){
  flg =0;
  for(j=0; j<nseq-2; j++){
    if( i == j ) continue;
    nc=2;
    if( j == nseq-3 ) nc=3;
    for(k=0; k<nc ; k++){
      if( node[j][k] == i+nseq+1 ) {
        flg =1;
        nodes[i]->childn[2]=j+1;
        nodes[i]->childio[2]= 1;
        break;
      }
    }
    if( flg == 1) break;
  }
}

if( dflg == 2){
   for(i=0; i<nseq-2 ; i++){
     printf("nodes %d:",i);
     for(j=0;j<3 ; j++) printf("%d %d  ",nodes[i]->childio[j],nodes[i]->childn[j]);
     printf("\n");
   }
 }

if( dflg == 2){
   for(i=0; i<nseq-2 ; i++){
     printf("nodes %d:",i);
     for(j=0;j<3 ; j++) printf("%d %d  ",nodes[i]->childio[j],nodes[i]->childn[j]);
     printf("\n");
   }
 }
return(0);
}


parti(nseq,nodes,part,bri,rlo,rli,chf)
int nseq,**bri/*[MAXOTU-3][2]*/;
Nodc **nodes/*[MAXOTU-2]*/;
char **part/*[MAXOTU-3][MAXOTU]*/,*rlo,*rli,*chf;
{
int i,j,k,nb,flg,iw;
int nbri,nr,nl,or,ol,ns;
/* char rlo[MAXOTU],rli[MAXOTU-2],chf[MAXOTU-2];*/

/* printf("parti start nseq=%d\n",nseq);  */
nbri=0;
for(i=0; i<nseq-2; i++){
  for(j=0; j<3 ; j++) {
    if(  nodes[i]->childio[j] ==  1 && nodes[i]->childn[j] < i+1 ){
         bri[nbri][0]= nodes[i]->childn[j];
         bri[nbri][1]= i+1;
/*         printf("%d   %d %d\n",nbri,bri[nbri][0],bri[nbri][1]);  */
         nbri++;
       }
  }
}
/*  for(i=0; i<nseq-2; i++) printf("node %d  %d (%d) %d (%d) %d (%d)\n",i,nodes[i].childn[0],nodes[i].childio[0],nodes[i].childn[1],nodes[i].childio[1],nodes[i].childn[2],nodes[i].childio[2]);
    }
*/
if( nbri != nseq-3 ){
    printf("number of internal branches invalid %d\n",nbri);
    exit(1);
  }

for(nb=0; nb < nbri ; nb++){
   for(i=0; i<nseq-2 ; i++){
        chf[i]=0;
        rli[i]=' ';
      }
   for(i=0; i<nseq ; i++) {
     rlo[i]=' ';
     part[nb][i]=0;
   }
   or=bri[nb][0];
   ol=bri[nb][1];
   nr=0;
   nl=0;
   for(i=0; i<3 ; i++){
      if( nodes[or-1]->childio[i] == 1 && nodes[or-1]->childn[i] == ol ) continue;
      switch(nodes[or-1]->childio[i] ){
          case 1:  iw = nodes[or-1]->childn[i]-1; rli[iw]='r';
                   break;
          case 0 : iw = nodes[or-1]->childn[i]-1;
                   rlo[iw]='r';
                   nr++;
                   break;
	}
    }
   for(i=0; i<3 ; i++){
      if( nodes[ol-1]->childio[i] == 1 && nodes[ol-1]->childn[i] == or ) continue;
      switch(nodes[ol-1]->childio[i]){
          case 1 :  iw = nodes[ol-1]->childn[i]-1;
                    rli[iw]='l';
                    break;
          case 0 :  iw = nodes[ol-1]->childn[i]-1;rlo[iw]='l';
                    nl++;
                    break;
	}
    }
    chf[or-1]=1;
    chf[ol-1]=1;
    ns=2;
  for( ; ; ){
    for(i=0; i< nseq-2 ; i++){
/*
      printf("i=%d nseq=%d nb=%d ns=%d\n",i,nseq,nb,ns); 
      printf("chf ");
      for(j=0; j< nseq-2 ; j++) printf(" %d",chf[j]);
      printf("\n");
      printf("rli ");
      for(j=0; j< nseq-2 ; j++) printf(" %c",rli[j]);
      printf("\n");
      printf("rlo ");
      for(j=0; j< nseq ; j++) printf(" %c",rlo[j]);
      printf("\n");
*/
      if( ns >= nseq-2 && nseq == 4 ) goto S1;
      if( chf[i] == 1 ) continue;
      if( rli[i] == ' '  ) continue; 
      switch( rli[i] ){
         case  'r':
                   for(j=0; j<3 ; j++){
                     iw = nodes[i]->childn[j]-1;
                     if( nodes[i]->childio[j] == 1 && rli[iw] == 'r' )
 continue;
                     switch(nodes[i]->childio[j]) {
                       case 1 : iw = nodes[i]->childn[j]-1; rli[iw]='r';
                                break;
                       case 0 : iw = nodes[i]->childn[j]-1;
                                rlo[iw]='r';
                                nr++;
                                break;
		     }
		   }
                    ns++;
/*                    printf("ns=%d nseq=%d (1)\n",ns,nseq);*/
                    if( ns >= nseq-2 ) goto S1;
                    break;
        case  'l' :
           for(j=0; j<3 ; j++){
             iw = nodes[i]->childn[j]-1;
             if( nodes[i]->childio[j] == 1 && rli[iw] == 'l' )
continue;
             switch( nodes[i]->childio[j]) {
                 case 1 : iw = nodes[i]->childn[j]-1; rli[iw]='l';
                          break;
                 case 0 : iw = nodes[i]->childn[j]-1;
                          rlo[iw]='l';
                          nl++;
		  }
	   }
           ns++;
/*           printf("ns=%d nseq=%d (2)\n",ns,nseq); */
           if( ns >= nseq-2 ) goto S1;
           break;
		 }
        chf[i]=1;
    }
  }
S1:    if( nl+nr != nseq ) {
      printf("nl=%d nr=%d nseq=%d\n",nl,nr,nseq);
      exit(1);
    }
/*     printf("nl=%d nr=%d nseq=%d\n",nl,nr,nseq); */
   
    if( nl < nr ){
        for(i=0; i<nseq ; i++){
          if( rlo[i] == 'l' ) part[nb][i]=1;
        }
      }
    if( nl >= nr ){
        for(i=0; i<nseq ; i++){
          if( rlo[i] == 'r' ) part[nb][i]=1;
        }
      }
/*
    printf("rlo:");
    for(i=0; i<nseq ; i++){
      printf(" %c",rlo[i]);
    }
    printf("\n");
    printf("part:");
    for(i=0; i<nseq ; i++){
      printf(" %d",part[nb][i]);
    }
    printf("\n");
*/

  
 }

  
if( dflg == 1 ) {
   for(i=0; i<nseq-3 ; i++){
     for(j=0; j<nseq ; j++){
        printf(" %d",part[i][j]);
      }
     printf("\n");
   }
 }
/*  printf("parti return\n");  */
return(0);
}



reloci(nloci,rloci,seed)
int nloci,*rloci;
long *seed;
{
int i,rn;


for(i=0; i<nloci ; i++){
/*   rn=random()%nloci; */
	rn= ran1(seed)*(float)(nloci);
	rloci[i]=rn;
/*   printf("rn=%d seed=%d\n",rn,*seed); */
 }
return(0);
}

caldist(napop,apop,nloci,rloci,nallele,allelefrq,samplesz,dist,dop,pflg,fstep,mstep,vflg,avar)
int nloci,*rloci,*nallele,dop,*apop,napop,pflg;
float ***allelefrq,**samplesz,**fstep;
double **dist,*mstep,*avar;
{
int i,j,k,l,nc,n1,n2,k1,k2;
double sxy,jx,jy,jxy,jxy1,jx1,jy1,sx,sy,jxa,jya,dw,dsz1,dsz2,dv;
/* static double dunit[30]={2.,2.,4.,2.,2.,2.,2.,2.,2.,2.,2.,2.,2.,2.,2.,
								 2.,2.,2.,2.,2.,2.,2.,2.,2.,2.,2.,2.,2.,2.,2.};
*/
extern int dflg;

if( vflg == 1 ){

 for(i=0; i<napop ; i++) {
			avar[i] = 0.0;
		 }

 for(i=0; i< nloci ; i++){
	 printf("@locus %d",i+1); fflush(stdout);
	 nc = rloci[i];
	 for(j=0; j<napop ; j++){
		jx = 0.0;
		jxa = 0.0;
		n1 = apop[j];
		sx = samplesz[nc][n1];
		dv = 0.;
		for(k=0; k< nallele[nc] ; k++){
		  for(l=k+1; l< nallele[nc] ; l++){
				dw = (fstep[nc][k]- fstep[nc][l])*(fstep[nc][k]- fstep[nc][l]);
				dw *= (double)allelefrq[nc][k][j]*(double)allelefrq[nc][l][j];
				dv += dw;
				avar[j] += dw;
	  }
		}
				printf("  %0.3f",dv);  fflush(stdout);
	 }
	 printf("\n");  fflush(stdout);
  }
 printf("ave. ");
for(i=0; i<napop ; i++){
 avar[i] /= nloci;
 printf(" %0.3f", avar[i]);  fflush(stdout);
}
printf("\n");  fflush(stdout);
}







if( dop == 2 ){
/*   printf("dop=%d\n",dop); fflush(stdout); */


	for(i=0; i< napop-1 ; i++){
	 for(j=i+1; j< napop ; j++) dist[i][j]=dist[j][i]=0.;
  }

	for( k=0; k< nloci ; k++){
	  nc = rloci[k];
	  if( pflg == 1 ) printf("locus %2d\n",nc+1);
	  for(i=0; i<napop ; i++){
		 mstep[i]=0.0;
		 n1 = apop[i];
		 if( samplesz[nc][n1] <= 0. + ACU ) continue;
		 for(j=0; j< nallele[nc] ; j++){
			if( dop == 2 )  mstep[i] += (double)((fstep[nc][j]))*(double)allelefrq[nc][j][n1];
/*          printf("nstep=%d afrq=%f\n",nstep[nc][j],allelefrq[nc][j][n1]); */
		 }
		 /*( if( pflg == 1 )  printf(" %3.1f",mstep[i]*dunit[nc]);fflush(stdout);*/
	  }
	  if( pflg == 1 ) printf("\n");
	  for(i=0; i<napop-1 ; i++){
			 n1 = apop[i];
			 for(j=i+1; j< napop ; j++){
			  n2 = apop[j];
			  if( samplesz[nc][n1] <= 0. + ACU || samplesz[nc][n2] <= 0. + ACU ) continue;
			  dw = (mstep[i]-mstep[j])*(mstep[i]-mstep[j]);
			  dist[i][j] += dw;
			  dist[j][i] += 1.;
	 }
	}
	}

	for(i=0; i< napop-1 ; i++){
	 for(j=i+1 ; j< napop ; j++){
				 dist[i][j] /= dist[j][i];
		  if( pflg == 1)  {
				printf(" dist=%4.2f",dist[i][j]); fflush(stdout);
	  }
	  }
	  if( pflg == 1 ) printf("\n");
  }
 }


if( dop == 3 ){
 /*printf("dop=%d\n",dop); fflush(stdout); */

	  for(i=0; i<napop-1 ; i++){
			 n1 = apop[i];
			 for(j=i+1; j< napop ; j++){
			  n2 = apop[j];
			  dist[i][j] = dist[j][i] = 0.;
			  jxy=0.; jx=jy=0.;
			  for(k = 0; k< nloci ; k++){
				  nc = rloci[k];
				  if( samplesz[nc][n1] <= 0. + ACU || samplesz[nc][n2] <= 0. + ACU ) continue;
					dist[j][i] += 1.;
					dsz1 = samplesz[nc][n1];
					dsz2 = samplesz[nc][n2];
					jx1=jy1=0.;
					for(k1=0; k1< nallele[nc] ; k1++){
					 for(k2=0 ; k2 <nallele[nc]; k2++){
						  if( k1 == k2 ) continue;
						  dw = fstep[nc][k1] - fstep[nc][k2];
						  if( dw < 0. ) dw *= -1.;
						  if( dw <= ACU ) continue;

					  /*   dw /= dunit[nc]; */
						  jx1 += dw * allelefrq[nc][k1][n1] * allelefrq[nc][k2][n1];
						  jy1 += dw * allelefrq[nc][k1][n2] * allelefrq[nc][k2][n2];

						  jxy += dw * allelefrq[nc][k1][n1] * allelefrq[nc][k2][n2];

		  }
		}
		 jx += jx1*dsz1/(dsz1-1.);
		 jy += jy1*dsz2/(dsz2-1.);

		 }

				dist[i][j] = jxy - (jx+jy)/2.;
				dist[i][j] /= dist[j][i];

		/*    printf("%d %d dist=%f jx=%f jy=%f jxy=%f\n",i,j,dist[i][j],jx,jy,jxy); fflush(stdout);  */

	}
 }

}

if( dop <= 1 ){
 for(i=0; i< napop-1 ; i++){
	for(j=i+1; j<napop; j++){
		sxy=jx=jy=jxy=0.0;
		n1 = apop[i];
		n2 = apop[j];
		for(k=0; k<nloci ; k++){
		  nc= rloci[k];
		  jxa=jya=0.0;
		  for(l=0; l< nallele[nc] ; l++){
			 jxy1 = allelefrq[nc][l][n1]*allelefrq[nc][l][n2];
			 switch(dop){
				  case 0 :   /* da */
/*                        printf("%d %d nc=%d jxy1=%f %f %f\n",i,j,nc,jxy1,allelefrq[nc][l][n1],allelefrq[nc][l][n2]);*/
								  sxy += sqrt(jxy1);
								 break;
				  case 1:   /* ds */
								 jx1 = allelefrq[nc][l][n1]*allelefrq[nc][l][n1];
								 jy1 = allelefrq[nc][l][n2]*allelefrq[nc][l][n2];
								 sx = samplesz[nc][n1];
								 sy = samplesz[nc][n2];
								 jxy += jxy1;
								 jxa  += jx1;
								 jya  += jy1;
								 break;
			}
	}
								 jx  += (jxa*sx-1.0)/(sx-1.0);
								 jy  += (jya*sy-1.0)/(sy-1.0);

		}
		switch(dop){
			 case 0: /* da */
						sxy /= nloci;
						dist[i][j] = 1.0 - sxy;
/*                  printf("%d %d %f\n",i,j,dist[i][j]); */
						if( pflg ==1 )  printf(" %1.3f",dist[i][j]);
						break;
			 case 1:  jx /= nloci;
						 jy /= nloci;
						 jxy /= nloci;
						 if( jx*jy <= 0.0 + ACU ) return(-1);
						 if( jxy <= 0.0 + ACU ){
							  printf("no shared allele between %d %d infinite distance\n",i+1,j+1);
							  return(-1);
			  }
						 dist[i][j] = -log(jxy/sqrt(jx*jy));
						 if( pflg ==1 ) printf(" %1.3f",dist[i][j]);
/*                   printf("%d %d jx=%f jy=%f jxy=%f dis=%f\n",i,j,jx,jy,jxy,dist[i][j]); */
						 break;
		}
	 }
  if( pflg ==1 )  printf("\n");
 }
}




return(0);

}

int cpart(nseq,part,partb,npart,bw,pw1,pw2)
int nseq;
long *npart;
int *bw;
char *pw1,*pw2;
char **part/*[MAXOTU-3][MAXOTU]*/,**partb/*[MAXOTU-3][MAXOTU]*/;
{
int i,j,k,np,ncf1,ncf2,nb;

np=nseq-3;
/*
printf("part\n");
for(i=0; i<np ; i++){
  for(j=0; j<nseq ; j++) printf(" %d",part[i][j]);
  printf("\n");
}
printf("partb\n");
for(i=0; i<np ; i++){
  for(j=0; j<nseq ; j++) printf(" %d",partb[i][j]);
  printf("\n");
}
*/
for(i=0; i<np ; i++) bw[i]=i;
nb = np;
for(i=0; i<np ; i++){
  for(j=0; j<nseq ; j++){
     pw1[j]=part[i][j];
     switch(part[i][j]){
       case 0 : pw2[j]=1;
                break;
       case 1 : pw2[j]=0;
                break;
       }
   }
       for(j=0; j<nb ; j++){
           ncf1=0;
           ncf2=0;
          for(k=0; k<nseq ; k++){
             if( pw1[k] != partb[bw[j]][k] ) {
                ncf1=1;
                break;
	      }
           }
          if( ncf1 == 0 ) {
             npart[i]++;
             for(k=j; k<nb-1 ; k++) bw[k]=bw[k+1];
             nb--;
             break;
	   }
          for(k=0; k<nseq ; k++){
             if( pw2[k] != partb[bw[j]][k] ) {
                ncf2=1;
                break;
	      }
           }
        
          if( ncf2 == 0 ) {
             npart[i]++;
             for(k=j; k<nb-1 ; k++) bw[k]=bw[k+1];
             nb--;
             break;
	   }
	 }
}
/*
printf("pb:");
for(i=0; i<np ; i++) printf(" %d",pb[i]);
printf("\n");
printf("npart:");
for(i=0; i<np ; i++) printf(" %d",npart[i]);
printf("\n");
*/
return(0);
}
   


#include <sys/types.h>
#include <unistd.h>


/* RAND_MAX is a machine dependent constant, equal to the maximum value
 * random() can return (probably (2^31)-1 = 017777777777 octal).
 */
/* Get an integer to use as a seed for the random number generator */
int getseed()
{
  /****************************************************************
   getpid() returns an integer identifying the current process.  I
   am using this as a random number seed.
   ****************************************************************/
  pid_t getpid();
  int seed;

  seed = getpid();
/*  fprintf(stdout,"getseed(): seed=%d\n", seed); */
  return(seed);
}


upg(nseq,dist,node0,branch0,otu,sij,nclus,dcm)
int nseq,**node0/*[MAXOTU-1][3]*/,*otu/*[MAXOTU]*/,*nclus/*[MAXOTU]*/;
int **sij/*[MAXOTU*(MAXOTU-1)/2][2]*/;
double **dist/*[MAXOTU][MAXOTU]*/,**branch0/*[MAXOTU][3]*/;
double *dcm/*[MAXOTU]*/;
{
int i,j,k,l,nsc,cyc,n1,n2;

double sm,dw1,dw2,dw3;
extern int dflg;


/*  printf("upg\n");
  for(i=0; i<nseq ; i++){
   for(j=0; j<nseq ; j++){
     if(i >= j) printf("         "); 
     if( i < j ) printf(" %f",dist[i][j]);
   }
   printf("\n");

 }
*/


  nsc=nseq;
  for(i=0; i< nseq-1 ; i++){
    for(j=0; j<3 ; j++) node0[i][j]=0;
  }
  for(i=0; i<nseq; i++) {
      otu[i]=i+1;
      nclus[i]=1;
    }
/*  printf("upg\n"); fflush(stdout); */
  for(cyc=0; cyc<nseq-1; cyc++){
     sm = 999999.0;
/*     printf("cyc=%d\n",cyc); fflush(stdout); */
     for(i=0; i<nsc-1; i++){
        for(j=i+1; j<nsc; j++){
          if( sm > dist[i][j] ){
             sm = dist[i][j];
             sij[0][0]=i;
             sij[0][1]=j;
	   }
	}
      }
/*     printf("sij\n"); fflush(stdout); */
/*
     scnt=1;
     for(i=0; i<nsc-1; i++){
        for(j=i+1; j<nsc; j++){
          if( i == sij[0][0] && j == sij[0][1] ) continue;
          if( sm+ACU >= dist[i][j]  &&  dist[i][j] >= sm-ACU ){
             sij[scnt][0]=i;
             sij[scnt][1]=j;
             scnt++;
	   }
	}
      }
*/
/*     printf("sij\n"); fflush(stdout); */
     n1=sij[0][0];
     n2=sij[0][1];

       node0[cyc][0]=otu[n1];
       node0[cyc][1]=otu[n2];
       dcm[cyc]=dist[n1][n2];
       if( otu[n1] <= nseq ){
             branch0[cyc][0]=dist[n1][n2]/2.0;
	   }else{
             branch0[cyc][0]=dist[n1][n2]/2.0 - dcm[otu[n1]-nseq-1]/2.0;
       }
       if( otu[n2] <= nseq ){
             branch0[cyc][1]=dist[n1][n2]/2.0;
	   }else{
             branch0[cyc][1]=dist[n1][n2]/2.0 - dcm[otu[n2]-nseq-1]/2.0;
       }
/*      printf("%d %f %f",cyc,branch0[cyc][0],branch0[cyc][1]); fflush(stdout);*/
		if( dflg == 1 ) printf("tie=%d n1=%d n2=%d\n",n1,n2);
      for(k=0; k<nsc; k++) {
          dw1 = nclus[n1]*nclus[k];
          dw2 = nclus[n2]*nclus[k];
          dw3 = nclus[n1]*nclus[k]+nclus[n2]*nclus[k];
          if( k == n1 || k == n2 ) continue;
          if( n1 < k && n2 < k ) dist[n1][k] = (dist[n1][k]*dw1 + dist[n2][k]*dw2)/dw3;
          if( n1 < k && n2 > k ) dist[n1][k] = (dist[n1][k]*dw1 + dist[k][n2]*dw2)/dw3;
          if( n1 > k && n2 < k ) dist[k][n1] = (dist[k][n1]*dw1 + dist[n2][k]*dw2)/dw3;
          if( n1 > k && n2 > k ) dist[k][n1] = (dist[k][n1]*dw1 + dist[k][n2]*dw2)/dw3;
	}
      otu[n1]=nseq+cyc+1;
      nclus[n1] += nclus[n2];
      for(k=n2; k<nsc-1; k++) {
          otu[k]=otu[k+1];
          nclus[k]=nclus[k+1];
	}
      if( dflg == 1 ) {
         printf("otu:");
         for(k=0; k<nsc ; k++ ) printf(" %d",otu[k]);
         printf("\n");
       }

      for(k=0; k< n2 ; k++){
         for(l=n2+1 ; l< nsc ; l++)  dist[k][l-1] = dist[k][l];
       }
       for(k=n2+1 ; k<nsc-1 ; k++){
         for(l=k+1 ; l<nsc ; l++) dist[k-1][l-1] =dist[k][l];
       }

   
       nsc--;
   }

 cyc=nseq-2;
 if( node0[cyc][0] == 2*nseq-2 ){
      node0[cyc-1][2]=node0[cyc][1];
      branch0[cyc-1][2]=branch0[cyc][0]+branch0[cyc][1];
    }

 if( node0[cyc][1] == 2*nseq-2 ){
      node0[cyc-1][2]=node0[cyc][0];
      branch0[cyc-1][2]=branch0[cyc][0]+branch0[cyc][1];
    }
/*
for(i=0; i<2*nseq-1 ; i++){
  printf("%f %f\n",branch0[i][0],branch0[i][1]);
}
*/
 return(0);
}

upgr(nseq,dist,node0,branch0,otu,sij,nclus,dcm,seed1)
int nseq,**node0/*[MAXOTU-1][3]*/,*otu/*[MAXOTU]*/,*nclus/*[MAXOTU]*/;
long *seed1;
int **sij/*[MAXOTU*(MAXOTU-1)/2][2]*/;
double **dist/*[MAXOTU][MAXOTU]*/,**branch0/*[MAXOTU][3]*/;
double *dcm/*[MAXOTU]*/;
{
int i,j,k,l,nsc,cyc,scnt,n1,n2;
int rn;
double sm,dw1,dw2,dw3;
extern int dflg;



  nsc=nseq;
  for(i=0; i< nseq-1 ; i++){
    for(j=0; j<3 ; j++) node0[i][j]=0;
  }
  for(i=0; i<nseq; i++) {
      otu[i]=i+1;
      nclus[i]=1;
    }
/*  printf("upg\n"); fflush(stdout); */
  for(cyc=0; cyc<nseq-1; cyc++){
     sm = 999999.0;
/*     printf("cyc=%d\n",cyc); fflush(stdout); */
     for(i=0; i<nsc-1; i++){
        for(j=i+1; j<nsc; j++){
          if( sm > dist[i][j] ){
             sm = dist[i][j];
             sij[0][0]=i;
             sij[0][1]=j;
	   }
	}
      }
/*     printf("sij\n"); fflush(stdout); */
     scnt=1;
     for(i=0; i<nsc-1; i++){
        for(j=i+1; j<nsc; j++){
          if( i == sij[0][0] && j == sij[0][1] ) continue;
          if( sm+ACU >= dist[i][j]  &&  dist[i][j] >= sm-ACU ){
             sij[scnt][0]=i;
             sij[scnt][1]=j;
             scnt++;
	   }
	}
      }

/*     printf("sij\n"); fflush(stdout); */
     n1=sij[0][0];
     n2=sij[0][1];
	  if( scnt > 1 ){
		  rn = ran1(seed1)*(float)scnt;
        n1 = sij[rn][0];
        n2 = sij[rn][1];
      }
       node0[cyc][0]=otu[n1];
       node0[cyc][1]=otu[n2];
       dcm[cyc]=dist[n1][n2];
       if( otu[n1] <= nseq ){
             branch0[cyc][0]=dist[n1][n2]/2.0;
	   }else{
             branch0[cyc][0]=dist[n1][n2]/2.0 - dcm[otu[n1]-nseq-1]/2.0;
       }
       if( otu[n2] <= nseq ){
             branch0[cyc][1]=dist[n1][n2]/2.0;
	   }else{
             branch0[cyc][1]=dist[n1][n2]/2.0 - dcm[otu[n2]-nseq-1]/2.0;
       }
/*      printf("%d %f %f",cyc,branch0[cyc][0],branch0[cyc][1]); fflush(stdout);*/
		if( dflg == 1 ) printf("tie=%d n1=%d n2=%d\n",n1,n2);
      for(k=0; k<nsc; k++) {
          dw1 = nclus[n1]*nclus[k];
          dw2 = nclus[n2]*nclus[k];
          dw3 = nclus[n1]*nclus[k]+nclus[n2]*nclus[k];
          if( k == n1 || k == n2 ) continue;
          if( n1 < k && n2 < k ) dist[n1][k] = (dist[n1][k]*dw1 + dist[n2][k]*dw2)/dw3;
          if( n1 < k && n2 > k ) dist[n1][k] = (dist[n1][k]*dw1 + dist[k][n2]*dw2)/dw3;
          if( n1 > k && n2 < k ) dist[k][n1] = (dist[k][n1]*dw1 + dist[n2][k]*dw2)/dw3;
          if( n1 > k && n2 > k ) dist[k][n1] = (dist[k][n1]*dw1 + dist[k][n2]*dw2)/dw3;
	}
      otu[n1]=nseq+cyc+1;
      nclus[n1] += nclus[n2];
      for(k=n2; k<nsc-1; k++) {
          otu[k]=otu[k+1];
          nclus[k]=nclus[k+1];
	}
      if( dflg == 1 ) {
         printf("otu:");
         for(k=0; k<nsc ; k++ ) printf(" %d",otu[k]);
         printf("\n");
       }

      for(k=0; k< n2 ; k++){
         for(l=n2+1 ; l< nsc ; l++)  dist[k][l-1] = dist[k][l];
       }
       for(k=n2+1 ; k<nsc-1 ; k++){
         for(l=k+1 ; l<nsc ; l++) dist[k-1][l-1] =dist[k][l];
       }

   
       nsc--;
   }

 cyc=nseq-2;
 if( node0[cyc][0] == 2*nseq-2 ){
      node0[cyc-1][2]=node0[cyc][1];
      branch0[cyc-1][2]=branch0[cyc][0]+branch0[cyc][1];
    }

 if( node0[cyc][1] == 2*nseq-2 ){
      node0[cyc-1][2]=node0[cyc][0];
      branch0[cyc-1][2]=branch0[cyc][0]+branch0[cyc][1];
    }
/*
for(i=0; i<2*nseq-1 ; i++){
  printf("%f %f\n",branch0[i][0],branch0[i][1]);
}
*/
 return(0);
}


#define M1 259200L
#define IA1 7141L
#define IC1 54773L
#define RM1 (1.0/M1)
#define M2 134456L
#define IA2 8121L
#define IC2 28411L
#define RM2 (1.0/M2)
#define M3 243000L
#define IA3 4561L
#define IC3 51349L
/* generate uniform random number >= 0 && < 1 */
/* if you want generate random number from 0 to n-1
 *  multiply by n
 *  set *idum by any negative value. The sequence is reset.
 */
float ran1(idum)
long *idum;
{
static long ix1,ix2,ix3;
static float r[98];
float temp;
static int iff=0;
long j;

if( *idum < 0 || iff == 0 ){
   iff = 1;
	ix1 = (IC1 - (*idum)) % M1;
   ix1 = (IA1*ix1+IC1) % M1;
   ix2 = ix1 % M2;
   ix1 = (IA1*ix1+IC1) % M1;
   ix3 = ix1 % M3;
   for(j=1 ; j<97 ; j++){
     ix1 =(IA1*ix1+IC1) % M1;
     ix2 =(IA2*ix2+IC2) % M2;
	  r[j] =(ix1+ix2*RM2)*RM1;
   }
   *idum = 1;
 }

 ix1 = (IA1*ix1+IC1) % M1;
 ix2 = (IA2*ix2+IC2) % M2;
 ix3 = (IA3*ix3+IC3) % M3;
 j = 1 + ((97*ix3)/M3);
 if( j > 97 || j < 1 ) {
	printf("ran1(): j = %d \n");
   exit(1);
 }
 temp = r[j];
 r[j]=(ix1 + ix2*RM2)*RM1;
 return(temp);
}

           










           










  


























           


void main(argc,argv)
int argc;
char **argv;
{
FILE *fpo=stdout,*fpi,*fpe=stderr;
int i,j,k,fin,ifc,rn,flg,iw,distflg;
int npop,**node/*[MAXOTU-2][3]*/,**nodeb/*[MAXOTU-2][3]*/,nloci,*nallele,*rloci,*apop,napop,*epop,nepop;
float fw,**samplesz,***allelefrq,fs,**fstep;
long seed1,seed, *npart;
double **dist/*[MAXOTU][MAXOTU]*/,**branch0/*[MAXOTU][3]*/,**branchb/*[MAXOTU][3]*/,*mstep;
char **part/*[MAXOTU-3][MAXOTU]*/,**partb/*[MAXOTU-3][MAXOTU]*/;
Nodc **nodes/*[MAXOTU-2]*/;
int **bri/*[MAXOTU-3][2]*/,**brib/*[MAXOTU-3][2]*/,dop,maxnm;
long nbn,nboot;
int pflg,hflg,vflg;
long nw[3],nb,n1,n2,ninap=0,nc;
static char *distop[NDIST]={"Da","Dst","Dmyu","Dsw"};
/* njt */
int *otu,**spair,*sw,*bw,*nclus;
double *st,*dcm,*rij,*heteroz,*avar;
char *ncn,*rlo,*rli,*chf,*pw1,*pw2;
char **popname;
int iec,upflg;
float ran1();



dflg=0;
pflg=0;
distflg = 0.;
	seed = 0;
   seed=getseed();
	dop=0;
	hflg=0;
	vflg=0;
	nboot=0;
	nepop=0;
	iec= -1;
	upflg =0;
	ifc=0;
	if( argc == 1 ){
	  printf("njbafd inputfile -b[bootstrap number] -d[distace option] -o [output file] -s[seed]\n");
	  printf("distance option\n");
	  for(i=0; i< NDIST ; i++){
		 printf("%d    %s\n",i,distop[i]);
	  }
	  printf("-upg       UPGMA tree\n");
	  printf("-h         Gst and heterozygosity\n");
	  printf("-distance  distance matrix\n");
	  exit(1);
	}

  /*	printf("argc=%d\n",argc); fflush(stdout);  */
	for(i=1; i< argc ; i++){
	  /* printf("i=%d\n",i); fflush(stdout);  */
	  if( argv[i][0] == '-' ){
		if( strcmp(argv[i]+1,"upg") == 0 ) {
			upflg = 1;
			continue;
		 }
		 if( strcmp(argv[i]+1,"distance") == 0 ) {
			 distflg = 1;
			continue;
		 }
		switch( argv[i][1]){
		 case 'o' : if( argv[i][2] != 0 ){
						  if( (fpo=fopen(argv[i]+2,"w")) == NULL ){
							fprintf(fpe,"Can't open output-file:%s\n",argv[i]+2);
							exit(1);
							}
							break;
							}
						  if((fpo=fopen(argv[i+1],"w")) == NULL ) {
						  fprintf(fpe,"Can't open output-file:%s\n",argv[i+1]);
						  exit(1);
						}
						i++;
						break;
		 case 'd' :  sscanf(argv[i]+2,"%d",&dop);
						 if( dop > NDIST || dop < 0 ){
							 fprintf(fpe,"invalid option %d\n",dop);
							 exit(1);
						 }
						break;

		 case 'b' : sscanf(argv[i]+2,"%D",&nboot);
						break;
		 case 'm' : pflg=1;
						break;
		 case 'h' : hflg=1;
						break;
		 case 'v' : vflg=1;
						break;
		 case 's' :  sscanf(argv[i]+2,"%D",&seed);
						 break;
		 case 'e' :  iec=i;
						 for(j=i+1 ; j<argc ; j++){
							if( argv[j][0] < '0' || argv[j][0] > '9' ) break;
							 i++;
						 }
						 break;
		 case 'u' :  if(argv[i][2] == 0 ){
							dflg=1;
							break;
						 }
						 sscanf(argv[i]+2,"%d",&dflg);
						 break;
		 default :  fprintf(fpe,"invalid argument",argv[i]);
						exit(1);
		}
	  }else{
		if((fpi=fopen(argv[i],"r")) == NULL ){
					 fprintf(fpe,"Can't open input-file:%s\n",argv[i]);
					 exit(1);
		}
		fin=i;
		ifc++;
		/* printf("fin=%d\n"); fflush(stdout); */

	  }
	}

/*  printf("end of arguments\n");  */

  if( ifc == 0 ){
		fprintf(fpe,"no input-file\n");
		exit(1);
	}

checkloci(fpi,&nloci,&npop);
fclose(fpi);
 /* printf("nloci=%d npop=%d\n",nloci,npop); fflush(stdout); */

if( (fpi= fopen(argv[fin],"r")) == NULL ){
  fprintf(fpo,"Can't open file %s\n",argv[fin]);
  exit(1);
}

nallele = ivector(nloci);
mstep = dvector(npop);
/* printf("nallele %p\n",nallele); */
checkflal(fpi,nloci,nallele,&maxnm,npop);

fclose(fpi);

if( (fpi= fopen(argv[fin],"r")) == NULL ){
  fprintf(fpo,"Can't open file %s\n",argv[fin]);
  exit(1);
}
popname = cmatrix(npop,maxnm+1);
samplesz = fmatrix(nloci,npop);
for(i=0; i<nloci ; i++){
 for(j=0; j<npop ; j++) {
	 samplesz[i][j]=0.0;
  }
}
if( dflg == 1 ){
	printf("sample size\n"); fflush(stdout);
 }

allelefrq = f3matrix(nloci,nallele,npop);
fstep = f2matrix(nloci,nallele);
if( dflg == 1 ){
  printf("allelfrq\n"); fflush(stdout);
 }


for(i=0; i< nloci ; i++){
  for(j=0; j<nallele[i] ; j++){
	 for(k=0; k<npop ; k++){

		 allelefrq[i][j][k]=0.0;
	  }
  }
}
for(i=0; i<npop ; i++){
 for(j=0; j<maxnm+1 ; j++) popname[i][j]=0;
}
if( dflg == 1 ){
	printf("getal begin\n"); fflush(stdout);
 }

getal(fpi,dop,nloci,nallele,popname,allelefrq,samplesz,npop,fstep);
fclose(fpi);
/*
  printf("%d populations\n",noutp);
  for(i=0; i< noutp ; i++){
	 printf("%d %s\n",i+1,popname[outp[i]-1]);
  }
  for(i=0; i<nloci ; i++){
	  printf("@locus %d\n",i+1);
	  for(j=0; j<nallele[i] ; j++){
		  printf("          * ");
		  for(k=0; k<noutp ; k++){
			  printf(" %1.3f",allelefrq[i][j][outp[k]-1]);
	 }
		  printf("\n");
		}
	  printf(" #          ");
	  for(j=0; j<noutp ; j++) printf(" %3.1f",samplesz[i][j]);
	  printf("\n");
	}

  */


 apop = ivector(npop);
 epop = ivector(npop);
 if( vflg == 1 ) avar = dvector(npop);

 nepop=0;
 if( iec > 0 ){
	if( argv[iec][2] >= '0' && argv[iec][2] <= '9' ){
		sscanf(argv[iec]+2,"%d",&iw);
		if( iw > npop ){
			printf("invalid excluding otu %d\n",iw);
			exit(1);
		 }
		 epop[0] = iw;
		 nepop=1;
	 }
	 for(i=iec+1 ; i< argc ; i++){
		if( argv[i][0] > '9' || argv[i][0] < '0' ) break;
		sscanf(argv[i],"%d",&iw);
		if( iw > npop || iw < 0 ){
			printf("invalid excluding otu %d\n",iw);
			exit(1);
		 }
		 epop[nepop]=iw;
		 nepop++;
	 }
 }

 napop=0;
 for(i=0; i<npop ; i++){
	flg=0;
	for(j=0; j<nepop ; j++){
	  if( i+1 == epop[j] ){
		flg=1;
		break;
	 }
	}
	if( flg == 0 ){
	 apop[napop]=i;
	 napop++;
	}
}

if( dflg == 1 ){
	  printf("getal end\n"); fflush(stdout);
	}
if( dflg == 10 ){
	fs=0.;
	printf("nloci=%d npop=%d\n",nloci,npop);
	for(i=0; i<nloci ; i++){
	fw=0.;
	printf("locus %d\n",i+1);
	for(j=0; j<nallele[i] ; j++){
	  printf(" %3.1f *",fstep[i][j]);
	  for(k=0; k< npop ; k++) printf(" %0.4f",allelefrq[i][j][k]);
	  printf("\n");
	 }
	 for(j=0; j<npop ; j++){
			  printf("   %3.1f",samplesz[i][j]);
			  fs += samplesz[i][j];
			  fw += samplesz[i][j];
	 }
	printf(" ttl =%f\n",fw);

}
	printf("total allele=%f\n",fs);
 }
/* printf("maxnm=%d\n",maxnm);  */

/* printf("maxnm=%d\n",maxnm);  */

if( hflg == 1 ){
	  heteroz = dvector(npop);
	  hetero(fpo,napop,apop,nloci,allelefrq, samplesz,nallele,heteroz,popname);
	  exit(0);

}


 node = imatrix(npop-1,3);
 nodeb = imatrix(npop-1,3);
 npart = lvector(npop-3);
 dist = dmatrix(npop,npop);
 branch0 = dmatrix(npop,3);
 branchb = dmatrix(npop,3);
 part = cmatrix(npop-3,npop);
 partb = cmatrix(npop-3,npop);
 nodes = nvector(npop-2);
 bri = imatrix(npop-3,2);
 brib = imatrix(npop-3,2);
 otu = ivector(npop);
 if( upflg == 1 ) nclus = ivector(npop);
 rloci = ivector(nloci);
 spair = imatrix(npop*(npop-1)/2,2);
 sw = ivector(npop*(npop-1)/2);
 st = dvector(npop*(npop-1)/2);
 dcm = dvector(npop);
 rij = dvector(npop);
 ncn = cvector(npop-2);
 rlo = cvector(npop);
 rli = cvector(npop-2);
 chf = cvector(npop-2);
/* pb = ivector(npop-3);
 npw = ivector(npop-3);
 */
 bw = ivector(npop-3);
 pw1 = cvector(npop);
 pw2 = cvector(npop);


	if( nboot > 0 ) fprintf(fpo,"   %d otus     %d bootstraping\n",napop,nboot);
	if( nboot == 0 ) fprintf(fpo,"   %d otus\n",napop);
	for(i=0; i<napop ; i++){
	  fprintf(fpo,"%d %s\n",i+1,popname[apop[i]]);
	 }
	 fflush(fpo);
/*     srandom(seed); */
	  seed1 = -seed;

/*     printf("seed1=%d\n",seed1); */
	  ran1(&seed1);
/*     printf("seed1=%d\n",seed1); */
	  for(i=0; i<nloci ; i++) rloci[i]=i;
	  for(i=0; i< npop-3 ; i++) npart[i]=0;
/*      printf("check nseq=%d\n",nseq); */
		  rn=caldist(napop,apop,nloci,rloci,nallele,allelefrq,samplesz,dist,dop,pflg,fstep,mstep,vflg,avar);

		  if( dflg  == 1 )    {
			  printf("caldist end\n"); fflush(stdout);
	 }
			  if( rn == -1 ) {
			  printf("distance was inapplicable\n");
			  exit(1);
			}
/*      printf("njt\n"); fflush(stdout); */
		if( upflg == 0 ) njt(napop,dist,node,branch0,otu,spair,st,dcm,rij);
		if( upflg == 1 ) upg(napop,dist,node,branch0,otu,spair,nclus,dcm);
		if( dflg == 1 ){
			  printf("njt end\n"); fflush(stdout);
	 }

		njtndp(napop,node,nodes,ncn);
		if( dflg == 1 ){
			  printf("njtndp end\n"); fflush(stdout);
	 }

		parti(napop,nodes,part,bri,rlo,rli,chf);
		if( dflg == 1 ){
			  printf("parti end\n"); fflush(stdout);
	 }

		for(nbn=0; nbn < nboot ; ){
	/* printf("nbn=%d\n",nbn); fflush(fpo); */
		  reloci(nloci,rloci,&seed1);
		  rn=caldist(napop,apop,nloci,rloci,nallele,allelefrq,samplesz,dist,dop,pflg,fstep,mstep,vflg,avar);
			 if( rn == -1 ) {
			  ninap++;
			  continue;
			}
			if( upflg == 0 ) njr(napop,dist,nodeb,branchb,otu,spair,sw,st,dcm,rij,&seed1);
			if( upflg == 1 ) upgr(napop,dist,nodeb,branchb,otu,spair,nclus,dcm,&seed1);
			njtndp(napop,nodeb,nodes,ncn);
			parti(napop,nodes,partb,brib,rlo,rli,chf);
			cpart(napop,part,partb,npart,bw,pw1,pw2);
			nbn++;
		 }
		for(i=0; i<napop-2 ; i++){
		 nb=2;
		 if( i == napop-3 ) nb=3;
		 for(j=0; j<nb ; j++){
			 if( node[i][j] <= napop ) nw[j]= nboot;
			 if( node[i][j]  > napop ) {
				  n1=i+1;
				  n2=node[i][j]-napop;
				  if( n1 > n2 ){
						nc = n1;
						n1=n2;
						n2=nc;
		}
					for(k=0; k<napop-3 ; k++){
					  if( bri[k][0] == n1 && bri[k][1] == n2 ) {
						  nw[j] = npart[k];
						  break;
		  }
			 }
		 }
				  if( nboot > 0 ) fprintf(fpo,"%3d and %3d        %f    %6d\n",napop+i+1,node[i][j],branch0[i][j],nw[j]);
				  if( nboot == 0 ) fprintf(fpo,"%3d and %3d        %f\n",napop+i+1,node[i][j],branch0[i][j]);
	}
		}

fprintf(fpo,"\n");
fprintf(fpo,"datafile %s   %s was used\n",argv[fin],distop[dop]);
fprintf(fpo,"\n");
fprintf(fpo,"Number of loci compared %d\n",nloci);
fprintf(fpo,"seed=%d ninap=%d\n",seed,ninap);


if( distflg == 1 ){
  for(i=0; i<nloci ; i++) rloci[i]=i;
  rn=caldist(napop,apop,nloci,rloci,nallele,allelefrq,samplesz,dist,dop,pflg,fstep,mstep,vflg,avar);
  prdist(fpo,napop,apop,dist );
  }
/*
free_ivector(apop);
free_ivector(epop);

free_imatrix(node,npop-2);
free_imatrix(nodeb,npop-2);
free_lvector(npart);
free_dmatrix(dist,npop);
free_dmatrix(branch0,npop);
free_dmatrix(branchb,npop);
free_cmatrix(popname,npop);
free_cmatrix(part,npop-3);
free_cmatrix(partb,npop-3);
free_nvector(nodes,npop-2);
free_imatrix(bri,npop-3);
free_imatrix(brib,npop-3);
free_ivector(rloci);
free_fmatrix(samplesz,nloci);
free_f3matrix(allelefrq,nloci,nallele);
free_ivector(nallele);

free_ivector(otu);
free_imatrix(spair,npop*(npop-1)/2);
free_ivector(sw);
free_dvector(st);
free_dvector(dcm);
free_dvector(rij);
free_cvector(ncn);
free_cvector(rlo);
free_cvector(rli);
free_cvector(chf);
free_ivector(pb);
free_ivector(npw);
free_ivector(bw);
free_cvector(pw1);
free_cvector(pw2);
  */


	exit(0);
}


