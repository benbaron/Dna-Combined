#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>



#define NSYM 4
#define NDIST 7
#define ERR stdout
#define ACU  0.000000000001
#define CR  0x0d
#define LF  0x0a
#define MAXALLELE_LOCUS 200
#define MAXALLELE_NAME 20

typedef struct nodc {
   char childio[3];
   int childn[3];
 } Nodc;

extern int dflg;

extern char *distop[NDIST];

int *ivector(int );
int **imatrix(int,int);

double *dvector(int);
double **dmatrix(int,int);
char *cvector(int);
char **cmatrix(int, int );
char ***c3matrix(int, int , int);
char ***c3matrix1(int, int* , int);
float **fmatrix(int, int);
float ***f3matrix(int, int* , int);
float **f2matrix(int,int*);
void free_fmatrix(float**,int);
Nodc **nvector(int);
long *lvector(int);
int **imatrix(int, int );
float ran1(long*);
int ***i3matrix1(int nloci0,int *nallele0,int npop0);
extern char delimiter[6];

int *ivector( n)
int n;
{
int *vp;

	vp = (int *)malloc((unsigned) n*sizeof(int));
	if( !vp ) {
		 fprintf(ERR,"memory allocation error\n");
		 fprintf(ERR,"integer vector[%d]\n",n);
		 exit(1);
	  }
	 return(vp);
}
long *lvector( n)
int n;
{
long *vp;

	vp = (long *)malloc((unsigned) n*sizeof(long));
	if( !vp ) {
		 fprintf(ERR,"memory allocation error\n");
		 fprintf(ERR,"integer vector[%d]\n",n);
		 exit(1);
	  }
	 return(vp);
}
char *cvector(n)
int n;
{
char *vp;

	vp = (char *)malloc((unsigned) n*sizeof(char));
	if( !vp ) {
		 fprintf(ERR,"memory allocation error\n");
		 fprintf(ERR,"char vector[%d]\n",n);
		 exit(1);
	  }
	 return(vp);
}

double *dvector(n)
int n;
{
double *vp;

	vp = (double *)malloc((unsigned) n*sizeof(double));
	if( !vp ) {
		 fprintf(ERR,"memory allocation error\n");
		 fprintf(ERR,"double vector[%d]\n",n);
		 exit(1);
	  }
	 return(vp);
}

int **imatrix(n1,n2)
int n1,n2;
{
int i,**ip;

 ip = (int **) malloc((unsigned ) n1*sizeof(int*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	ip[i] = (int *) malloc((unsigned) n2*sizeof(int));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
	 exit(1);

  }
 }

  return(ip);

}


float **f2matrix(n1,n2)
int n1,*n2;
{
int i;
float **ip;

/* printf("n1=%d\n",n1); */
 ip = (float **) malloc((unsigned ) n1*sizeof(float *) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
/*   printf("n2[%d]=%d\n",i,n2[i]); */
	ip[i] = (float *) malloc((unsigned) n2[i]*sizeof(float ));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
	 exit(1);

  }
 }

  return(ip);

}




float **fmatrix(n1,n2)
int n1,n2;
{
int i;
float **ip;

 ip = (float **) malloc((unsigned ) n1*sizeof(float*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 float matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	ip[i] = (float *) malloc((unsigned) n2*sizeof(float));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) float matrix %d %d\n",i,n1,n2);
	 exit(1);

  }
 }

  return(ip);

}




float ***f3matrix(nloci,nalle,npop)
int nloci,npop,*nalle;
{
int i,j,k;
float ***ip, **fmatrix(int n1, int n2);


 ip = (float ***) malloc((unsigned ) nloci*sizeof(float**) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 float 3matrix %d\n",nloci);
	 exit(1);
  }
 for(i=0; i<nloci ; i++){
	  ip[i] = fmatrix(nalle[i],npop);
	    for(j=0; j<nalle[i] ; j++){
		 for(k=0; k < npop ; k++) ip[i][j][k]=0.0;
            }
        
	  if( !ip[i] ) {
			 fprintf(ERR,"memory allocation error\n");
			 fprintf(ERR,"step2(i=%d) float3 matrix %d %d\n",i,nloci,nalle[i]);
			 exit(1);
	}
	}

  return(ip);

}



int ***i3matrix1(nloci,nalle,npop)
int nloci,npop,*nalle;
{
int i,j,k;
int ***ip, **imatrix(int n1, int n2);


 ip = (int ***) malloc((unsigned ) nloci*sizeof(int**) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 float 3matrix %d\n",nloci);
	 exit(1);
  }
 for(i=0; i<nloci ; i++){
	  ip[i] = imatrix(nalle[i],npop);
	    for(j=0; j<nalle[i] ; j++){
		 for(k=0; k < npop ; k++) ip[i][j][k]=0.0;
            }
        
	  if( !ip[i] ) {
			 fprintf(ERR,"memory allocation error\n");
			 fprintf(ERR,"step2(i=%d) float3 matrix %d %d\n",i,nloci,nalle[i]);
			 exit(1);
	}
	}

  return(ip);

}




char **cmatrix(n1,n2)
int n1,n2;
{
int i;
char **ip;

 ip = (char **) malloc((unsigned ) n1*sizeof(char*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	ip[i] = (char *) malloc((unsigned) n2*sizeof(char));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
	 exit(1);

  }
 }

  return(ip);

}


char ***c3matrix(n1,n2,n3)
     int n1, n2, n3;
{
int i,j,k;
char ***ip, **cmatrix(int n1, int n2);


 ip = (char ***) malloc((unsigned ) n1*sizeof(char**) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 float 3matrix %d\n",n1);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	  ip[i] = cmatrix(n2,n3);
	    for(j=0; j<n2 ; j++){
		 for(k=0; k < n3 ; k++) ip[i][j][k]=0;
            }
        
	  if( !ip[i] ) {
			 fprintf(ERR,"memory allocation error\n");
			 fprintf(ERR,"step2(i=%d) float3 matrix %d %d\n",i,n1,n2);
			 exit(1);
	}
	}

  return(ip);

}


char ***c3matrix1(n1,n2,n3)
     int n1, *n2, n3;
{
int i,j,k;
char ***ip, **cmatrix(int n1, int n2);


 ip = (char ***) malloc((unsigned ) n1*sizeof(char**) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 float 3matrix %d\n",n1);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	  ip[i] = cmatrix(n2[i],n3);
	    for(j=0; j<n2[i] ; j++){
		 for(k=0; k < n3 ; k++) ip[i][j][k]=0;
            }
        
	  if( !ip[i] ) {
			 fprintf(ERR,"memory allocation error\n");
			 fprintf(ERR,"step2(i=%d) float3 matrix %d %d\n",i,n1,n2);
			 exit(1);
	}
	}

  return(ip);

}




double **dmatrix(n1,n2)
int n1,n2;
{
int i;
double **ip;

 ip = (double **) malloc((unsigned ) n1*sizeof(double*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	ip[i] = (double *) malloc((unsigned) n2*sizeof(double));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) double matrix %d %d\n",i,n1,n2);
	 exit(1);

  }
 }

  return(ip);

}



double **dmatrixf(n1,n2)
int n1,*n2;
{
int i;
double **ip;

 ip = (double **) malloc((unsigned ) n1*sizeof(double*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
	 exit(1);
  }
 for(i=0; i<n1 ; i++){
	ip[i] = (double *) malloc((unsigned) n2[i]*sizeof(double));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) double matrixf %d %d\n",i,n1,n2[i]);
	 exit(1);

  }
 }

  return(ip);

}


Nodc **nvector(n)
int n;
{
int i;
Nodc **ip;

 ip = (Nodc **) malloc((unsigned ) n*sizeof(Nodc*) );
 if( !ip ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"Nodc step1 %d\n",n);
	 exit(1);
  }
 for(i=0; i<n ; i++){
	ip[i] = (Nodc *) malloc(sizeof(Nodc));
	if( !ip[i] ) {
	 fprintf(ERR,"memory allocation error\n");
	 fprintf(ERR,"step2(i=%d) Tnode %d\n",i,n);
	 exit(1);

  }
 }

  return(ip);

}


void free_ivector(v)
int *v;
{
	free((char*) v );
	return ;
 }
void free_lvector(v)
long *v;
{
	free((char*) v );
	return ;
 }

void free_dvector(v)
double *v;
{
	free((char*) v );
	return ;
 }


void free_cvector(v)
char *v;
{
   free((char*) v );
   return ;
 }


void free_cmatrix(m,n1)
char **m;
int n1;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}

void free_imatrix(m,n1)
int  **m;
int n1;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}


void free_fmatrix(m,n1)
float  **m;
int n1;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}

void free_f3matrix(m,n1,n2)
float  ***m;
int n1, *n2;
{
int i;
void free_fmatrix(float **m, int n1);

    for(i=n1-1 ; i >= 0 ; i-- ){
       free_fmatrix(m[i],n2[i]);
       free((char *) (m[i]));
     }
    free((char *) m);
}
void free_dmatrix(m,n1)
double  **m;
int n1;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}


void free_nvector(ip,n)
Nodc **ip;
int n;
{
int i;


 for(i=n-1; i >=0 ; i--){
   free((char*) ip[i]);
 }
 free((char *)ip); 
  return ;
				 
}

int checklinelen(fpi)
     FILE *fpi;
{
  int maxlen,linelen;
  int c,crflg,lfflg;

  maxlen=linelen=0;
  crflg = 0;
  
  for( ; ; ){
     c = fgetc(fpi);
     if( c == EOF ){
       break;
     }
     linelen++;
     if( c == CR || c == LF ) {
       if( linelen > maxlen ){
	 maxlen = linelen;
       }
       linelen = 0;
     }

  }
  return(maxlen);
}
int checkloci(fpi,nloci,npop,maxnm,bf,bf1,maxlinelen)
FILE *fpi;
int *nloci,*npop,*maxnm,maxlinelen;
char *bf,*bf1;
{
  int cw,nl,rn,n,nl1,i,j,spflg,nc,nw,np;
  int stringst,stringend,stringst2,targetorder;
/* char bf[100],bf1[20];*/
  extern int dflg;

/* flg  0   initial
		  1   file name
        2   file name end
        3   sequence
   flg1 1   comment
 */


   nl = nl1 = 0;
   *nloci=0;
   *maxnm=0;
   stringst = stringend = stringst2 = -1;

   for( ; ; ){
      clrbf(bf,maxlinelen);
      rn = rdline(fpi,bf, &n, maxlinelen);
      nl++;
      if( rn == -1 ){
        break;
      }
      if( rn == 1 ){
        continue;
      }
      if( rn == 2 ){
	printf("line %d line length exceeded the buffer size %d\n",nl,maxlinelen);
        exit(1);
      }
      nl1++;
      if( nl1 == 1 ){
        clrbf(bf1,maxlinelen);
	sscanf(bf,"%d %s",npop,bf1);
         if( strcmp_case(bf1,"otu") != 0 && strcmp_case(bf1,"populations") != 0  ){
	   printf("invalid format first line bf %s bf1 %s\n",bf);
           exit(1);
        }
        continue;
      }

      if( getword(bf,n,bf1,maxlinelen,"@locus",&targetorder) == 0 ) {
	if( targetorder != 1 ){
	  fprintf(stdout,"At line %d format error: bf %s\n",nl,bf);
          exit(1);
	}         
         (*nloci)++;           
      }

      if( (*nloci) == 0 ){
        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        for(i=0; i<n; i++){
          if( bf[i] == ' ' || bf[i] == '\t'|| bf[i] == '\n' || bf[i] == CR || bf[i] == LF  ){
            if( spflg == 1 ) {
              continue;
	    }
	    /*            fprintf(stdout,"nw=%d bf1 %s\n",nw,bf1);*/
            if( nw == 1 ){
	      for(j=0; j<nc ; j++){
                if( bf1[j] < '0' || bf1[j] > '9' ) {
		  printf("line %d:%s: population number is missing bf1 %s\n",nl,bf,bf1);
                  exit(1);
		}
	      }
                sscanf(bf1,"%d",&np);
                if( np != nl1-1 ){
		  printf("line %d (nl1=%d):%s: population number %d (bf1 %s) does not match %d\n",nl,nl1,bf, np,bf1,nl1-1);
                  exit(1);
		}
	    }
            stringend = i-1;
            spflg = 1;
            continue;

	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             stringst = i;
             if( nw == 2 ){
               stringst2 = stringst;
	     }
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
        if( nw == 1 ){
	  printf("At line %d, no population name\n",nl);
	  printf("bf %s\n",bf);
          exit(1);
	}
        if( *maxnm < stringend - stringst2+1) {
           *maxnm = stringend - stringst2+1 ;
	}
      }
   }

   if( np != *npop ){
     fprintf(stdout,"npop %d does not match to the number of population names %d\n",*npop,np);
     exit(1);
   }
    return(0);
}




checkflal(fpi,nloci,nallele,npop,bf,bf1,maxlinelen)
FILE *fpi;
int nloci,*nallele,npop,maxlinelen;
char *bf,*bf1;
{
  int nc,nw,i,cw,nl,ncf,nl1,n;
  int rn,locusflg,asterflg, sharpflg,targetorder;

  extern int dflg;

        nl = ncf = 0;
	for(i=0; i<nloci ; i++) nallele[i]=0;
	nc=0;

	 for( ; ; ){
           clrbf(bf,maxlinelen);
           rn = rdline(fpi,bf, &n, maxlinelen);
           nl++;
           if( rn == -1 ){
             break;
           }
           if( rn == 1 ){
            continue;
           }
           if( rn == 2 ){
        	printf("line %d line length exceeded the buffer size %d\n",nl,maxlinelen);
                exit(1);
            }
           nl1++;

	   locusflg = 0;
	   asterflg = 0;
	   sharpflg = 0;
           if( getword(bf,n,bf1,maxlinelen,"@locus",&targetorder) == 0 ) {
	     if( targetorder == 1 ){
   	        locusflg = 1;
                nc++;
	     }
	   }
           if( locusflg != 1 ){
	     if( getword(bf,n,bf1,maxlinelen,"#",&targetorder) == 0 ){
	       if( targetorder == 1 ){
   	        sharpflg = 1;
	       }
	     }
	   }
           if( locusflg == 0 && sharpflg == 0 ){
	     if( getword(bf,n,bf1,maxlinelen,"*",&targetorder) == 0 ){
   	        asterflg = 1;
                nallele[nc-1]++;
	     }

 	   }
	 }
	 return(0);
}








getal(fpi,dop,nloci,nallele,popname,allelef,samplesz,npop,fstep, bf,bf1,maxlinelen)
FILE *fpi;
int dop,nloci,*nallele,npop,maxlinelen;
float ***allelef,**samplesz,**fstep;
char **popname,*bf,*bf1;
{
  int cw,flg,nc,na,nw,nw1,nl,nl1,np,nloci1,i,j,k,rn,n;
  int spflg,stringst,stringend,stringst1,stringst2,locusflg,asterflg,astermark,sharpflg,targetorder;
float fw;
extern int dflg;

/* flg  0   initial
		  1   file name
		  2   file name end
		  3   sequence
	flg1 1   comment
 */


/* printf("getal start\n"); fflush(stdout); */

  for(i=0; i< nloci ; i++){
    /*         printf("nloci %d nallele %d\n",i,nallele[i]);*/
	 for(j=0; j<nallele[i] ; j++){
		 for(k=0; k<npop ; k++){
		    allelef[i][j][k]= -1.;
		 }
         }
  }
	nc=0;
	flg = 0;
	cw =0;
	na=0; nl=nl1=0;
	nloci1=0;
	 for( ; ; ){
           clrbf(bf,maxlinelen);
           rn = rdline(fpi,bf, &n, maxlinelen);
           nl++;
           if( rn == -1 ){
             break;
           }
           if( rn == 1 ){
            continue;
           }
           if( rn == 2 ){
        	printf("line %d line length exceeded the buffer size %d\n",nl,maxlinelen);
                exit(1);
            }
           nl1++;
           if( nl1 == 1 ){
              clrbf(bf1,maxlinelen);
              sscanf(bf,"%d %s",&np,bf1);
              if( np != npop ){
                fprintf(stdout,"number of populations (%d) does not match npop %d\n",np,npop);
	      }
              if( strcmp_case(bf1,"otu") != 0 && strcmp_case(bf1,"populations") != 0) {
                fprintf(stdout,"the first line format error (bf1 %s):%s\n",bf1,bf);
                exit(1);
	      }
              continue;
	   }
	   locusflg = 0;
	   asterflg = 0;
	   sharpflg = 0;
           if( getword(bf,n,bf1,maxlinelen,"@locus",&targetorder) == 0 ) {
	     /*             fprintf(stderr,"nl=%d locus\n",nl);*/
	     if( targetorder == 1 ){
   	        locusflg = 1;
                nloci1++;
                na = 0;
	     }
	   }
           if( locusflg != 1 ){
	     if( getword(bf,n,bf1,maxlinelen,"#",&targetorder) == 0 ){
	       if( targetorder == 1 ){
   	         if( strcmp(bf1,"#" ) == 0 ){
   	            sharpflg = 1;
                    np=0;
		 }
	       }
	     }
	   }
           if( locusflg == 0 && sharpflg == 0 ){
	     if( getword(bf,n,bf1,maxlinelen,"*",&targetorder) == 0 ){
	       if( strcmp(bf1,"*" ) == 0 ){
   	        asterflg = 1;
                na++;
                np=0;
	       }

	     }

 	   }
        
      if( nloci1 == 0 ){
        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        stringst=stringend=stringst2=0;
        astermark=0;
        for(i=0; i<n; i++){
          if( bf[i] == ' ' || bf[i] == '\t'|| bf[i] == '\n' || bf[i] == CR || bf[i] == LF){
            if( spflg == 1 ) {
              continue;
	    }
            stringend = i-1;
	    /*            fprintf(stdout,"nw=%d bf1 %s\n",nw,bf1);*/
            if( nw == 1 ){
	      for(j=0; j<nc ; j++){
                if( bf1[j] < '0' || bf1[j] > '9' ) {
		  printf("line %d:%s: population number is missing bf1 %s\n",nl,bf,bf1);
                  exit(1);
		}
	      }
                sscanf(bf1,"%d",&np);
                if( np != nl1-1 ){
		  printf("line %d (nl1=%d):%s: population number %d (bf1 %s) does not match %d\n",nl,nl1,bf, np,bf1,nl1-1);
                  exit(1);
		}
	    }
            stringend = i-1;
            spflg = 1;
            continue;

	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             stringst = i;
             if( nw == 2 ){
               stringst2 = stringst;
	     }
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
        for(j=stringst2; j<=stringend; j++){
	  popname[np-1][j-stringst2]=bf[j];
	}
        continue;
      }

      if( nloci1 > 0 ){

	if( locusflg != 1 && asterflg != 1 && sharpflg != 1 ){
	    fprintf(stdout,"at line %d, format error. No @,*,#\n",nl);
	    fprintf(stdout,"bf:%s\n",bf);
            exit(1);
	}

        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        astermark=-1;
        for(i=0; i<n; i++){
          if( bf[i] == ' ' || bf[i] == '\t'|| bf[i] == '\n' || bf[i] == CR || bf[i] == LF ){
            if( spflg == 1 ) {
              continue;
	    }
            spflg = 1;
            if( locusflg == 1 ){
               if( nw == 1 ){
                 if( strncmp_case(bf1,"@locus",6) != 0 ){
                   fprintf(stdout,"line %d: locus number format error :%s",nl,bf);
                   exit(1);
		 }
		 /*                 fprintf(stderr,"bf:%s bf1:%s\n",bf,bf1);*/
                 if( strlen(bf1) > 6 ){
 		     sscanf(bf1+6,"%d",&nw1);
                     if( nw1 != nloci1 ){
                     fprintf(stdout,"line %d locus number %d does not match the order %d: %s",nl,nw1,nloci1);
                     exit(1);
                   }
                   break;
		 }
                 continue;
	       }
               if( nw == 2 ){
		 sscanf(bf1, "%d",&nw1);
                 if( nw1 != nloci1 ){
                   fprintf(stdout,"line %d locus number %d does not match the order %d: %s",nl,nw1,nloci1);
                   exit(1);
		 }
                 break;
	       }
               continue;
	    }
            if( asterflg == 1 ){
              if( nw == 1 ){
	        if( dop >= 5 ){
		  sscanf(bf1,"%f",&fw);
		  fstep[nloci1-1][na-1]=fw;
                  continue;
		}
	      }
	      if( strcmp(bf1,"*") == 0 ){    
		if( dop >= 5 ){
		  if( nw != 2 ){
		    fprintf(stdout,"line %d: allele step number is invalid: stringst %d stringst1 %d",nl,stringst,stringst1);
                    for(j=0; j<i; j++){
		      fprintf(stdout,"%c",bf[j]);
		    }
		    fprintf(stdout,"\n");
                    exit(1);
		  }
		}
                 astermark = i;
                continue;
	      }
              if( astermark >= 0 ){
                   sscanf(bf1,"%f",&fw);
		   allelef[nloci1-1][na-1][np]=fw;
		   /*                   fprintf(stdout,"np=%d bf1=%s ",np,bf1);*/
                   np++;
                   continue;
	      }
             continue;
	    }
            if( sharpflg == 1 ){
	      if( nw == 1 ){
		if( strcmp(bf1,"#")  != 0 ){
		  fprintf(stdout,"line %d: sharp does not appear at the beginning\n",nl);
		  fprintf(stdout,"bf:%s",bf);
                  exit(1);
		}
                continue;
	      }
	      sscanf(bf1,"%f",&fw);
	      samplesz[nloci1-1][np]=fw;
              np++;
              continue;
	    }

	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             stringst = i;
             if( nw == 1 ){
               stringst1 = stringst;
	     }
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
        if( asterflg == 1 || sharpflg == 1 ){
          if( np != npop ){
	    fprintf(stdout,"line %d: locus %d allele %d  number of values (%d) does not match the number of populations (%d)\n",nl,nloci1,na,np,npop);
	    fprintf(stdout,"bf:%s",bf);
            exit(1);         
	  }
	}
      }

	 }

    
	 if( nloci1 != nloci ){
           fprintf(stdout,"getal:number of loci %d does not match nloci=%d\n",nloci,nloci1); 
           exit(1);
	 }
	 return(0);
}


   
                 



clrbf(bf,n)
char *bf;
int n;
{
int i;

/* fprintf(stderr,"clrbf n=%d\n",n);*/

 for(i=0; i<n ; i++) {
   bf[i]=0;
 }

return(0);
}



clr_ibf(bf,n)
int *bf;
int n;
{
int i;

 for(i=0; i<n ; i++) {
   bf[i]=0;
 }

return(0);
}


clr_cmatrix(bf,n1,n2)
char **bf;
int n1,n2;
{
  int i,j;


 for(i=0; i<n1 ; i++) {
   for(j=0; j<n2 ; j++) {
        bf[i][j]=0;
     }
 }

return(0);
}


clr_imatrix(bf,n1,n2)
int **bf;
int n1,n2;
{
  int i,j;


 for(i=0; i<n1 ; i++) {
   for(j=0; j<n2 ; j++) {
        bf[i][j]=0;
     }
 }

return(0);
}




clr_c3matrix(bf,n1,n2,n3)
char ***bf;
int n1,n2,n3;
{
  int i,j,k;

/* fprintf(stderr,"clrbf n=%d\n",n);*/

 for(i=0; i<n1 ; i++) {
   for(j=0; j<n2 ; j++) {
     for(k=0; k<n3 ; k++) {
        bf[i][j][k]=0;
     }
   }
 }

return(0);
}



clr_c3matrix1(bf,n1,n2,n3)
char ***bf;
int n1,*n2,n3;
{
  int i,j,k;

/* fprintf(stderr,"clrbf n=%d\n",n);*/

 for(i=0; i<n1 ; i++) {
   for(j=0; j<n2[i] ; j++) {
     for(k=0; k<n3 ; k++) {
        bf[i][j][k]=0;
     }
   }
 }

return(0);
}


clr_i3matrix(bf,n1,n2,n3)
int ***bf;
int n1,n2,n3;
{
  int i,j,k;

/* fprintf(stderr,"clrbf n=%d\n",n);*/

 for(i=0; i<n1 ; i++) {
   for(j=0; j<n2 ; j++) {
     for(k=0; k<n3 ; k++) {
        bf[i][j][k]=0;
     }
   }
 }

return(0);
}


clr_i3matrix1(bf,n1,n2,n3)
int ***bf;
int n1,*n2,n3;
{
  int i,j,k;

/* fprintf(stderr,"clrbf n=%d\n",n);*/

 for(i=0; i<n1 ; i++) {
   for(j=0; j<n2[i] ; j++) {
     for(k=0; k<n3 ; k++) {
        bf[i][j][k]=0;
     }
   }
 }

return(0);
}



clr_fmatrix(bf,n1,n2)
float **bf;
int n1,n2;
{
  int i,j;


 for(i=0; i<n1 ; i++) {
   for(j=0; j<n2 ; j++) {
     bf[i][j]=0.0;
     }
 }

return(0);
}


clr_fmatrix1(bf,n1,n2)
float **bf;
int n1,*n2;
{
  int i,j;


 for(i=0; i<n1 ; i++) {
   for(j=0; j<n2[i] ; j++) {
     bf[i][j]=0.0;
     }
 }

return(0);
}


clr_f3matrix(bf,n1,n2,n3)
float ***bf;
int n1,n2,n3;
{
  int i,j,k;

/* fprintf(stderr,"clrbf n=%d\n",n);*/

 for(i=0; i<n1 ; i++) {
   for(j=0; j<n2 ; j++) {
     for(k=0; k<n3 ; k++) {
       bf[i][j][k]=0.0;
     }
   }
 }

return(0);
}

clr_f3matrix1(bf,n1,n2,n3)
float ***bf;
int n1,*n2,n3;
{
  int i,j,k;

/* fprintf(stderr,"clrbf n=%d\n",n);*/

 for(i=0; i<n1 ; i++) {
   for(j=0; j<n2[i] ; j++) {
     for(k=0; k<n3 ; k++) {
       bf[i][j][k]=0.0;
     }
   }
 }

return(0);
}



int rdline(fp,b,n, maxc)
FILE *fp;
char *b;
int *n,maxc;
{
  int cw,nc,rn;

  *n = 0;
  nc = 0;
  for( ; ; ){
    cw = getc(fp);
    if( cw == EOF ){
      return(-1);
      break;
    }
    if( *n == maxc ){
      return(2);
    }
    b[*n]=cw;
    (*n)++;
    rn = matchdelimiter(cw,delimiter);
    if( rn < 0 ){
      nc++;
    }
    if( cw == CR || cw == LF || cw == '\n'  ){
      if( nc == 0 ){
	return(1);
      }
      return(0);
    }

  }  
  

}


int getword(bf,n,bf1,maxlinelen,targetword,targetorder)
char *bf,*bf1,*targetword;
int n,maxlinelen,*targetorder;
{
  int i,nw,spflg,nt,nc;
        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        nt = strlen(targetword);
        for(i=0; i<n; i++){
          if( bf[i] == ' ' || bf[i] == '\t'|| bf[i] == '\n' || bf[i] == CR || bf[i] == LF ){
            if( spflg == 1 ) {
              continue;
	    }
            if( strncmp_case(bf1,targetword,nt) == 0 ){
	      (*targetorder) = nw;
              return(0);
	    }
            spflg = 1;
            continue;
	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
	return(-1);

}



strncmp_case(b,b1,nc)
char *b,*b1;
int nc;
{
  int i,n,cw,cw1,nmatch;



  /*  fprintf(stderr,"strncmp b b1 %s %s nc=%d\n",b,b1,nc);*/
  n= strlen(b1);

  nmatch = 0;

  for(i=0; i<nc ; i++){
    cw = b[i];   
    cw1 = b1[i];   
    if( b[i] >= 'A' && b[i] <= 'Z' ){
      cw = b[i] + 'a' - 'A';
    }
    if( b1[i] >= 'A' && b1[i] <= 'Z' ){
      cw1 = b1[i] + 'a' - 'A';
    }
    if( cw == cw1 ){
      nmatch++;
      continue;
    }
    return(-1);
  }

  return(0);

}


strcmp_case(b,b1)
char *b,*b1;
{
  int i,n,cw,cw1,nmatch,n1;



  /*  fprintf(stderr,"strncmp b b1 %s %s nc=%d\n",b,b1,nc);*/
  n1 = strlen(b1);
  n = strlen(b);
  
  if( n1 != n ){
    return(1);
  }

  nmatch = 0;

  for(i=0; i<n ; i++){
    cw = b[i];   
    cw1 = b1[i];   
    if( b[i] >= 'A' && b[i] <= 'Z' ){
      cw = b[i] + 'a' - 'A';
    }
    if( b1[i] >= 'A' && b1[i] <= 'Z' ){
      cw1 = b1[i] + 'a' - 'A';
    }
    if( cw == cw1 ){
      nmatch++;
      continue;
    }
    return(-1);
  }

  return(0);

}






int getword_order(bf,n,bf1,maxlinelen,targetorder)
char *bf,*bf1;
int n,maxlinelen,targetorder;
/* return the targetrorer of the  word in bf1 
    if targetorder = 2, the second word should be returned in bf1 */
{
  int i,nw,spflg,nt,nc;
        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        for(i=0; i<n; i++){
          if( bf[i] == ' ' || bf[i] == '\t'|| bf[i] == '\n' || bf[i] == CR || bf[i] == LF ){
            if( spflg == 1 ) {
              continue;
	    }

            if( nw  == targetorder ){
              return(0);
	    }
            spflg = 1;
            continue;
	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
	return(-1);

}




int getword_order_popname(bf,n,bf1,maxlinelen,targetorder)
char *bf,*bf1;
int n,maxlinelen,targetorder;
/* return the targetrorer of the  word in bf1 
    if targetorder = 2, the second word should be returned in bf1 */
{
  int i,j,nw,spflg,nt,nc,endpos;
        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        for(i=0; i<n; i++){
          if( bf[i] == ' ' || bf[i] == '\t'|| bf[i] == '\n' || bf[i] == CR || bf[i] == LF ){
            if( spflg == 1 ) {
              continue;
	    }

            if( nw  == targetorder ){
              endpos = i-1;
              for(j=n-1; j>i; j--){
		if( bf[j] == ' ' || bf[j] == '\t'|| bf[j] == '\n' || bf[j] == CR || bf[j] == LF ){
		  continue;
		}
                endpos = j;
                break;
	      }
              if( endpos > i-1 ){
		for(j=i-1; j<= endpos ; j++){
                  if( bf[j] == ' ' || bf[j] == '\t'|| bf[j] == '\n' || bf[j] == CR || bf[j] == LF ){
                     bf1[nc + (j-i+1)] = '_';
		  }else{
                     bf1[nc + (j-i+1)] = bf[j];
		  }
		}
	      }
              
              return(0);
	    }
            spflg = 1;
            continue;
	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
	return(-1);

}



int getword_nword_locusname(bf,n,bf1,maxlinelen,delimiter_locus,nword,maxlen_word)
     char *bf,*bf1,*delimiter_locus;
     int n,maxlinelen,*nword, *maxlen_word;
{
  int i,nw,spflg,nt,nc,nd,rn,rn1;

        *nword = 0;
        *maxlen_word = 0;
        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        for(i=0; i<n; i++){
          rn = matchdelimiter(bf[i],delimiter_locus);
          if( rn >~ 0 ){
            if( spflg == 1 ) {
              continue;
	    }
            removeendspace(bf1);
            rn1 = strlen(bf1);
            (*nword)++;
	    /*            fprintf(stderr,"getword_nword_locusname nword %d bf1 %s",*nword,bf1);*/
            if( rn1 > (*maxlen_word) ){
	      (*maxlen_word) = rn1;
	    }
            spflg = 1;
            continue;
	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
	return(-1);

}




int getword_nword_locusname_get(bf,n,bf1,maxlinelen,delimiter_locus,nloci1,nword,maxlen_word,locusname)
     char *bf,*bf1,*delimiter_locus, **locusname;
     int n,maxlinelen,nloci1,*nword, *maxlen_word;
{
  int i,nw,spflg,nt,nc,nd,rn,rn1;

        *nword = 0;
        *maxlen_word = 0;
        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        for(i=0; i<n; i++){
          rn = matchdelimiter(bf[i],delimiter_locus);
          if( rn >~ 0 ){
            if( spflg == 1 ) {
              continue;
	    }
            removebothendspace(bf1);
            rn1 = strlen(bf1);
            (*nword)++;
	    /*	    fprintf(stderr,"getword_nword_locusname nword %d nloci1=%d bf1 %s",*nword,nloci1,bf1);*/
            if( rn1 > (*maxlen_word) ){
	      (*maxlen_word) = rn1;
	    }
            strcat(locusname[nloci1+(*nword)-1],bf1);
	    /*	    fprintf(stderr,"getword_nword_locusname nword %d nloci1=%d bf1 %s",*nword,nloci1,bf1);*/
            spflg = 1;
            continue;
	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
	return(-1);

}




int getword_nword_locusdata(bf,n,bf1,maxlinelen,delimiter_locus,nword,maxlen_word)
     char *bf,*bf1,*delimiter_locus;
     int n,maxlinelen,*nword, *maxlen_word;
{
  int i,nw,spflg,nt,nc,nd,rn,rn1,commapos;


       commapos = -1;
       for(i=0; i<n; i++){
	 if(bf[i] == ',' ){
           commapos = i;
           break;
	 }
       }
       if( commapos == -1 ){
	 return(-1); /* no comma */
       }


        nd = strlen(delimiter);
        *nword = 0;
        *maxlen_word = 0;
        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        for(i=commapos+1; i<n; i++){
          rn = matchdelimiter(bf[i],delimiter);
          if( rn >~ 0 ){
            if( spflg == 1 ) {
              continue;
	    }
            removeendspace(bf1);
            rn1 = strlen(bf1);
            (*nword)++;
            if( rn1 > (*maxlen_word) ){
	      (*maxlen_word) = rn1;
	    }
            spflg = 1;
            continue;
	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
	return(0);

}


int getword_nword_locusdata_nallele(bf,n,bf1,maxlinelen,delimiter_locus,nloci1,nl,nword,maxlen_word,nallele,allelename_store)
     char *bf,*bf1,*delimiter_locus, ***allelename_store;
     int n,maxlinelen,nloci1,nl,*nword, *maxlen_word,*nallele;
{
  int i,j,nw,spflg,nt,nc,rn,rn1,rn2,commapos;
  int allelematchflg,allelematchflg1,allelematchflg2,n1,n2;


       commapos = -1;
       for(i=0; i<n; i++){
	 if(bf[i] == ',' ){
           commapos = i;
           break;
	 }
       }
       if( commapos == -1 ){
	 return(-1); /* no comma */
       }

       /*        fprintf(stderr,"getword_nword_locusdata_nallele commapos=%d\n",commapos);*/
        *nword = 0;
        *maxlen_word = 0;
        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        for(i=commapos+1; i<n; i++){
          rn = matchdelimiter(bf[i],delimiter);
          if( rn >= 0 ){
            if( spflg == 1 ) {
              continue;
	    }
            removeendspace(bf1);
            rn1 = strlen(bf1);
            (*nword)++;
            if( rn1 > (*maxlen_word) ){
	      (*maxlen_word) = rn1;
	    }
	    /*	    fprintf(stderr,"bf1 %s rn1 =%d ",bf1,rn1);*/
            if( rn1 <= 3 ){
	      allelematchflg = 0;
	      /*  	      fprintf(stderr,"nallele[%d]=%d  ",nw-1,nallele[nw-1]);  */
	      for(j=0; j< nallele[nw-1]; j++){
                rn2 = strcmp_case(allelename_store[nw-1][j],bf1);
                if( rn2 == 0 ){
		  allelematchflg = 1;
                  break;
		}
	      }
              if( allelematchflg == 0 ){
                n1 = nallele[nw-1];
		strcat(allelename_store[nw-1][n1],bf1);
		nallele[nw-1]++;
	      }
	    }
            if( rn1 > 3 ){
	      allelematchflg = 0;
              if( rn1 % 2 != 0 ){
		fprintf(stdout,"one allele data %s\n",bf1); 
		fprintf(stdout,"line %d  %s\n",nl,bf); 
                exit(1);
	      }
              n2 = rn1/2;
	      /*              fprintf(stderr,"n2=%d nallele[%d]=%d ",n2,nw-1,nallele[nw-1]);*/
              allelematchflg1 =  0;
	      for(j=0; j< nallele[nw-1]; j++){
                rn2 = strncmp_case(allelename_store[nw-1][j],bf1,n2);
                if( rn2 == 0 ){
		  allelematchflg1 = 1;
                  break;
		}
	      }
	      /*              fprintf(stderr,"allelematchflg1=%d ",allelematchflg1);*/
              if( allelematchflg1 == 0 ){
                n1 = nallele[nw-1];
		strncat(allelename_store[nw-1][n1],bf1,n2);
		nallele[nw-1]++;
	      }
              allelematchflg2 =  0;
	      for(j=0; j< nallele[nw-1]; j++){
                rn2 = strncmp_case(allelename_store[nw-1][j],bf1+n2,n2);
                if( rn2 == 0 ){
		  allelematchflg2 = 1;
                  break;
		}
	      }
	      /*              fprintf(stderr,"allelematchflg2=%d ",allelematchflg2);*/
              if( allelematchflg2 == 0 ){
                n1 = nallele[nw-1];
		strncat(allelename_store[nw-1][n1],bf1+n2,n2);
		nallele[nw-1]++;
	      }
	    }

            spflg = 1;
            continue;
	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
	return(0);

}



int getword_nword_locusdata_nallele_get(bf,n,bf1,maxlinelen,delimiter_locus,nloci1,npop1,nl,nword,maxlen_word,nallele,allelename_store,allelecount)
     char *bf,*bf1,*delimiter_locus, ***allelename_store;
     int n,maxlinelen,nloci1,npop1,nl,*nword, *maxlen_word,*nallele;
     int ***allelecount;
{
  int i,j,nw,spflg,nt,nc,rn,rn1,rn2,commapos;
  int allelematchflg,allelematchflg1,allelematchflg2,n1,n2;

       commapos = -1;
       for(i=0; i<n; i++){
	 if(bf[i] == ',' ){
           commapos = i;
           break;
	 }
       }
       if( commapos == -1 ){
	 return(-1); /* no comma */
       }

       /*       fprintf(stderr,"getword_nword_locusdata_nallele get commapos=%d\n",commapos);*/
        *nword = 0;
        *maxlen_word = 0;
        nw = 0;
        spflg = 1;
        clrbf(bf1,maxlinelen);
        for(i=commapos+1; i<n; i++){
          rn = matchdelimiter(bf[i],delimiter);
          if( rn >= 0 ){
            if( spflg == 1 ) {
              continue;
	    }
            removeendspace(bf1);
            rn1 = strlen(bf1);
            (*nword)++;
            if( rn1 > (*maxlen_word) ){
	      (*maxlen_word) = rn1;
	    }
	    /*	    fprintf(stderr,"bf1 %s rn1 =%d ",bf1,rn1);*/
            if( rn1 <= 3 ){
	      allelematchflg = -1;
	      for(j=0; j< nallele[nw-1]; j++){
                rn2 = strcmp_case(allelename_store[nw-1][j],bf1);
                if( rn2 == 0 ){
		  allelematchflg = j;
                  break;
		}
	      }

              if( allelematchflg == -1 ){
		/*
                n1 = nallele[nw-1];
		strcat(allelename_store[nloci1][n1],bf1);
		nallele[nw-1]++;
		*/
                fprintf(stdout,"allele %s does not match\n",bf1);
                fprintf(stdout,"nl=%d bf %s\n",nl,bf);
                exit(1);
	      }
              allelecount[nw-1][allelematchflg][npop1-1] ++;
	    }
            if( rn1 >= 3 ){
	      allelematchflg = 0;
              if( rn1 % 2 != 0 ){
		fprintf(stdout,"one allele data %s\n",bf1); 
		fprintf(stdout,"line %d  %s\n",nl,bf); 
                exit(1);
	      }
              n2 = rn1/2;
	      /*	      fprintf(stderr,"n2=%d ",n2);*/
              allelematchflg1 =  -1;
	      for(j=0; j< nallele[nw-1]; j++){
                rn2 = strncmp_case(allelename_store[nw-1][j],bf1,n2);
                if( rn2 == 0 ){
		  allelematchflg1 = j;
                  break;
		}
	      }
              if( allelematchflg1 == -1 ){
		/*
                n1 = nallele[nw-1];
		strncat(allelename_store[nw-1][n1],bf1,n2);
		nallele[nw-1]++;
		*/
                fprintf(stdout,"allele %s does not match\n",bf1);
                fprintf(stdout,"nl=%d bf %s\n",nl,bf);
                exit(1);
	      }
              allelecount[nw-1][allelematchflg1][npop1-1] ++;
	      /*     fprintf(stderr,"allelematchflg1=%d nw=%d npop1=%d",allelematchflg1,nw,npop1);*/

              allelematchflg2 =  -1;
	      for(j=0; j< nallele[nw-1]; j++){
                rn2 = strncmp_case(allelename_store[nw-1][j],bf1+n2,n2);
                if( rn2 == 0 ){
		  allelematchflg2 = j;
                  break;
		}
	      }
	      /*              fprintf(stderr,"allelematchflg2=%d ",allelematchflg2);*/
              if( allelematchflg2 == -1 ){
		/*
                n1 = nallele[nw-1];
		strncat(allelename_store[nw-1][n1],bf1+n2,n2);
		nallele[nw-1]++;
		*/
                fprintf(stdout,"allele %s does not match\n",bf1+n2);
                fprintf(stdout,"nl=%d bf %s\n",nl,bf);
                exit(1);
	      }
              allelecount[nw-1][allelematchflg2][npop1-1] ++;
	    }

            spflg = 1;
            continue;
	  }else{
            if( spflg == 1 ){
             clrbf(bf1,maxlinelen);
             spflg = 0;
             bf1[0] = bf[i];
             nc=1;
             nw++;
             continue;
	    }
            if( spflg == 0 ){
             bf1[nc] = bf[i];
             nc++;
             continue;
	    }
	  }
	}
	return(0);

}




int matchdelimiter(cw,delimiter)

     char cw,*delimiter;
{
  int i,nd;

  nd = strlen(delimiter);

  for(i=0; i< nd; i++){
    if( cw == delimiter[i] ){
      return(i);
    }
  }

  return(-1);

}

 removeendspace(b)
 char *b;
 {
   int i,n;

   n = strlen(b);
   for(i=n-1; i>=0; i--){
     if(b[i] == ' ' ){
       b[i] = 0;
       continue;
     }else{
       return(i);
     }
   }

   return(-1);  
 }


 removebothendspace(b)
 char *b;
 {
   int i,n,endpos,startpos;

   /*   fprintf(stderr,"b:(%s)\n",b);*/
   endpos = startpos = -1;
   n = strlen(b);
   for(i=n-1; i>=0; i--){
     if(b[i] == ' ' || b[i] == '\t' || b[i] == '\n' || b[i] == CR || b[i] == LF ){
       b[i] = 0;
       continue;
     }else{
       endpos = i;
       break;
     }
   }

   for(i=0; i<n; i++){
       if(b[i] == ' ' || b[i] == '\t' || b[i] == '\n' || b[i] == CR || b[i] == LF ){
         continue;
       }
       startpos = i;
       break;
   }
  
  for(i=startpos; i<=endpos; i++){
      b[i-startpos] = b[i];
    }
  for(i=endpos-startpos+1 ; i<n; i++){
      b[i] = 0;
   }
   return(-1);  
 }
int checkdataformat(fpi,bf,bf1,maxlinelen,genepopflg)
FILE *fpi;
int maxlinelen,*genepopflg;
char *bf,*bf1;
{
  int rn, rn1,rn2, nl,nl1, n, genepopf, poptreef, poptreef1;
  int stringst,stringend,stringst2,targetorder,targetorder1,targetorder2;
/* char bf[100],bf1[20];*/
  extern int dflg;

/* flg  0   initial
		  1   file name
        2   file name end
        3   sequence
   flg1 1   comment
 */


   (*genepopflg) = 0;
 
   genepopf =  poptreef = poptreef1 = 0;
   nl = nl1 = 0;

   for( ; ; ){
      clrbf(bf,maxlinelen);
      rn = rdline(fpi,bf, &n, maxlinelen);
      nl++;
      if( rn == -1 ){
        break;
      }
      if( rn == 1 ){
        continue;
      }
      if( rn == 2 ){
	printf("line %d line length exceeded the buffer size %d\n",nl,maxlinelen);
        exit(1);
      }
      nl1++;
      if( nl1 == 1 ){
	rn1 = getword(bf,n,bf1,maxlinelen,"populations",&targetorder1);
	rn2 = getword(bf,n,bf1,maxlinelen,"otus",&targetorder2);
        if( rn1 == 0 && targetorder1 == 2 ){
          poptreef1++;
	}
        if( rn2 == 0 && targetorder2 == 2 ){
          poptreef1++;
	}
        continue;
      }

      if( getword(bf,n,bf1,maxlinelen,"@locus",&targetorder) == 0 ) {
	if( targetorder == 1 ){
           poptreef++;
           continue;

	}         

      }
      if( getword(bf,n,bf1,maxlinelen,"#",&targetorder) == 0 ) {
	if( targetorder == 1 ){
           poptreef++;
           continue;

	}         

      }
      if( getword(bf,n,bf1,maxlinelen,"pop",&targetorder) == 0 ) {
	if( targetorder == 1 ){
           genepopf++;
           continue;
	}         
      }

   }

   /*   fprintf(stderr,"genepopf poptreef %d %d\n",genepopf,poptreef);*/

   if( genepopf > 0 && poptreef == 0 ){
     (*genepopflg) = 1;
     return(0);
   }

   if( poptreef > 0 && genepopf == 0 ){
     (*genepopflg) = 0;
     return(0);
   }

   if( poptreef = 0 && genepopf == 0 ){
     if( poptreef1 > 0 ){
       fprintf(stdout,"the first line indicates the data is poptree format. But, there are no data for loci\n");
       exit(1);
     }
     fprintf(stdout,"Input data is not in poptree format nor genepop format\n");
       exit(1);
   }
      

    return(-1);
}



int checkdata_genepop(fpi,bf,bf1,maxlinelen,nloci,npop,maxnm,maxlocname)
FILE *fpi;
int maxlinelen,*nloci,*npop,*maxnm, *maxlocname;
char *bf,*bf1;
{
  int rn, rn1,rn2, nl,nl1, n,nword,maxlen_word, popnamelen;
  int stringst,stringend,stringst2,targetorder;
  char delimiter_locus[10],delimiter_locus1[10];
/* char bf[100],bf1[20];*/
  extern int dflg;


/* flg  0   initial
	    1   file name
        2   file name end
        3   sequence
   flg1 1   comment
 */



  *nloci = *npop = *maxnm = *maxlocname = 0;

  clrbf(delimiter_locus,10);

  delimiter_locus[0] = ',';
  delimiter_locus[1] = '\n';
  delimiter_locus[2] = CR;
  delimiter_locus[3] = LF;

  /*
  clrbf(delimiter_locus1,10);
  delimiter_locus1[0] = ',';
  delimiter_locus1[1] = ' ';
  delimiter_locus1[2] = '\n';
  delimiter_locus1[3] = CR;
  delimiter_locus1[4] = LF;
  */

   nl = nl1 = 0;

   for( ; ; ){
      clrbf(bf,maxlinelen);
      rn = rdline(fpi,bf, &n, maxlinelen);
      nl++;
      /*      fprintf(stderr,"checkdata_genepop nl1=%d nloci=%d bf %s",nl1,*nloci,bf);*/
      if( rn == -1 ){
        break;
      }
      if( rn == 1 ){
        continue;
      }
      if( rn == 2 ){
	printf("line %d line length exceeded the buffer size %d\n",nl,maxlinelen);
        exit(1);
      }

      nl1++;

      if( nl1 == 1 ){
        continue;
      }

      targetorder = 1;
      rn1 = getword_order(bf,n,bf1,maxlinelen,targetorder);
      if( rn1 == 0 ){
	if( strcmp_case(bf1,"pop") == 0 ){
	  (*npop)++;
          targetorder = 2;
          rn2 = getword_order_popname(bf,n,bf1,maxlinelen,targetorder);
          if( rn2 == 0 ){
	     popnamelen = strlen(bf1);
             if( popnamelen > *maxnm ){
	       *maxnm = popnamelen;
	     }
	  }
          continue;
	}
      }
      if( (*npop) == 0 ){
 	 getword_nword_locusname(bf,n,bf1,maxlinelen,delimiter_locus,&nword,&maxlen_word);
        if( maxlen_word > *maxlocname ){
	  *maxlocname = maxlen_word;
	}
        (*nloci) += nword;
 	continue;
      }
  
      rn1 = getword_nword_locusdata(bf,n,bf1,maxlinelen,delimiter_locus,&nword,&maxlen_word);
      if( rn1 == -1 ){
	fprintf(stdout,"There is no comma in the locus data line\n");
	fprintf(stdout,"line=%d %s\n",nl,bf);
        exit(1);
      }
      if( nword != *nloci ){
	fprintf(stdout,"The number of data (%d) does not match the number of loci (%d)\n",nword, *nloci);
	fprintf(stdout,"line=%d %s\n",nl,bf);
        exit(1);
      }

   }



    return(0);
}




int checkdata_genepop_nallele(fpi,bf,bf1,maxlinelen,nloci,npop,maxnm,maxlocname,nallele,allelename_store)
FILE *fpi;
int maxlinelen,nloci,npop,maxnm, maxlocname,*nallele;
char *bf,*bf1,***allelename_store;
{
  int rn, rn1,rn2, nl,nl1, n,nword,maxlen_word, popnamelen;
  int stringst,stringend,stringst2,targetorder;
  int nloci1,npop1,maxnm1, maxlocname1;
  char delimiter_locus[10],delimiter_locus1[10];
/* char bf[100],bf1[20];*/
  extern int dflg;


/* flg  0   initial
	    1   file name
        2   file name end
        3   sequence
   flg1 1   comment
 */

  nloci1 = npop1 = maxnm1 = maxlocname1 = 0;


  clrbf(delimiter_locus,10);
  delimiter_locus[0] = ',';
  delimiter_locus[1] = '\n';
  delimiter_locus[2] = CR;
  delimiter_locus[3] = LF;

  /*
  clrbf(delimiter_locus1,10);
  delimiter_locus1[0] = ',';
  delimiter_locus1[1] = ' ';
  delimiter_locus1[2] = '\n';
  delimiter_locus1[3] = CR;
  delimiter_locus1[4] = LF;
  */

   nl = nl1 = 0;

   for( ; ; ){
      clrbf(bf,maxlinelen);
      rn = rdline(fpi,bf, &n, maxlinelen);
      nl++;
      if( rn == -1 ){
        break;
      }
      if( rn == 1 ){
        continue;
      }
      if( rn == 2 ){
	printf("line %d line length exceeded the buffer size %d\n",nl,maxlinelen);
        exit(1);
      }
      nl1++;
      if( nl1 == 1 ){
        continue;
      }
      /*     fprintf(stderr,"checkdata_genepop_nallele bf %s",bf);*/

      targetorder = 1;
      rn1 = getword_order(bf,n,bf1,maxlinelen,targetorder);
      if( rn1 == 0 ){
	if( strcmp_case(bf1,"pop") == 0 ){
	  npop1++;
          targetorder = 2;
          rn2 = getword_order(bf,n,bf1,maxlinelen,targetorder);          
          if( rn2 == 0 ){
	     popnamelen = strlen(bf1);
             if( popnamelen > maxnm1 ){
	       maxnm1 = popnamelen;
	     }
	  }
          continue;
	}
      }
      if( npop1 == 0 ){
 	 getword_nword_locusname(bf,n,bf1,maxlinelen,delimiter_locus,&nword,&maxlen_word);
        if( maxlen_word > maxlocname1 ){
	  maxlocname1 = maxlen_word;
	}
        nloci1 += nword;
 	continue;
      }
  
      rn1 = getword_nword_locusdata_nallele(bf,n,bf1,maxlinelen,delimiter_locus,nloci1,nl,&nword,&maxlen_word,nallele,allelename_store);
      if( rn1 == -1 ){
	fprintf(stdout,"There is no comma in the locus data line\n");
	fprintf(stdout,"line=%d %s\n",nl,bf);
        exit(1);
      }
      if( nword != nloci1 ){
	fprintf(stdout,"The number of data (%d) does not match the number of loci (%d)\n",nword, nloci1);
	fprintf(stdout,"line=%d %s\n",nl,bf);
        exit(1);
      }

   }



    return(0);
}



int getdata_genepop(fpi,bf,bf1,maxlinelen,nloci,npop,maxnm,maxlocname,nallele,allelename_store,locusname,popname,allelecount)
FILE *fpi;
int maxlinelen,nloci,npop,maxnm, maxlocname,*nallele;
char *bf,*bf1,***allelename_store,**locusname,**popname;
int ***allelecount/*nloci nallele npop*/;
{
  int rn, rn1,rn2, nl,nl1, n,nword,maxlen_word, popnamelen;
  int stringst,stringend,stringst2,targetorder;
  int nloci1,npop1,maxnm1, maxlocname1;
  int i,j,k;
  char delimiter_locus[10],delimiter_locus1[10];
  extern int dflg;
  /*  int getword_nword_locusname_get(char *bf, int n, char *bf1, int maxlinelen,char *delimiter_locus,int nloci1,int *nword,int *maxlen_word,char **locusname); */



/* flg  0   initial
	    1   file name
        2   file name end
        3   sequence
   flg1 1   comment
 */

  nloci1 = npop1 = maxnm1 = maxlocname1 = 0;

  clrbf(delimiter_locus,10);
  delimiter_locus[0] = ',';
  delimiter_locus[1] = '\n';
  delimiter_locus[2] = CR;
  delimiter_locus[3] = LF;

  /*
  clrbf(delimiter_locus1,10);
  delimiter_locus1[0] = ',';
  delimiter_locus1[1] = ' ';
  delimiter_locus1[2] = '\n';
  delimiter_locus1[3] = CR;
  delimiter_locus1[4] = LF;
  */

   nl = nl1 = 0;

   for( ; ; ){
      clrbf(bf,maxlinelen);
      rn = rdline(fpi,bf, &n, maxlinelen);
      nl++;
      if( rn == -1 ){
        break;
      }
      if( rn == 1 ){
        continue;
      }
      if( rn == 2 ){
	printf("line %d line length exceeded the buffer size %d\n",nl,maxlinelen);
        exit(1);
      }
      nl1++;
      if( nl1 == 1 ){
        continue;
      }
      /*      fprintf(stderr,"getdata_genepop bf %s",bf);*/

      targetorder = 1;
      rn1 = getword_order(bf,n,bf1,maxlinelen,targetorder);
      if( rn1 == 0 ){
	if( strcmp_case(bf1,"pop") == 0 ){
	  npop1++;
          targetorder = 2;
          rn2 = getword_order_popname(bf,n,bf1,maxlinelen,targetorder);
	  /*          fprintf(stderr,"rn2=%d bf1 %s npop1=%d ",rn2,bf1,npop1);*/
          if( rn2 == 0 ){
 	     strcat(popname[npop1-1],bf1);

	     /*
	     popnamelen = strlen(bf1);
             if( popnamelen > maxnm1 ){
	       maxnm1 = popnamelen;
	     }
	     */
	  }else{
            sprintf(popname[npop1-1],"pop%d",npop1);
	  }
          continue;
	}
      }
      if( npop1 == 0 ){
	/*        fprintf(stderr,"before getword_nword_locusname_get\n");*/
	getword_nword_locusname_get(bf,n,bf1,maxlinelen,delimiter_locus,nloci1,&nword,&maxlen_word,locusname);
        if( maxlen_word > maxlocname1 ){
	  maxlocname1 = maxlen_word;
	}
        nloci1 += nword;
 	continue;
      }
  
      rn1 = getword_nword_locusdata_nallele_get(bf,n,bf1,maxlinelen,delimiter_locus,nloci1,npop1,nl,&nword,&maxlen_word,nallele,allelename_store,allelecount);
      if( rn1 == -1 ){
	fprintf(stdout,"There is no comma in the locus data line\n");
	fprintf(stdout,"line=%d %s\n",nl,bf);
        exit(1);
      }
      if( nword != nloci1 ){
	fprintf(stdout,"The number of data (%d) does not match the number of loci (%d)\n",nword, nloci1);
	fprintf(stdout,"line=%d %s\n",nl,bf);
        exit(1);
      }

   }

   /*
   for(i=0; i< nloci1; i++){
     fprintf(stderr,"@locus %d %s\n",i+1,locusname[i]);
     for(j=0; j<nallele[i]; j++){
       fprintf(stderr,"%s *",allelename_store[i][j]);
       for(k=0; k<npop; k++){
         fprintf(stderr," %3d",allelecount[i][j][k]);
       }
       fprintf(stderr,"\n");
     }
   }
   */


    return(0);
}


int check_allelefrq(nloci0,npop0,nloci,npop,locusname0,popname0,allelename_store0,nallele0,allelecount0,nallele_pop,nallele1)
int nloci0,npop0,*nloci,*npop,*nallele0/*nloci*/,***allelecount0,**nallele_pop/*nloci npop*/,*nallele1/*nloci*/;
char **locusname0,**popname0,***allelename_store0/*nloci0,MAXALLELE_LOCUS,MAXALLELE_NAME*/;
 {
   int i,j,k,rn,nz;


   *nloci = *npop = 0;
   clr_ibf(nallele1,nloci0);
   clr_imatrix(nallele_pop,nloci0,npop0);

   for(i=0; i<nloci0; i++){
     for(j=0; j<nallele0[i]; j++){
       rn = checkletterzero(allelename_store0[i][j]);
       if( rn == 0 ){
	 continue;
       }
       for(k=0; k< npop0; k++){
	 nallele1[i] += allelecount0[i][j][k];
	 nallele_pop[i][k] += allelecount0[i][j][k];
       }
     }
     /*     fprintf(stderr,"i=%d nallele1 %d ",i,nallele1[i]);*/
     if( nallele1[i] != 0 ){
       (*nloci)++;
     }
   }
   /*
   fprintf(stderr,"\n");
     for(i=0; i<npop0; i++){
       fprintf(stderr,"i=%d popname %s",i,popname0[i]);
       for(j=0; j<nloci0; j++){
         fprintf(stderr," %d",nallele_pop[j][i]);
       }
       fprintf(stderr,"\n");
     }
   */

   for(i=0; i<npop0; i++){
     nz = 0;
     for(j=0; j<nloci0; j++){
        if( nallele1[j] == 0 ){
          continue;
         }

        if( nallele_pop[j][i] == 0 ){
 	  fprintf(stdout,"There is no data at locus %d %s for %d pop %s\n",j+1,locusname0[j],i+1,popname0[i]);
          nz++;
	}
     }
      if( nz == 0 ){
	  (*npop)++;
      }else{
        exit(1);
      }

   }

   /*   fprintf(stderr,"nloci0 npop0 %d %d  nloci npop %d %d\n",nloci0, npop0,*nloci,*npop);*/

  return(0);
 }



int get_allelefrq(nloci0,npop0,nloci,npop,locusname0,popname0,allelename_store0,nallele0,allelecount0,nallele_pop,nallele1,locusname,popname,allelename_store,allelecount,allelefrq,nallele,fstep,samplesz,dop)
     int nloci0,npop0,nloci,npop,*nallele0/*nloci*/,***allelecount0,***allelecount,**nallele_pop/*nloci npop*/,*nallele1/*nloci*/,*nallele/*nloci*/,dop;
char **locusname0,**popname0,***allelename_store0/*nloci0,MAXALLELE_LOCUS,MAXALLELE_NAME*/;
char **locusname,**popname,***allelename_store;
float ***allelefrq,**fstep,**samplesz;
 {
   int i,j,k,rn,nz,nza;
   int nloci1,npop1,nallelew;
   float fw;

   
   nz = 0;
   for(i=0; i<nloci0; i++){
     if( nallele1[i] == 0 ){
       continue;
     }

     for(k=0; k< npop0; k++){
	 if( nallele_pop[i][k] == 0 ) {
	   fprintf(stdout,"poplation %d %s does not have data at locus %d %s\n",k+1,popname0[k],i+1,locusname0[i]);
           nz++;
	 }

     }
   }

   if( nz > 0 ){
     exit(1);
   }



   nloci1 = npop1 = 0;
   for(i=0; i<nloci0; i++){
     if( nallele1[i] == 0 ){
       continue;
     }

     for(k=0; k< npop0; k++){
	 if( nallele_pop[i][k] == 0 ) {
	   continue;
	 }

     }
     strcat(locusname[nloci1], locusname0[i]);
     nallele[nloci1] = nallele1[i];
     nallelew = 0;
    
     for(j=0; j<nallele0[i]; j++){
       rn =  checkletterzero(allelename_store0[i][j]);
       if( rn == 0 ){
         continue;
       }
       strcat(allelename_store[nloci1][nallelew],allelename_store0[i][j]);
       npop1 = 0;
       for(k=0; k< npop0; k++){
	 if( nallele_pop[i][k] == 0 ) {
            continue;
	 }
         allelecount[nloci1][nallelew][npop1] = allelecount0[i][j][k];
         npop1++;
       }
       nallelew++;
     }
     nallele[nloci1] = nallelew;
     nloci1++;
   }
  

   npop1 = 0;
   for(i=0; i<npop0; i++){
     nz = 0;
     for(j=0; j<nloci0; j++){
       if( nallele1[j] == 0 ){
	 continue;
       }       
       if( nallele_pop[j][i] == 0 ){
	 nz++;
       }
     }
     if( nz > 0 ){
       continue;
     }
     strcat(popname[npop1],popname0[i]);
     npop1++;
   }
  
   /*   fprintf(stderr,"nloci0 npop0 %d %d  nloci1 npop1 %d %d\n",nloci0, npop0,nloci1,npop1);*/


   for(i=0; i<nloci ; i++){
     /*     fprintf(stderr,"@locus %d %s\n",i+1,locusname[i]);*/
     for(j=0; j<nallele[i]; j++){
       /*       fprintf(stderr,"%s *",allelename_store[i][j]);*/
       for(k=0; k<npop; k++){
	 /*           fprintf(stderr," %d",allelecount[i][j][k]);*/
           samplesz[i][k] += allelecount[i][j][k];
       }
       /*       fprintf(stderr,"\n");*/
       }
       /*       fprintf(stderr,"#");*/
     /*
       for(k=0; k<npop; k++){
           fprintf(stderr," %3.0f",samplesz[i][k]);
       }
       fprintf(stderr,"\n");
     */
   }  




   for(i=0; i<nloci ; i++){
     /*     fprintf(stderr,"@locus %d %s\n",i+1,locusname[i]);*/
     for(j=0; j<nallele[i]; j++){
       if( dop == 5 || dop == 6 ){ /* distance is Dmyu or Dsw */
	 rn = checkfnumber(allelename_store[i][j]);
         if( rn != 0 ){
           fprintf(stdout,"allele %s at %dth locus %s is not number\n",allelename_store[i][j],i+1,locusname[i]);
           exit(1);
	 }
         sscanf(allelename_store[i][j],"%f",&fw);
         fstep[i][j] = fw;
       }

       /*       fprintf(stderr,"%s %f*",allelename_store[i][j],fw);*/
       for(k=0; k<npop; k++){
	   allelefrq[i][j][k] = allelecount[i][j][k];
	   allelefrq[i][j][k] /= samplesz[i][k];
	   /*           fprintf(stderr," %5.3f",allelefrq[i][j][k]);*/
       }
       /*       fprintf(stderr,"\n");*/
       }
     /*       fprintf(stderr,"#");*/
     /*
       for(k=0; k<npop; k++){
           fprintf(stderr," %3.0f",samplesz[i][k]);
       }
       fprintf(stderr,"\n");
     */

   }  



  return(0);
 }



checkletterzero(b)
char *b;
{
  int i,n;

  n = strlen(b);
  for(i=0; i<n; i++){
    if( b[i] != '0' ){
      return(-1);    
    }
  }

  return(0);
}

int checkfnumber(b)
char *b;
{
  int i,n;

  n = strlen(b);
  for(i=0; i<n; i++){
    if( (b[i] >= '0' && b[i] <= '9') || (b[i] == '.') ){
      continue;
    }
    return(-1);
  }

  return(0);
}

njr(nseq,dist,node,branch0,otu,spair,sw,st,dcm,rij,seed1)
int nseq,**node/*[MAXOTU-2][3]*/;
long *seed1;
int *otu/*[MAXOTU]*/,**spair/*[MAXOTU*(MAXOTU-1)/2][2]*/,*sw/*[MAXOTU*(MAXOTU-1)/2]*/;
double *st/*[MAXOTU*(MAXOTU-1)/2]*/,*dcm/*[MAXOTU]*/,*rij/*[MAXOTU]*/;
double **dist/*[MAXOTU][MAXOTU]*/,**branch0/*[MAXOTU][3]*/;
{
int i,j,k,l,nsc,cyc,scnt,n1,n2,n3,nsm,nsw,rn;
double dw,sm,ds;
extern int dflg;


  nsc=nseq;

  for(i=0; i<nseq-2 ; i++){
    for(j=0; j<3 ; j++) node[i][j]=0;
  }
  for(i=0; i<nseq; i++) otu[i]=i+1;
  for(cyc=0; cyc<nseq-3; cyc++){
     scnt=0;
     ds=nsc-2;
     for(i=0; i<nsc ; i++){
        rij[i]=0.0;
        for(k=0; k<nsc ; k++){
             if( i < k ) rij[i] += dist[i][k];
             if( i > k ) rij[i] += dist[k][i];
         }
      }
     for(i=0; i<nsc-1; i++){
          for(j=i+1; j<nsc; j++){
          st[scnt]=dist[i][j]*ds-rij[i]-rij[j];
          spair[scnt][0]=i;
          spair[scnt][1]=j;
          if( scnt == 0 ) {
             sm=st[0];
             nsm = 0;
	   }else{
            if( st[scnt] < sm ){
               sm = st[scnt];
               nsm = scnt;
	     }
	  }
          scnt++;
	}
      }
      sw[0]=nsm;
      nsw=1;
      for(i=0; i<scnt ; i++){
         if( i == nsm ) continue;
         dw = st[i]-sm;
         if( dw < 0.0 ) dw *= -1.0;
         if( dw <= ACU ) {
           sw[nsw]=i;
           nsw++;
         }
       }
       if( nsw > 1 ){
          rn= ran1(seed1)*(float)nsw;
/*          rn = random()%nsw; */
          nsm = sw[rn];
	}
      n1=spair[nsm][0];
      n2=spair[nsm][1];
      node[cyc][0]=otu[n1];
      node[cyc][1]=otu[n2];
      dcm[cyc]=dist[n1][n2];
      branch0[cyc][0]=dist[n1][n2]/2.0+(rij[n1]-rij[n2])/(2.0*ds);
      branch0[cyc][1]=dist[n1][n2]/2.0+(rij[n2]-rij[n1])/(2.0*ds);
      if( otu[n1] > nseq ){
         n3=otu[n1]-nseq-1;
         branch0[cyc][0] -= dcm[n3]/2.0;
       }
      if( otu[n2] > nseq ){
         n3=otu[n2]-nseq-1;
         branch0[cyc][1] -= dcm[n3]/2.0;
       }
      for(k=0; k<nsc; k++) {
          if( k == n1 || k == n2 ) continue;
          if( n1 < k && n2 < k ) dist[n1][k] = (dist[n1][k] + dist[n2][k])/2.0;
          if( n1 < k && n2 > k ) dist[n1][k] = (dist[n1][k] + dist[k][n2])/2.0;
          if( n1 > k && n2 < k ) dist[k][n1] = (dist[k][n1] + dist[n2][k])/2.0;
          if( n1 > k && n2 > k ) dist[k][n1] = (dist[k][n1] + dist[k][n2])/2.0;
	}
      otu[n1]=nseq+cyc+1;
      for(k=n2; k<nsc-1; k++) otu[k]=otu[k+1];

      for(k=0; k< n2 ; k++){
         for(l=n2+1 ; l< nsc ; l++)  dist[k][l-1] = dist[k][l];
       }
       for(k=n2+1 ; k<nsc-1 ; k++){
         for(l=k+1 ; l<nsc ; l++) dist[k-1][l-1] =dist[k][l];
       }

   
     

/*      for(k=0; k<nsc ; k++){
        for(l=n2; l<nsc-1; l++){
           dist[k][l] =dist[k][l+1];
	 }
       }
      for(k=0; k<nsc ; k++){
         for(l=n2; l<nsc-1 ; l++){
           dist[l][k] =dist[l+1][k];
         }
       }
*/
       nsc--;
   
}

cyc=nseq-3;
 branch0[cyc][0]=(dist[0][1]+dist[0][2]-dist[1][2])/2.0;
 branch0[cyc][1]=(dist[0][1]-dist[0][2]+dist[1][2])/2.0;
 branch0[cyc][2]=(-dist[0][1]+dist[0][2]+dist[1][2])/2.0;
 for(i=0; i<3 ; i++){
   node[cyc][i]=otu[i];
   if( otu[i] > nseq ){
         n3=otu[i]-nseq-1;
         branch0[cyc][i] -= dcm[n3]/2.0;
       }
 }

 return(0);
}
           



njt(nseq,dist,node,branch0,otu,spair,st,dcm,rij)
int nseq,**node/*[MAXOTU-2][3]*/;
int *otu/*[MAXOTU]*/,**spair/*[MAXOTU*(MAXOTU-1)/2][2]*/;
double *st/*[MAXOTU*(MAXOTU-1)/2]*/,*dcm/*[MAXOTU]*/,*rij/*[MAXOTU]*/;
double **dist/*[MAXOTU][MAXOTU]*/,**branch0/*[MAXOTU][3]*/;
{
int i,j,k,l,nsc,cyc,scnt,n1,n2,n3,nsm;
double sm,ds;

float ran1();

  nsc=nseq;

  for(i=0; i<nseq-2 ; i++){
    for(j=0; j<3 ; j++) node[i][j]=0;
  }
  for(i=0; i<nseq; i++) otu[i]=i+1;
  for(cyc=0; cyc<nseq-3; cyc++){
     scnt=0;
     ds=nsc-2;
     for(i=0; i<nsc ; i++){
        rij[i]=0.0;
        for(k=0; k<nsc ; k++){
             if( i < k ) rij[i] += dist[i][k];
             if( i > k ) rij[i] += dist[k][i];
         }
      }
     for(i=0; i<nsc-1; i++){
          for(j=i+1; j<nsc; j++){
          st[scnt]=dist[i][j]*ds-rij[i]-rij[j];
          spair[scnt][0]=i;
          spair[scnt][1]=j;
          if( scnt == 0 ) {
             sm=st[0];
				 nsm = 0;
	   }else{
            if( st[scnt] < sm ){
               sm = st[scnt];
               nsm = scnt;
	     }
	  }
          scnt++;
	}
      }
/*
      sw[0]=nsm;
      nsw=1;
      for(i=0; i<scnt ; i++){
         if( i == nsm ) continue;
         dw = st[i]-sm;
         if( dw < 0.0 ) dw *= -1.0;
         if( dw <= ACU ) {
           (*tief)++;
           sw[nsw]=i;
           nsw++;
         }
       }
       if( nsw > 1 ){
          rn = random()%nsw;
          nsm = sw[rn];
	}
*/
      n1=spair[nsm][0];
      n2=spair[nsm][1];
      node[cyc][0]=otu[n1];
      node[cyc][1]=otu[n2];
      dcm[cyc]=dist[n1][n2];
      branch0[cyc][0]=dist[n1][n2]/2.0+(rij[n1]-rij[n2])/(2.0*ds);
      branch0[cyc][1]=dist[n1][n2]/2.0+(rij[n2]-rij[n1])/(2.0*ds);
      if( otu[n1] > nseq ){
         n3=otu[n1]-nseq-1;
         branch0[cyc][0] -= dcm[n3]/2.0;
       }
      if( otu[n2] > nseq ){
         n3=otu[n2]-nseq-1;
         branch0[cyc][1] -= dcm[n3]/2.0;
       }
      for(k=0; k<nsc; k++) {
          if( k == n1 || k == n2 ) continue;
          if( n1 < k && n2 < k ) dist[n1][k] = (dist[n1][k] + dist[n2][k])/2.0;
          if( n1 < k && n2 > k ) dist[n1][k] = (dist[n1][k] + dist[k][n2])/2.0;
          if( n1 > k && n2 < k ) dist[k][n1] = (dist[k][n1] + dist[n2][k])/2.0;
          if( n1 > k && n2 > k ) dist[k][n1] = (dist[k][n1] + dist[k][n2])/2.0;
	}
      otu[n1]=nseq+cyc+1;
      for(k=n2; k<nsc-1; k++) otu[k]=otu[k+1];

      for(k=0; k< n2 ; k++){
         for(l=n2+1 ; l< nsc ; l++)  dist[k][l-1] = dist[k][l];
       }
       for(k=n2+1 ; k<nsc-1 ; k++){
         for(l=k+1 ; l<nsc ; l++) dist[k-1][l-1] =dist[k][l];
       }

   
     

       nsc--;
   
}

cyc=nseq-3;
 branch0[cyc][0]=(dist[0][1]+dist[0][2]-dist[1][2])/2.0;
 branch0[cyc][1]=(dist[0][1]-dist[0][2]+dist[1][2])/2.0;
 branch0[cyc][2]=(-dist[0][1]+dist[0][2]+dist[1][2])/2.0;
 for(i=0; i<3 ; i++){
   node[cyc][i]=otu[i];
   if( otu[i] > nseq ){
         n3=otu[i]-nseq-1;
         branch0[cyc][i] -= dcm[n3]/2.0;
       }
 }

 return(0);
}
           






upg(nseq,dist,node0,branch0,otu,sij,nclus,dcm)
int nseq,**node0/*[MAXOTU-1][3]*/,*otu/*[MAXOTU]*/,*nclus/*[MAXOTU]*/;
int **sij/*[MAXOTU*(MAXOTU-1)/2][2]*/;
double **dist/*[MAXOTU][MAXOTU]*/,**branch0/*[MAXOTU][3]*/;
double *dcm/*[MAXOTU]*/;
{
int i,j,k,l,nsc,cyc,n1,n2;

double sm,dw1,dw2,dw3;
extern int dflg;


/*  printf("upg\n");
  for(i=0; i<nseq ; i++){
   for(j=0; j<nseq ; j++){
     if(i >= j) printf("         "); 
     if( i < j ) printf(" %f",dist[i][j]);
   }
   printf("\n");

 }
*/


  nsc=nseq;
  for(i=0; i< nseq-1 ; i++){
    for(j=0; j<3 ; j++) node0[i][j]=0;
  }
  for(i=0; i<nseq; i++) {
      otu[i]=i+1;
      nclus[i]=1;
    }
/*  printf("upg\n"); fflush(stdout); */
  for(cyc=0; cyc<nseq-1; cyc++){
     sm = 999999.0;
/*     printf("cyc=%d\n",cyc); fflush(stdout); */
     for(i=0; i<nsc-1; i++){
        for(j=i+1; j<nsc; j++){
          if( sm > dist[i][j] ){
             sm = dist[i][j];
             sij[0][0]=i;
             sij[0][1]=j;
	   }
	}
      }
/*     printf("sij\n"); fflush(stdout); */
/*
     scnt=1;
     for(i=0; i<nsc-1; i++){
        for(j=i+1; j<nsc; j++){
          if( i == sij[0][0] && j == sij[0][1] ) continue;
          if( sm+ACU >= dist[i][j]  &&  dist[i][j] >= sm-ACU ){
             sij[scnt][0]=i;
             sij[scnt][1]=j;
             scnt++;
	   }
	}
      }
*/
/*     printf("sij\n"); fflush(stdout); */
     n1=sij[0][0];
     n2=sij[0][1];

       node0[cyc][0]=otu[n1];
       node0[cyc][1]=otu[n2];
       dcm[cyc]=dist[n1][n2];
       if( otu[n1] <= nseq ){
             branch0[cyc][0]=dist[n1][n2]/2.0;
	   }else{
             branch0[cyc][0]=dist[n1][n2]/2.0 - dcm[otu[n1]-nseq-1]/2.0;
       }
       if( otu[n2] <= nseq ){
             branch0[cyc][1]=dist[n1][n2]/2.0;
	   }else{
             branch0[cyc][1]=dist[n1][n2]/2.0 - dcm[otu[n2]-nseq-1]/2.0;
       }
/*      printf("%d %f %f",cyc,branch0[cyc][0],branch0[cyc][1]); fflush(stdout);*/
		if( dflg == 1 ) printf("tie=%d n1=%d n2=%d\n",n1,n2);
      for(k=0; k<nsc; k++) {
          dw1 = nclus[n1]*nclus[k];
          dw2 = nclus[n2]*nclus[k];
          dw3 = nclus[n1]*nclus[k]+nclus[n2]*nclus[k];
          if( k == n1 || k == n2 ) continue;
          if( n1 < k && n2 < k ) dist[n1][k] = (dist[n1][k]*dw1 + dist[n2][k]*dw2)/dw3;
          if( n1 < k && n2 > k ) dist[n1][k] = (dist[n1][k]*dw1 + dist[k][n2]*dw2)/dw3;
          if( n1 > k && n2 < k ) dist[k][n1] = (dist[k][n1]*dw1 + dist[n2][k]*dw2)/dw3;
          if( n1 > k && n2 > k ) dist[k][n1] = (dist[k][n1]*dw1 + dist[k][n2]*dw2)/dw3;
	}
      otu[n1]=nseq+cyc+1;
      nclus[n1] += nclus[n2];
      for(k=n2; k<nsc-1; k++) {
          otu[k]=otu[k+1];
          nclus[k]=nclus[k+1];
	}
      if( dflg == 1 ) {
         printf("otu:");
         for(k=0; k<nsc ; k++ ) printf(" %d",otu[k]);
         printf("\n");
       }

      for(k=0; k< n2 ; k++){
         for(l=n2+1 ; l< nsc ; l++)  dist[k][l-1] = dist[k][l];
       }
       for(k=n2+1 ; k<nsc-1 ; k++){
         for(l=k+1 ; l<nsc ; l++) dist[k-1][l-1] =dist[k][l];
       }

   
       nsc--;
   }

 cyc=nseq-2;
 if( node0[cyc][0] == 2*nseq-2 ){
      node0[cyc-1][2]=node0[cyc][1];
      branch0[cyc-1][2]=branch0[cyc][0]+branch0[cyc][1];
    }

 if( node0[cyc][1] == 2*nseq-2 ){
      node0[cyc-1][2]=node0[cyc][0];
      branch0[cyc-1][2]=branch0[cyc][0]+branch0[cyc][1];
    }
/*
for(i=0; i<2*nseq-1 ; i++){
  printf("%f %f\n",branch0[i][0],branch0[i][1]);
}
*/
 return(0);
}


           









upgr(nseq,dist,node0,branch0,otu,sij,nclus,dcm,seed1)
int nseq,**node0/*[MAXOTU-1][3]*/,*otu/*[MAXOTU]*/,*nclus/*[MAXOTU]*/;
long *seed1;
int **sij/*[MAXOTU*(MAXOTU-1)/2][2]*/;
double **dist/*[MAXOTU][MAXOTU]*/,**branch0/*[MAXOTU][3]*/;
double *dcm/*[MAXOTU]*/;
{
int i,j,k,l,nsc,cyc,scnt,n1,n2;
int rn;
double sm,dw1,dw2,dw3;
extern int dflg;



  nsc=nseq;
  for(i=0; i< nseq-1 ; i++){
    for(j=0; j<3 ; j++) node0[i][j]=0;
  }
  for(i=0; i<nseq; i++) {
      otu[i]=i+1;
      nclus[i]=1;
    }
/*  printf("upg\n"); fflush(stdout); */
  for(cyc=0; cyc<nseq-1; cyc++){
     sm = 999999.0;
/*     printf("cyc=%d\n",cyc); fflush(stdout); */
     for(i=0; i<nsc-1; i++){
        for(j=i+1; j<nsc; j++){
          if( sm > dist[i][j] ){
             sm = dist[i][j];
             sij[0][0]=i;
             sij[0][1]=j;
	   }
	}
      }
/*     printf("sij\n"); fflush(stdout); */
     scnt=1;
     for(i=0; i<nsc-1; i++){
        for(j=i+1; j<nsc; j++){
          if( i == sij[0][0] && j == sij[0][1] ) continue;
          if( sm+ACU >= dist[i][j]  &&  dist[i][j] >= sm-ACU ){
             sij[scnt][0]=i;
             sij[scnt][1]=j;
             scnt++;
	   }
	}
      }

/*     printf("sij\n"); fflush(stdout); */
     n1=sij[0][0];
     n2=sij[0][1];
	  if( scnt > 1 ){
		  rn = ran1(seed1)*(float)scnt;
        n1 = sij[rn][0];
        n2 = sij[rn][1];
      }
       node0[cyc][0]=otu[n1];
       node0[cyc][1]=otu[n2];
       dcm[cyc]=dist[n1][n2];
       if( otu[n1] <= nseq ){
             branch0[cyc][0]=dist[n1][n2]/2.0;
	   }else{
             branch0[cyc][0]=dist[n1][n2]/2.0 - dcm[otu[n1]-nseq-1]/2.0;
       }
       if( otu[n2] <= nseq ){
             branch0[cyc][1]=dist[n1][n2]/2.0;
	   }else{
             branch0[cyc][1]=dist[n1][n2]/2.0 - dcm[otu[n2]-nseq-1]/2.0;
       }
/*      printf("%d %f %f",cyc,branch0[cyc][0],branch0[cyc][1]); fflush(stdout);*/
		if( dflg == 1 ) printf("tie=%d n1=%d n2=%d\n",n1,n2);
      for(k=0; k<nsc; k++) {
          dw1 = nclus[n1]*nclus[k];
          dw2 = nclus[n2]*nclus[k];
          dw3 = nclus[n1]*nclus[k]+nclus[n2]*nclus[k];
          if( k == n1 || k == n2 ) continue;
          if( n1 < k && n2 < k ) dist[n1][k] = (dist[n1][k]*dw1 + dist[n2][k]*dw2)/dw3;
          if( n1 < k && n2 > k ) dist[n1][k] = (dist[n1][k]*dw1 + dist[k][n2]*dw2)/dw3;
          if( n1 > k && n2 < k ) dist[k][n1] = (dist[k][n1]*dw1 + dist[n2][k]*dw2)/dw3;
          if( n1 > k && n2 > k ) dist[k][n1] = (dist[k][n1]*dw1 + dist[k][n2]*dw2)/dw3;
	}
      otu[n1]=nseq+cyc+1;
      nclus[n1] += nclus[n2];
      for(k=n2; k<nsc-1; k++) {
          otu[k]=otu[k+1];
          nclus[k]=nclus[k+1];
	}
      if( dflg == 1 ) {
         printf("otu:");
         for(k=0; k<nsc ; k++ ) printf(" %d",otu[k]);
         printf("\n");
       }

      for(k=0; k< n2 ; k++){
         for(l=n2+1 ; l< nsc ; l++)  dist[k][l-1] = dist[k][l];
       }
       for(k=n2+1 ; k<nsc-1 ; k++){
         for(l=k+1 ; l<nsc ; l++) dist[k-1][l-1] =dist[k][l];
       }

   
       nsc--;
   }

 cyc=nseq-2;
 if( node0[cyc][0] == 2*nseq-2 ){
      node0[cyc-1][2]=node0[cyc][1];
      branch0[cyc-1][2]=branch0[cyc][0]+branch0[cyc][1];
    }

 if( node0[cyc][1] == 2*nseq-2 ){
      node0[cyc-1][2]=node0[cyc][0];
      branch0[cyc-1][2]=branch0[cyc][0]+branch0[cyc][1];
    }
/*
for(i=0; i<2*nseq-1 ; i++){
  printf("%f %f\n",branch0[i][0],branch0[i][1]);
}
*/
 return(0);
}


           









njtndp(nseq,node,nodes,ncn)
int nseq,**node/*[MAXOTU-1][3]*/;
Nodc **nodes/*[MAXOTU-2]*/;
char *ncn/*[MAXOTU-2]*/;
{
int i,j,k,nc,flg;
extern int dflg;


for(i=0; i<nseq-2 ; i++){
   nc=2;
   ncn[i]=0;
   if( i == nseq-3 ) nc=3;
   for(j=0; j<nc ; j++) {
      if( node[i][j] <= nseq ){
          nodes[i]->childn[j]=node[i][j];
          nodes[i]->childio[j]= 0;
          continue;
	}
        nodes[i]->childn[j]=node[i][j]-nseq;
        nodes[i]->childio[j]= 1;
    }
}
for(i=0; i<nseq-3; i++){
  flg =0;
  for(j=0; j<nseq-2; j++){
    if( i == j ) continue;
    nc=2;
    if( j == nseq-3 ) nc=3;
    for(k=0; k<nc ; k++){
      if( node[j][k] == i+nseq+1 ) {
        flg =1;
        nodes[i]->childn[2]=j+1;
        nodes[i]->childio[2]= 1;
        break;
      }
    }
    if( flg == 1) break;
  }
}

if( dflg == 2){
   for(i=0; i<nseq-2 ; i++){
     printf("nodes %d:",i);
     for(j=0;j<3 ; j++) printf("%d %d  ",nodes[i]->childio[j],nodes[i]->childn[j]);
     printf("\n");
   }
 }

if( dflg == 2){
   for(i=0; i<nseq-2 ; i++){
     printf("nodes %d:",i);
     for(j=0;j<3 ; j++) printf("%d %d  ",nodes[i]->childio[j],nodes[i]->childn[j]);
     printf("\n");
   }
 }
return(0);
}


parti(nseq,nodes,part,bri,rlo,rli,chf)
int nseq,**bri/*[MAXOTU-3][2]*/;
Nodc **nodes/*[MAXOTU-2]*/;
char **part/*[MAXOTU-3][MAXOTU]*/,*rlo,*rli,*chf;
{
int i,j,k,nb,flg,iw;
int nbri,nr,nl,or,ol,ns;
/* char rlo[MAXOTU],rli[MAXOTU-2],chf[MAXOTU-2];*/

/* printf("parti start nseq=%d\n",nseq);  */
nbri=0;
for(i=0; i<nseq-2; i++){
  for(j=0; j<3 ; j++) {
    if(  nodes[i]->childio[j] ==  1 && nodes[i]->childn[j] < i+1 ){
         bri[nbri][0]= nodes[i]->childn[j];
         bri[nbri][1]= i+1;
/*         printf("%d   %d %d\n",nbri,bri[nbri][0],bri[nbri][1]);  */
         nbri++;
       }
  }
}
/*  for(i=0; i<nseq-2; i++) printf("node %d  %d (%d) %d (%d) %d (%d)\n",i,nodes[i].childn[0],nodes[i].childio[0],nodes[i].childn[1],nodes[i].childio[1],nodes[i].childn[2],nodes[i].childio[2]);
    }
*/
if( nbri != nseq-3 ){
    printf("number of internal branches invalid %d\n",nbri);
    exit(1);
  }

for(nb=0; nb < nbri ; nb++){
   for(i=0; i<nseq-2 ; i++){
        chf[i]=0;
        rli[i]=' ';
      }
   for(i=0; i<nseq ; i++) {
     rlo[i]=' ';
     part[nb][i]=0;
   }
   or=bri[nb][0];
   ol=bri[nb][1];
   nr=0;
   nl=0;
   for(i=0; i<3 ; i++){
      if( nodes[or-1]->childio[i] == 1 && nodes[or-1]->childn[i] == ol ) continue;
      switch(nodes[or-1]->childio[i] ){
          case 1:  iw = nodes[or-1]->childn[i]-1; rli[iw]='r';
                   break;
          case 0 : iw = nodes[or-1]->childn[i]-1;
                   rlo[iw]='r';
                   nr++;
                   break;
	}
    }
   for(i=0; i<3 ; i++){
      if( nodes[ol-1]->childio[i] == 1 && nodes[ol-1]->childn[i] == or ) continue;
      switch(nodes[ol-1]->childio[i]){
          case 1 :  iw = nodes[ol-1]->childn[i]-1;
                    rli[iw]='l';
                    break;
          case 0 :  iw = nodes[ol-1]->childn[i]-1;rlo[iw]='l';
                    nl++;
                    break;
	}
    }
    chf[or-1]=1;
    chf[ol-1]=1;
    ns=2;
  for( ; ; ){
    for(i=0; i< nseq-2 ; i++){
/*
      printf("i=%d nseq=%d nb=%d ns=%d\n",i,nseq,nb,ns); 
      printf("chf ");
      for(j=0; j< nseq-2 ; j++) printf(" %d",chf[j]);
      printf("\n");
      printf("rli ");
      for(j=0; j< nseq-2 ; j++) printf(" %c",rli[j]);
      printf("\n");
      printf("rlo ");
      for(j=0; j< nseq ; j++) printf(" %c",rlo[j]);
      printf("\n");
*/
      if( ns >= nseq-2 && nseq == 4 ) goto S1;
      if( chf[i] == 1 ) continue;
      if( rli[i] == ' '  ) continue; 
      switch( rli[i] ){
         case  'r':
                   for(j=0; j<3 ; j++){
                     iw = nodes[i]->childn[j]-1;
                     if( nodes[i]->childio[j] == 1 && rli[iw] == 'r' )
 continue;
                     switch(nodes[i]->childio[j]) {
                       case 1 : iw = nodes[i]->childn[j]-1; rli[iw]='r';
                                break;
                       case 0 : iw = nodes[i]->childn[j]-1;
                                rlo[iw]='r';
                                nr++;
                                break;
		     }
		   }
                    ns++;
/*                    printf("ns=%d nseq=%d (1)\n",ns,nseq);*/
                    if( ns >= nseq-2 ) goto S1;
                    break;
        case  'l' :
           for(j=0; j<3 ; j++){
             iw = nodes[i]->childn[j]-1;
             if( nodes[i]->childio[j] == 1 && rli[iw] == 'l' )
continue;
             switch( nodes[i]->childio[j]) {
                 case 1 : iw = nodes[i]->childn[j]-1; rli[iw]='l';
                          break;
                 case 0 : iw = nodes[i]->childn[j]-1;
                          rlo[iw]='l';
                          nl++;
		  }
	   }
           ns++;
/*           printf("ns=%d nseq=%d (2)\n",ns,nseq); */
           if( ns >= nseq-2 ) goto S1;
           break;
		 }
        chf[i]=1;
    }
  }
S1:    if( nl+nr != nseq ) {
      printf("nl=%d nr=%d nseq=%d\n",nl,nr,nseq);
      exit(1);
    }
/*     printf("nl=%d nr=%d nseq=%d\n",nl,nr,nseq); */
   
    if( nl < nr ){
        for(i=0; i<nseq ; i++){
          if( rlo[i] == 'l' ) part[nb][i]=1;
        }
      }
    if( nl >= nr ){
        for(i=0; i<nseq ; i++){
          if( rlo[i] == 'r' ) part[nb][i]=1;
        }
      }
/*
    printf("rlo:");
    for(i=0; i<nseq ; i++){
      printf(" %c",rlo[i]);
    }
    printf("\n");
    printf("part:");
    for(i=0; i<nseq ; i++){
      printf(" %d",part[nb][i]);
    }
    printf("\n");
*/

  
 }

  
if( dflg == 1 ) {
   for(i=0; i<nseq-3 ; i++){
     for(j=0; j<nseq ; j++){
        printf(" %d",part[i][j]);
      }
     printf("\n");
   }
 }
/*  printf("parti return\n");  */
return(0);
}








reloci(nloci,rloci,seed)
int nloci,*rloci;
long *seed;
{
int i,rn;


for(i=0; i<nloci ; i++){
/*   rn=random()%nloci; */
	rn= ran1(seed)*(float)(nloci);
	rloci[i]=rn;
/*   printf("rn=%d seed=%d\n",rn,*seed); */
 }
return(0);
}
caldist(napop,apop,nloci,rloci,nallele,allelefrq,samplesz,dist,dop,pflg,fstep,mstep,vflg,avar)
int nloci,*rloci,*nallele,dop,*apop,napop,pflg;
float ***allelefrq,**samplesz,**fstep;
double **dist,*mstep,*avar;
{
int i,j,k,l,nc,n1,n2,k1,k2;
 double sxy,jx,jy,jxy,jxy1,jx1,jy1,sx,sy,jxa,jya,dw,dsz1,dsz2,dv,jxb,jyb;

extern int dflg;

if( vflg == 1 ){

 for(i=0; i<napop ; i++) {
			avar[i] = 0.0;
		 }

 for(i=0; i< nloci ; i++){
	 printf("@locus %d",i+1); fflush(stdout);
	 nc = rloci[i];
	 for(j=0; j<napop ; j++){
		jx = 0.0;
		jxa = 0.0;
		n1 = apop[j];
		sx = samplesz[nc][n1];
		dv = 0.;
		for(k=0; k< nallele[nc] ; k++){
		  for(l=k+1; l< nallele[nc] ; l++){
				dw = (fstep[nc][k]- fstep[nc][l])*(fstep[nc][k]- fstep[nc][l]);
				dw *= (double)allelefrq[nc][k][j]*(double)allelefrq[nc][l][j];
				dv += dw;
				avar[j] += dw;
	  }
		}
				printf("  %0.3f",dv);  fflush(stdout);
	 }
	 printf("\n");  fflush(stdout);
  }
 printf("ave. ");
for(i=0; i<napop ; i++){
 avar[i] /= nloci;
 printf(" %0.3f", avar[i]);  fflush(stdout);
}
printf("\n");  fflush(stdout);
}







if( dop == 5 ){
/*   printf("dop=%d\n",dop); fflush(stdout); */


	for(i=0; i< napop-1 ; i++){
	 for(j=i+1; j< napop ; j++) dist[i][j]=dist[j][i]=0.;
  }

	for( k=0; k< nloci ; k++){
	  nc = rloci[k];
	  if( pflg == 1 ) printf("locus %2d\n",nc+1);
	  for(i=0; i<napop ; i++){
		 mstep[i]=0.0;
		 n1 = apop[i];
		 if( samplesz[nc][n1] <= 0. + ACU ) continue;
		 for(j=0; j< nallele[nc] ; j++){
		         mstep[i] += (double)((fstep[nc][j]))*(double)allelefrq[nc][j][n1];
/*          printf("nstep=%d afrq=%f\n",nstep[nc][j],allelefrq[nc][j][n1]); */
		 }
		 /*( if( pflg == 1 )  printf(" %3.1f",mstep[i]*dunit[nc]);fflush(stdout);*/
	  }
	  if( pflg == 1 ) printf("\n");
	  for(i=0; i<napop-1 ; i++){
			 n1 = apop[i];
			 for(j=i+1; j< napop ; j++){
			  n2 = apop[j];
			  if( samplesz[nc][n1] <= 0. + ACU || samplesz[nc][n2] <= 0. + ACU ) continue;
			  dw = (mstep[i]-mstep[j])*(mstep[i]-mstep[j]);
			  dist[i][j] += dw;
			  dist[j][i] += 1.;
	 }
	}
	}

	for(i=0; i< napop-1 ; i++){
	 for(j=i+1 ; j< napop ; j++){
				 dist[i][j] /= dist[j][i];
		  if( pflg == 1)  {
				printf(" dist=%4.2f",dist[i][j]); fflush(stdout);
	  }
	  }
	  if( pflg == 1 ) printf("\n");
  }
 }


if( dop == 6 ){
 /*printf("dop=%d\n",dop); fflush(stdout); */

	  for(i=0; i<napop-1 ; i++){
			 n1 = apop[i];
			 for(j=i+1; j< napop ; j++){
			  n2 = apop[j];
			  dist[i][j] = dist[j][i] = 0.;
			  jxy=0.; jx=jy=0.;
			  for(k = 0; k< nloci ; k++){
				  nc = rloci[k];
				  if( samplesz[nc][n1] <= 0. + ACU || samplesz[nc][n2] <= 0. + ACU ) continue;
					dist[j][i] += 1.;
					dsz1 = samplesz[nc][n1];
					dsz2 = samplesz[nc][n2];
					jx1=jy1=0.;
					for(k1=0; k1< nallele[nc] ; k1++){
					 for(k2=0 ; k2 <nallele[nc]; k2++){
						  if( k1 == k2 ) continue;
						  dw = fstep[nc][k1] - fstep[nc][k2];
						  if( dw < 0. ) dw *= -1.;
						  if( dw <= ACU ) continue;

					  /*   dw /= dunit[nc]; */
						  jx1 += dw * allelefrq[nc][k1][n1] * allelefrq[nc][k2][n1];
						  jy1 += dw * allelefrq[nc][k1][n2] * allelefrq[nc][k2][n2];

						  jxy += dw * allelefrq[nc][k1][n1] * allelefrq[nc][k2][n2];

		  }
		}
		 jx += jx1*dsz1/(dsz1-1.);
		 jy += jy1*dsz2/(dsz2-1.);

		 }

				dist[i][j] = jxy - (jx+jy)/2.;
				dist[i][j] /= dist[j][i];

		/*    printf("%d %d dist=%f jx=%f jy=%f jxy=%f\n",i,j,dist[i][j],jx,jy,jxy); fflush(stdout);  */

	}
 }

}

if( dop <= 4 ){
 for(i=0; i< napop-1 ; i++){
	for(j=i+1; j<napop; j++){
		sxy=jx=jy=jxy=jxb=jyb=0.0;
		n1 = apop[i];
		n2 = apop[j];
		for(k=0; k<nloci ; k++){
		  nc= rloci[k];
		  jxa=jya=0.0;
		  for(l=0; l< nallele[nc] ; l++){
			 jxy1 = allelefrq[nc][l][n1]*allelefrq[nc][l][n2];
			 switch(dop){
				  case 0 :   /* da */
								  sxy += sqrt(jxy1);
								  /*								  printf("%d %d nc=%d n1=%d n2=%d l=%d jxy1=%f frq %f %f sxy=%f\n",i,j,nc,n1,n2,l,jxy1,allelefrq[nc][l][n1],allelefrq[nc][l][n2],sxy);*/

								 break;
				  case 1:   /* ds */
				  case 2:   /* bunc ds */
				  case 3:   /* fst */
				  case 4:   /* bunc fst */

								 jx1 = allelefrq[nc][l][n1]*allelefrq[nc][l][n1];
								 jy1 = allelefrq[nc][l][n2]*allelefrq[nc][l][n2];
								 sx = samplesz[nc][n1];
								 sy = samplesz[nc][n2];
								 jxy += jxy1;
								 jxa  += jx1;
								 jya  += jy1;
								 break;
			}
		  }
								 jx  += (jxa*sx-1.0)/(sx-1.0);
								 jy  += (jya*sy-1.0)/(sy-1.0);
								 jxb += jxa;
								 jyb += jya;

		}
		switch(dop){
			 case 0: /* da */
						sxy /= nloci;
						dist[i][j] = 1.0 - sxy;
						if( pflg ==1 )  printf(" %1.3f",dist[i][j]);
						break;
			 case 1:
			 case 2:
	 	         case 3:
		         case 4:
			   /* dst */
			   /* bunc dst */
			   /* fst */
			   /* bunc fst */
                                                 jx /= nloci;
						 jy /= nloci;
                                                 jxb /= nloci;
						 jyb /= nloci;
						 jxy /= nloci;
                                                 if( dop == 1 ){ 
						   if( jx*jy <= 0.0 + ACU ) return(-1);
						   if( jxy <= 0.0 + ACU ){
							  printf("no shared allele between %d %d infinite distance\n",i+1,j+1);
							  return(-1);

						   }
						   dist[i][j] = -log(jxy/sqrt(jx*jy));
						 }
                                                 if( dop == 2 ){ 
						   if( jx*jy <= 0.0 + ACU ) return(-1);
						   if( jxy <= 0.0 + ACU ){
							  printf("no shared allele between %d %d infinite distance\n",i+1,j+1);
							  return(-1);

						   }
						   dist[i][j] = -log(jxy/sqrt(jxb*jyb));
						 }
                                                 if( dop == 3 ){
						   dist[i][j] = ((jx+jy)/2.0-jxy)/(1.0-jxy);
						 }
                                                 if( dop == 4 ){
						   dist[i][j] = ((jxb+jyb)/2.0-jxy)/(1.0-jxy);
						 }
						 if( pflg ==1 ) printf(" %1.3f",dist[i][j]);
/*                   printf("%d %d jx=%f jy=%f jxy=%f dis=%f\n",i,j,jx,jy,jxy,dist[i][j]); */
						 break;
		}
	 }
  if( pflg ==1 )  printf("\n");
 }
}




return(0);

}

int cpart(nseq,part,partb,npart,bw,pw1,pw2)
int nseq;
long *npart;
int *bw;
char *pw1,*pw2;
char **part/*[MAXOTU-3][MAXOTU]*/,**partb/*[MAXOTU-3][MAXOTU]*/;
{
int i,j,k,np,ncf1,ncf2,nb;

np=nseq-3;
/*
printf("part\n");
for(i=0; i<np ; i++){
  for(j=0; j<nseq ; j++) printf(" %d",part[i][j]);
  printf("\n");
}
printf("partb\n");
for(i=0; i<np ; i++){
  for(j=0; j<nseq ; j++) printf(" %d",partb[i][j]);
  printf("\n");
}
*/
for(i=0; i<np ; i++) bw[i]=i;
nb = np;
for(i=0; i<np ; i++){
  for(j=0; j<nseq ; j++){
     pw1[j]=part[i][j];
     switch(part[i][j]){
       case 0 : pw2[j]=1;
                break;
       case 1 : pw2[j]=0;
                break;
       }
   }
       for(j=0; j<nb ; j++){
           ncf1=0;
           ncf2=0;
          for(k=0; k<nseq ; k++){
             if( pw1[k] != partb[bw[j]][k] ) {
                ncf1=1;
                break;
	      }
           }
          if( ncf1 == 0 ) {
             npart[i]++;
             for(k=j; k<nb-1 ; k++) bw[k]=bw[k+1];
             nb--;
             break;
	   }
          for(k=0; k<nseq ; k++){
             if( pw2[k] != partb[bw[j]][k] ) {
                ncf2=1;
                break;
	      }
           }
        
          if( ncf2 == 0 ) {
             npart[i]++;
             for(k=j; k<nb-1 ; k++) bw[k]=bw[k+1];
             nb--;
             break;
	   }
	 }
}
/*
printf("pb:");
for(i=0; i<np ; i++) printf(" %d",pb[i]);
printf("\n");
printf("npart:");
for(i=0; i<np ; i++) printf(" %d",npart[i]);
printf("\n");
*/
return(0);
}
   











#define M1 259200L
#define IA1 7141L
#define IC1 54773L
#define RM1 (1.0/M1)
#define M2 134456L
#define IA2 8121L
#define IC2 28411L
#define RM2 (1.0/M2)
#define M3 243000L
#define IA3 4561L
#define IC3 51349L
/* generate uniform random number >= 0 && < 1 */
/* if you want generate random number from 0 to n-1
 *  multiply by n
 *  set *idum by any negative value. The sequence is reset.
 */
float ran1(idum)
long *idum;
{
static long ix1,ix2,ix3;
static float r[98];
float temp;
static int iff=0;
long j;

if( *idum < 0 || iff == 0 ){
   iff = 1;
	ix1 = (IC1 - (*idum)) % M1;
   ix1 = (IA1*ix1+IC1) % M1;
   ix2 = ix1 % M2;
   ix1 = (IA1*ix1+IC1) % M1;
   ix3 = ix1 % M3;
   for(j=1 ; j<97 ; j++){
     ix1 =(IA1*ix1+IC1) % M1;
     ix2 =(IA2*ix2+IC2) % M2;
	  r[j] =(ix1+ix2*RM2)*RM1;
   }
   *idum = 1;
 }

 ix1 = (IA1*ix1+IC1) % M1;
 ix2 = (IA2*ix2+IC2) % M2;
 ix3 = (IA3*ix3+IC3) % M3;
 j = 1 + ((97*ix3)/M3);
 if( j > 97 || j < 1 ) {
	printf("ran1(): j = %d \n");
   exit(1);
 }
 temp = r[j];
 r[j]=(ix1 + ix2*RM2)*RM1;
 return(temp);
}


hetero(fpo,napop,apop,nloci,allelefrq, samplesz,nallele,popname,rloci,buncflg)
int napop, *apop,nloci,*nallele, *rloci, buncflg;
float ***allelefrq,**samplesz;
char **popname;
FILE *fpo;

{

int i,j,k,l,nc,n1,n2,nl,na;

double js1,gst,dst1,hs1,gst1,jkl,jx,jxa,gstj,gstvar,hmz1,hs11,ht1,jt1,gst2,gst2a;
double dw,sx,hm,hm1,dw1,hmza,dw2,h1,h2;
double jostD,hedrickGst,jostD1,hedrickGst1, jostD_j,hedrickGst_j,gst2a_j;
double jostD_var,hedrickGst_var,gst2a_var;
double *da1,*da2,*heteroz1,dnapop;
double *heteroz;
extern double hetero1();

 heteroz  = dvector(napop+1);
 heteroz1 = dvector(napop+1);
 for(i=0; i< napop+1 ; i++){
   heteroz[i] = heteroz1[i] = 0.;
 }

	fprintf(fpo,"   %d otus\n",napop);
	for(i=0; i<napop ; i++){
	  fprintf(fpo,"%d %s\n",i+1,popname[apop[i]]);
	 }
	 fflush(fpo);
 for(i=0; i<napop ; i++) heteroz[i] = 0.0;
 if( buncflg == 0 ){
   fprintf(fpo,"\nHeterozygosity and Gst\n");
 }
 if( buncflg == 1 ){
   fprintf(fpo,"\nHeterozygosity and Gst uncorrected\n");
 }
 fprintf(fpo,"Locus");

 for(i=0; i< napop ; i++) {
	fprintf(fpo," ");
	nc = strlen(popname[apop[i]]);
	if( nc >= 5 ){
		for(j=0; j<5 ; j++ ) fprintf(fpo,"%c",popname[apop[i]][j]);
		}else{
		for(j=0; j< 5-nc ; j++ ) fprintf(fpo," ");
		for(j=0; j< nc ; j++ ) fprintf(fpo,"%c",popname[apop[i]][j]);
	}
 }

 fprintf(fpo,"  Gst Hedrick Jost\n");

 fprintf(fpo,"     ");
 for(i=0; i< napop ; i++) {
	fprintf(fpo," ");
	for(j=0; j< 5 ; j++ ) fprintf(fpo," ");
 }
 fprintf(fpo,"       Gst'    D\n");

 gst = 0.;
 gst2a = 0.;
 jostD = hedrickGst = 0.;
 for(i=0; i< nloci ; i++){
	 fprintf(fpo,"%5d",i+1); fflush(fpo);
	 nc = i;
	 dst1 = 0.;
	 jkl=0.;
	 dw = 0.;
         hm1=0.;
	 for(k=0; k< napop ; k++){
		n1 = apop[k];
                dw=samplesz[nc][n1];
                hm1 += 1./dw;
	 }
         hm1 /= napop;
         hm = 1./hm1;
         jt1 = 0.;
         dw = 0.;
	 for(j=0; j< nallele[nc] ; j++){
                dw1 = 0.;
		for(k=0; k< napop ; k++){
			n1 = apop[k];
			dw += allelefrq[nc][j][n1]*allelefrq[nc][j][n1];
                        dw1 += allelefrq[nc][j][n1];
			for(l=k+1; l< napop ; l++ ) {
			  n2 = apop[l];
			  jkl += allelefrq[nc][j][n1]*allelefrq[nc][j][n2];
			 }

		 }
                 dw1 /= napop;
                 jt1 += dw1*dw1;
	 }


	 dst1 = (dw*(double)((napop-1))- jkl*2.)/((double)(napop*napop));

	 js1 = dw/(double)napop;
         hmza = 0.;
         h1 = 0.;
	 for(j=0; j<napop ; j++){
		jx = 0.0;
		jxa = 0.0;
		n1 = apop[j];
		sx = samplesz[nc][n1];
		for(k=0; k< nallele[nc] ; k++){
			jxa += allelefrq[nc][k][n1]*allelefrq[nc][k][n1];
		 }
	         jx =  (jxa*sx-1.0)/(sx-1.0);
                 if( buncflg == 0 ){               
                    hmza += jx;
   		    heteroz[j] += 1.0 - jx;
                    h1 +=  1.0 - jx;
		    heteroz1[j] += (1.0 - jx)*(1.0 - jx);
		 }
                 if( buncflg == 1){
                    hmza += jxa;
   		    heteroz[j] += 1.0 - jxa;
                    h1 +=  1.0 - jxa;
		    heteroz1[j] += (1.0 - jxa)*(1.0 - jxa);
		 }
/*

		 if( jx <= 0.0+ACU ){

			printf("jx=%f jxa=%f sx=%f\n",jx,jxa,sx);
		 }
*/
                 if( buncflg == 0 ){
		    fprintf(fpo," %5.3f",1.0-jx);  fflush(stdout);
		 }
                 if( buncflg == 1 ){
		    fprintf(fpo," %5.3f",1.0-jxa);  fflush(stdout);
		 }
	 }
         h1 /= napop;

         heteroz[napop] += h1;
	 heteroz1[napop] += h1*h1;

         hmza /= napop;
	 hs1 = 1. - js1;
         if( buncflg == 0 ){
            hs11 = hm*(1. - hmza)/(hm - 1.);
            ht1 = 1. - jt1 + hs11/(hm*(double)napop);
	 }
         if( buncflg == 1 ){
	   hs11 = 1. - hmza;
            ht1 = 1. - jt1 + hs11/((double)napop);
	 }

/*	fprintf(fpo," hs1=%f dst1=%f\n",hs1,dst1);fflush(stdout);   */
         gst2 = 1. - hs11/ht1;
         gst2a += gst2;
	 gst1 = dst1/(hs1+dst1);
	 gst += gst1;
         dnapop = napop;
         hedrickGst1 = gst2*(dnapop-1 + hs11)/((dnapop - 1.)*(1.-hs11));
         jostD1 = (ht1-hs11)/(1. - hs11)*dnapop/(dnapop-1.);
         hedrickGst += hedrickGst1;
         jostD += jostD1;
	 fprintf(fpo," %5.3f %5.3f %5.3f\n",gst2,hedrickGst1,jostD1);  fflush(fpo);
	 /*  fprintf(fpo," %5.3f %5.3f\n",h1,gst2);  fflush(fpo);*/
  }
 fprintf(fpo,"ave. ");
for(i=0; i<napop ; i++){
 heteroz[i] /= nloci;
 heteroz1[i] /= nloci;
 heteroz1[i] -= heteroz[i]*heteroz[i];
 heteroz1[i] /= nloci-1;
 heteroz1[i] *= nloci;
 fprintf(fpo," %5.3f", heteroz[i]);  fflush(fpo);
}

gst /= nloci;

gst2a /= nloci;
hedrickGst /= nloci;
jostD /= nloci;
gstvar=0.;
gst2a_var = 0.;
hedrickGst_var = 0.;
jostD_var = 0.;
for(i=0; i<nloci  ; i++){
nl=0;
  for(j=0; j< nloci; j++){
    if( j == i ) continue;
    rloci[nl]=j;
    nl++;
  }
  gstj = hetero1(fpo,napop,apop,nl,rloci,allelefrq, samplesz,nallele,popname,&gst2a_j,&hedrickGst_j,&jostD_j,buncflg);
  /*    printf("i=%d gst1=%f\n",i,gstj);*/
  /*  gstvar += (gstj-gst)*(gstj-gst);*/
  gst2a_var += (gst2a_j - gst2a)*(gst2a_j - gst2a);
  hedrickGst_var += (hedrickGst_j - hedrickGst)*(hedrickGst_j - hedrickGst);
  jostD_var += (jostD_j - jostD)*(jostD_j-jostD);

}
/*
 gstvar *= nloci-1;
 gstvar /= nloci;
*/

 gst2a_var *= nloci-1;
 gst2a_var /= nloci;

 hedrickGst_var *= nloci-1;
 hedrickGst_var /= nloci;

 jostD_var *= nloci-1;
 jostD_var /= nloci;


 fprintf(fpo," %5.3f %5.3f %5.3f\n",gst2a,hedrickGst,jostD);  fflush(fpo);
 /* 
 fprintf(fpo," %5.3f var=%f se=%f\n",gst2a,gstvar,sqrt(gstvar));  fflush(fpo);
 */

 fprintf(fpo,"se.  ");
 for(i=0; i<napop ; i++){
  fprintf(fpo," %5.3f", sqrt(heteroz1[i]/(double)nloci));  fflush(fpo);
 }
 fprintf(fpo," %5.3f %5.3f %5.3f\n",sqrt(gst2a_var),sqrt(hedrickGst_var),sqrt(jostD_var));  fflush(fpo);




 fprintf(fpo,"\n\n Number of alleles\n");  fflush(fpo);

 da1= dvector(napop+1);
 da2= dvector(napop+1);
 for(i=0; i<napop+1; i++){
   da1[i] = da2[i] = 0.;
 }

 fprintf(fpo,"Locus"); fflush(fpo);
 for(i=0; i< napop ; i++) {
	fprintf(fpo," ");
	nc = strlen(popname[apop[i]]);
	if( nc >= 4 ){
		for(j=0; j<4 ; j++ ) fprintf(fpo,"%c",popname[apop[i]][j]);
	}else{
	  for(j=0; j< 4-nc ; j++ ) fprintf(fpo," ");
	  for(j=0; j< nc ; j++ ) fprintf(fpo,"%c",popname[apop[i]][j]);

 }
 }
 fprintf(fpo,"\n");
 dw2 = 0.;
 for(i=0; i< nloci ; i++){
	 fprintf(fpo,"%5d",i+1); fflush(fpo);
         dw1 = 0.0;
	 for(k=0; k< napop ; k++){
                 na = 0;
                 nc = i;
                 n1 = apop[k];
        	 for(j=0; j< nallele[nc] ; j++){
                        if( allelefrq[nc][j][n1] > ACU ) na++;
		 }
           	 fprintf(fpo," %4d",na); fflush(fpo);
                 da1[k] += na;
                 da2[k] += na*na;
                 dw1 += na;
	 }
         dw2 += dw1;
         dw1 /= napop;
	 /*
      	 fprintf(fpo," %4.1f",dw1); fflush(fpo);
	 */
         da1[napop] += dw1;
         da2[napop] += dw1*dw1;
      	 fprintf(fpo,"\n"); fflush(fpo);
 }

fprintf(fpo,"ave. "); fflush(fpo); 
for(i=0; i<napop; i++){
  da1[i] /= nloci;
  da2[i] /= nloci;
  da2[i] -= da1[i]*da1[i];
  da2[i] /= nloci-1;
  da2[i] *= nloci;
  fprintf(fpo," %4.1f",da1[i]);
 }
 fprintf(fpo,"\n"); fflush(fpo);

fprintf(fpo,"se.  "); fflush(fpo);
for(i=0; i<napop; i++){
  fprintf(fpo,"%5.1f",sqrt(da2[i]/(double)nloci));
 }
fprintf(fpo,"\n"); fflush(fpo);


return(0);

}




double hetero1(fpo,napop,apop,nloci,rloci,allelefrq, samplesz,nallele,popname,gst2a_j,hedrickGst_j,jostD_j,buncflg)

int napop, *apop,nloci,*nallele,*rloci;
float ***allelefrq,**samplesz;
char **popname;
FILE *fpo;
double *gst2a_j,*hedrickGst_j,*jostD_j;

{

int i,j,k,l,nc,n1,n2;

double js1,gst,dst1,hs1,gst1,jkl,jx,jxa,hmz1,hs11,ht1,jt1,gst2,gst2a;
double dw,sx,hm,hm1,dw1,hmza;
double jostD,hedrickGst,jostD1,hedrickGst1;

/*	fprintf(fpo,"   %d otus\n",napop);
	for(i=0; i<napop ; i++){
	  fprintf(fpo,"%d %s\n",i+1,popname[apop[i]]);
	 }
	 fflush(fpo);
	 */
/* for(i=0; i<napop ; i++) heteroz[i] = 0.0;*/
 /* fprintf(fpo,"Heterozygosity and Gst\n");
 fprintf(fpo,"Locus");

 for(i=0; i< napop ; i++) {
	fprintf(fpo," ");
	nc = strlen(popname[apop[i]]);
	if( nc >= 5 ){
		for(j=0; j<5 ; j++ ) fprintf(fpo,"%c",popname[apop[i]][j]);
		}else{
		for(j=0; j< nc ; j++ ) fprintf(fpo,"%c",popname[apop[i]][j]);
		for(j=0; j< 5-nc ; j++ ) fprintf(fpo," ");
 }
 }
 fprintf(fpo,"  Gst\n");
 */
 gst = 0.;
 gst2a = 0.;
 hedrickGst = 0.;
 jostD = 0.;

 for(i=0; i< nloci ; i++){
   /*	 fprintf(fpo,"%5d",i+1); fflush(fpo);*/
	 nc = rloci[i];
	 /*         printf("nc=%d\n",nc);*/
	 dst1 = 0.;
	 jkl=0.;
	 dw = 0.;
         hm1=0.;
	 for(k=0; k< napop ; k++){
		n1 = apop[k];
                dw=samplesz[nc][n1];
                hm1 += 1./dw;
	 }

         hm1 /= napop;
         hm = 1./hm1;
         jt1 = 0.;
         dw = 0.;
	 for(j=0; j< nallele[nc] ; j++){
                dw1 = 0.;
		for(k=0; k< napop ; k++){
			n1 = apop[k];
			dw += allelefrq[nc][j][n1]*allelefrq[nc][j][n1];
                        dw1 += allelefrq[nc][j][n1];
			for(l=k+1; l< napop ; l++ ) {
			  n2 = apop[l];
			  jkl += allelefrq[nc][j][n1]*allelefrq[nc][j][n2];
			 }


		 }
                 dw1 /= napop;
                 jt1 += dw1*dw1;
	 }


	 dst1 = (dw*(double)((napop-1))- jkl*2.)/((double)(napop*napop));

	 js1 = dw/(double)napop;
         hmza = 0.;
	 for(j=0; j<napop ; j++){
		jx = 0.0;
		jxa = 0.0;
		n1 = apop[j];
		sx = samplesz[nc][n1];
		for(k=0; k< nallele[nc] ; k++){
			jxa += allelefrq[nc][k][n1]*allelefrq[nc][k][n1];
		 }
		 jx =  (jxa*sx-1.0)/(sx-1.0);
		if( buncflg == 0 ){
                 hmza += jx;
		}
		if( buncflg == 1 ){
                 hmza += jxa;
		}
		 /*		 heteroz[j] += 1.0 - jx;*/
/*

		 if( jx <= 0.0+ACU ){

			printf("jx=%f jxa=%f sx=%f\n",jx,jxa,sx);
		 }
*/
		 /*		 fprintf(fpo," %5.3f",1.0-jx);  fflush(stdout);*/
	 }
         hmza /= napop;
	 hs1 = 1. - js1;
         if( buncflg == 0 ){
           hs11 = hm*(1. - hmza)/(hm - 1.);
           ht1 = 1. - jt1 + hs11/(hm*(double)napop);
	 }
         if( buncflg == 1 ){
           hs11 = 1. - hmza;
           ht1 = 1. - jt1 + hs11/(double)napop;
	 }

/*	fprintf(fpo," hs1=%f dst1=%f\n",hs1,dst1);fflush(stdout);   */
         gst2 = 1. - hs11/ht1;
         gst2a += gst2;
	 gst1 = dst1/(hs1+dst1);
	 gst += gst1;
         hedrickGst1 = gst2*(napop-1+hs11)/((napop-1)*(1.-hs11));
         jostD1 = (ht1-hs11)/(1. - hs11)*napop/(napop-1);
         hedrickGst += hedrickGst1;
         jostD += jostD1;
	 /*	 fprintf(fpo," %5.3f\n",gst2a);  fflush(fpo);*/
  }
 /* fprintf(fpo,"ave. ");
for(i=0; i<napop ; i++){
 heteroz[i] /= nloci;
 fprintf(fpo," %5.3f", heteroz[i]);  fflush(fpo);
}
*/
gst /= nloci;
gst2a /= nloci;
hedrickGst /= nloci;
jostD /= nloci;

 *gst2a_j = gst2a;
 *hedrickGst_j = hedrickGst;
 *jostD_j = jostD;

/*fprintf(fpo," %5.3f\n",gst);  fflush(fpo);*/
return(gst2a);

}

#include <time.h>
int getseed()
{
long seed;
time_t tm;
time_t time();

      time(&tm);
      seed = tm%3000;
      
      return((int)seed);
}



#define Width  80

#define DPRE    3

prdist(fpo,napop, apop, dist )

FILE *fpo;

int napop,*apop;

double **dist;

{

  double dw,dwm;

int i, j, k,l, n,iw,ia,nt,na,n1,n2;

char b[10],cw,b1[10];



  fprintf(fpo,"\n\nDistance matrix\n");

  dwm=0.;
  dw = -99999.0;

  for(i=0; i< napop ; i++){

	for(j=i+1; j< napop ; j++){

	  if( dw < dist[i][j] ) {
             dw = dist[i][j];
	  }
	  if( dist[i][j] < dwm ){
            dwm = dist[i][j];
	  }
	}

  }



  iw = dw;

  for(i=0;  ; ){

	 iw /= 10;

	 if( iw == 0 ) break;

	 i++;

  }

  ia = i+1+DPRE+1;
  if( dwm < 0. ){
    ia++;
  }

  cw = '%';

  for(i=0; i< 10 ; i++ ){
	 b[i]=b1[i]=0;
  }
  sprintf(b," %c%d.%df",cw,ia,DPRE);
  sprintf(b1," %c%dd",cw,ia);
        

  n = Width / (ia+1);
  nt = (napop-1)/n;
  na = (napop-1)%n;

  for(i=0; i< nt+1 ; i++){

    if( i == 0 ) {
      n1 = 0;
    }else{
      n1 = i*n;
    }
    if( i == nt ) {
      /*  n2 = na;*/
      n2 = napop-1;

    } else{
       n2 = (i+1)*n;
    }
    /* */
    /*   fprintf(fpo,"i=%d n1 n2 %d %d\n",i,n1,n2);*/
    /* */

   fprintf(fpo,"     ");
   for(k=n1+1; k<=n2 ; k++) {
      fprintf(fpo,b1,apop[k]+1);
   }
   fprintf(fpo,"\n");fflush(fpo);


   for(j=0; j< n2 ; j++){
       fprintf(fpo,"%5d",apop[j]+1);

       for(k=n1+1; k<=n2 ; k++){
	   if( j >= k ) {
	     for(l=0; l< ia+1 ; l++) {
                fprintf(fpo," ");
	     }
	   }else{
	      fprintf(fpo,b,dist[j][k]);
	   }
       }
       fprintf(fpo,"\n");fflush(fpo);

  }


  }


  return(0);

 }














char delimiter[6]={' ','\t','\n',CR,LF,0};

int dflg = 0;

void main(argc,argv)
int argc;
char **argv;
{
FILE *fpo=stdout,*fpi,*fpe=stderr;
int i,j,k,fin,ifc,rn,flg,iw,distflg,maxlinelen;
int npop,**node/*[MAXOTU-2][3]*/,**nodeb/*[MAXOTU-2][3]*/,nloci,*nallele,*rloci,*apop,napop,*epop,nepop;
/* genepop input data start */
char ***allelename_store0,**locusname0,**popname0;
char ***allelename_store,**locusname;
 int *nallele0,*nallele1,***allelecount0,***allelecount,**nallele_pop0,**nallele_pop,nloci0,npop0;
/* genepop input data end */

float fw,**samplesz,***allelefrq,fs,**fstep;
long seed1,seed, *npart;
double **dist/*[MAXOTU][MAXOTU]*/,**branch0/*[MAXOTU][3]*/,**branchb/*[MAXOTU][3]*/,*mstep;
char **part/*[MAXOTU-3][MAXOTU]*/,**partb/*[MAXOTU-3][MAXOTU]*/;
Nodc **nodes/*[MAXOTU-2]*/;
int **bri/*[MAXOTU-3][2]*/,**brib/*[MAXOTU-3][2]*/,dop,maxnm;
int maxlocusname;
long nbn,nboot;
int pflg,hflg,vflg,buncflg,genepopflg;
long nw[3],nb,n1,n2,ninap=0,nc;
/* static char *distop[NDIST]={"Da","Dst","Fst","Dmyu","Dsw"}; */
static char *distop[NDIST]={"Da","Dst","Dst(u)","Fst","Fst(u)","Dmyu","Dsw"};
/* njt */
int *otu,**spair,*sw,*bw,*nclus;
double *st,*dcm,*rij,*heteroz,*avar;
char *ncn,*rlo,*rli,*chf,*pw1,*pw2;
char **popname,*bf,*bf1;
int iec,upflg;
float ran1();


/*int checkdata_genepop(FILE *fpi,char *bf,char *bf1, int maxlinelen, int *nloci, int *npop,int *maxnm,int *maxlocname);
int getdata_genepop(FILE *fpi, char *bf, char *bf1, int maxlinelen,int nloci,int npop,int maxnm,int maxlocname,int *nallele,char ***allelename_store,char **locusname,char **popname,int ***allelecount);
int check_allelefrq(int nloci0,int npop0,int *nloci,int *npop,char **locusname0,char **popname0,char ***allelename_store0,int *nallele0, int ***allelecount0, int **nallele_pop,int *nallele1);
*/


dflg=0;
pflg=0;
distflg = 0.;
genepopflg = 0;
	seed = 0;
   seed=getseed();
	dop=0;
	hflg=0;
	vflg=0;
	nboot=0;
	nepop=0;
	iec= -1;
	upflg =0;
	ifc=0;
        buncflg = 0;
	if( argc == 1 ){
	  printf("poptree inputfile -b[bootstrap number] -d[distace option] -o [output file] -s[seed]\n");
	  printf("distance option\n");
	  for(i=0; i< NDIST ; i++){
		 printf("%d    %s\n",i,distop[i]);
	  }
	  printf("-upg       UPGMA tree\n");
	  printf("-h         Gst and heterozygosity bias corrected\n");
	  printf("-hu        Gst and heterozygosity bias uncorrected\n");
	  printf("-distance  distance matrix\n");
	  exit(1);
	}

  /*	printf("argc=%d\n",argc); fflush(stdout);  */
	for(i=1; i< argc ; i++){
	  /* printf("i=%d\n",i); fflush(stdout);  */
	  if( argv[i][0] == '-' ){
		if( strcmp(argv[i]+1,"upg") == 0 ) {
			upflg = 1;
			continue;
		 }
		 if( strcmp(argv[i]+1,"distance") == 0 ) {
			 distflg = 1;
			continue;
		 }
		 if( strcmp(argv[i]+1,"hu") == 0 ) {
			 hflg = 1;
                         buncflg = 1;
			continue;
		 }
		switch( argv[i][1]){
		 case 'o' : if( argv[i][2] != 0 ){
						  if( (fpo=fopen(argv[i]+2,"w")) == NULL ){
							fprintf(fpe,"Can't open output-file:%s\n",argv[i]+2);
							exit(1);
							}
							break;
							}
						  if((fpo=fopen(argv[i+1],"w")) == NULL ) {
						  fprintf(fpe,"Can't open output-file:%s\n",argv[i+1]);
						  exit(1);
						}
						i++;
						break;
		 case 'd' :  sscanf(argv[i]+2,"%d",&dop);
						 if( dop > NDIST || dop < 0 ){
							 fprintf(fpe,"invalid option %d\n",dop);
							 exit(1);
						 }
						break;

		 case 'b' : sscanf(argv[i]+2,"%d",&nboot);
						break;
		 case 'm' : pflg=1;
						break;
		 case 'h' : hflg=1;
   		            buncflg = 0;
						break;
		 case 'v' : vflg=1;
						break;
		 case 's' :  sscanf(argv[i]+2,"%d",&seed);
						 break;
		 case 'e' :  iec=i;
						 for(j=i+1 ; j<argc ; j++){
							if( argv[j][0] < '0' || argv[j][0] > '9' ) break;
							 i++;
						 }
						 break;
		 case 'u' :  if(argv[i][2] == 0 ){
							dflg=1;
							break;
						 }
						 sscanf(argv[i]+2,"%d",&dflg);
						 break;
		 default :  fprintf(fpe,"invalid argument",argv[i]);
						exit(1);
		}
	  }else{
		if((fpi=fopen(argv[i],"r")) == NULL ){
					 fprintf(fpe,"Can't open input-file:%s\n",argv[i]);
					 exit(1);
		}
		fin=i;
		ifc++;
		/* printf("fin=%d\n"); fflush(stdout); */

	  }
	}

	/*  printf("end of arguments\n");   fflush(stdout);*/

  if( ifc == 0 ){
		fprintf(fpe,"no input-file\n");
		exit(1);
	}

if( (fpi= fopen(argv[fin],"r")) == NULL ){
  fprintf(fpo,"Can't open file %s\n",argv[fin]);
  exit(1);
 }

maxlinelen = checklinelen(fpi);
fclose(fpi);

 bf  = cvector(maxlinelen+1);
 bf1 = cvector(maxlinelen+1);


if( (fpi= fopen(argv[fin],"r")) == NULL ){
  fprintf(fpo,"Can't open file %s\n",argv[fin]);
  exit(1);
 }
 checkdataformat(fpi,bf,bf1,maxlinelen,&genepopflg);
 fclose(fpi);


 /* fprintf(stderr,"genepopflg=%d\n",genepopflg);*/

if( (fpi= fopen(argv[fin],"r")) == NULL ){
  fprintf(fpo,"Can't open file %s\n",argv[fin]);
  exit(1);
 }

 if( genepopflg == 0 ){
   checkloci(fpi,&nloci,&npop,&maxnm,bf,bf1,maxlinelen+1);
   fclose(fpi);
   if( (fpi= fopen(argv[fin],"r")) == NULL ){
    fprintf(fpo,"Can't open file %s\n",argv[fin]);
     exit(1);
   }

   nallele = ivector(nloci);
   mstep = dvector(npop);
   checkflal(fpi,nloci,nallele,npop,bf,bf1,maxlinelen);
   fclose(fpi);

   if( (fpi= fopen(argv[fin],"r")) == NULL ){
     fprintf(fpo,"Can't open file %s\n",argv[fin]);
     exit(1);
   }
   popname = cmatrix(npop,maxnm+1);
   samplesz = fmatrix(nloci,npop);
   clr_cmatrix(popname,npop,maxnm+1);
   clr_fmatrix(samplesz,nloci,npop);

   allelefrq = f3matrix(nloci,nallele,npop);
   fstep = f2matrix(nloci,nallele);
   clr_fmatrix1(fstep,nloci,nallele);
   clr_f3matrix1(allelefrq,nloci,nallele,npop);

   getal(fpi,dop,nloci,nallele,popname,allelefrq,samplesz,npop,fstep,bf,bf1,maxlinelen+1);
   fclose(fpi);
 }


 if( genepopflg == 1 ){
   checkdata_genepop(fpi,bf,bf1,maxlinelen+1,&nloci0,&npop0,&maxnm,&maxlocusname);
   fclose(fpi);
   /*   fprintf(stderr,"checkdata_genepop nloci0 npop0 %d %d\n",nloci0,npop0);*/
   
   nallele0 = ivector(nloci0);
   clr_ibf(nallele0,nloci0);

   allelename_store0 = c3matrix(nloci0,MAXALLELE_LOCUS,MAXALLELE_NAME);  
   clr_c3matrix(allelename_store0,nloci0,MAXALLELE_LOCUS,MAXALLELE_NAME);

   if( (fpi= fopen(argv[fin],"r")) == NULL ){
     fprintf(fpo,"Can't open file %s\n",argv[fin]);
     exit(1);
   }

   checkdata_genepop_nallele(fpi,bf,bf1,maxlinelen+1,nloci0,npop0,maxnm,maxlocusname,nallele0,allelename_store0);

   fclose(fpi);

   /*   fprintf(stderr,"checkdata_genepop_nallele nloci0=%d maxlocusname=%d\n",nloci0,maxlocusname);*/
   locusname0 = cmatrix(nloci0,maxlocusname+1);
   clr_cmatrix(locusname0,nloci0,maxlocusname+1);

   if( maxnm == 0 ){
     iw = npop0;
     for(i=0; ;i++){
       iw /= 10;
       if( iw == 0 ){
         maxnm = i+1+3;
         break;
       }
     }
   }

   popname0 = cmatrix(npop0,maxnm+1);
   clr_cmatrix(popname0,npop0,maxnm+1);

   allelecount0 = i3matrix1(nloci0,nallele0,npop0);

   if( (fpi= fopen(argv[fin],"r")) == NULL ){
     fprintf(fpo,"Can't open file %s\n",argv[fin]);
     exit(1);
   }
   getdata_genepop(fpi,bf,bf1,maxlinelen+1,nloci0,npop0,maxnm,maxlocusname,nallele0,allelename_store0,locusname0,popname0,allelecount0);
   fclose(fpi);
   /*   fprintf(stderr,"getdata_genepop end nloci0 npop0 %d %d\n",nloci0,npop0);
   for(i=0; i<npop0; i++){
     fprintf(stderr,"i=%d popname %s",i,popname0[i]);
   }
   fprintf(stderr,"\n");
   */

   nallele1 = ivector(nloci0);
   nallele_pop0 = imatrix(nloci0,npop0);
   clr_imatrix(nallele_pop0,nloci0,npop0);
   check_allelefrq(nloci0,npop0,&nloci,&npop,locusname0,popname0,allelename_store0,nallele0,allelecount0,nallele_pop0,nallele1);

   nallele = ivector(nloci);
   iw = 0;
   for(i=0; i<nloci0 ; i++){
     if( nallele0[i] == 0 ){
       continue;
     }
     nallele[iw] = nallele0[i];
     iw++;
   }
   allelecount = i3matrix1(nloci,nallele,npop);
   allelefrq = f3matrix(nloci,nallele,npop);
   fstep = f2matrix(nloci,nallele);
   samplesz = fmatrix(nloci,npop);

   clr_i3matrix1(allelecount,nloci,nallele,npop);
   clr_f3matrix1(allelefrq,nloci,nallele,npop);
   clr_fmatrix1(fstep,nloci,nallele);
   clr_fmatrix(samplesz,nloci,npop);
   locusname = cmatrix(nloci,maxlocusname+1);
   popname = cmatrix(npop,maxnm+1);
   allelename_store = c3matrix1(nloci,nallele,MAXALLELE_NAME);
   clr_cmatrix(locusname,nloci,maxlocusname+1);
   clr_cmatrix(popname,npop,maxnm+1);
   clr_c3matrix1(allelename_store,nloci,nallele,MAXALLELE_NAME);

   get_allelefrq(nloci0,npop0,nloci,npop,locusname0,popname0,allelename_store0,nallele0,allelecount0,nallele_pop0,nallele1,locusname,popname,allelename_store,allelecount,allelefrq,nallele,fstep,samplesz,dop);

   if( npop < 3 ){
     fprintf(stdout,"Number of pop (%d) is smaller tnan 3\n",npop);
     exit(1);
   }
   if( nloci < 1 ){
     fprintf(stdout,"Number of loci (%d) is smaller tnan 1\n",nloci);
     exit(1);
   }
   mstep = dvector(npop);


 }



/* fprintf(stdout,"checkloci nloci=%d npop=%d maxnm=%d\n",nloci,npop,maxnm); fflush(stdout);*/
  
 /*
  printf("%d populations\n",noutp);
  for(i=0; i< noutp ; i++){
	 printf("%d %s\n",i+1,popname[outp[i]-1]);
  }
  for(i=0; i<nloci ; i++){
	  printf("@locus %d\n",i+1);
	  for(j=0; j<nallele[i] ; j++){
		  printf("          * ");
		  for(k=0; k<noutp ; k++){
		        printf(" %1.3f",allelefrq[i][j][outp[k]-1]);
	 }
		  printf("\n");
		}
	  printf(" #          ");
	  for(j=0; j<noutp ; j++) printf(" %3.1f",samplesz[i][j]);
	  printf("\n");
	}
 */

 /*
for(i=0; i< nloci ; i++){
  printf("locus %d\n",i+1);
  for(j=0; j<nallele[i] ; j++){
	 for(k=0; k<npop ; k++){
	   printf(" %f",allelefrq[i][j][k]);
	  }
	 printf("\n");
  }
  for(k=0; k<npop ; k++){
	   printf(" %f",samplesz[i][k]);
	  }
   printf("\n");

}

 */

 apop = ivector(npop);
 epop = ivector(npop);
 if( vflg == 1 ) avar = dvector(npop);

 nepop=0;
 if( iec > 0 ){
	if( argv[iec][2] >= '0' && argv[iec][2] <= '9' ){
		sscanf(argv[iec]+2,"%d",&iw);
		if( iw > npop ){
			printf("invalid excluding otu %d\n",iw);
			exit(1);
		 }
		 epop[0] = iw;
		 nepop=1;
	 }
	 for(i=iec+1 ; i< argc ; i++){
		if( argv[i][0] > '9' || argv[i][0] < '0' ) break;
		sscanf(argv[i],"%d",&iw);
		if( iw > npop || iw < 0 ){
			printf("invalid excluding otu %d\n",iw);
			exit(1);
		 }
		 epop[nepop]=iw;
		 nepop++;
	 }
 }

 napop=0;
 for(i=0; i<npop ; i++){
	flg=0;
	for(j=0; j<nepop ; j++){
	  if( i+1 == epop[j] ){
		flg=1;
		break;
	 }
	}
	if( flg == 0 ){
	 apop[napop]=i;
	 napop++;
	}
}

if( dflg == 1 ){
	  printf("getal end\n"); fflush(stdout);
	}
if( dflg == 10 ){
	fs=0.;
	printf("nloci=%d npop=%d\n",nloci,npop);
	for(i=0; i<nloci ; i++){
	fw=0.;
	printf("locus %d\n",i+1);
	for(j=0; j<nallele[i] ; j++){
	  printf(" %3.1f *",fstep[i][j]);
	  for(k=0; k< npop ; k++) printf(" %0.4f",allelefrq[i][j][k]);
	  printf("\n");
	 }
	 for(j=0; j<npop ; j++){
			  printf("   %3.1f",samplesz[i][j]);
			  fs += samplesz[i][j];
			  fw += samplesz[i][j];
	 }
	printf(" ttl =%f\n",fw);
}
	printf("total allele=%f\n",fs);
 }


 rloci = ivector(nloci);

if( hflg == 1 ){
          hetero(fpo,napop,apop,nloci,allelefrq, samplesz,nallele,popname,rloci,buncflg);
	  exit(0);

}


 node = imatrix(npop-1,3);
 nodeb = imatrix(npop-1,3);
 npart = lvector(npop-3);
 dist = dmatrix(npop,npop);
 branch0 = dmatrix(npop,3);
 branchb = dmatrix(npop,3);
 part = cmatrix(npop-3,npop);
 partb = cmatrix(npop-3,npop);
 nodes = nvector(npop-2);
 bri = imatrix(npop-3,2);
 brib = imatrix(npop-3,2);
 otu = ivector(npop);
 if( upflg == 1 ) nclus = ivector(npop);
 spair = imatrix(npop*(npop-1)/2,2);
 sw = ivector(npop*(npop-1)/2);
 st = dvector(npop*(npop-1)/2);
 dcm = dvector(npop);
 rij = dvector(npop);
 ncn = cvector(npop-2);
 rlo = cvector(npop);
 rli = cvector(npop-2);
 chf = cvector(npop-2);
/* pb = ivector(npop-3);
 npw = ivector(npop-3);
 */
 bw = ivector(npop-3);
 pw1 = cvector(npop);
 pw2 = cvector(npop);


	if( nboot > 0 ) fprintf(fpo,"   %d otus     %d bootstraping\n",napop,nboot);
	if( nboot == 0 ) fprintf(fpo,"   %d otus\n",napop);
	for(i=0; i<napop ; i++){
	  fprintf(fpo,"%d %s\n",i+1,popname[apop[i]]);
	 }
	 fflush(fpo);
/*     srandom(seed); */
	  seed1 = -seed;

/*     printf("seed1=%d\n",seed1); */
	  ran1(&seed1);
/*     printf("seed1=%d\n",seed1); */
	  for(i=0; i<nloci ; i++) rloci[i]=i;
	  for(i=0; i< npop-3 ; i++) npart[i]=0;
/*      printf("check nseq=%d\n",nseq); */
		  rn=caldist(napop,apop,nloci,rloci,nallele,allelefrq,samplesz,dist,dop,pflg,fstep,mstep,vflg,avar);

		  if( dflg  == 1 )    {
			  printf("caldist end\n"); fflush(stdout);
	 }
			  if( rn == -1 ) {
			  printf("distance was inapplicable\n");
			  exit(1);
			}
/*      printf("njt\n"); fflush(stdout); */
		if( upflg == 0 ) njt(napop,dist,node,branch0,otu,spair,st,dcm,rij);
		if( upflg == 1 ) upg(napop,dist,node,branch0,otu,spair,nclus,dcm);
		if( dflg == 1 ){
			  printf("njt end\n"); fflush(stdout);
	 }

		njtndp(napop,node,nodes,ncn);
		if( dflg == 1 ){
			  printf("njtndp end\n"); fflush(stdout);
	 }

		parti(napop,nodes,part,bri,rlo,rli,chf);
		if( dflg == 1 ){
			  printf("parti end\n"); fflush(stdout);
	 }

		for(nbn=0; nbn < nboot ; ){
	/* printf("nbn=%d\n",nbn); fflush(fpo); */
		  reloci(nloci,rloci,&seed1);
		  rn=caldist(napop,apop,nloci,rloci,nallele,allelefrq,samplesz,dist,dop,pflg,fstep,mstep,vflg,avar);
			 if( rn == -1 ) {
			  ninap++;
			  continue;
			}
			if( upflg == 0 ) njr(napop,dist,nodeb,branchb,otu,spair,sw,st,dcm,rij,&seed1);
			if( upflg == 1 ) upgr(napop,dist,nodeb,branchb,otu,spair,nclus,dcm,&seed1);
			njtndp(napop,nodeb,nodes,ncn);
			parti(napop,nodes,partb,brib,rlo,rli,chf);
			cpart(napop,part,partb,npart,bw,pw1,pw2);
			nbn++;
		 }
		for(i=0; i<napop-2 ; i++){
		 nb=2;
		 if( i == napop-3 ) nb=3;
		 for(j=0; j<nb ; j++){
			 if( node[i][j] <= napop ) nw[j]= nboot;
			 if( node[i][j]  > napop ) {
				  n1=i+1;
				  n2=node[i][j]-napop;
				  if( n1 > n2 ){
						nc = n1;
						n1=n2;
						n2=nc;
		}
					for(k=0; k<napop-3 ; k++){
					  if( bri[k][0] == n1 && bri[k][1] == n2 ) {
						  nw[j] = npart[k];
						  break;
		  }
			 }
		 }
				  if( nboot > 0 ) fprintf(fpo,"%3d and %3d        %f    %6d\n",napop+i+1,node[i][j],branch0[i][j],nw[j]);
				  if( nboot == 0 ) fprintf(fpo,"%3d and %3d        %f\n",napop+i+1,node[i][j],branch0[i][j]);
	}
		}

fprintf(fpo,"\n");
fprintf(fpo,"datafile %s   %s was used\n",argv[fin],distop[dop]);
fprintf(fpo,"\n");
fprintf(fpo,"Number of loci compared %d\n",nloci);
fprintf(fpo,"seed=%d ninap=%d\n",seed,ninap);


if( distflg == 1 ){
  for(i=0; i<nloci ; i++) rloci[i]=i;
  rn=caldist(napop,apop,nloci,rloci,nallele,allelefrq,samplesz,dist,dop,pflg,fstep,mstep,vflg,avar);
  prdist(fpo,napop,apop,dist );
  }

 if( genepopflg == 1 ){
   fprintf(fpo,"--- allele frequencies from genepop data----\n");
   fprintf(fpo,"%d populations\n",npop);
   for(i=0; i<npop; i++){
     fprintf(fpo,"%d %s\n",i+1,popname[i]);
   }
   for(i=0; i<nloci ; i++){
     fprintf(fpo,"@locus %d %s\n",i+1,locusname[i]);
     for(j=0; j<nallele[i]; j++){
       sscanf(allelename_store[i][j],"%f",&fw);
       fprintf(fpo,"%s *",allelename_store[i][j],fw);
       for(k=0; k<npop; k++){
	   allelefrq[i][j][k] = allelecount[i][j][k];
	   allelefrq[i][j][k] /= samplesz[i][k];
           fprintf(fpo," %5.3f",allelefrq[i][j][k]);
       }
       fprintf(fpo,"\n");
       }
       fprintf(fpo,"#");
       for(k=0; k<npop; k++){
           fprintf(fpo," %3.0f",samplesz[i][k]);
       }
       fprintf(fpo,"\n");

   }  
   

 }



	exit(0);
}





