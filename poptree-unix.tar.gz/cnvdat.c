#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#define NLOCI 500
#define NALLELE 50
#define NPOP  100
#define NIND  1000
#define NNAME  20
#define BFLEN  100
#define ERR stderr

int *ivector(int);
int **imatrix(int, int);
char **cmatrix(int, int);
char ***c3matrix(int, int, int);
float ***f3matrix(int,int,int);



main(argc,argv)
int argc;
char **argv;
{
FILE *fp=stdin,*fpo=stdout;
 int nmloci, nmallele, nmpop, nmind, nw;
 int i,j,k,l,*indcount/*[NIND]*/,n,rn,nind,flg,npop,*popsz/*[NPOP]*/,nloci,*nallele/*[NLOCI]*/;
 char **indname/*[NIND][10]*/,bf[BFLEN],b[NNAME],b1[NNAME],b2[NNAME],**popname/*[NPOP][20]*/,b3[NNAME],
b4[NNAME];
 char ***allele/*[NLOCI][NALLE][10]*/,**loci/*[NLOCI][10]*/,bw[NNAME];
 float ***freq/*[NLOCI][NALLE][NPOP]*/,fw;
 int **samplesz/*[NLOCI][NPOP]*/,locia,allelea1,allelea2,popa,iw,iw1,ns,tflg;
int ifc,fin,indflg;

 nmloci = NLOCI;
 nmallele = NALLELE;
 nmpop = NPOP;
 nmind = NIND;

 if( argc == 1 ){
	  printf("cnvdat inputfile -o [output file] -p[MAXPOP] -l[MAXLOCI] -a[MAX ALLELE] -i[MAX INDIVIDUAL] \n");
          printf("Max POP %d\n",NPOP);
          printf("MAX LOCI %d\n",NLOCI);
          printf("MAX ALLELES PER LOCUS %d\n",NALLELE);
          printf("MAX INDIVIDUALS %d\n",NIND);
	  exit(1);
  }

  ifc=fin=0;
  tflg=1;
  indflg=0;


	for(i=1; i< argc ; i++){
	  /* printf("i=%d\n",i); fflush(stdout);  */
	  if( argv[i][0] == '-' ){
		switch( argv[i][1]){
		 case 'o' : if( argv[i][2] != 0 ){
						  if( (fpo=fopen(argv[i]+2,"w")) == NULL ){
							fprintf(stderr,"Can't open output-file:%s\n",argv[i]+2);
							exit(1);
							}
							break;
							}
						  if((fpo=fopen(argv[i+1],"w")) == NULL ) {
						  fprintf(stderr,"Can't open output-file:%s\n",argv[i+1]);
						  exit(1);
						}
						i++;
						break;
		case 'p': nw=0;
                           if (argv[i][2] != 0 ){
  		            sscanf(argv[i]+2,"%d",&nw);
		           }else{
  		            sscanf(argv[i+1],"%d",&nw);
                            i++;
                           }
			    if( nw <= 0 ){
			      fprintf(stderr,"Max pop %d\n",nw);
			      exit(1);
			    }
                            nmpop = nw;
			    break;
		case 'l': nw=0;
                           if (argv[i][2] != 0 ){
  		            sscanf(argv[i]+2,"%d",&nw);
		           }else{
  		            sscanf(argv[i+1],"%d",&nw);
                            i++;
                           }
			    if( nw <= 0 ){
			      fprintf(stderr,"Max number of loci %d\n",nw);
			      exit(1);
			    }
                            nmloci = nw;
                            break;

		case 'a': nw=0;
                           if (argv[i][2] != 0 ){
  		            sscanf(argv[i]+2,"%d",&nw);
		           }else{
  		            sscanf(argv[i+1],"%d",&nw);
                            i++;
                           }
			    if( nw <= 0 ){
			      fprintf(stderr,"Max number of alleles per locus%d\n",nw);
			      exit(1);
			    }
                            nmallele = nw;
			    break;
		case 'i': nw=0;
                           if (argv[i][2] != 0 ){
  		            sscanf(argv[i]+2,"%d",&nw);
		           }else{
  		            sscanf(argv[i+1],"%d",&nw);
                            i++;
                           }
			    if( nw <= 0 ){
			      fprintf(stderr,"Max number of indiduals %d\n",nw);
			      exit(1);
			    }
                            nmind = nw;
			   break;
		 default : fprintf(stderr,"invalid argument",argv[i]);
						exit(1);
		}
	  }else{
		if((fp=fopen(argv[i],"r")) == NULL ){
					 fprintf(stderr,"Can't open input-file:%s\n",argv[i]);
					 exit(1);
		}
		fin=i;
		ifc++;
		/* printf("fin=%d\n"); fflush(stdout); */

	  }
	}


  if( ifc == 0 ){
		fprintf(stderr,"no input-file\n");
		exit(1);
	}



  fprintf(stderr,"Max number of loci %d\n",nmloci);
  fprintf(stderr,"Max number of populations %d\n",nmpop);
  fprintf(stderr,"Max number of alleles per locus %d\n",nmallele);
  fprintf(stderr,"Max number of individuals %d\n",nmind);
  

  samplesz = imatrix(nmloci,nmpop);
  for(i=0; i< nmloci ; i++){
    for(j=0; j<nmpop ; j++) samplesz[i][j]=0;
  }

  /*  fprintf(stderr,"samplesz\n");*/
  nallele = ivector(nmloci);
  freq = f3matrix(nmloci,nmallele,nmpop);
  for(i=0; i<nmloci ; i++){
    nallele[i]=0;
    for(j=0; j<nmallele ; j++){
       for(k=0; k<nmpop ; k++) freq[i][j][k]=0.;
    }
  }
  /*  fprintf(stderr,"nallele\n");*/

  loci = cmatrix(nmloci,NNAME);
  for(i=0; i< nmloci ; i++) {
    for( j=0; j<NNAME ; j++) loci[i][j]=0;
  }

  popsz = ivector(nmpop);

  allele = c3matrix(nmloci,nmallele,NNAME);
  for(i=0; i<nmloci ; i++){
    for(j=0; j<nmallele ; j++){
       for(k=0; k<NNAME ; k++) allele[i][j][k]=0.;
    }
  }
 


  indcount = ivector(nmind);
  indname = cmatrix(nmind,NNAME);

  for(i=0; i< nmind ; i++) {
    indcount[i]=0;
    for(j=0; j<NNAME ; j++) indname[i][j]=0;
  }

  popname = cmatrix(nmpop,NNAME);
  for(i=0; i<nmpop ; i++){
    for(j=0; j<NNAME ; j++) popname[i][j]=0;
  }

  nind=0;
  npop=0;
  nloci=0;

  for( ; ; ){
   clrbf(bf,BFLEN);
   rn=rdline(fp,bf,&n);
   if( rn == -1 && n == 0 ) break;
   if( rn == 1 ) continue;

   for(i=0; i<NNAME ; i++){
     b[i]=b1[i]=b2[i]=b3[i]=b4[i]=0;
   }
   sscanf(bf,"%s %s %s %s %s",b,b1,b2,b3,b4);
   printf(bf,"%s %s %s %s %s",b,b1,b2,b3,b4);
      
   if( indflg == 1 ){
     for(j=0; j< nind ; j++){
    if( strcmp(indname[j],b2) == 0 ){
      indcount[j]++;
      flg=1;
      break;
    }
   }
   if( flg == 0  ){
     strcpy(indname[nind],b2);
     nind++;
   }
   }


   locia=-1;
   allelea1=-1;
   allelea2=-1;
   popa=-1;
   for(j=0; j< nloci ; j++){
     if( strcmp(loci[j],b1) == 0 ){
       locia=j;
       break;
     }
   }
   if( locia == -1 ){
      strcpy(loci[nloci],b1);
      locia=nloci;
      nloci++;
    }

   /*   printf("locia=%d nloci=%d\n",locia,nloci); fflush(stdout); */
  for(j=0; j< nallele[locia] ; j++){
   if( strcmp(allele[locia][j],b3) == 0 ){
     allelea1=j;
     break;
   }
 }

  /*  printf("allelea1=%d\n",allelea1); fflush(stdout); */
  if( allelea1 == -1 ){
    strcpy(allele[locia][nallele[locia]],b4);
    allelea1 = nallele[locia];
    nallele[locia]++;
  }

  allelea2 = -1;
  for(j=0; j< nallele[locia] ; j++){
   if( strcmp(allele[locia][j],b4) == 0 ){
     allelea2 = j;
     break;
   }
 }
  /*  printf("allelea2=%d\n",allelea2); fflush(stdout); */

  if( allelea2 == -1 ){
    strcpy(allele[locia][nallele[locia]],b4);
    allelea2 = nallele[locia];
    nallele[locia]++;
  }


  /*  printf("allelea2=%d nallele=%d\n",allelea2,nallele[locia]); fflush(stdout); */
  for(j=0; j<npop ; j++){
    if( strncmp(popname[j],b,strlen(b)) == 0 ){
      popa=j;
      break;
    }
  }
  if( popa == -1 ){
     strcpy(popname[npop],b);
     popa = npop;
     npop++;
   }
/*   printf("locia =%d allelea=%d popa=%d\n",locia,allelea,popa);
   fflush(stdout);
*/

   freq[locia][allelea1][popa] += 1.0;
   freq[locia][allelea2][popa] += 1.0;
/*   printf("freq\n"); fflush(stdout); */
    samplesz[locia][popa] += 2;
      popsz[popa] += 2;
/*   printf("samplen"); fflush(stdout); */
  }

ns=0;

for(i=0; i<nloci ; i++){
  for(j=0; j< nallele[i] ; j++){
    for(k= j+1 ; k< nallele[i] ; k++){
        sscanf(allele[i][j],"%d",&iw);
        sscanf(allele[i][k],"%d",&iw1);      
        if( iw > iw1 ){
          strcpy(bw,allele[i][j]);
          strcpy(allele[i][j],allele[i][k]);
          strcpy(allele[i][k],bw);
          for(l=0; l<npop ; l++){
            fw = freq[i][j][l];
            freq[i][j][l] = freq[i][k][l];
            freq[i][k][l] = fw;
	  }
	}
   
      }
  }
}


 

 fprintf(fpo,"%d populations\n",npop); 
 for(i=0; i<npop ; i++) {
    fprintf(fpo,"%d %s\n",i+1,popname[i]);
  }

 for(i=0; i<npop ; i++) {
    fprintf(stderr,"%d %s %d\n",i+1,popname[i],popsz[i]);
  }


for(i=0; i< nloci ; i++){
  iw=0;
  fprintf(fpo,"@locus %d %s\n",i+1,loci[i]);
  for(j=0; j<nallele[i] ; j++){
    fprintf(fpo,"%4s * ",allele[i][j]);
    for(k=0; k<npop ; k++){
      freq[i][j][k] /= samplesz[i][k];
      fprintf(fpo," %1.4f",freq[i][j][k]);
    }
    fprintf(fpo,"\n");
  }
  fprintf(fpo,"#      ");
  for(k=0; k<npop ; k++){
     fprintf(fpo,"    %3d",samplesz[i][k]);
     ns += samplesz[i][k];
     iw += samplesz[i][k];
   }
   fprintf(fpo,"\n");
  /*  if( tflg == 1 ) printf("  ttl=%d\n",iw);*/
   
}

fprintf(stderr,"total sample %d\n",ns);
if( indflg == 1 ) fprintf(stderr,"total individual %d\n",nind);
 exit(0);
}



rdline(fp,bf,n)
FILE *fp;
char *bf;
int *n;
{
int i,cw,n1;
*n=0;
for(i=0; i<100 ; i++) bf[i]=0;

n1=0;
for( ; ; ){
  cw = getc(fp);
  if( cw == EOF ) return(-1);
  bf[*n]=cw;
  (*n)++;
  if( cw != ' ' && cw != '\n' && cw != '\t') n1++;
  if( cw == '\n' ) {
     if( n1 > 0 ) return(0);
     return(1);
   }
   
}


}



 clrbf(b,n)
   char *b;
   int n;
 {
   int i;
   
   for(i=0; i<n; i++){
     b[i]=0;
   }
   return(0);
 }



int *ivector(n)
int n;
{
int *vp;

   vp = (int *)malloc((unsigned) n*sizeof(int));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"integer vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}


char *cvector(n)
int n;
{
char *vp;

   vp = (char *)malloc((unsigned) n*sizeof(char));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"char vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}


float *fvector(n)
int n;
{
float *vp;

   vp = (float *)malloc((unsigned) n*sizeof(float));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"char vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

double *dvector(n)
int n;
{
double *vp;

   vp = (double *)malloc((unsigned) n*sizeof(double));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"double vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}
double *dvectorc(n,covflg)
int n,*covflg;
{
double *vp;

   vp = (double *)malloc((unsigned) n*sizeof(double));
   if( !vp ) {
     /*
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"double vector[%d]\n",n);
       */
       *covflg=1;
     }
    return(vp);
}

int **imatrix(n1,n2)
int n1,n2;
{
int i,**ip;

 ip = (int **) malloc((unsigned ) n1*sizeof(int*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (int *) malloc((unsigned) n2*sizeof(int));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}


int ***i3matrix(n1,n2,n3)
int n1,n2,n3;
{
int i,j,***ip;

 ip = (int ***) malloc((unsigned ) n1*sizeof(int**) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (int **) malloc((unsigned) n2*sizeof(int*));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);
   }

   for(j=0;j<n2 ; j++){
      ip[i][j] = (int *) malloc((unsigned) n3*sizeof(int));
      if( !ip[i][j] ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"step3(i=%d)(j=%d) integer matrix %d %d %d\n",i,j,n1,n2,n3);
       exit(1);
      }
   }
 }
 
  return(ip);
				 
}



double ***d3matrix(n1,n2,n3)
int n1,n2,n3;
{
int i,j;
double ***ip;

 ip = (double ***) malloc((unsigned ) n1*sizeof(double**) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (double **) malloc((unsigned) n2*sizeof(double*));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);
   }

   for(j=0;j<n2 ; j++){
      ip[i][j] = (double *) malloc((unsigned) n3*sizeof(double));
      if( !ip[i][j] ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"step3(i=%d)(j=%d) integer matrix %d %d %d\n",i,j,n1,n2,n3);
       exit(1);
      }
   }
 }
 
  return(ip);
				 
}



char ***c3matrix(n1,n2,n3)
int n1,n2,n3;
{
int i,j;
char ***ip;

 ip = (char ***) malloc((unsigned ) n1*sizeof(char**) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 float 3 matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (char **) malloc((unsigned) n2*sizeof(char*));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) float 3 matrix %d %d\n",i,n1,n2);
    exit(1);
   }

   for(j=0;j<n2 ; j++){
      ip[i][j] = (char *) malloc((unsigned) n3*sizeof(char));
      if( !ip[i][j] ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"step3(i=%d)(j=%d) integer matrix %d %d %d\n",i,j,n1,n2,n3);
       exit(1);
      }
   }
 }
 
  return(ip);
				 
}



float ***f3matrix(n1,n2,n3)
int n1,n2,n3;
{
int i,j;
float ***ip;

 ip = (float ***) malloc((unsigned ) n1*sizeof(float**) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 float 3 matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (float **) malloc((unsigned) n2*sizeof(float*));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) float 3 matrix %d %d\n",i,n1,n2);
    exit(1);
   }

   for(j=0;j<n2 ; j++){
      ip[i][j] = (float *) malloc((unsigned) n3*sizeof(float));
      if( !ip[i][j] ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"step3(i=%d)(j=%d) integer matrix %d %d %d\n",i,j,n1,n2,n3);
       exit(1);
      }
   }
 }
 
  return(ip);
				 
}




char **cmatrix(n1,n2)
int n1,n2;
{
int i;
char **ip;

 ip = (char **) malloc((unsigned ) n1*sizeof(char*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (char *) malloc((unsigned) n2*sizeof(char));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}


double **dmatrix(n1,n2)
int n1,n2;
{
int i;
double **ip;

 ip = (double **) malloc((unsigned ) n1*sizeof(double*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (double *) malloc((unsigned) n2*sizeof(double));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) double matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}



void free_ivector(v,n)
int *v,n;
{
   free((int*) v );
   return ;
 }

void free_fvector(v,n)
float *v;
int n;
{
   free((float*) v );
   return ;
 }

void free_dvector(v,n)
double *v;
int n;
{
   free((double*) v );
   return ;
 }


void free_cvector(v,n)
char *v;
int n;
{
   free((char*) v );
   return ;
 }


void free_cmatrix(m,n1,n2)
char **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}

void free_imatrix(m,n1,n2)
int  **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((int *) (m[i]));
     }
    free((int *) m);
}


void free_dmatrix(m,n1,n2)
double  **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((double *) (m[i]));
     }
    free((double *) m);
}


