/*#include "head.h"*/
#include <stdio.h>
#include <stdlib.h>
#define   ERR stderr

int *ivector(n)
int n;
{
int *vp;

   vp = (int *)malloc((unsigned) n*sizeof(int));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"integer vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}


char *cvector(n)
int n;
{
char *vp;

   vp = (char *)malloc((unsigned) n*sizeof(char));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"char vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}


float *fvector(n)
int n;
{
float *vp;

   vp = (float *)malloc((unsigned) n*sizeof(float));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"char vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

double *dvector(n)
int n;
{
double *vp;

   vp = (double *)malloc((unsigned) n*sizeof(double));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"double vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}
double *dvectorc(n,covflg)
int n,*covflg;
{
double *vp;

   vp = (double *)malloc((unsigned) n*sizeof(double));
   if( !vp ) {
     /*
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"double vector[%d]\n",n);
       */
       *covflg=1;
     }
    return(vp);
}

int **imatrix(n1,n2)
int n1,n2;
{
int i,**ip;

 ip = (int **) malloc((unsigned ) n1*sizeof(int*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (int *) malloc((unsigned) n2*sizeof(int));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}


int ***i3matrix(n1,n2,n3)
int n1,n2,n3;
{
int i,j,***ip;

 ip = (int ***) malloc((unsigned ) n1*sizeof(int**) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (int **) malloc((unsigned) n2*sizeof(int*));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);
   }

   for(j=0;j<n2 ; j++){
      ip[i][j] = (int *) malloc((unsigned) n3*sizeof(int));
      if( !ip[i][j] ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"step3(i=%d)(j=%d) integer matrix %d %d %d\n",i,j,n1,n2,n3);
       exit(1);
      }
   }
 }
 
  return(ip);
				 
}



double ***d3matrix(n1,n2,n3)
int n1,n2,n3;
{
int i,j;
double ***ip;

 ip = (double ***) malloc((unsigned ) n1*sizeof(double**) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (double **) malloc((unsigned) n2*sizeof(double*));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);
   }

   for(j=0;j<n2 ; j++){
      ip[i][j] = (double *) malloc((unsigned) n3*sizeof(double));
      if( !ip[i][j] ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"step3(i=%d)(j=%d) integer matrix %d %d %d\n",i,j,n1,n2,n3);
       exit(1);
      }
   }
 }
 
  return(ip);
				 
}



char ***c3matrix(n1,n2,n3)
int n1,n2,n3;
{
int i,j;
char ***ip;

 ip = (char ***) malloc((unsigned ) n1*sizeof(char**) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 float 3 matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (char **) malloc((unsigned) n2*sizeof(char*));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) float 3 matrix %d %d\n",i,n1,n2);
    exit(1);
   }

   for(j=0;j<n2 ; j++){
      ip[i][j] = (char *) malloc((unsigned) n3*sizeof(char));
      if( !ip[i][j] ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"step3(i=%d)(j=%d) integer matrix %d %d %d\n",i,j,n1,n2,n3);
       exit(1);
      }
   }
 }
 
  return(ip);
				 
}



float ***f3matrix(n1,n2,n3)
int n1,n2,n3;
{
int i,j;
float ***ip;

 ip = (float ***) malloc((unsigned ) n1*sizeof(float**) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 float 3 matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (float **) malloc((unsigned) n2*sizeof(float*));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) float 3 matrix %d %d\n",i,n1,n2);
    exit(1);
   }

   for(j=0;j<n2 ; j++){
      ip[i][j] = (float *) malloc((unsigned) n3*sizeof(float));
      if( !ip[i][j] ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"step3(i=%d)(j=%d) integer matrix %d %d %d\n",i,j,n1,n2,n3);
       exit(1);
      }
   }
 }
 
  return(ip);
				 
}




char **cmatrix(n1,n2)
int n1,n2;
{
int i;
char **ip;

 ip = (char **) malloc((unsigned ) n1*sizeof(char*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (char *) malloc((unsigned) n2*sizeof(char));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}


double **dmatrix(n1,n2)
int n1,n2;
{
int i;
double **ip;

 ip = (double **) malloc((unsigned ) n1*sizeof(double*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (double *) malloc((unsigned) n2*sizeof(double));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) double matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}



void free_ivector(v,n)
int *v,n;
{
   free((int*) v );
   return ;
 }

void free_fvector(v,n)
float *v;
int n;
{
   free((float*) v );
   return ;
 }

void free_dvector(v,n)
double *v;
int n;
{
   free((double*) v );
   return ;
 }


void free_cvector(v,n)
char *v;
int n;
{
   free((char*) v );
   return ;
 }


void free_cmatrix(m,n1,n2)
char **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}

void free_imatrix(m,n1,n2)
int  **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((int *) (m[i]));
     }
    free((int *) m);
}


void free_dmatrix(m,n1,n2)
double  **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((double *) (m[i]));
     }
    free((double *) m);
}


