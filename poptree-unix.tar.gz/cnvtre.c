#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#define MAXOTU 500
#define MAXNM 100
#define MAXTMLAB 20
#define MAXLEN 60
#define MAXSBNM 30
#define ERR stdout
#define ACU  0.00000000001

struct nds{
    int nkey,nc;
    double height,dx,dy,x,y,db;
    struct nds *b, *lc,*rc;
    double *bbx,*blcx,*brcx;
    int *bstbx,*bstlcx,*bstrcx;
    int *bstbx1,*bstlcx1,*bstrcx1,iflg;
    unsigned char *pbx,*plcx,*prcx;
 };
struct com{
int nseq,npc,idnflg,bstflg,nbstflg,ext,tieflg,ntietree;
unsigned char **part/*[MAXOTU-2][(MAXOTU-1)/8+1]*/;
char **fl/*[MAXOTU][MAXNM]*/;
int mr,ml,mb,bc,titflg,*nlr/*[MAXOTU]*/,*nll/*[MAXOTU]*/;
struct nds *bt1,*bt2,*a1,*a2;
struct nds *maxp[2],*maxps;
int idmaxflg;
char bf[100];
int *bstnb/*[2*MAXOTU-3]*/,lowlim;
double *conflvl/*[2*MAXOTU-3]*/;
FILE *fps,*fpo;
double dmax;
int nintnode,nobranch,nc;
};





     
struct com comm;
struct nds *nda/*[2*MAXOTU-2]*/,**adpart/*[MAXOTU-2]*/;
int dflg;

struct nds *ndsvector(n)
int n;
{
 struct nds *vp;


   vp = (struct nds *)malloc((unsigned) n*sizeof(struct nds));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"integer vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

struct nds **ndspvector(n)
int n;
{
 struct nds **vp;


   vp = (struct nds **)malloc((unsigned) n*sizeof(struct nds *));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"integer vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

int *ivector(n)
int n;
{
int *vp;

   vp = (int *)malloc((unsigned) n*sizeof(int));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"integer vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

char *cvector(n)
int n;
{
char *vp;

   vp = (char *)malloc((unsigned) n*sizeof(char));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"char vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

double *dvector(n)
int n;
{
double *vp;

   vp = (double *)malloc((unsigned) n*sizeof(double));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"double vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

int **imatrix(n1,n2)
int n1,n2;
{
int i,**ip;

 ip = (int **) malloc((unsigned ) n1*sizeof(int*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (int *) malloc((unsigned) n2*sizeof(int));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}




char **cmatrix(n1,n2)
int n1,n2;
{
int i;
char **ip;

 ip = (char **) malloc((unsigned ) n1*sizeof(char*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (char *) malloc((unsigned) n2*sizeof(char));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}


unsigned char **ucmatrix(n1,n2)
int n1,n2;
{
int i;
unsigned char **ip;

 ip = (unsigned char **) malloc((unsigned ) n1*sizeof(unsigned char*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (unsigned char *) malloc((unsigned) n2*sizeof(unsigned  char));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}


double **dmatrix(n1,n2)
int n1,n2;
{
int i;
double **ip;

 ip = (double **) malloc((unsigned ) n1*sizeof(double*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (double *) malloc((unsigned) n2*sizeof(double));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) double matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}


void free_ivector(v,n)
int *v,n;
{
   free((char*) v );
   return ;
 }

void free_dvector(v,n)
double *v;
int n;
{
   free((char*) v );
   return ;
 }


void free_cvector(v,n)
char *v;
int n;
{
   free((char*) v );
   return ;
 }


void free_cmatrix(m,n1,n2)
char **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}

void free_imatrix(m,n1,n2)
int  **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}


void free_dmatrix(m,n1,n2)
double  **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}



rdtv(fp,nseqw,fl,nda,blen,maxnm,nbst)
struct ndc *nda/*[2*MAXOTU-2]*/;
FILE *fp;
int *nseqw,*nbst;
double *blen/*[2*MAXOTU-2]*/;
char **fl/*[MAXOTU][MAXNM]*/;
{
int i,j, rn,n,**ntb/*[2*MAXOTU-3][2]*/,nw,n1,n2,n3,bstn,nl,r1,r2,bstflg,tieflg;
char b[1000],bw[200],bw1[200],s1[20],s2[20];
float fw,fw1,fw2;
extern int **imatrix();
extern void free_imatrix();

    ntb = imatrix(2*(*nseqw)-3,2);
    
    bstflg =0;
    tieflg =0;
    nl=0;
    for(i=0; i< *nseqw ; i++){
     for(j=0; j<maxnm+1 ; j++) fl[i][j]=0;
    }
   
   for(i=0; i<200; i++){
       bw[i]=bw1[i]=0;
     }
   for( ; ; ){
     rn=rdline(fp,b,&n);
     nl++;
/*     printf("nl=%d\n",nl); */
     if( rn == 2 ) continue;
     if( rn == 1 ){
        printf("first line read error\n");
        exit(1);
    }
     break;
   }

   sscanf(b,"%d %s %s\n",nseqw,bw,s1);
   sscanf(b,"%d %s %d %s\n",nseqw,bw,&bstn,bw1);
   *nbst = bstn;
   if( strcmp(bw,"sequences") != 0 && strcmp(bw,"populations") != 0 && strcmp(bw,"individuals") !=0 && strcmp(bw,"otus") != 0 ){
      printf("first line invalid format\n");
      exit(1);
    }
   if( *nseqw > MAXOTU ){
       printf("too many sequences\n");
       exit(1);
     }
    if( strlen(bw1) != 0 ){
         if( strcmp(bw1,"bootstraping") == 0 ){
           bstflg=1;
           comm.bstflg=1;
	   /*           fprintf(stderr,"%d bootstrapping\n",bstn);*/
         }
       }

    if( strlen(bw1) != 0 ){
         if( strcmp(bw1,"tie") == 0 || strcmp(bw1,"ties") == 0 ){
           bstflg=4;
           comm.ntietree = bstn;
           comm.bstflg=4;
         }
       }

    if( strlen(s1) != 0 ){
         if( strcmp(s1,"ratetest") == 0 ){
           bstflg =3;
           comm.bstflg=3;
         }
       }
   for(i=0; i<*nseqw ; i++){
     if( (rn=rdline(fp,b,&n)) != 0 ){
        printf("sequence names read error\n");
      }
     nl++;
/*     printf("nl=%d\n",nl); */
     getname(&nw,bw,b,n);
/*     sscanf(b,"%d %s",&nw,bw); */     if( nw != i+1 ){
        printf("sequence number read error %d %d\n",nw,i+1);
        exit(1);
      }
      nw = strlen(bw);
      if( nw > MAXNM){
        printf("sequence name too long %s\n",bw);
        exit(1);
      }

/*
      if( strcmp(fl[i],bw) != 0 ) {
         printf("sequence name inconsistency %d %s %s\n",i+1,fl[i],bw);
         exit(1);
       }
*/
       strcpy(fl[i],bw);
/*       printf("bw %s fl %s\n",bw,fl[i]); */
   }
/*  printf("bootstap =%d\n",comm.bstflg); */
  for(i=0; i< 2*(*nseqw)-3 ; i++){
     for( ; ; ){
        rn = rdline(fp,b,&n);
        nl++;
/*        printf("nl=%d\n",nl); */
        if( rn == 2 ) continue;
        if( rn == 1 ){
             printf("format error\n");
              exit(1);
	   }
         break;
     }
     if( i == 0 ){
         for(j=0; j<n ; j++){
           if( b[j] == '%' ) {
              comm.bstflg=2;
              break;
	    }
	 }
       }
/*      printf("comm.bstflg=%d\n",comm.bstflg); */
      switch(comm.bstflg){
         case 0:  /* no bootstrap nor confidence level */
                 sscanf(b,"%d and %d %f",&n1,&n2,&fw);
                 ntb[i][0]=n1;
                 ntb[i][1]=n2;
                 blen[i]=fw;
                 break;
        case 1:  /* bootstrap */
                 sscanf(b,"%d and %d %f %d",&n1,&n2,&fw,&n3);
                 ntb[i][0]=n1;
                 ntb[i][1]=n2;
                 blen[i]=fw;
                 comm.bstnb[i]=n3*100;
                 comm.bstnb[i] /= bstn;
                 break;
       case 2:   /* confidence level */
       case 3:   /* rate test  */
                 brm(b,n);
                 sscanf(b,"%d and %d %f %s  %s",&n1,&n2,&fw,s1,s2);
                 r1 = chkminus(s1);
                 r2 = chkminus(s2);
                 if( r2 > 1 ){
                      ntb[i][0]=n1;
                      ntb[i][1]=n2;
                      blen[i]=fw;
                      comm.bstnb[i]= -1.0;
                      break;
		    }
                 sscanf(b,"%d and %d %f %f  %f",&n1,&n2,&fw,&fw1,&fw2);
                 ntb[i][0]=n1;
                 ntb[i][1]=n2;
                 blen[i]=fw;
                 comm.bstnb[i]=fw2;
                 break;
       case 4:  /* bootstrap */
                 sscanf(b,"%d and %d %f %d",&n1,&n2,&fw,&n3);
                 ntb[i][0]=n1;
                 ntb[i][1]=n2;
                 blen[i]=fw;
                 comm.bstnb[i]=n3;
                 break;

       }
   }
   
   rn=trnd(*nseqw,ntb,nda,blen);

  if( bstflg == 3 ) comm.bstflg=3;

  free_imatrix(ntb,2*(*nseqw)-3,2);
   return(0);
}

chkminus(s1)
char *s1;
{

int i,n;

  n=0;
  for(i=0; i<20 ; i++){
     if( s1[i] == 0 ) return(n);
     if( s1[i] == '-' ) n++;
   }

   return(n);
}

brm(b,n)
char b[];
{
 int i,psflg;
  psflg=0;
  for(i=0; i<n ; i++){
    if( b[i] == '%' ) psflg++;
    if( b[i] < 0x26 || b[i] > 0x7e ) b[i] = ' ';
  }
  if( psflg != 1 ){
    printf("invalid format in input file confidence level is assumed %d\n%s\n",psflg,b);
    exit(1);
  }
  return(0);
}


trnd(nseqw,ntb,nda,blen)
int nseqw,**ntb/*[2*MAXOTU-3][2]*/;
struct nds *nda/*[2*MAXOTU-2]*/;
double *blen/*[2*MAXOTU-2]*/;
{
int i,j,k,n1,ns;

  for(i=0; i<2*nseqw-2; i++){
     nda[i].nkey = i+1;
     nda[i].nc = 0;
     nda[i].lc=NULL;
     nda[i].rc=NULL;
     nda[i].b=NULL;
     nda[i].plcx=NULL;
     nda[i].prcx=NULL;
     nda[i].pbx=NULL;
     nda[i].blcx=NULL;
     nda[i].brcx=NULL;
     nda[i].bbx=NULL;
     nda[i].bstlcx=NULL;
     nda[i].bstrcx=NULL;
     nda[i].bstbx=NULL;
     nda[i].height=0.0;
   }
  for(i=0; i<nseqw ; i++){
     ns=0;
     for(j=0; j<2*nseqw-3; j++){
         if( ntb[j][1] == i+1 ){
             nda[i].b = &nda[ntb[j][0]-1];
             nda[i].bbx = &blen[j];
             nda[i].bstbx = &comm.bstnb[j];
/*             printf(" %d %d %f\n",i+1,ntb[j][0],blen[j]); */
             ns++;
	   }
         if( ntb[j][0] == i+1 ){
             nda[i].b = &nda[ntb[j][1]-1];
             nda[i].bbx = &blen[j];
             nda[i].bstbx = &(comm.bstnb[j]);
/*             printf(" %d %d %f\n",i+1,ntb[j][1],blen[j]); */
             ns++;
	   }
       }
      if( ns != 1 ){
         printf("sequence %d format error\n",i+1);
       }
   }

    
    for( i=nseqw+1 ; i<= 2*nseqw-2 ; i++){
       ns=0;
       for(j=0; j<2*nseqw-3 ; j++){
         for(k=0; k<2 ; k++){
           if( ntb[j][k] == i ){
              switch(k){
                  case 0: n1 = ntb[j][1];
                          break;
                  case 1: n1 = ntb[j][0];
                          break;
		  }
               switch(ns){
 	         case 0: nda[i-1].lc = &nda[n1-1];
                         nda[i-1].blcx = &blen[j];
                         nda[i-1].bstlcx = &(comm.bstnb[j]);
                         break;
 	         case 1: nda[i-1].rc = &nda[n1-1];
                         nda[i-1].brcx = &blen[j];
                         nda[i-1].bstrcx = &(comm.bstnb[j]);
                         break;
      	         case 2: nda[i-1].b = &nda[n1-1];
                         nda[i-1].bbx = &blen[j];
                         nda[i-1].bstbx = &(comm.bstnb[j]);
                         break;
                 default: printf("format error node%d ns=%d\n",i,ns);
                          exit(1);
		 }
               ns++;  
               break;
	    }
	 }
       }
       if( ns != 3 ){
          printf("format error node%d ns=%d\n",i,ns);
          exit(1);
        }
     }

/*for(i=0; i<2*nseqw-3 ; i++){
   if( nda[i].nkey <= nseqw ) printf("%d b:%d\n",nda[i].nkey,nda[i].b->nkey);
   if( nda[i].nkey > nseqw ) printf("%d b:%d l:%d r:%d\n",nda[i].nkey,nda[i].b->nkey,nda[i].lc->nkey,nda[i].rc->nkey);

 }
*/
return(0);
}

rdline(fp,b,n)
int *n;
char *b;
FILE *fp;
{
int c,np;
   *n=0;

   np=0;
   for( ; ; ){
      c = fgetc(fp);
      if( c == EOF ) return(1);
      if( c != ' ' ) np++;
      b[*n]=c;
      (*n)++;
      if( c == '\n' ) break;
    }
    if( np == 0 ) return(2);
   return(0);
}





getname(nid,snm,bf,nl)
int *nid,nl;
char *snm,*bf;
{
char bn[10];
int i,n,flg,nc,nst,nend;
 flg=0;
 n=0;
 for(i=0; i<MAXNM ; i++) snm[i]=0;
 for(i=0; i<10 ; i++) bn[i]=0;
 for( ; ; ){
  if( bf[n] == ' ' ){
     n++;
     continue;
   }
   break;
 }
 nc=0;
 for( ; ; ){
   if( bf[n] == ' ' ) break;
   bn[nc] = bf[n];
   if( bn[nc] > '9' || bn[nc] < '0' ) return(-1);
   nc++;
   n++;
 }
 sscanf(bn,"%d",nid);
 for( ; ; ){
   if( bf[n] == ' ' ) {
     n++;
     continue;
   }
   break;
 }

  nst=n;
  for(i=nl-1;  ; i--){
   if( bf[i] == ' ' ) continue;
   nend=i;
   break;
  }
  
  for(i=nst ; i< nend ; i++) snm[i-nst]=bf[i];

  return(0);
}


/*
#include "maxds.c"
#include "rdtv.c"
#include "dwnarg.c"
#include "drwarg.c"
#include "outchk.c"
#include "under.c"
*/

chktv(fp,nseqw,maxnm)
FILE *fp;
int *nseqw,*maxnm;
{
int i,j, rn,n,nw,n1,n2,n3,bstn,nl,r1,r2;
char b[1000],bw[200],bw1[200],s1[20],s2[20];
float fw,fw1,fw2;

    nl=0;
   (*maxnm) = -1;    
   for(i=0; i<200; i++){
       bw[i]=bw1[i]=0;
     }
   for( ; ; ){
     rn=rdline(fp,b,&n);
     nl++;
/*     printf("nl=%d\n",nl); */
     if( rn == 2 ) continue;
     if( rn == 1 ){
        printf("first line read error\n");
        exit(1);
    }
     break;
   }

   sscanf(b,"%d %s %s\n",nseqw,bw,s1);
   sscanf(b,"%d %s %d %s\n",nseqw,bw,&bstn,bw1);
   if( strcmp(bw,"sequences") != 0 && strcmp(bw,"populations") != 0 
      && strcmp(bw,"individuals") !=0 && strcmp(bw,"otus") != 0 ){
      printf("first line invalid format\n");
      exit(1);
    }
    if( strlen(bw1) != 0 ){
         if( strcmp(bw1,"bootstraping") == 0 ){
           comm.bstflg=1;
         }
       }

    if( strlen(bw1) != 0 ){
         if( strcmp(bw1,"tie") == 0 || strcmp(bw1,"ties") == 0 ){
           comm.ntietree = bstn;
           comm.bstflg=4;
         }
       }

    if( strlen(s1) != 0 ){
         if( strcmp(s1,"ratetest") == 0 ){
           comm.bstflg=3;
         }
       }
   for(i=0; i<*nseqw ; i++){
     if( (rn=rdline(fp,b,&n)) != 0 ){
        printf("sequence names read error\n");
      }
     nl++;
/*     printf("nl=%d\n",nl); */
     getname(&nw,bw,b,n);
/*     sscanf(b,"%d %s",&nw,bw); */     if( nw != i+1 ){
        printf("sequence number read error %d %d\n",nw,i+1);
        exit(1);
      }
      nw = strlen(bw);
      if( nw > *maxnm ){
         *maxnm = nw;
      }

   }
  for(i=0; i< 2*(*nseqw)-3 ; i++){
     for( ; ; ){
        rn = rdline(fp,b,&n);
        nl++;
/*        printf("nl=%d\n",nl); */
        if( rn == 2 ) continue;
        if( rn == 1 ){
             printf("format error\n");
              exit(1);
	   }
         break;
     }
     if( i == 0 ){
         for(j=0; j<n ; j++){
           if( b[j] == '%' ) {
              comm.bstflg=2;
              break;
	    }
	 }
       }
/*      printf("comm.bstflg=%d\n",comm.bstflg); */
      switch(comm.bstflg){
         case 0:  /* no bootstrap nor confidence level */
                 sscanf(b,"%d and %d %f",&n1,&n2,&fw);
                 break;
        case 1:  /* bootstrap */
                 sscanf(b,"%d and %d %f %d",&n1,&n2,&fw,&n3);
                 break;
       case 2:   /* confidence level */
       case 3:   /* rate test  */
                 brm(b,n);
                 sscanf(b,"%d and %d %f %s  %s",&n1,&n2,&fw,s1,s2);
                 r1 = chkminus(s1);
                 r2 = chkminus(s2);
                 sscanf(b,"%d and %d %f %f  %f",&n1,&n2,&fw,&fw1,&fw2);
                 break;
       case 4:  /* bootstrap */
                 sscanf(b,"%d and %d %f %d",&n1,&n2,&fw,&n3);
                 break;

       }
   }
   
   return(0);
}


chkarg(nseqw,argc,argv,noutg0,outg)
int argc,nseqw,noutg0,*outg;
char **argv;
{
int i,j,nfnode,noutg,iw;
float fw;
nfnode=0;
noutg=0;
        for(i=1; i<argc; i++){
           if(argv[i][0] == '-' ){
              switch(argv[i][1]){
        	   case 'o': 
                             noutg=0;
                             if( argv[i][2] >= '0' && argv[i][2] <= '9' ){
                                  sscanf(argv[i]+2,"%d",&outg[noutg]);
                                  noutg=1;
				}
                             for(j=i+1 ; j<argc ; j++){
                              if( argv[j][0] > '9' || argv[j][0] < '0' ) break;
                                sscanf(argv[j],"%d",&outg[noutg]);
                                noutg++;
                                if( noutg >noutg0 ){
                                     printf("too many outgroup %d\n",noutg);
                                     exit(1);
				   }
                                i++;
		     }
                            if( noutg == 0 ){
                                 printf("no outgroup");
                                 exit(1);
			       }
                             printf("outgroup =%d\n",noutg); fflush(stdout);
                             break;



			   }
	   }


	}

return(0);
}


dwnarg(cur,anc)
struct nds *cur, *anc;
{
struct nds *pw;
double *bw,dnc,dw1,dw;
int flg,i,j,nw,nm,nc,na,iw,*ip;
unsigned char nx,ny, *pc;

/* printf("dwnarg cur %d anc %d\n",cur->nkey,anc->nkey); 
 if( cur->b != NULL ) printf("cur b %d",cur->b->nkey);
 if( cur->lc != NULL ) printf("cur l %d",cur->lc->nkey);
 if( cur->rc != NULL ) printf("cur r %d",cur->rc->nkey);
 printf("cur->lc=%p anc=%p cur->rc=%p cur->b=%p\n",cur->lc,anc,cur->rc,cur->b);
 printf("\n");
 fflush(stdout); 
*/
    flg = 0;
    if( cur->b  == anc ) flg += 1;
    if( cur->lc == anc ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx=ip;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
      }

    if( cur->rc == anc ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx=ip;

        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;

        flg += 3;
      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }
     if( cur->lc != NULL ){
         dw = *(cur->blcx);
         if( dw < 0.0 ) dw=0.0;
         cur->lc->height = cur->height+ dw; 
       }
     if( cur->rc != NULL ){
         dw = *(cur->brcx);
         if( dw < 0.0 ) dw=0.0;
         cur->rc->height = cur->height+ dw; 
       }
    fflush(stdout);
    if( cur->lc != NULL && cur->rc != NULL ) comm.nintnode++;
/*    printf("%d cur->height=%f\n",cur->nkey,cur->height); */
    if( (cur->nkey <= comm.nseq) && ( cur == comm.bt1) ){
        dw = 0.;
        for(i=0; i< comm.nintnode ; i++ ) fprintf(comm.fpo,"(");
         comm.nc += comm.nintnode + strlen(comm.fl[cur->nkey-1]);
        if( cur->b == anc ) dw = *cur->bbx;
        if( cur->lc == anc ) dw = *cur->blcx;
        if( cur->rc == anc ) dw = *cur->brcx;
        if( comm.nobranch == 0 || comm.idnflg == 1) {
           fprintf(comm.fpo,"%s:%f,",comm.fl[cur->nkey-1],dw);
           clrbf(comm.bf,100);
           sprintf(comm.bf,"%f",dw);
           comm.nc += strlen(comm.bf)+2;
	}
        if( comm.nobranch == 1 && comm.idnflg == 0 ) {
          fprintf(comm.fpo,"%s,",comm.fl[cur->nkey-1]);
          comm.nc  += 1;
	}
        if( comm.nc >= MAXLEN ){
          fprintf(comm.fpo,"\n");
          comm.nc = 0;
	}
        comm.ext++;
    }
    if( (cur->nkey <= comm.nseq) && (cur == anc->lc) && ( cur != comm.bt1) ){
        for(i=0; i< comm.nintnode ; i++ ) fprintf(comm.fpo,"(");
        comm.nc += comm.nintnode + strlen(comm.fl[cur->nkey-1]);
        if( comm.nobranch == 0 || comm.idnflg == 1) {
           fprintf(comm.fpo,"%s:%f,",comm.fl[cur->nkey-1],*anc->blcx);
           clrbf(comm.bf,100);
           sprintf(comm.bf,"%f",*anc->blcx);
           comm.nc += strlen(comm.bf)+2;
	}
        if( comm.nobranch == 1 && comm.idnflg == 0 ) {
          fprintf(comm.fpo,"%s,",comm.fl[cur->nkey-1]);
          comm.nc  += 1;
	}
        if( comm.nc >= MAXLEN ){
          fprintf(comm.fpo,"\n");
          comm.nc = 0;
	}
        comm.ext++;
     }
    if( (cur->nkey <= comm.nseq ) && (cur == anc->rc) && ( cur != comm.bt1) ){
         comm.nc += strlen(comm.fl[cur->nkey-1]);
        if( comm.nobranch == 0 || comm.idnflg == 1 ) {
            fprintf(comm.fpo,"%s:%f",comm.fl[cur->nkey-1],*anc->brcx);
            clrbf(comm.bf,100);
            sprintf(comm.bf,"%f",*anc->brcx);
            comm.nc += strlen(comm.bf)+1;
   	}
        if( comm.nobranch == 1 && comm.idnflg == 0) {
           fprintf(comm.fpo,"%s",comm.fl[cur->nkey-1]);
	}
        if( comm.nc >= MAXLEN ){
          fprintf(comm.fpo,"\n");
          comm.nc = 0;
	}
        comm.ext++;
     }

    if( cur->lc != NULL) {
        dwnarg(cur->lc,cur);
     }

   if( cur->rc != NULL) {
        comm.nintnode=0; 
        dwnarg(cur->rc,cur);
     }

  
  if( cur->rc != NULL && cur->lc != NULL){
       if( cur != comm.bt1 ){
                    if(  comm.idnflg == 1 ){
              clrbf(comm.bf,100);
              sprintf(comm.bf,"%d",cur->nkey);
              comm.nc += strlen(comm.bf)+1;
              clrbf(comm.bf,100);
              sprintf(comm.bf,"%f",*cur->bbx);
              comm.nc += strlen(comm.bf);;
             if(cur == anc->lc) {
                fprintf(comm.fpo,")%d:%f,",cur->nkey,*cur->bbx);
                comm.nc += 3;
	     }
             if(cur == anc->rc) {
                fprintf(comm.fpo,")%d:%f",cur->nkey,*cur->bbx);
                comm.nc += 2;
	     }
         }else{
           if( comm.nobranch == 0 ){
           if( comm.bstflg != 0 && comm.idnflg == 0 ){
              if( *cur->bstbx >= comm.lowlim ){
                 clrbf(comm.bf,100);

                 sprintf(comm.bf,"%d",*cur->bstbx);
                 comm.nc += strlen(comm.bf)+1;
	      }
              clrbf(comm.bf,100);
              sprintf(comm.bf,"%f",*cur->bbx);
              comm.nc += strlen(comm.bf);;
             if(cur == anc->lc) {
                if( *cur->bstbx >= comm.lowlim ){
                  fprintf(comm.fpo,")%d:%f,",*cur->bstbx,*cur->bbx);
                  comm.nc += 3;
		}else{
                  fprintf(comm.fpo,")%f,",*cur->bbx);
                  comm.nc += 3;
		}
	     }
             if(cur == anc->rc) {
                if( *cur->bstbx >= comm.lowlim ){
                  fprintf(comm.fpo,")%d:%f",*cur->bstbx,*cur->bbx);
                  comm.nc += 2;
		}else{
                  fprintf(comm.fpo,")%f",*cur->bbx);
                  comm.nc += 1;
		}
	     }
	   }
           if( comm.bstflg == 0 && comm.idnflg == 0 ) {
              clrbf(comm.bf,100);
              sprintf(comm.bf,"%f",*cur->bbx);
              comm.nc += strlen(comm.bf);
             if(cur == anc->lc) {
                fprintf(comm.fpo,")%f,",*cur->bbx);
                comm.nc += 2;
	     }
             if(cur == anc->rc){
                fprintf(comm.fpo,")%f",*cur->bbx);
                comm.nc += 1;
	     }
	   }
	 }
         if( comm.nobranch == 1 ) {
             if(cur == anc->lc)  {
                  fprintf(comm.fpo,"),");
                  comm.nc += 2;
	     }
             if(cur == anc->rc)  {
                fprintf(comm.fpo,")");
                  comm.nc += 2;
	     }
	 }
	 }
       }
       if(  cur == comm.bt1 ){
	   if( comm.idnflg == 1 ){
              clrbf(comm.bf,100);
              sprintf(comm.bf,"%d",cur->nkey);
              comm.nc += strlen(comm.bf)+1;
              clrbf(comm.bf,100);
              sprintf(comm.bf,"%f",*cur->bbx);
              comm.nc += strlen(comm.bf)+3;
             if(cur == anc->lc) fprintf(comm.fpo,")%d:%f,",cur->nkey,*cur->bbx);
             if(cur == anc->rc) fprintf(comm.fpo,")%d:%f,",cur->nkey,*cur->bbx);
             if(cur == anc->b) fprintf(comm.fpo,")%d:%f,",cur->nkey,*cur->bbx);
	   }else{
             if( comm.nobranch == 0 ) {
	       if( comm.idnflg == 1 ){
                 clrbf(comm.bf,100);
                 sprintf(comm.bf,"%d",cur->nkey);
              comm.nc += strlen(comm.bf)+1;
              clrbf(comm.bf,100);
              sprintf(comm.bf,"%f",*cur->bbx);
              comm.nc += strlen(comm.bf)+3;
             if(cur == anc->lc) fprintf(comm.fpo,")%d:%f,",cur->nkey,*cur->bbx);
             if(cur == anc->rc) fprintf(comm.fpo,")%d:%f,",cur->nkey,*cur->bbx);
             if(cur == anc->b) fprintf(comm.fpo,")%d:%f,",cur->nkey,*cur->bbx);
	   }
	   if( comm.bstflg != 0 && comm.idnflg == 0 ){
              if( *cur->bstbx >= comm.lowlim ){
                clrbf(comm.bf,100);
                sprintf(comm.bf,"%d",*cur->bstbx);
                comm.nc += strlen(comm.bf)+1;
	      }
              clrbf(comm.bf,100);
              sprintf(comm.bf,"%f",*cur->bbx);
              comm.nc += strlen(comm.bf)+3;
             if(  *cur->bstbx >= comm.lowlim ){
               if(cur == anc->lc) fprintf(comm.fpo,")%d:%f,",*cur->bstbx,*cur->bbx);
               if(cur == anc->rc) fprintf(comm.fpo,")%d:%f,",*cur->bstbx,*cur->bbx);
               if(cur == anc->b) fprintf(comm.fpo,")%d:%f,",*cur->bstbx,*cur->bbx);
	     }else{
                fprintf(comm.fpo,")%f,",*cur->bbx);
	     }
	   }
	   if( comm.bstflg == 0 && comm.idnflg == 0  ){
              clrbf(comm.bf,100);
              sprintf(comm.bf,"%f",*cur->bbx);
              comm.nc += strlen(comm.bf)+2;
             if(cur == anc->lc) fprintf(comm.fpo,")%f,",*cur->bbx);
             if(cur == anc->rc) fprintf(comm.fpo,")%f,",*cur->bbx);
             if(cur == anc->b) fprintf(comm.fpo,")%f,",*cur->bbx);
	   }
          
	 }else{
            fprintf(comm.fpo,"),");
            comm.nc += 2;
	 }
 

	   }
       }
	 if( comm.nc >= MAXLEN) {
            fprintf(comm.fpo,"\n");
            comm.nc=0;
         }        
 


  }




   return(0);

}


outchk(nseq0,noutg,outg,cur0,anc0)
int nseq0,noutg,outg[];
struct nds **anc0,**cur0;

{
int i,j,k,*a0/*[MAXOTU]*/,*a1/*[MAXOTU]*/,n0,n1,nm,na,flg,bn,ln,rn;
int *bm/*[MAXOTU]*/,*lm/*[MAXOTU]*/,*rm/*[MAXOTU]*/;
unsigned char nx,ny;
extern int *ivector();
extern void free_ivector();

   a0 = ivector(nseq0);
   a1 = ivector(nseq0);
  
/* printf("outchk\n");fflush(stdout); */

for(i=0; i<nseq0-2; i++){
  n0=0;
  n1=0;
/*  printf("outchk %d\n",i);fflush(stdout); */
  for(j=0; j<nseq0 ; j++){
     nm = j/8;
     na = j%8;
     nx = 0x80;
     nx >>= na;
     ny = nx & comm.part[i][nm];
     if( ny == 0 ) {
           a0[n0]=j;
           n0++;
	 }
     else{
           a1[n1]=j;
           n1++;
	 }
/*    printf("j=%d n0=%d n1=%d\n",j,n0,n1);fflush(stdout);  */
   }

    flg=0;
    if( n0 == noutg || n1 == noutg){
    printf("%d n1=%d n0=%d %d b %d\n",i,n1,n0,adpart[i]->nkey,adpart[i]->b->nkey);

        if( n0 == noutg ){
          for(j=0; j<noutg ; j++){
            if( a0[j]+1 != outg[j] ) break;
            flg++;
	  }
          if( flg == noutg  ){
                  *cur0 = adpart[i];
                  *anc0 = adpart[i]->b;
                  free_ivector(a0,nseq0);
                  free_ivector(a1,nseq0);
                  return(0);
		}


	}
        if( n1 == noutg ){
         for(j=0; j<noutg ; j++){
            if( a1[j]+1 != outg[j] ) break;
            flg++;
	  }
        if( flg == noutg  ){
                  *cur0 = adpart[i]->b;
                  *anc0 = adpart[i];
                  free_ivector(a0,nseq0);
                  free_ivector(a1,nseq0);
                  return(0);
		}
       }
      }


}
   free_ivector(a0,nseq0);
   free_ivector(a1,nseq0);

    return(-1);
}






under(ac,cur,nmem,nmeml)
struct nds *ac,*cur;
int *nmem,*nmeml;
{
struct nds *pw;
double *bw,dsum,ra,rb;
int flg,i,j,nw,*ip;
unsigned char nx,ny, *pc;
/* printf("nseq=%d  cur=%d\n",nseq,cur->nkey); 
fflush(stdout); 
*/
    flg = 0;
    if( cur->b  == ac ) flg += 1;
    if( cur->lc == ac ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx=ip;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
      }

    if( cur->rc == ac ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx=ip;
        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;
        flg += 3;
      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }


    if( cur->rc != NULL) {
       under(cur,cur->rc,nmem,nmeml);
     }

    if( cur->lc != NULL) {
       under(cur,cur->lc,nmem,nmeml);
     }
   if( cur->lc != NULL && cur->rc != NULL){
       if( cur->lc->nkey <= comm.nseq ) {
              cur->plcx=NULL;
              nw=cur->lc->nkey;
              nmeml[*nmem]=nw;
              (*nmem)++;
	   }
       if( cur->rc->nkey <= comm.nseq ) {
              cur->prcx=NULL;
              nw=cur->rc->nkey;
	      nmeml[*nmem]=nw;
              (*nmem)++;
	    }
	    }







   return(0);
     }












dsmax()
{
int i,j;
/* printf("nseq=%d bc=%d  cur=%d\n",nseq,bc,cur->nkey); 
fflush(stdout); 
*/


/*   printf("dsmax begin\n"); fflush(stdout); */
   comm.dmax=-990.0;
   for(i=0; i< comm.nseq*2 -2 ; i++) nda[i].iflg =0;
   for(i=0; i< comm.nseq-1 ; i++){
      comm.maxps = &nda[i];
      for(j=0; j< comm.nseq*2 - 2 ; j++){
        nda[j].db = 0.;
      }
      nda[i].b->db = *(nda[i].bbx);
      serdmax(nda[i].b,&nda[i]);
/*      printf("i=%d maxp %d %d dmax=%f\n",i,comm.maxp[0]->nkey,comm.maxp[1]->nkey,comm.dmax); */
      fflush(stdout);

    }
    
    for(i=0; i< comm.nseq*2 -2 ; i++){
        nda[i].iflg =0;
        nda[i].db =0.;
      }
    comm.idmaxflg = 0;
    sermid(comm.maxp[0]->b,comm.maxp[0]);
    return(0);
}

serdmax(cur,ac)
struct nds *cur, *ac;
{
struct nds *pw;
double *bw,dw,db;
int flg,*ip;
unsigned char *pc;
    flg = 0;
    if( cur->b  == ac ) flg += 1;
    if( cur->lc == ac ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx = ip;
      }

    if( cur->rc == ac ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;

        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx = ip;

        flg += 3;
      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }

/*     printf("serdmax cur %d ac %d rc\n",cur->nkey,ac->nkey); fflush(stdout); */
   
    if( cur->rc != NULL) {
        cur->rc->db = *(cur->brcx) + cur->db;
        serdmax(cur->rc,cur);

     }

    if( cur->lc != NULL) {
        cur->lc->db = *(cur->blcx) + cur->db;
        serdmax(cur->lc,cur);
     }

     if( cur->nkey <= comm.nseq && cur != comm.maxps) {
              if( cur->db > comm.dmax ){
                 comm.dmax = cur->db;
                 comm.maxp[0] = comm.maxps;
                 comm.maxp[1] = cur;
/*                 printf("maxp %d %d dmax=%f\n",comm.maxp[0]->nkey,comm.maxp[1]->nkey,comm.dmax); */
                 fflush(stdout);
	       }
	    }
      return(0);
  }



sermid(cur,ac)
struct nds *cur, *ac;
{
struct nds *pw;
double *bw,dw,db;
int flg,*ip;
unsigned char *pc;

    flg = 0;
    if( cur->b  == ac ) flg += 1;
    if( cur->lc == ac ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx = ip;
      }

    if( cur->rc == ac ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;

        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx = ip;

        flg += 3;
      }
    
    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }

    if( cur->rc != NULL) {
        sermid(cur->rc,cur);

     }

    if( cur->lc != NULL) {
        sermid(cur->lc,cur);
     }
     if( cur->nkey <= comm.nseq ) {
              if( cur == comm.maxp[1] ){
                  cur->iflg = 1;
                  cur->db = *(cur->bbx);
/*                  printf("nkey=%d b=%d db=%f\n",cur->nkey,cur->b->nkey,cur->db); */
                  if( cur->db >= comm.dmax/2.0 && comm.idmaxflg == 0 ){
                      comm.a1=cur;
                      comm.a2=cur->b;
                      comm.idmaxflg = 1;
                        return(0);
         	       }
		}
    }
     if( cur->lc != NULL && cur->rc != NULL ){
          if( cur->lc->iflg == 1 ){
              cur->db = *(cur->bbx)+cur->lc->db;
/*              printf("nkey=%d b=%d db=%f blcx=%f db=%f dmax/2=%f\n",cur->nkey,cur->b->nkey,cur->db,*(cur->bbx),cur->lc->db,comm.dmax/2.);  */
              cur->iflg = 1;
	    }
          if( cur->rc->iflg == 1 ){
              cur->db = *(cur->bbx)+cur->rc->db;
/*              printf("nkey=%d b=%d db=%f brcx=%f db=%f dmax/2=%f\n",cur->nkey,cur->b->nkey,cur->db,*(cur->bbx),cur->rc->db,comm.dmax/2.); */
              cur->iflg = 1;
	    }
          if( cur->iflg == 1 ){
             if( cur->db >= comm.dmax/2.0  && comm.idmaxflg == 0  ){
                     comm.a1 = cur;
                     comm.a2 = cur->b;
                     comm.idmaxflg = 1;
/*                     printf("cur=%d curb=%d\n",cur->nkey,cur->b->nkey); */
                     return(0);
		   }
	   }
	}

      return(0);
}





























partition(ac,cur)
struct nds *ac,*cur;
{
struct nds *pw;
double *bw,dw,db;
int flg,*ip,i,nm,nw,na;
unsigned char *pc,nx,ny;

/* 
   tnodex  ancestor 
   tnodey  right
   tnodez  left
 */
    flg = 0;
/*    printf("cur=%d ac=%d",cur->nkey,ac->nkey); */
/*    if( cur->b != NULL ) printf(" b=%d",cur->b->nkey);
    if( cur->lc != NULL ) printf(" lc=%d",cur->lc->nkey);
    if( cur->rc != NULL ) printf(" rc=%d",cur->rc->nkey);
    printf("\n"); fflush(stdout);
*/
/*
    printf("cur=%p ac=%p",cur,ac);
    if( cur->b != NULL ) printf(" b=%p",cur->b);
    if( cur->lc != NULL ) printf(" lc=%p",cur->lc);
    if( cur->rc != NULL ) printf(" rc=%p",cur->rc);
    printf("\n");
*/
    if( cur->b  == ac ) flg += 1;
    if( cur->lc == ac ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx = ip;
      }

    if( cur->rc == ac ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;

        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx = ip;
        flg += 3;
      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d cur=%d\n",flg,cur->nkey);
       exit(1);
     }


    if( cur->lc != NULL) partition(cur,cur->lc);

    if( cur->rc != NULL) partition(cur,cur->rc);

    if( cur->lc != NULL && cur->rc != NULL ){
       if( cur->lc->nkey <= comm.nseq ){
        nw = cur->lc->nkey;
        nm = (nw-1)/8;
        na = (nw-1)%8;
        nx = 0x80;
        nx >>= na;
        comm.part[comm.npc][nm] |= nx;
        comm.ml=1;
        comm.nll[0]=nw-1;
       }else{
        cur->plcx = cur->lc->pbx;
        for(i=0; i< (comm.nseq-1)/8+1 ; i++){
          comm.part[comm.npc][i] |= cur->plcx[i];
        }
        getmem(cur->plcx,&comm.ml,comm.nll);
       }
       if( cur->rc->nkey <= comm.nseq ){
              cur->prcx = NULL;
              nw = cur->rc->nkey;
              nm = (nw-1)/8;
              na = (nw-1)%8;
              nx = 0x80;
              nx >>= na;
              comm.part[comm.npc][nm] |= nx;
              comm.mr =1;
              comm.nlr[0]=nw-1;
/*              printf("prc[%d]:",cur->rc->nkey);
              prpart1(comm.part[comm.npc]);
*/
	    }else{
              cur->prcx = cur->rc->pbx;
              for(i=0; i< (comm.nseq-1)/8+1 ; i++){
                comm.part[comm.npc][i] |= cur->prcx[i];
              }
/*              printf("part[%2d]:",comm.npc);
              prpart1(comm.part[comm.npc]);
              printf("prc[%d]:",cur->rc->nkey);
              prpart1(cur->prcx);
*/
              getmem(cur->prcx,&comm.mr,comm.nlr);
            }
           adpart[comm.npc] = cur;
           cur->pbx = comm.part[comm.npc];
/*           printf("cur[%d]:",cur->nkey);
           prpart1(cur->pbx);
*/
           comm.npc++;

     }
     return(0);
}
          

getmem(cpo,mx,nlx)
unsigned char *cpo;
int *mx,*nlx;
{
unsigned char nx,ny;
int i,j,nc,nm;
     nc=0;
     *mx=0;
     nm=0;
     for(i=0; i< (comm.nseq-1)/8+1 ; i++){
        for(j=0; j<8 ; j++){
            nx = 0x80;
            nx = nx >> j;
            ny = cpo[i] & nx;
/*            printf("x=%02x p=%d y=%d ",nx,cpo[i],ny);  */
            ny = ny >> (7-j);
/*            printf("y=%d\n",ny);*/
            switch(ny){
                  case 0: break;
                  case 1: nlx[nm]=nc;
                          nm++;
                          if( dflg == 1 ) printf("getmem nm=%d\n",nm);
                          break;
                 default: printf("invalid ny=%d\n",ny);
                      exit(1);
	     }
       nc++;
       if( nc >= comm.nseq ) {
            *mx=nm;
            return(0);
	  }

	      }
	    }


}




prpart()
{
int i,j,nw,nm,na;
unsigned char nx,ny;

for(i=0; i< comm.nseq-2 ; i++){

  for(j=0; j<comm.nseq ; j++){
        nw = j;
        nm = (nw-1)/8;
        na = (nw-1)%8;
        nx = 0x80;
        nx >>= na;
        ny = comm.part[i][nm] & nx;
        if( ny == 0 ) printf("0");
        if( ny != 0 ) printf("1");
      }
   printf("\n");
}
return(0);
}

prpart1(pc)
unsigned char *pc;
{
int i,j,nw,nm,na;
unsigned char nx,ny;

  for(j=0; j<comm.nseq ; j++){
        nw = j;
        nm = (nw-1)/8;
        na = (nw-1)%8;
        nx = 0x80;
        nx >>= na;
        ny = pc[nm] & nx;
        if( ny == 0 ) printf("0");
        if( ny != 0 ) printf("1");
      }
   printf("\n");
return(0);
}







main(argc,argv)
int argc;
char **argv;
{
struct nds *cur,*anc,*pw;
FILE *fpi,*fpo=stderr,*fpt=stdin;
float fw;
int i,j,k,l,rn,ifc,itc,iw,outflg,n1,n2,nbst,maxnm;
int dop=0,outgroup=0,noutg,*outg/*[MAXOTU]*/,nfnode,*fnode/*[MAXOTU]*/;
int nw,nseqw,noutg0,*ip,flg;
double *blen/*[2*MAXOTU-2]*/,xscale=1.0,yscale=1.0,linew=0.5;
double dw,dw1,db,dn,dw2,dw3,dwt,dwb,dwl,dwr,blc,brc,*bw;
char cw;
unsigned char *pc;
extern int *ivector();
extern char *cvector(),**cmatrix();
extern unsigned char **ucmatrix();
extern double *dvector();
extern struct nds *ndsvector(), **ndspvector();
dflg=0;
noutg=0;
nfnode=0;
comm.nobranch=0;
ifc = 0;
outflg=0;
comm.lowlim = 0;
comm.idnflg = 0;
/*printf("start\n"); fflush(stdout);*/
comm.fpo = stdout;
        if( argc == 1 ){
            printf("cnvtre  inputfile -o [outgroup] -u[outfile] -id -nobranch -l[low limit for showing bootstrap number\n");
            printf("-id [show id numbers for internal nodes]");
            printf("-nobranch [not show branch lengths");
            exit(1);
	  }
        for(i=1; i<argc; i++){
           if(argv[i][0] == '-' ){
	     if( strcmp(argv[i]+1,"nobranch") == 0 ){
                comm.nobranch=1;
                continue;
	     }
	     if( strcmp(argv[i]+1,"id") == 0 ){
                comm.idnflg=1;
                continue;
	     }
              switch(argv[i][1]){
        	   case 'o': 
                             noutg=0;
                             if( argv[i][2] >= '0' && argv[i][2] <= '9' ){
			       /*    sscanf(argv[i]+2,"%d",&outg[noutg]);*/
                                  noutg=1;
				}
                             for(j=i+1 ; j<argc ; j++){
                              if( argv[j][0] > '9' || argv[j][0] < '0' ) break;

			      /*    sscanf(argv[j],"%d",&outg[noutg]);*/
                                noutg++;
                                if( noutg > MAXOTU ){
                                     printf("too many outgroup %d\n",noutg);
                                     exit(1);
				   }
                                i++;
			     }
                            if( noutg == 0 ){
                                 printf("no outgroup");
                                 exit(1);
			       }
                             printf("outgroup =%d\n",noutg); fflush(stdout);
                             break;
                   case 'u' :  if( argv[i][2] != 0 ){
		                  if( (comm.fpo = fopen(argv[i]+2,"w") ) == NULL ){
                                   printf("Can't open %s\n",argv[i]+2);
                                   exit(1);
				  }
                               }
                	       else{
		                  if( (comm.fpo = fopen(argv[i+1],"w") ) == NULL ){
                                   printf("Can't open %s\n",argv[i+1]);
                                   exit(1);
				  }
                                  i++;
				}
                              break;
                   case 'l' :  if( argv[i][2] != 0 ){
                                  sscanf(argv[i]+2,"%d",&comm.lowlim);
                               }
                	       else{
                                  sscanf(argv[i+1],"%d",&comm.lowlim);
                                   i++;
			       }
                              break;

	      }
              }else{
                         if((fpt = fopen(argv[i],"r")) == NULL ){
                                 printf("Can't open file %s arg %d\n",argv[i],i);
                                 exit(1);
			 }
                         ifc=i;
	      }


	}



    if( ifc == 0 ){
       printf("topology file is not specified\n");
       exit(1);
    }
  chktv(fpt,&(comm.nseq),&maxnm);
  fclose(fpt);

  /*   printf("end of chktv maxnm=%d tmag=%f\n",maxnm,comm.tmag); fflush(stdout);*/
  if( noutg > 0 ) outg = ivector(noutg);
  else {
    outg = ivector(2);
    outg[0]=1;
  }
  if( fnode > 0 ) fnode = ivector(nfnode);
  blen = dvector(comm.nseq*2-2);
  nda = ndsvector(comm.nseq*2-2);
  adpart = ndspvector(comm.nseq-2);
  comm.part = ucmatrix(comm.nseq-2, (comm.nseq-1)/8+1);
  comm.fl = cmatrix(comm.nseq,maxnm+1);
  /*  comm.ndlab = cmatrix(comm.nseq*2,40);*/
  comm.bstnb = ivector(comm.nseq*2-3);
  comm.conflvl = dvector(2*comm.nseq-3);
  comm.nll = ivector(comm.nseq);
  comm.nlr = ivector(comm.nseq);

  for(i=0; i<comm.nseq; i++){
   for(j=0; j<maxnm+1; j++) comm.fl[i][j]=0;
  }
    
/*  printf("%s\n",argv[ifc]);*/
  /*  printf("chkarg\n"); fflush(stdout);*/

  if((fpt = fopen(argv[ifc],"r")) == NULL ){
        printf("Can't open file %s arg %d\n",argv[ifc],ifc);
        exit(1);
    }

  

  rdtv(fpt,&(comm.nseq),comm.fl,nda,blen,maxnm,&nbst);
  fclose(fpt);
  nseqw = comm.nseq;
  chkarg(nseqw,argc,argv,noutg,outg);
for(i=0; i<noutg ; i++){
   if( outg[i] > comm.nseq ) {
      printf("invalid outgroup %d\n",outg[i]);
      exit(1);
    }
 }

for(i=0; i<noutg-1 ; i++){
   for(j=i+1; j<noutg ; j++){
     if( outg[i] > outg[j] ){
        iw = outg[i];
        outg[i]=outg[j];
        outg[j]=iw;
      }
   }
 }

for(i=0; i<(comm.nseq-1)/8+1 ; i++){
  for(j=0; j<comm.nseq-2; j++) comm.part[j][i]=0;
}
fprintf(fpo,"topology file %s: nseq=%d bstflg=%d idnflg=%d\n",argv[ifc],comm.nseq,comm.bstflg,comm.idnflg); fflush(fpo);
if( comm.bstflg == 1 ) fprintf(fpo,"%d bootstrapping: low limit =%d\n",nbst,comm.lowlim);
 if( comm.bstflg == 4 ) fprintf(fpo,"ntietree=%d\n",comm.ntietree);
 fflush(fpo);

if( noutg > 0 ){
   fprintf(fpo,"outgroup:");
   for(i=0; i<noutg ; i++) fprintf(fpo,"  %d %s",outg[i],comm.fl[outg[i]-1]);
   fprintf(fpo,"\n");
   fflush(fpo);
 }
fflush(fpo);


     

      if( noutg > 0 ){
         if( noutg > 1 ){
           comm.npc=0;
           partition(&nda[0],nda[0].b);
/*           prpart(); */
           rn=outchk(comm.nseq,noutg,outg,&cur,&anc);
           if( rn != 0 ){
            printf("outgroup error\n");
            exit(1);
	   }
           comm.bt1=anc;
           comm.bt2=cur;
         }else{
            comm.bt1 = &nda[outg[0]-1];
            comm.bt2 = nda[outg[0]-1].b;
	  }
       }else{
            dsmax();
            comm.bt1 = comm.a1;
            comm.bt2 = comm.a2;
            if( comm.a1->nkey <= comm.nseq ){
               comm.bt1 = comm.a1;
               comm.bt2 = comm.a2;
	    }

            if( comm.a2->nkey <= comm.nseq ){
               comm.bt2 = comm.a1;
               comm.bt1 = comm.a2;
	    }


            fprintf(fpo,"bt %d %d\n",comm.bt1->nkey,comm.bt2->nkey); fflush(stdout);

	  }

      fprintf(fpo,"com.bt1 = %d  com.bt2 = %d\n",comm.bt1->nkey,comm.bt2->nkey);

      comm.nc=0; 
      comm.nintnode=1; 
      comm.ext=0;
      dwnarg(comm.bt1,comm.bt2);
      fflush(comm.fpo);
      comm.nintnode=0;
      comm.ext=0;

   
      /*    printf("comm.bt2 %d b lc rc %p %p %p %d %d %d bt1 %d %p\n",comm.bt2->nkey,comm.bt2->b,comm.bt2->lc,comm.bt2->rc,comm.bt2->b->nkey,comm.bt2->lc->nkey,comm.bt2->rc->nkey,comm.bt1->nkey,comm.bt1);
       */

    flg = 0;
 
    if( comm.bt2->b  == comm.bt1 ) {
       flg += 1;
    }

    if( comm.bt2->lc == comm.bt1 ){
        flg += 2;
        pw = comm.bt2->lc;
        comm.bt2->lc = comm.bt2->b;
        comm.bt2->b = pw;
        bw = comm.bt2->blcx;
        comm.bt2->blcx = comm.bt2->bbx;
        comm.bt2->bbx = bw;
        ip = comm.bt2->bstlcx;
        comm.bt2->bstlcx = comm.bt2->bstbx;
        comm.bt2->bstbx = ip;
        pc = comm.bt2->plcx;
        comm.bt2->plcx = comm.bt2->pbx;
        comm.bt2->pbx=pc;
      }

    if( comm.bt2->rc == comm.bt1 ){
        flg += 3;
        pw = comm.bt2->rc;
        comm.bt2->rc = comm.bt2->b;
        comm.bt2->b = pw;
        bw = comm.bt2->brcx;
        comm.bt2->brcx = comm.bt2->bbx;
        comm.bt2->bbx=bw;
        ip = comm.bt2->bstrcx;
        comm.bt2->bstrcx = comm.bt2->bstbx;
        comm.bt2->bstbx=ip;

        pc = comm.bt2->prcx;
        comm.bt2->prcx = comm.bt2->pbx;
        comm.bt2->pbx=pc;

      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }
        comm.nintnode=0;
        comm.ext=0;
        dwnarg(comm.bt2->lc,comm.bt2);
        comm.nintnode=0;
        comm.ext=0;
        dwnarg(comm.bt2->rc,comm.bt2);

      fprintf(comm.fpo,");\n");
      fflush(comm.fpo);
      fclose(comm.fpo);

      


exit(0);
}

clrbf(bf,n)
char *bf;
int n;
{
int i;
  for(i=0; i<n ; i++) bf[i]=0;
  return(0);
}
