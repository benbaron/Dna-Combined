cc poptree.c -o poptree -lm
cc postree.c -o postree -lm
cc cnvdat.c -o cnvdat -lm
cc cnvtre.c -o cnvtre -lm

