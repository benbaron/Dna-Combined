/*#include "head.h"*/
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
/*
#define MAXOTU 700
*/
#define MAXNM 500
#define MAXTMLAB 20
#define MAXSB 20
#define MAXSBNM 30
#define NTITLE 5
#define ERR stdout
#define ACU  0.00000000001

struct nds{
    int nkey,nc;
    double height,dx,dy,x,y,db;
    struct nds *b, *lc,*rc;
    double *bbx,*blcx,*brcx;
    int *bstbx,*bstlcx,*bstrcx;
    int *bstbx1,*bstlcx1,*bstrcx1,iflg;
    unsigned char *pbx,*plcx,*prcx;
 };
struct com{
int nseq,npc,udflg,upflg,fontsize,fontsizeb,fontsizet,fontsizes,fontsizesb,idnflg,bstflg,nbstflg,rotate,ext,tieflg,ntietree;
unsigned char **part/*[MAXOTU-2][(MAXOTU-1)/8+1]*/;
char **fl/*[MAXOTU][MAXNM]*/;
int mr,ml,mb,bc,nlc,lastotu,titflg,*nlr/*[MAXOTU]*/,*nll/*[MAXOTU]*/;
struct nds *bt1,*bt2,*a1,*a2;
struct nds *maxp[2],*maxps;
double dmax,dsum,dbt1,dbt2,dw,rmag,lmag,tmag,bmag,dyint,dxunt,dwn,dwnv,dwnb,dwnvb;
double rmag1,lmag1,tmag1,bmag1;
double dhmax,hsize,vsize,dhmax1,dhmax2,dbw,ovlap,hvcrto,rootrto;
int idmaxflg;
double scalew,slinew,xtitle,ytitle,xscale,yscale,tscaley,tscalex,nscaley;
char  sscale[10],tscale[10];
char **ndlab/*[2*MAXOTU][40]*/,title[100];
double dscale;
int seqhmax,seqhmax1,seqhmax2,npcol,nprow,rootlcn,treeord,upkey;
int *bstnb/*[2*MAXOTU-3]*/,lowlim;
double *conflvl/*[2*MAXOTU-3]*/;
FILE *fps;
double sbx1,sbx2,sbx3;
int nsb1,nsb2,nsb3;
char sbname1[MAXSB][MAXSBNM],sbname2[MAXSB][MAXSBNM],sbname3[MAXSB][MAXSBNM];
int  sbnum1[MAXSB][2],sbnum2[MAXSB][2],sbnum3[MAXSB][2];
int ntsint,ntimelab,timelab[MAXTMLAB];
double tsend,tsint,tsheight,tstime,tsintw,tsnx,tsny,tsy,tsx,tsly;
char tsname[20];
double bstyw1,bstyw2;
};










/* postscript fonts
    /Times-Roman
    /Times-Bold
    /Times-Italic
    /TImes-BoldItalic
    /Helvetica
    /Helvetica-Bold
    /Helvetica-Oblique
    /Helvetica-BoldOblique
    /Courier
    /Courier-Bold
    /Courier-Oblique
    /Courier-BoldOblique
    */


     
struct com comm;
struct nds *nda/*[2*MAXOTU-2]*/,**adpart/*[MAXOTU-2]*/;
int dflg;



struct nds *ndsvector(n)
int n;
{
 struct nds *vp;


   vp = (struct nds *)malloc((unsigned) n*sizeof(struct nds));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"integer vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

struct nds **ndspvector(n)
int n;
{
 struct nds **vp;


   vp = (struct nds **)malloc((unsigned) n*sizeof(struct nds *));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"integer vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

int *ivector(n)
int n;
{
int *vp;

   vp = (int *)malloc((unsigned) n*sizeof(int));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"integer vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

char *cvector(n)
int n;
{
char *vp;

   vp = (char *)malloc((unsigned) n*sizeof(char));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"char vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

double *dvector(n)
int n;
{
double *vp;

   vp = (double *)malloc((unsigned) n*sizeof(double));
   if( !vp ) {
       fprintf(ERR,"memory allocation error\n");
       fprintf(ERR,"double vector[%d]\n",n);
       exit(1);
     }
    return(vp);
}

int **imatrix(n1,n2)
int n1,n2;
{
int i,**ip;

 ip = (int **) malloc((unsigned ) n1*sizeof(int*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (int *) malloc((unsigned) n2*sizeof(int));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}




char **cmatrix(n1,n2)
int n1,n2;
{
int i;
char **ip;

 ip = (char **) malloc((unsigned ) n1*sizeof(char*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (char *) malloc((unsigned) n2*sizeof(char));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}


unsigned char **ucmatrix(n1,n2)
int n1,n2;
{
int i;
unsigned char **ip;

 ip = (unsigned char **) malloc((unsigned ) n1*sizeof(unsigned char*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (unsigned char *) malloc((unsigned) n2*sizeof(unsigned  char));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}


double **dmatrix(n1,n2)
int n1,n2;
{
int i;
double **ip;

 ip = (double **) malloc((unsigned ) n1*sizeof(double*) );
 if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
 for(i=0; i<n1 ; i++){
   ip[i] = (double *) malloc((unsigned) n2*sizeof(double));
   if( !ip[i] ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step2(i=%d) double matrix %d %d\n",i,n1,n2);
    exit(1);

  }
 }
 
  return(ip);
				 
}


void free_ivector(v,n)
int *v,n;
{
   free((char*) v );
   return ;
 }

void free_dvector(v,n)
double *v;
int n;
{
   free((char*) v );
   return ;
 }


void free_cvector(v,n)
char *v;
int n;
{
   free((char*) v );
   return ;
 }


void free_cmatrix(m,n1,n2)
char **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}

void free_imatrix(m,n1,n2)
int  **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}


void free_dmatrix(m,n1,n2)
double  **m;
int n1,n2;
{
int i;

    for(i=n1-1 ; i >= 0 ; i-- ){
       free((char *) (m[i]));
     }
    free((char *) m);
}

/* #include "globals.h"*/
extern struct com comm;
extern struct nds *nda,**adpart;
extern int dflg;


cominit()
{
int i,j;
for(i=0; i<100 ; i++) comm.title[i]=0;

for(i=0; i<20 ; i++) comm.tsname[i]=0;

comm.sbx1=0.0;
comm.sbx2=0.0;
comm.sbx3=0.0;
comm.xtitle=0.0;
comm.ytitle=0.0;
comm.xscale=0.0;
comm.yscale=0.0;
comm.rmag=72.0;
comm.tmag=72.0;
comm.lmag=72.0;
comm.bmag=72.0;
comm.rmag1=0.0;
comm.tmag1=0.0;
comm.lmag1=0.0;
comm.bmag1=0.0;
comm.ovlap = 10;
comm.hvcrto=1.5;
comm.dwn = 3.0;
comm.fontsize=8;
comm.fontsizes=10;
comm.fontsizeb=8;
comm.fontsizet=10;
comm.fontsizesb=10;
comm.nsb1=0;
comm.nsb2=0;
comm.nsb3=0;
comm.npcol=1;
comm.nprow=1;
comm.hsize=72*8.5;
comm.vsize=72*11;
comm.ntietree=0;
comm.dwn = comm.fontsize;
comm.dwn /= 2.0;
comm.dwnv = comm.dwn*0.7;
comm.lowlim = 0;
comm.dwnb = comm.fontsizeb;
comm.dwnb /= 2.0;
comm.dwnvb = comm.dwnb*0.7;
comm.rotate=0;
comm.idnflg=0;
comm.bstflg=0;
comm.tieflg=0;
comm.nbstflg=0;
comm.ext=0;
comm.rootrto=20.0;
comm.rootlcn=0; /* 0 outgoup upper, 1 outgoup lower */
comm.treeord=0;
comm.dscale = -1.0;
comm.scalew = 2.0;
comm.slinew = 0.5;
comm.tsend=0.;
comm.tsint=0;
comm.tsnx=0.;
comm.tsny=0.;
comm.tsy=0.;
comm.tsly=0.;
comm.ntsint=0;
comm.tsheight=0.;
comm.tstime=0;
comm.ntimelab=0;
comm.tsintw=3;
comm.bstyw1=0.;
comm.bstyw2=0.;
comm.tscalex=0.;
comm.tscaley=0.;
comm.nscaley=0.;
for(i=0; i< MAXSB ; i++){
  comm.sbnum1[i][0]=0;
  comm.sbnum1[i][1]=0;
  comm.sbnum2[i][0]=0;
  comm.sbnum2[i][1]=0;
  comm.sbnum3[i][0]=0;
  comm.sbnum3[i][1]=0;
  for(j=0; j< MAXSBNM ; j++){
    comm.sbname1[i][j]=0;
    comm.sbname2[i][j]=0;
    comm.sbname3[i][j]=0;
  }
}
for(i=0; i<10 ; i++) {
   comm.sscale[i]=0;
   comm.tscale[i]=0;
 }
return(0);
}



chktv(fp,nseqw,maxnm)
FILE *fp;
int *nseqw,*maxnm;
{
int i,j, rn,n,nw,n1,n2,n3,bstn,nl,r1,r2;
char b[1000],bw[200],bw1[200],s1[20],s2[20];
float fw,fw1,fw2;

    nl=0;
   (*maxnm) = -1;    
   for(i=0; i<200; i++){
       bw[i]=bw1[i]=0;
     }
   for( ; ; ){
     clrbf(b,1000);
     rn=rdline(fp,b,&n);
     nl++;
/*     printf("nl=%d\n",nl); */
     if( rn == 2 ) continue;
     if( rn == 1 ){
        printf("first line read error\n");
        exit(1);
    }
     break;
   }

   sscanf(b,"%d %s %s\n",nseqw,bw,s1);
   sscanf(b,"%d %s %d %s\n",nseqw,bw,&bstn,bw1);
   if( strcmp(bw,"sequences") != 0 && strcmp(bw,"populations") != 0 
      && strcmp(bw,"individuals") !=0 && strcmp(bw,"otus") != 0 ){
      printf("first line invalid format\n");
      exit(1);
    }
    if( strlen(bw1) != 0 ){
         if( strcmp(bw1,"bootstraping") == 0 ){
           comm.bstflg=1;
         }
       }

    if( strlen(bw1) != 0 ){
         if( strcmp(bw1,"tie") == 0 || strcmp(bw1,"ties") == 0 ){
           comm.ntietree = bstn;
           comm.bstflg=4;
         }
       }

    if( strlen(s1) != 0 ){
         if( strcmp(s1,"ratetest") == 0 ){
           comm.bstflg=3;
         }
       }
   for(i=0; i<*nseqw ; i++){
     clrbf(b,1000);
     if( (rn=rdline(fp,b,&n)) != 0 ){
        printf("sequence names read error\n");
      }
     nl++;
     /*     printf("nl=%d b:%s\n",nl,b); */
     clrbf(bw,200);
     getname(&nw,bw,b,n);
/*     sscanf(b,"%d %s",&nw,bw); */     if( nw != i+1 ){
       printf("sequence number read error nseqw %d %d %d b: %s\n",*nseqw,nw,i+1,b);
        exit(1);
      }
      nw = strlen(bw);
      if( nw > *maxnm ){
         *maxnm = nw;
      }

   }
  for(i=0; i< 2*(*nseqw)-3 ; i++){
     for( ; ; ){
        clrbf(b,1000);
        rn = rdline(fp,b,&n);
        nl++;
/*        printf("nl=%d\n",nl); */
        if( rn == 2 ) continue;
        if( rn == 1 ){
             printf("format error\n");
              exit(1);
	   }
         break;
     }
     if( i == 0 ){
         for(j=0; j<n ; j++){
           if( b[j] == '%' ) {
              comm.bstflg=2;
              break;
	    }
	 }
       }
/*      printf("comm.bstflg=%d\n",comm.bstflg); */
      switch(comm.bstflg){
         case 0:  /* no bootstrap nor confidence level */
                 sscanf(b,"%d and %d %f",&n1,&n2,&fw);
                 break;
        case 1:  /* bootstrap */
                 sscanf(b,"%d and %d %f %d",&n1,&n2,&fw,&n3);
                 break;
       case 2:   /* confidence level */
       case 3:   /* rate test  */
                 brm(b,n);
                 sscanf(b,"%d and %d %f %s  %s",&n1,&n2,&fw,s1,s2);
                 r1 = chkminus(s1);
                 r2 = chkminus(s2);
                 sscanf(b,"%d and %d %f %f  %f",&n1,&n2,&fw,&fw1,&fw2);
                 break;
       case 4:  /* bootstrap */
                 sscanf(b,"%d and %d %f %d",&n1,&n2,&fw,&n3);
                 break;

       }
   }
   
   return(0);
}


chkarg(nseqw,argc,argv,nfnode0,noutg0,outg,fnode)
int argc,nseqw,nfnode0,noutg0,*outg,*fnode;
char **argv;
{
int i,j,nfnode,noutg,iw;
float fw;
nfnode=0;
noutg=0;
        for(i=1; i<argc; i++){
           if(argv[i][0] == '-' ){
              if( strcmp(argv[i]+1,"root" ) == 0 ){
               comm.rootlcn = 1;
               continue;
              }
              if( strcmp(argv[i]+1,"sbx1" ) == 0 ){
                sscanf(argv[i+1],"%f",&fw);
                comm.sbx1=fw;
                i++;
                continue;
              }                
              if( strcmp(argv[i]+1,"sbx2" ) == 0 ){
                sscanf(argv[i+1],"%f",&fw);
                comm.sbx2=fw;
                i++;
                continue;
              }                
              if( strcmp(argv[i]+1,"sbx3" ) == 0 ){
                sscanf(argv[i+1],"%f",&fw);
                comm.sbx3=fw;
                i++;
                continue;
              }                
              if( strcmp(argv[i]+1,"psb" ) == 0 ){
                sscanf(argv[i+1],"%f",&fw);
                comm.fontsizesb=fw;
                i++;
                continue;
              }                

              if( strcmp(argv[i]+1,"vs" ) == 0 ){
                sscanf(argv[i+1],"%f",&fw);
                comm.vsize=72.*fw;
                i++;
                continue;
              }                



              if( strcmp(argv[i]+1,"bsty1" ) == 0 ){
                sscanf(argv[i+1],"%f",&fw);
                comm.bstyw1=fw;
                i++;
                continue;
              }                

              if( strcmp(argv[i]+1,"bsty2" ) == 0 ){
                sscanf(argv[i+1],"%f",&fw);
                comm.bstyw2=fw;
                i++;
                continue;
              }                
              if( strcmp(argv[i]+1,"tscaley" ) == 0 ){
                sscanf(argv[i+1],"%f",&fw);
                comm.tscaley=fw;
                i++;
                continue;
              }                
              if( strcmp(argv[i]+1,"nscaley" ) == 0 ){
                sscanf(argv[i+1],"%f",&fw);
                comm.nscaley=fw;
                i++;
                continue;
              }                

              if( strcmp(argv[i]+1,"sb1") == 0 ){
                 for(j=i+1; j <argc ; j += 3){
                    if( argv[j][0] == '-' ) break;
                    strcpy(comm.sbname1[comm.nsb1],argv[j]);
                    sscanf(argv[j+1],"%d",&comm.sbnum1[comm.nsb1][0]);
                    sscanf(argv[j+2],"%d",&comm.sbnum1[comm.nsb1][1]);
                    comm.nsb1++;
                    i += 3;
		  }
                  continue;
	       }
              if( strcmp(argv[i]+1,"sb2") == 0 ){
                 for(j=i+1; j <argc ; j += 3){
                    if( argv[j][0] == '-' ) break;
                    strcpy(comm.sbname2[comm.nsb2],argv[j]);
                    sscanf(argv[j+1],"%d",&comm.sbnum2[comm.nsb2][0]);
                    sscanf(argv[j+2],"%d",&comm.sbnum2[comm.nsb2][1]);
                    comm.nsb2++;
                    i += 3;
		  }
                  continue;
	       }

              if( strcmp(argv[i]+1,"sb3") == 0 ){
                 for(j=i+1; j <argc ; j += 3){
                    if( argv[j][0] == '-' ) break;
                    strcpy(comm.sbname3[comm.nsb1],argv[j]);
                    sscanf(argv[j+1],"%d",&comm.sbnum3[comm.nsb3][0]);
                    sscanf(argv[j+2],"%d",&comm.sbnum3[comm.nsb3][1]);
                    comm.nsb3++;
                    i += 3;
		  }
                  continue;
	       }

              if( strcmp(argv[i]+1,"tsend") == 0 ){
                 sscanf(argv[i+1],"%f",&fw);
                 comm.tsend=fw;
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tsint") == 0 ){
                 sscanf(argv[i+1],"%f",&fw);
                 comm.tsint=fw;
                 i++;
                  continue;
	       }

              if( strcmp(argv[i]+1,"ntsint") == 0 ){
                 sscanf(argv[i+1],"%d",&comm.ntsint);
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tsheight") == 0 ){
                 sscanf(argv[i+1],"%f",&fw);
                 comm.tsheight=fw;
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tstime") == 0 ){
                 sscanf(argv[i+1],"%f",&fw);
                 comm.tstime = fw;
                 i++;
                  continue;
	       }
	    
              if( strcmp(argv[i]+1,"tsintw") == 0 ){
                 sscanf(argv[i+1],"%f",&fw);
                 comm.tsintw=fw;
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tsy") == 0 ){
                 sscanf(argv[i+1],"%f",&fw);
                 comm.tsy=fw;
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tsly") == 0 ){
                 sscanf(argv[i+1],"%f",&fw);
                 comm.tsly=fw;
                 i++;
                 continue;
	       }

              if( strcmp(argv[i]+1,"tsnx") == 0 ){
                 sscanf(argv[i+1],"%f",&fw);
                 comm.tsnx = fw;
                 i++;
                  continue;
	       }

              if( strcmp(argv[i]+1,"tsny") == 0 ){
                 sscanf(argv[i+1],"%f",&fw);
                 fw = comm.tsny;
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tsname") == 0 ){
                  strcpy(comm.tsname,argv[i+1]);
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tslab") == 0 ){
                 for(j=i+1 ; j<argc ; j++){
                   if( argv[j][0] == '-' ) break;
                   sscanf(argv[j],"%d",&comm.timelab[comm.ntimelab]);
                   i++;
                   comm.ntimelab++;
                 }
                  continue;
	       }
              switch(argv[i][1]){
        	   case 'l': 
                             if( argv[i][2] == 'o' && argv[i][3] == 'w' ){
                                sscanf(argv[i]+4,"%d",&comm.lowlim);
                                break;
			      }
                             nfnode=0;
                             if( argv[i][2] >= '0' && argv[i][2] <= '9' ){
                                  sscanf(argv[i]+2,"%d",&fnode[nfnode]);
                                  nfnode=1;
				}
                             for(j=i+1 ; j<argc ; j++){
                              if( argv[j][0] > '9' || argv[j][0] < '0' ) break;
                                sscanf(argv[j],"%d",&fnode[nfnode]);
                                nfnode++;
                                if( nfnode> nfnode0 ){
                                     printf("too many flipnode %d\n",nfnode);
                                     exit(1);
				   }
                                i++;
		     }
                             break;
        	   case 'o': 
                             noutg=0;
                             if( argv[i][2] >= '0' && argv[i][2] <= '9' ){
                                  sscanf(argv[i]+2,"%d",&outg[noutg]);
                                  noutg=1;
				}
                             for(j=i+1 ; j<argc ; j++){
                              if( argv[j][0] > '9' || argv[j][0] < '0' ) break;
                                sscanf(argv[j],"%d",&outg[noutg]);
                                noutg++;
                                if( noutg >noutg0 ){
                                     printf("too many outgroup %d\n",noutg);
                                     exit(1);
				   }
                                i++;
		     }
                            if( noutg == 0 ){
                                 printf("no outgroup");
                                 exit(1);
			       }
                             printf("outgroup =%d\n",noutg); fflush(stdout);
                             break;

                   case 'c' : 
                              comm.rootlcn=1;
                              break;
                   case 'v' : sscanf(argv[i]+2,"%d",&comm.npcol);
                              break;
                   case 'h' : sscanf(argv[i]+2,"%d",&comm.nprow);
                              break;
                   case 'f' : 
                              break;
                   case 'p' : if( argv[i][2] == 'b' ){
                                 sscanf(argv[i]+3,"%d",&comm.fontsizeb);
                                 break;
			       }
                              if( argv[i][2] == 't' ){
                                 sscanf(argv[i]+3,"%d",&comm.fontsizet);
                                 break;
			       }
                              if( argv[i][2] == 's' && argv[i][3] == 'b' ){
                                 sscanf(argv[i]+4,"%d",&comm.fontsizesb);
                                 break;
			       }
                              if( argv[i][2] == 's' ){
                                 sscanf(argv[i]+3,"%d",&comm.fontsizes);
                                 break;
			       }
                              sscanf(argv[i]+2,"%d",&comm.fontsize);
                              break;
                   case 's' : if( argv[i][2] >= '0' && argv[i][2] <= '9' || argv[i][2] == '.' )  {
                              sscanf(argv[i]+2,"%s",comm.sscale);
                              sscanf(argv[i]+2,"%f",&fw);
                              comm.dscale = fw;
			    } 
                              if( argv[i][2] == 'l' ){
                                  sscanf(argv[i]+3,"%f",&fw);
                                  comm.slinew=fw;
				}
                              if( argv[i][2] == 'x' ){
                                  sscanf(argv[i]+3,"%f",&fw);
                                  comm.xscale=fw;
				}
                              if( argv[i][2] == 'y' ){
                                  sscanf(argv[i]+3,"%f",&fw);
                                  comm.yscale=fw;
				}
                              if( argv[i][2] == 'w' ){
                                  sscanf(argv[i]+3,"%f",&fw);
                                  comm.scalew=fw;
				}
                              if( argv[i][2] == 't' ){
                                  sscanf(argv[i]+3,"%s",comm.tscale);
				}
                              break;
                   case 't' :  if( argv[i][2] == 'i' ){
                                   break;
				 }
                               if( argv[i][2] == 'x' ) {
                                   break;
				 }
                               if( argv[i][2] == 'y' ) {
                                   break;
				 }

                              comm.treeord=1;
                              break;
                   case 'i' : comm.idnflg=1;
                              break;
                   case 'e' : comm.ext=1;
                              break;
                   case 'r' : comm.rotate=1;
                              break;
                   case 'b' : sscanf(argv[i]+2,"%d",&comm.lowlim);
                              break;
                   case 'w' : sscanf(argv[i]+2,"%f",&fw);
                              break;
                   case 'm' : switch(argv[i][2]){
                                case 'b': sscanf(argv[i]+3,"%f",&fw);
                                          comm.bmag=fw;
                                           break;
                                case 't': sscanf(argv[i]+3,"%f",&fw);
                                          comm.tmag=fw;
                                           break;
                                case 'l': sscanf(argv[i]+3,"%f",&fw);
                                          comm.lmag=fw;
                                           break;
                                case 'r': sscanf(argv[i]+3,"%f",&fw);
                                          comm.rmag=fw;
                                           break;
                                default: printf("invalid argument\n");
                                         exit(1);
                                         break;
				}
                               break;

                   case 'n' : switch(argv[i][2]){
                                case 'd': 
                                          sscanf(argv[i]+3,"%d",&iw);
                                          strcpy(comm.ndlab[iw],argv[i+1]);
                                          i++;
                                          break;                             
                                case 'b': sscanf(argv[i]+3,"%f",&fw);
                                          comm.bmag1=fw;
                                           break;
                                case 't': sscanf(argv[i]+3,"%f",&fw);
                                          comm.tmag1=fw;
                                           break;
                                case 'l': sscanf(argv[i]+3,"%f",&fw);
                                          comm.lmag1=fw;
                                           break;
                                case 'r': sscanf(argv[i]+3,"%f",&fw);
                                          comm.rmag1=fw;
                                           break;
                                default: printf("invalid argument\n");
                                         exit(1);
                                         break;
				}
                               break;

			   }
               }


	 }

return(0);
}


dsmax()
{
int i,j;
/* printf("nseq=%d bc=%d  cur=%d\n",nseq,bc,cur->nkey); 
fflush(stdout); 
*/


/*   printf("dsmax begin\n"); fflush(stdout); */
   comm.dmax=-990.0;
   for(i=0; i< comm.nseq*2 -2 ; i++) nda[i].iflg =0;
   for(i=0; i< comm.nseq-1 ; i++){
      comm.maxps = &nda[i];
      for(j=0; j< comm.nseq*2 - 2 ; j++){
        nda[j].db = 0.;
      }
      nda[i].b->db = *(nda[i].bbx);
      serdmax(nda[i].b,&nda[i]);
/*      printf("i=%d maxp %d %d dmax=%f\n",i,comm.maxp[0]->nkey,comm.maxp[1]->nkey,comm.dmax); */
      fflush(stdout);

    }
    
    for(i=0; i< comm.nseq*2 -2 ; i++){
        nda[i].iflg =0;
        nda[i].db =0.;
      }
    comm.idmaxflg = 0;
    sermid(comm.maxp[0]->b,comm.maxp[0]);
    return(0);
}

serdmax(cur,ac)
struct nds *cur, *ac;
{
struct nds *pw;
double *bw,dw,db;
int flg,*ip;
unsigned char *pc;
    flg = 0;
    if( cur->b  == ac ) flg += 1;
    if( cur->lc == ac ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx = ip;
      }

    if( cur->rc == ac ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;

        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx = ip;

        flg += 3;
      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }

/*     printf("serdmax cur %d ac %d rc\n",cur->nkey,ac->nkey); fflush(stdout); */
   
    if( cur->rc != NULL) {
        cur->rc->db = *(cur->brcx) + cur->db;
        serdmax(cur->rc,cur);

     }

    if( cur->lc != NULL) {
        cur->lc->db = *(cur->blcx) + cur->db;
        serdmax(cur->lc,cur);
     }

     if( cur->nkey <= comm.nseq && cur != comm.maxps) {
              if( cur->db > comm.dmax ){
                 comm.dmax = cur->db;
                 comm.maxp[0] = comm.maxps;
                 comm.maxp[1] = cur;
/*                 printf("maxp %d %d dmax=%f\n",comm.maxp[0]->nkey,comm.maxp[1]->nkey,comm.dmax); */
                 fflush(stdout);
	       }
	    }
      return(0);
  }



sermid(cur,ac)
struct nds *cur, *ac;
{
struct nds *pw;
double *bw,dw,db;
int flg,*ip;
unsigned char *pc;

    flg = 0;
    if( cur->b  == ac ) flg += 1;
    if( cur->lc == ac ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx = ip;
      }

    if( cur->rc == ac ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;

        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx = ip;

        flg += 3;
      }
    
    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }

    if( cur->rc != NULL) {
        sermid(cur->rc,cur);

     }

    if( cur->lc != NULL) {
        sermid(cur->lc,cur);
     }
     if( cur->nkey <= comm.nseq ) {
              if( cur == comm.maxp[1] ){
                  cur->iflg = 1;
                  cur->db = *(cur->bbx);
/*                  printf("nkey=%d b=%d db=%f\n",cur->nkey,cur->b->nkey,cur->db); */
                  if( cur->db >= comm.dmax/2.0 && comm.idmaxflg == 0 ){
                      comm.a1=cur;
                      comm.a2=cur->b;
                      comm.idmaxflg = 1;
                        return(0);
         	       }
		}
    }
     if( cur->lc != NULL && cur->rc != NULL ){
          if( cur->lc->iflg == 1 ){
              cur->db = *(cur->bbx)+cur->lc->db;
/*              printf("nkey=%d b=%d db=%f blcx=%f db=%f dmax/2=%f\n",cur->nkey,cur->b->nkey,cur->db,*(cur->bbx),cur->lc->db,comm.dmax/2.);  */
              cur->iflg = 1;
	    }
          if( cur->rc->iflg == 1 ){
              cur->db = *(cur->bbx)+cur->rc->db;
/*              printf("nkey=%d b=%d db=%f brcx=%f db=%f dmax/2=%f\n",cur->nkey,cur->b->nkey,cur->db,*(cur->bbx),cur->rc->db,comm.dmax/2.); */
              cur->iflg = 1;
	    }
          if( cur->iflg == 1 ){
             if( cur->db >= comm.dmax/2.0  && comm.idmaxflg == 0  ){
                     comm.a1 = cur;
                     comm.a2 = cur->b;
                     comm.idmaxflg = 1;
/*                     printf("cur=%d curb=%d\n",cur->nkey,cur->b->nkey); */
                     return(0);
		   }
	   }
	}

      return(0);
}


rdtv(fp,nseqw,fl,nda,blen,maxnm)
struct ndc *nda/*[2*MAXOTU-2]*/;
FILE *fp;
int *nseqw;
double *blen/*[2*MAXOTU-2]*/;
char **fl/*[MAXOTU][MAXNM]*/;
{
int i,j, rn,n,**ntb/*[2*MAXOTU-3][2]*/,nw,n1,n2,n3,bstn,nl,r1,r2,bstflg,tieflg;
char b[1000],bw[MAXNM+1],bw1[MAXNM+1],s1[20],s2[20];
float fw,fw1,fw2;
extern int **imatrix();
extern void free_imatrix();

    
    ntb = imatrix(2*(*nseqw)-3,2);
    
    bstflg =0;
    tieflg =0;
    nl=0;
    for(i=0; i< *nseqw ; i++){
     for(j=0; j<maxnm+1 ; j++) fl[i][j]=0;
    }
   
   for(i=0; i<MAXNM+1; i++){
       bw[i]=bw1[i]=0;
     }
   for( ; ; ){
     clrbf(b,1000);
     rn=rdline(fp,b,&n);
     nl++;
/*     printf("nl=%d\n",nl); */
     if( rn == 2 ) continue;
     if( rn == 1 ){
        printf("first line read error\n");
        exit(1);
    }
     break;
   }

   sscanf(b,"%d %s %s\n",nseqw,bw,s1);
   sscanf(b,"%d %s %d %s\n",nseqw,bw,&bstn,bw1);
   if( strcmp(bw,"sequences") != 0 && strcmp(bw,"populations") != 0 && strcmp(bw,"individuals") !=0 && strcmp(bw,"otus") != 0 ){
      printf("first line invalid format\n");
      exit(1);
    }
   /*
   if( *nseqw > MAXOTU ){
       printf("too many sequences\n");
       exit(1);
     }
   */
    if( strlen(bw1) != 0 ){
         if( strcmp(bw1,"bootstraping") == 0 ){
           bstflg=1;
           comm.bstflg=1;
         }
       }

    if( strlen(bw1) != 0 ){
         if( strcmp(bw1,"tie") == 0 || strcmp(bw1,"ties") == 0 ){
           bstflg=4;
           comm.ntietree = bstn;
           comm.bstflg=4;
         }
       }

    if( strlen(s1) != 0 ){
         if( strcmp(s1,"ratetest") == 0 ){
           bstflg =3;
           comm.bstflg=3;
         }
       }
   for(i=0; i<*nseqw ; i++){
     clrbf(b,1000);
     if( (rn=rdline(fp,b,&n)) != 0 ){
        printf("sequence names read error b:%s\n",b);
      }
     nl++;
/*     printf("nl=%d\n",nl); */
     clrbf(bw,MAXNM+1);
     getname(&nw,bw,b,n);
/*     sscanf(b,"%d %s",&nw,bw); */     
     if( nw != i+1 ){
       printf("sequence number read error b:(%s) nw=%d i+1=%d\n",b,nw,i+1);
        exit(1);
      }
      nw = strlen(bw);
      /*
      if( nw > MAXNM){
        printf("sequence name too long %s\n",bw);
        exit(1);
      }
      */


/*
      if( strcmp(fl[i],bw) != 0 ) {
         printf("sequence name inconsistency %d %s %s\n",i+1,fl[i],bw);
         exit(1);
       }
*/
       strcpy(fl[i],bw);
/*       printf("bw %s fl %s\n",bw,fl[i]); */
   }
/*  printf("bootstap =%d\n",comm.bstflg); */
  for(i=0; i< 2*(*nseqw)-3 ; i++){
     for( ; ; ){
        rn = rdline(fp,b,&n);
        nl++;
/*        printf("nl=%d\n",nl); */
        if( rn == 2 ) continue;
        if( rn == 1 ){
             printf("format error\n");
              exit(1);
	   }
         break;
     }
     if( i == 0 ){
         for(j=0; j<n ; j++){
           if( b[j] == '%' ) {
              comm.bstflg=2;
              break;
	    }
	 }
       }
/*      printf("comm.bstflg=%d\n",comm.bstflg); */
      switch(comm.bstflg){
         case 0:  /* no bootstrap nor confidence level */
                 sscanf(b,"%d and %d %f",&n1,&n2,&fw);
                 ntb[i][0]=n1;
                 ntb[i][1]=n2;
                 blen[i]=fw;
                 break;
        case 1:  /* bootstrap */
                 sscanf(b,"%d and %d %f %d",&n1,&n2,&fw,&n3);
                 ntb[i][0]=n1;
                 ntb[i][1]=n2;
                 blen[i]=fw;
                 comm.bstnb[i]=n3*100;
                 comm.bstnb[i] /= bstn;
                 break;
       case 2:   /* confidence level */
       case 3:   /* rate test  */
                 brm(b,n);
                 sscanf(b,"%d and %d %f %s  %s",&n1,&n2,&fw,s1,s2);
                 r1 = chkminus(s1);
                 r2 = chkminus(s2);
                 if( r2 > 1 ){
                      ntb[i][0]=n1;
                      ntb[i][1]=n2;
                      blen[i]=fw;
                      comm.bstnb[i]= -1.0;
                      break;
		    }
                 sscanf(b,"%d and %d %f %f  %f",&n1,&n2,&fw,&fw1,&fw2);
                 ntb[i][0]=n1;
                 ntb[i][1]=n2;
                 blen[i]=fw;
                 comm.bstnb[i]=fw2;
                 break;
       case 4:  /* bootstrap */
                 sscanf(b,"%d and %d %f %d",&n1,&n2,&fw,&n3);
                 ntb[i][0]=n1;
                 ntb[i][1]=n2;
                 blen[i]=fw;
                 comm.bstnb[i]=n3;
                 break;

       }
   }
   
   rn=trnd(*nseqw,ntb,nda,blen);

  if( bstflg == 3 ) comm.bstflg=3;

  free_imatrix(ntb,2*(*nseqw)-3,2);
   return(0);
}

chkminus(s1)
char *s1;
{

int i,n;

  n=0;
  for(i=0; i<20 ; i++){
     if( s1[i] == 0 ) return(n);
     if( s1[i] == '-' ) n++;
   }

   return(n);
}

brm(b,n)
char b[];
{
 int i,psflg;
  psflg=0;
  for(i=0; i<n ; i++){
    if( b[i] == '%' ) psflg++;
    if( b[i] < 0x26 || b[i] > 0x7e ) b[i] = ' ';
  }
  if( psflg != 1 ){
    printf("invalid format in input file confidence level is assumed %d\n%s\n",psflg,b);
    exit(1);
  }
  return(0);
}


trnd(nseqw,ntb,nda,blen)
int nseqw,**ntb/*[2*MAXOTU-3][2]*/;
struct nds *nda/*[2*MAXOTU-2]*/;
double *blen/*[2*MAXOTU-2]*/;
{
int i,j,k,n1,ns;

  for(i=0; i<2*nseqw-2; i++){
     nda[i].nkey = i+1;
     nda[i].nc = 0;
     nda[i].lc=NULL;
     nda[i].rc=NULL;
     nda[i].b=NULL;
     nda[i].plcx=NULL;
     nda[i].prcx=NULL;
     nda[i].pbx=NULL;
     nda[i].blcx=NULL;
     nda[i].brcx=NULL;
     nda[i].bbx=NULL;
     nda[i].bstlcx=NULL;
     nda[i].bstrcx=NULL;
     nda[i].bstbx=NULL;
     nda[i].height=0.0;
   }
  for(i=0; i<nseqw ; i++){
     ns=0;
     for(j=0; j<2*nseqw-3; j++){
         if( ntb[j][1] == i+1 ){
             nda[i].b = &nda[ntb[j][0]-1];
             nda[i].bbx = &blen[j];
             nda[i].bstbx = &comm.bstnb[j];
/*             printf(" %d %d %f\n",i+1,ntb[j][0],blen[j]); */
             ns++;
	   }
         if( ntb[j][0] == i+1 ){
             nda[i].b = &nda[ntb[j][1]-1];
             nda[i].bbx = &blen[j];
             nda[i].bstbx = &(comm.bstnb[j]);
/*             printf(" %d %d %f\n",i+1,ntb[j][1],blen[j]); */
             ns++;
	   }
       }
      if( ns != 1 ){
         printf("sequence %d format error\n",i+1);
       }
   }

    
    for( i=nseqw+1 ; i<= 2*nseqw-2 ; i++){
       ns=0;
       for(j=0; j<2*nseqw-3 ; j++){
         for(k=0; k<2 ; k++){
           if( ntb[j][k] == i ){
              switch(k){
                  case 0: n1 = ntb[j][1];
                          break;
                  case 1: n1 = ntb[j][0];
                          break;
		  }
               switch(ns){
 	         case 0: nda[i-1].lc = &nda[n1-1];
                         nda[i-1].blcx = &blen[j];
                         nda[i-1].bstlcx = &(comm.bstnb[j]);
                         break;
 	         case 1: nda[i-1].rc = &nda[n1-1];
                         nda[i-1].brcx = &blen[j];
                         nda[i-1].bstrcx = &(comm.bstnb[j]);
                         break;
      	         case 2: nda[i-1].b = &nda[n1-1];
                         nda[i-1].bbx = &blen[j];
                         nda[i-1].bstbx = &(comm.bstnb[j]);
                         break;
                 default: printf("format error node%d ns=%d\n",i,ns);
                          exit(1);
		 }
               ns++;  
               break;
	    }
	 }
       }
       if( ns != 3 ){
          printf("format error node%d ns=%d\n",i,ns);
          exit(1);
        }
     }

/*for(i=0; i<2*nseqw-3 ; i++){
   if( nda[i].nkey <= nseqw ) printf("%d b:%d\n",nda[i].nkey,nda[i].b->nkey);
   if( nda[i].nkey > nseqw ) printf("%d b:%d l:%d r:%d\n",nda[i].nkey,nda[i].b->nkey,nda[i].lc->nkey,nda[i].rc->nkey);

 }
*/
return(0);
}

rdline(fp,b,n)
int *n;
char *b;
FILE *fp;
{
int c,np;

   *n=0;

   np=0;
   for( ; ; ){
      c = fgetc(fp);
      if( c == EOF ) return(1);
      if( c != ' ' && c != '\n' &&  c != '\t') np++;
      b[*n]=c;
      (*n)++;
      if( c == '\n' ) break;
    }
   /*   printf("rdline %d b:%s\n",np,b); */
    if( np == 0 ) return(2);
   return(0);
}



getname(nid,snm,bf,nl)
int *nid,nl;
char *snm,*bf;
{
char bn[20];
int i,n,flg,nc,nst,nend,nw;

 flg=0;
 /* for(i=0; i<MAXNM ; i++) snm[i]=0;*/
 for(i=0; i<20 ; i++) bn[i]=0;
 n=0;
 for( ; ; ){
   if( bf[n] != ' ' ) break;
   n++;
 }

 nc=0;
 for( ; ; ){
   if( bf[n] == ' ' ) break;
   bn[nc] = bf[n];
   if( bn[nc] > '9' || bn[nc] < '0' ) return(-1);
   nc++;
   n++;
 }

 sscanf(bn,"%d",&nw);
 *nid=nw;
 for( ; ; ){
   if( bf[n] == ' ' ) {
     n++;
     continue;
   }
   break;
 }

  nst=n;
  for(i=nl-1;  ; i--){
   if( bf[i] == ' ' ) continue;
   nend=i;
   break;
  }
  
  for(i=nst ; i<=nend ; i++) snm[i-nst]=bf[i];

  return(0);
}

clrbf(b,n)
     char *b;
     int n;
{
  int i;
  for(i=0; i<n; i++) b[i]=0;
  return(0);
}

dwnarg(cur,anc)
struct nds *cur, *anc;
{
struct nds *pw;
double *bw,dnc,dw1,dw;
int flg,i,j,nw,nm,nc,na,iw,*ip;
unsigned char nx,ny, *pc;

/* printf("dwnarg cur %d anc %d\n",cur->nkey,anc->nkey); 
 if( cur->b != NULL ) printf("cur b %d",cur->b->nkey);
 if( cur->lc != NULL ) printf("cur l %d",cur->lc->nkey);
 if( cur->rc != NULL ) printf("cur r %d",cur->rc->nkey);
 printf("cur->lc=%p anc=%p cur->rc=%p cur->b=%p\n",cur->lc,anc,cur->rc,cur->b);
 printf("\n");
 fflush(stdout); 
*/
    flg = 0;
    if( cur->b  == anc ) flg += 1;
    if( cur->lc == anc ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx=ip;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
      }

    if( cur->rc == anc ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx=ip;

        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;

        flg += 3;
      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }
     if( cur->lc != NULL ){
         dw = *(cur->blcx);
         if( dw < 0.0 ) dw=0.0;
         cur->lc->height = cur->height+ dw; 
       }
     if( cur->rc != NULL ){
         dw = *(cur->brcx);
         if( dw < 0.0 ) dw=0.0;
         cur->rc->height = cur->height+ dw; 
       }
    fflush(stdout);
/*    printf("%d cur->height=%f\n",cur->nkey,cur->height); */
    if( cur->nkey <= comm.nseq ){
        cur->nc = 1;
        dw = comm.fontsize;
        dw /= comm.hvcrto;
        dnc = strlen(comm.fl[cur->nkey-1]);
/*        dw1 = cur->height+dw*dnc; */
        dw1 = cur->height;
        if( comm.dhmax <  dw1 ) {
            comm.dhmax=dw1;
            comm.seqhmax=cur->nkey;
	  }
   }
    if( cur->rc != NULL) {
        dwnarg(cur->rc,cur);
     }

    if( cur->lc != NULL) {
        dwnarg(cur->lc,cur);
     }

  if( cur->rc != NULL && cur->lc != NULL){
            cur->nc = cur->lc->nc + cur->rc->nc;
/*            printf("dwnargnc upflg=%d cur %d n=%d lc %d rc %d\n",comm.upflg,cur->nkey,cur->nc,cur->lc->nc,cur->rc->nc); */
	  }




   return(0);

}


dwnarg1(cur,anc)
struct nds *cur, *anc;
{
struct nds *pw;
double *bw,dnc,dw1,dw;
int flg,i,j,nw,nm,nc,na,iw,*ip;
unsigned char nx,ny, *pc;

/* printf("dwnarg cur %d anc %d\n",cur->nkey,anc->nkey); 
 if( cur->b != NULL ) printf("cur b %d",cur->b->nkey);
 if( cur->lc != NULL ) printf("cur l %d",cur->lc->nkey);
 if( cur->rc != NULL ) printf("cur r %d",cur->rc->nkey);
 printf("cur->lc=%p anc=%p cur->rc=%p cur->b=%p\n",cur->lc,anc,cur->rc,cur->b);
 printf("\n");
 fflush(stdout); 
*/
    flg = 0;
/*    printf("cur %d upflg=%d\n",cur->nkey,comm.upflg); */

    if( cur->b  == anc ) flg += 1;
    if( cur->lc == anc ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx=ip;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
      }

    if( cur->rc == anc ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx=ip;

        ip = cur->bstrcx1;
        cur->bstrcx1 = cur->bstbx1;
        cur->bstbx1=ip;

        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;

        flg += 3;
      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }
/*  if( cur->nkey == comm.upkey ) comm.upflg=1; */
  if( cur->rc != NULL && cur->lc != NULL){
/*            printf("dwnargnc upflg=%d cur %d n=%d lc %d rc %d\n",comm.upflg,cur->nkey,cur->nc,cur->lc->nc,cur->rc->nc); */
           if( (comm.upflg ==1 && cur->rc->nc > cur->lc->nc) ||
               (comm.upflg ==0 && cur->rc->nc < cur->lc->nc) ){
                      flpnode(cur);
		    }
	 }

    

    if( cur->rc != NULL) {
        dwnarg1(cur->rc,cur);
     }

    if( cur->lc != NULL) {
        dwnarg1(cur->lc,cur);
     }




   return(0);
     }




drwarg(cur,anc)
struct nds *cur, *anc;
{
struct nds *pw;
double *bw,dw,dv,dw1;
int flg,i,j,nw,nm,nc,na,iw,*ip,nbst;
unsigned char nx,ny, *pc;
/* printf("drwarg cur=%d\n",cur->nkey); 
fflush(stdout); 
*/

    flg = 0;

    if( cur->b  == anc ) flg += 1;
    if( cur->lc == anc ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;

        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;

        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx=ip;

        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;

      }

    if( cur->rc == anc ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;

        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;

        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx=ip;

        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;

        flg += 3;
      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }
/*   printf("drwarg cur %d\n",cur->nkey);
    fflush(stdout);
*/
    if( cur->nkey <= comm.nseq ) {
       comm.lastotu = cur->nkey;
/*       cur->x = comm.rmag+ (comm.dxunt)*(cur->height+comm.dbw); */
       cur->x =  (comm.dxunt)*(cur->height+comm.dbw)+comm.lmag1; 
       dw = comm.nlc;
       dv = comm.vsize-comm.tmag-comm.bmag;
       dv *= comm.npcol;
/*       cur->y = (comm.vsize -comm.tmag -(comm.dyint)*dw ; */
/*         cur->y = comm.tmag+(comm.dyint)*dw ; */

       dw1 = comm.fontsize;
       dw1 /= 2,0;
       cur->y = dv-comm.tmag1-(comm.dyint)*dw -dw1 ;
             comm.nlc++;
       drwname(comm.fps,comm.dwn+cur->x,cur->y-comm.dwnv,comm.fl[cur->nkey-1]);
/*       printf("drwarg cur %d drwname\n",cur->nkey);
       fflush(stdout);
*/
     }
    if( cur->lc != NULL ) drwarg(cur->lc,cur);
    if( cur->rc != NULL ) drwarg(cur->rc,cur);
/*
     printf("drwarg cur %d after NULL\n",cur->nkey);
     fflush(stdout);
*/
    if( cur->rc != NULL && cur->lc != NULL){
/*        cur->x = comm.rmag + comm.dxunt*(cur->height+comm.dbw); */
        cur->x =  comm.lmag1+comm.dxunt*(cur->height+comm.dbw); 
        cur->y = (cur->lc->y + cur->rc->y)/2.0;
        if( comm.idnflg == 1 ){
           if( comm.ndlab[cur->nkey][0] == 0 ) shwid(comm.fps,cur->nkey,cur->x,cur->y);
	 }
        if( comm.ndlab[cur->nkey][0] != 0 ) drwnameb(comm.fps,cur->x,cur->y,comm.ndlab[cur->nkey]);
        connect(comm.fps,cur->x,cur->y,cur->lc->x,cur->lc->y,cur->rc->x,cur->rc->y);
/*       printf("drwarg cur %d after connect line\n",cur->nkey);
        fflush(stdout);
*/
       if( ( comm.bstflg == 2 || comm.bstflg == 3 || comm.bstflg == 4 ) && comm.ext==1 ){
          if( cur->lc->nkey <= comm.nseq ){
              nbst = *cur->bstlcx;
              if( nbst >= comm.lowlim ){
              dw1 = comm.fontsizeb;
              dw1 /= 4.;
              drwidn1(comm.fps,nbst,cur->x+ (cur->lc->x-cur->x)/2.0,cur->lc->y+dw1-comm.bstyw1);
	    }
          }
          if( cur->rc->nkey <= comm.nseq ){
              nbst = *cur->bstrcx;
              if( nbst >= comm.lowlim ){
               dw1 = comm.fontsizeb;
               dw1 /= 2.0;
               drwidn1(comm.fps,nbst,cur->x+ (cur->rc->x-cur->x)/2.0,cur->rc->y-dw1*2.0-comm.bstyw2);}
	    }
	}
       if ( comm.bstflg == 1 || comm.bstflg ==2  || comm.bstflg == 3 || comm.bstflg == 4 ){
          flg = 1;
          if( cur->lc->nkey > comm.nseq ){
              nbst = *cur->bstlcx;
              if( comm.bstflg == 4 && comm.ntietree == nbst ) flg=0;
	      /* if( flg == 1 ) printf("nbst=%d ntietree=%d\n",nbst,comm.ntietree);*/
              if( nbst >= comm.lowlim && flg ==1 ){
              nc = cnumb(nbst);
/*              printf("drwarg cur %d  after cnumb %d nbst %d\n",cur->nkey,nc,nbst);
              fflush(stdout);
*/
              dw = comm.fontsizeb;
              dw /= 2.0;
              dw1 = comm.fontsizeb;
              dw1 /= 2.0;
              drwidn(comm.fps,nbst,cur->lc->x - dw/2.0,cur->lc->y+dw1-comm.bstyw1);
	    }
	    }
          if( cur->rc->nkey > comm.nseq ){
              if( comm.bstflg == 4 && comm.ntietree == nbst ) flg=0;
              nbst = *cur->bstrcx;
              if( comm.bstflg == 4 && comm.ntietree == nbst ) flg=0;
	      /* if( flg == 1 ) printf("nbst=%d \n",nbst);*/
              if( nbst >= comm.lowlim && flg == 1){
              nc = cnumb(nbst);
              dw = comm.fontsizeb;
              dw /= 2.0;
              dw *= nc;
              dw1 = comm.fontsizeb;
              dw1 /= 2.0;
              if( cur->rc->x - cur->x >= dw+comm.fontsizeb ) {
                 drwidn(comm.fps,nbst,cur->rc->x - dw1/2.0,cur->rc->y+dw1-comm.bstyw1);
	       }else{
                 drwidn(comm.fps,nbst,cur->rc->x - dw1/2.0,cur->rc->y-dw1*2.5+comm.bstyw2);
	       }
	    }
	    }
	}



                  
      }

   return(0);
     }




/*       +---------B (xb,yb)
         |
 (xa,ya) A 
         |
         +------------C (xc,yc)
*/
/*
connect(fp,xa,ya,xb,yb,xc,yc)
FILE *fp;
double xa,ya,xb,yb,xc,yc;
{

lndrw(fp,xa,yb,xb,yb);
lndrw(fp,xa,yc,xc,yc);
lndrw(fp,xa,yb,xa,yc);
return(0);
}

*/



connect(fp,xa,ya,xb,yb,xc,yc)
FILE *fp;
double xa,ya,xb,yb,xc,yc;
{

fprintf(fp,"%f %f %f %f %f %f connect\n",xa,ya,xb,yb,xc,yc);
return(0);
}

lndrw(fp,x1,y1,x2,y2)
FILE *fp;
double x1,y1,x2,y2;
{

  fprintf(fp,"%f %f moveto\n",x1,y1);
  fprintf(fp,"%f %f lineto\n",x2,y2);

  return(0);
}
/*
drwname(fp,x,y,name)
double x,y;
char name[];
{

 fprintf(fp,"%f %f moveto\n",x,y);
 fprintf(fp,"(%s)show\n",name);
 return(0);
}
*/

/*
drwname(fp,x,y,name)
double x,y;
char name[];
{

 fprintf(fp,"(%s) %f %f nameshow\n",name,x,y);
 return(0);
}
*/


drwname(fp,x,y,name)
FILE *fp;
double x,y;
char name[];
{

 fprintf(fp," %f %f moveto fontname setfont (%s)show\n",x,y,name);
 return(0);
}

drwnamet(fp,x,y,title)
FILE *fp;
double x,y;
char title[];
{

 fprintf(fp," %f %f moveto fontnamet setfont (%s)show\n",x,y,title);
 return(0);
}


drwnameb(fp,x,y,label)
FILE *fp;
char *label;
double x,y;
{

  fprintf(fp," %f %f moveto fontnameb setfont (%s)show\n",x+comm.dwnb,y-comm.dwnvb,label);
  return(0);
} 

drwnames(fp,x,y,label)
FILE *fp;
int label;
double x,y;
{

  fprintf(fp," %f %f moveto fontnames setfont (%d)centshow\n",x,y,label);
  return(0);
} 

drwnamesr(fp,x,y,label)
FILE *fp;
char *label;
double x,y;
{

  fprintf(fp," %f %f moveto fontnamesr setfont (%s)show\n",x,y,label);
  return(0);
} 

drwnamesb(fp,x,y,label)
FILE *fp;
char *label;
double x,y;
{

  fprintf(fp," %f %f moveto fontnamesb setfont (%s)show\n",x,y,label);
  return(0);
} 


shwid(fp,id,x,y)
FILE *fp;
int id;
double x,y;
{

  fprintf(fp," %f %f moveto fontnameb setfont (%d)show\n",x+comm.dwn,y-comm.dwnv,id);
  return(0);
} 




cnumb(nbst)
int nbst;
{
int n,nc;



   nc=1;
   for(; ; ){
      nbst /= 10;
      if( nbst < 10 ) break;
      nc++;
    }
   return(nc);
}





drwidn(fp,bstn,x, y)
FILE *fp;
int bstn;
double x,y;
{

fprintf(fp," %f %f moveto fontnameb setfont (%d)rightshow\n",x,y,bstn);
/* fprintf(fp," %f %f (%d) fillsps\n",x,y,bstn); */
return(0);
}

drwidn1(fp,bstn,x,y)
FILE *fp;
int bstn;
double x,y;
{

fprintf(fp," %f %f moveto fontnameb setfont (%d)centshow\n",x,y,bstn);
return(0);
}


outchk(nseq0,noutg,outg,cur0,anc0)
int nseq0,noutg,outg[];
struct nds **anc0,**cur0;

{
int i,j,k,*a0/*[MAXOTU]*/,*a1/*[MAXOTU]*/,n0,n1,nm,na,flg,bn,ln,rn;
int *bm/*[MAXOTU]*/,*lm/*[MAXOTU]*/,*rm/*[MAXOTU]*/;
unsigned char nx,ny;
extern int *ivector();
extern void free_ivector();

   a0 = ivector(nseq0);
   a1 = ivector(nseq0);
  
/* printf("outchk\n");fflush(stdout); */

for(i=0; i<nseq0-2; i++){
  n0=0;
  n1=0;
/*  printf("outchk %d\n",i);fflush(stdout); */
  for(j=0; j<nseq0 ; j++){
     nm = j/8;
     na = j%8;
     nx = 0x80;
     nx >>= na;
     ny = nx & comm.part[i][nm];
     if( ny == 0 ) {
           a0[n0]=j;
           n0++;
	 }
     else{
           a1[n1]=j;
           n1++;
	 }
/*    printf("j=%d n0=%d n1=%d\n",j,n0,n1);fflush(stdout);  */
   }

    flg=0;
    if( n0 == noutg || n1 == noutg){
    printf("%d n1=%d n0=%d %d b %d\n",i,n1,n0,adpart[i]->nkey,adpart[i]->b->nkey);

        if( n0 == noutg ){
          for(j=0; j<noutg ; j++){
            if( a0[j]+1 != outg[j] ) break;
            flg++;
	  }
          if( flg == noutg  ){
                  *cur0 = adpart[i];
                  *anc0 = adpart[i]->b;
                  free_ivector(a0,nseq0);
                  free_ivector(a1,nseq0);
                  return(0);
		}


	}
        if( n1 == noutg ){
         for(j=0; j<noutg ; j++){
            if( a1[j]+1 != outg[j] ) break;
            flg++;
	  }
        if( flg == noutg  ){
                  *cur0 = adpart[i]->b;
                  *anc0 = adpart[i];
                  free_ivector(a0,nseq0);
                  free_ivector(a1,nseq0);
                  return(0);
		}
       }
      }


}
   free_ivector(a0,nseq0);
   free_ivector(a1,nseq0);

    return(-1);
}




partition(ac,cur)
struct nds *ac,*cur;
{
struct nds *pw;
double *bw,dw,db;
int flg,*ip,i,nm,nw,na;
unsigned char *pc,nx,ny;

/* 
   tnodex  ancestor 
   tnodey  right
   tnodez  left
 */
    flg = 0;
/*    printf("cur=%d ac=%d",cur->nkey,ac->nkey); */
/*    if( cur->b != NULL ) printf(" b=%d",cur->b->nkey);
    if( cur->lc != NULL ) printf(" lc=%d",cur->lc->nkey);
    if( cur->rc != NULL ) printf(" rc=%d",cur->rc->nkey);
    printf("\n"); fflush(stdout);
*/
/*
    printf("cur=%p ac=%p",cur,ac);
    if( cur->b != NULL ) printf(" b=%p",cur->b);
    if( cur->lc != NULL ) printf(" lc=%p",cur->lc);
    if( cur->rc != NULL ) printf(" rc=%p",cur->rc);
    printf("\n");
*/
    if( cur->b  == ac ) flg += 1;
    if( cur->lc == ac ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx = ip;
      }

    if( cur->rc == ac ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;

        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx = ip;
        flg += 3;
      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d cur=%d\n",flg,cur->nkey);
       exit(1);
     }


    if( cur->lc != NULL) partition(cur,cur->lc);

    if( cur->rc != NULL) partition(cur,cur->rc);

    if( cur->lc != NULL && cur->rc != NULL ){
       if( cur->lc->nkey <= comm.nseq ){
        nw = cur->lc->nkey;
        nm = (nw-1)/8;
        na = (nw-1)%8;
        nx = 0x80;
        nx >>= na;
        comm.part[comm.npc][nm] |= nx;
        comm.ml=1;
        comm.nll[0]=nw-1;
       }else{
        cur->plcx = cur->lc->pbx;
        for(i=0; i< (comm.nseq-1)/8+1 ; i++){
          comm.part[comm.npc][i] |= cur->plcx[i];
        }
        getmem(cur->plcx,&comm.ml,comm.nll);
       }
       if( cur->rc->nkey <= comm.nseq ){
              cur->prcx = NULL;
              nw = cur->rc->nkey;
              nm = (nw-1)/8;
              na = (nw-1)%8;
              nx = 0x80;
              nx >>= na;
              comm.part[comm.npc][nm] |= nx;
              comm.mr =1;
              comm.nlr[0]=nw-1;
/*              printf("prc[%d]:",cur->rc->nkey);
              prpart1(comm.part[comm.npc]);
*/
	    }else{
              cur->prcx = cur->rc->pbx;
              for(i=0; i< (comm.nseq-1)/8+1 ; i++){
                comm.part[comm.npc][i] |= cur->prcx[i];
              }
/*              printf("part[%2d]:",comm.npc);
              prpart1(comm.part[comm.npc]);
              printf("prc[%d]:",cur->rc->nkey);
              prpart1(cur->prcx);
*/
              getmem(cur->prcx,&comm.mr,comm.nlr);
            }
           adpart[comm.npc] = cur;
           cur->pbx = comm.part[comm.npc];
/*           printf("cur[%d]:",cur->nkey);
           prpart1(cur->pbx);
*/
           comm.npc++;

     }
     return(0);
}
          

getmem(cpo,mx,nlx)
unsigned char *cpo;
int *mx,*nlx;
{
unsigned char nx,ny;
int i,j,nc,nm;
     nc=0;
     *mx=0;
     nm=0;
     for(i=0; i< (comm.nseq-1)/8+1 ; i++){
        for(j=0; j<8 ; j++){
            nx = 0x80;
            nx = nx >> j;
            ny = cpo[i] & nx;
/*            printf("x=%02x p=%d y=%d ",nx,cpo[i],ny);  */
            ny = ny >> (7-j);
/*            printf("y=%d\n",ny);*/
            switch(ny){
                  case 0: break;
                  case 1: nlx[nm]=nc;
                          nm++;
                          if( dflg == 1 ) printf("getmem nm=%d\n",nm);
                          break;
                 default: printf("invalid ny=%d\n",ny);
                      exit(1);
	     }
       nc++;
       if( nc >= comm.nseq ) {
            *mx=nm;
            return(0);
	  }

	      }
	    }


}




prpart()
{
int i,j,nw,nm,na;
unsigned char nx,ny;

for(i=0; i< comm.nseq-2 ; i++){

  for(j=0; j<comm.nseq ; j++){
        nw = j;
        nm = (nw-1)/8;
        na = (nw-1)%8;
        nx = 0x80;
        nx >>= na;
        ny = comm.part[i][nm] & nx;
        if( ny == 0 ) printf("0");
        if( ny != 0 ) printf("1");
      }
   printf("\n");
}
return(0);
}

prpart1(pc)
unsigned char *pc;
{
int i,j,nw,nm,na;
unsigned char nx,ny;

  for(j=0; j<comm.nseq ; j++){
        nw = j;
        nm = (nw-1)/8;
        na = (nw-1)%8;
        nx = 0x80;
        nx >>= na;
        ny = pc[nm] & nx;
        if( ny == 0 ) printf("0");
        if( ny != 0 ) printf("1");
      }
   printf("\n");
return(0);
}


under(ac,cur,nmem,nmeml)
struct nds *ac,*cur;
int *nmem,*nmeml;
{
struct nds *pw;
double *bw,dsum,ra,rb;
int flg,i,j,nw,*ip;
unsigned char nx,ny, *pc;
/* printf("nseq=%d  cur=%d\n",nseq,cur->nkey); 
fflush(stdout); 
*/
    flg = 0;
    if( cur->b  == ac ) flg += 1;
    if( cur->lc == ac ){
        flg += 2;
        pw=cur->lc;
        cur->lc = cur->b;
        cur->b = pw;
        bw = cur->blcx;
        cur->blcx = cur->bbx;
        cur->bbx=bw;
        ip = cur->bstlcx;
        cur->bstlcx = cur->bstbx;
        cur->bstbx=ip;
        pc = cur->plcx;
        cur->plcx = cur->pbx;
        cur->pbx=pc;
      }

    if( cur->rc == ac ){
        pw=cur->rc;
        cur->rc = cur->b;
        cur->b = pw;
        bw = cur->brcx;
        cur->brcx = cur->bbx;
        cur->bbx=bw;
        ip = cur->bstrcx;
        cur->bstrcx = cur->bstbx;
        cur->bstbx=ip;
        pc = cur->prcx;
        cur->prcx = cur->pbx;
        cur->pbx=pc;
        flg += 3;
      }

    if( flg < 1 || flg > 3 ){
       printf("flg =%d\n",flg);
       exit(1);
     }


    if( cur->rc != NULL) {
       under(cur,cur->rc,nmem,nmeml);
     }

    if( cur->lc != NULL) {
       under(cur,cur->lc,nmem,nmeml);
     }
   if( cur->lc != NULL && cur->rc != NULL){
       if( cur->lc->nkey <= comm.nseq ) {
              cur->plcx=NULL;
              nw=cur->lc->nkey;
              nmeml[*nmem]=nw;
              (*nmem)++;
	   }
       if( cur->rc->nkey <= comm.nseq ) {
              cur->prcx=NULL;
              nw=cur->rc->nkey;
	      nmeml[*nmem]=nw;
              (*nmem)++;
	    }
	    }







   return(0);
     }


setps0(fp,font,fontsize,linew)
FILE *fp;
char font[];
int fontsize;
double linew;
{
fprintf(fp,"newpath\n");
fprintf(fp,"/%s findfont\n",font);
fprintf(fp,"%d scalefont\n",fontsize);
fprintf(fp,"setfont\n");
fprintf(fp,"%f setlinewidth\n",linew);
fprintf(fp,"0 setlinejoin\n");
fprintf(fp,"/rightshow\n");
fprintf(fp,"{ dup stringwidth pop\n");
fprintf(fp,"neg\n");
fprintf(fp,"0 rmoveto\n");
fprintf(fp,"show}def\n");
fprintf(fp,"/centshow\n");
fprintf(fp,"{ dup stringwidth pop\n");
fprintf(fp,"2 div neg\n");
fprintf(fp,"0 rmoveto\n");
fprintf(fp,"show}def\n");
fprintf(fp,"/connect \n");
fprintf(fp,"{ /yc exch def /xc exch def /yb exch def /xb exch def /ya exch def /xa exch def\n");
fprintf(fp,"gsave newpath\n");
fprintf(fp,"%f setlinewidth\n",linew);
fprintf(fp,"xa yb moveto xb yb lineto\n");
fprintf(fp,"xa yc moveto xc yc lineto\n");
fprintf(fp,"xa yb moveto xa yc lineto\n");
fprintf(fp,"closepath \n");
fprintf(fp,"0 setgray stroke grestore\n");
fprintf(fp,"}def\n");


fprintf(fp,"/fillsps \n");
fprintf(fp,"{ /string exch def /y exch def /x exch def\n");
fprintf(fp,"string stringwidth /ys exch def /xs exch def\n");
fprintf(fp,"gsave newpath\n");
fprintf(fp,"x y moveto  xs neg  0 rlineto\n");
fprintf(fp,"0 ys rlineto\n");
fprintf(fp,"xs 0 rlineto\n");
fprintf(fp,"closepath \n");
fprintf(fp,"1 setgray fill  grestore\n");
fprintf(fp,"}def\n");

fprintf(fp,"/nameshow\n");
fprintf(fp,"{/string exch def   /y exch def /x exch def\n");
fprintf(fp,"/%s findfont %d scalefont setfont\n",font,comm.fontsize);
fprintf(fp,"x y moveto\n");
fprintf(fp,"string show}def\n");
fprintf(fp,"/fontname\n");
fprintf(fp," /%s findfont %d scalefont\n",font,fontsize);
fprintf(fp," def\n");
fprintf(fp,"/fontnameb\n");
fprintf(fp," /%s findfont %d scalefont\n",font,comm.fontsizeb);
fprintf(fp," def\n");
fprintf(fp,"/fontnames\n");
fprintf(fp," /%s findfont %d scalefont\n",font,comm.fontsizes);
fprintf(fp," def\n");
fprintf(fp,"/fontnamesr\n");
fprintf(fp," /%s findfont %d scalefont\n",font,comm.fontsizes);
fprintf(fp," def\n");

fprintf(fp,"/fontnamet\n");
fprintf(fp," /%s findfont %d scalefont\n",font,comm.fontsizet);
fprintf(fp," def\n");

fprintf(fp,"/fontnamesb\n");
fprintf(fp," /%s findfont %d scalefont\n",font,comm.fontsizesb);
fprintf(fp," def\n");

fprintf(fp,"/nmbshow\n");
fprintf(fp,"{ /string exch def  /y exch def /x exch def\n");
fprintf(fp,"%d scalefont setfont\n",comm.fontsizeb);
fprintf(fp,"x y moveto\n");
fprintf(fp,"string rightshow}def\n");

fprintf(fp,"/nmbshows\n");
fprintf(fp,"{ /string exch def  /y exch def /x exch def\n");
fprintf(fp,"%d scalefont setfont\n",comm.fontsizes);
fprintf(fp,"x y moveto\n");
fprintf(fp,"string rightshow}def\n");

fprintf(fp,"/nmbshowsr\n");
fprintf(fp,"{ /string exch def  /y exch def /x exch def\n");
fprintf(fp,"%d scalefont setfont\n",comm.fontsizes);
fprintf(fp,"x y moveto\n");
fprintf(fp,"string rightshow}def\n");


fprintf(fp,"/lndrw\n");
fprintf(fp,"{ /y2 exch def /x2 exch def /y1 exch def /x1 exch def /lw exch def\n");
fprintf(fp,"gsave newpath\n");
fprintf(fp,"lw setlinewidth\n",linew+0.5);
fprintf(fp,"x1 y1 moveto x2 y2 lineto\n");
fprintf(fp,"closepath \n");
fprintf(fp,"0 setgray stroke grestore\n");
fprintf(fp,"}def\n");
return(0);
}


setps(fp)
FILE *fp;
{
fprintf(fp,"%c!\n",'%');
fprintf(fp,"%cpostree\n",'%');
return(0);
}



closeps0(fp)
FILE *fp;
{
int i,j;
  fprintf(fp,"closepath\n");
  fprintf(fp,"stroke\n");
  fclose(fp);
  return(0);
}




wrtps(fp)
FILE *fp;
{
int i,j;
double pageheight,pagewidth,di,dj,dp,dymax;
FILE *fpi;
   pageheight = comm.vsize - comm.tmag - comm.bmag;
   pagewidth = comm.hsize - comm.lmag - comm.rmag;
   dymax = pageheight;
   dymax *= comm.npcol;
   setps(fp);
   dp = comm.ovlap;
 if( comm.rotate == 0 ){
   for(i=comm.npcol ; i>0 ; i--){
     di = i;
     for(j=0; j<comm.nprow ; j++){
       dj = j;
           fprintf(fp," %f %f translate\n",comm.lmag,comm.bmag);
           fprintf(fp,"newpath\n");
           fprintf(fp,"%f %f moveto\n",-dp,-dp);
           fprintf(fp,"%f %f lineto\n",-dp,pageheight+dp);
           fprintf(fp,"%f %f lineto\n",pagewidth+dp,pageheight+dp);
           fprintf(fp,"%f %f lineto\n",pagewidth+dp,-dp);
           fprintf(fp,"closepath clip\n");
           fprintf(fp," %f %f translate\n", -1.0*dj*pagewidth,-1.0*(di-1.0)*pageheight);
       
       if( (fpi = fopen("TEMPPS","r")) == NULL ){
         printf("Can't open temp\n");
         exit(1);
       }
       cpyfl(fpi,fp);
       fclose(fpi);
       fprintf(fp,"showpage\n");
	     

	 }
     }
 }

if( comm.rotate == 1 ){
   for(i=0 ; i < comm.nprow ; i++){
     di = i;
     for(j=0; j<comm.npcol ; j++){
           dj = j;
           fprintf(fp," %f %f translate\n",comm.lmag,comm.bmag);
           fprintf(fp,"newpath\n");
           fprintf(fp,"%f %f moveto\n",-dp,-dp);
           fprintf(fp,"%f %f lineto\n",-dp,pagewidth+dp);
           fprintf(fp,"%f %f lineto\n",pageheight+dp,pagewidth+dp);
           fprintf(fp,"%f %f lineto\n",pageheight+dp,-dp);
           fprintf(fp,"closepath clip\n");
           fprintf(fp,"%f %f translate\n",dymax,0.0);
           fprintf(fp,"90 rotate\n");
           fprintf(fp," %f %f translate\n",-1.0*di*pagewidth,dj*pageheight);
       
       if( (fpi = fopen("TEMPPS","r")) == NULL ){
         printf("Can't open temp\n");
         exit(1);
       }
       cpyfl(fpi,fp);
       fclose(fpi);
       fprintf(fp,"showpage\n");
	     

     }
}
}      



   fclose(fp);
  return(0);
}


cpyfl(fpi,fp)
FILE *fpi,*fp;
{
int cw;
char c;
  for( ; ; ){
      cw = fgetc(fpi);
      if( cw == EOF ) break;
      c = cw;
      fputc(c,fp);
    }
  return(0);
}

flpnode(cur)
struct nds *cur;
{
struct nds  *pw;
double *bw;
int *ip,iw;
unsigned char *pc;

                     pw=cur->rc;
                     cur->rc = cur->lc;
                     cur->lc = pw;

                      bw = cur->brcx;
                      cur->brcx = cur->blcx;
                      cur->blcx=bw;

                      ip = cur->bstrcx;
                      cur->bstrcx = cur->bstlcx;
                      cur->bstlcx=ip;

                     pc = cur->prcx;
                     cur->prcx = cur->plcx;
                     cur->plcx=pc;


    return(0);
}




drwscale0(fp,nda0)
FILE *fp;
struct nds *nda0/*[2*MAXOTU-2]*/;
{
int i;
double dy,dx;

  dy = nda0[comm.lastotu-1].y-comm.yscale;
  dx= comm.lmag1+comm.scalew+comm.xscale;
  fprintf(fp,"%f %f %f %f %f lndrw\n",comm.slinew,dx,dy,dx + comm.dscale*comm.dxunt,dy);
  fprintf(fp,"%f %f %f %f %f lndrw\n",comm.slinew,dx,dy-3,dx,dy+3);
  fprintf(fp,"%f %f %f %f %f lndrw\n",comm.slinew,dx+comm.dscale*comm.dxunt,dy-3,dx+comm.dscale*comm.dxunt,dy+3);
 if( comm.tscale[0] == 0 ){
        fprintf(fp,"%f %f moveto fontnames setfont (%s)centshow\n",dx+comm.dscale*comm.dxunt,dy- comm.fontsize*1.5,comm.sscale);
        fprintf(fp,"%f %f moveto fontnames setfont (%s)centshow\n",dx,dy- comm.fontsize*1.5,"0");
      }
  if( comm.tscale[0] != 0 ){
        fprintf(fp,"%f %f moveto fontnames setfont (%s)centshow\n",dx+comm.dscale*comm.dxunt,dy+ comm.fontsize/2.+1-comm.nscaley,comm.sscale);
        fprintf(fp,"%f %f moveto fontnames setfont (%s)centshow\n",dx,dy+ comm.fontsize/2.+1-comm.nscaley,"0");
     fprintf(fp,"%f %f moveto fontnames setfont (%s)centshow\n",dx + comm.dscale*comm.dxunt/2.,dy- comm.fontsize*1.5+comm.tscaley,comm.tscale);
   }
return(0);
  
}


drwscale(fp,nda0)
FILE *fp;
struct nds *nda0/*[2*MAXOTU-2]*/;
{
int i;
double dy,dx;

  dy = nda0[comm.lastotu-1].y-comm.yscale;
  dx= comm.lmag1+comm.scalew+comm.xscale;
  fprintf(fp,"%f %f %f %f %f lndrw\n",comm.slinew,dx,dy,dx + comm.dscale*comm.dxunt,dy);
  fprintf(fp,"%f %f %f %f %f lndrw\n",comm.slinew,dx,dy-3,dx,dy+3);
  fprintf(fp,"%f %f %f %f %f lndrw\n",comm.slinew,dx+comm.dscale*comm.dxunt,dy-3,dx+comm.dscale*comm.dxunt,dy+3);
 if( comm.tscale[0] == 0 ){
        fprintf(fp,"%f %f moveto fontnames setfont (%s)centshow\n",dx+comm.dscale*comm.dxunt/2.,dy- comm.fontsize*1.2,comm.sscale);
	/*        fprintf(fp,"%f %f moveto fontnames setfont (%s)centshow\n",dx,dy- comm.fontsize*1.5,"0");*/
      }
  if( comm.tscale[0] != 0 ){
        fprintf(fp,"%f %f moveto fontnames setfont (%s)centshow\n",dx+comm.dscale*comm.dxunt,dy+ comm.fontsize/2.+1-comm.nscaley,comm.sscale);
        fprintf(fp,"%f %f moveto fontnames setfont (%s)centshow\n",dx,dy+ comm.fontsize/2.+1-comm.nscaley,"0");
     fprintf(fp,"%f %f moveto fontnames setfont (%s)centshow\n",dx + comm.dscale*comm.dxunt/2.,dy- comm.fontsize*1.5+comm.tscaley,comm.tscale);
   }
return(0);
  
}

timescale(fp,nda0)
FILE *fp;
struct nds *nda0/*[2*MAXOTU-2]*/;
{
int i;
double dw,x1,x2,y1,y2,dw1,dw2;

   printf("tsend %f  tstime %f tsheight %f tsint %f fontsizes %d\n",comm.tsend,comm.tstime,comm.tsheight,comm.tsint,comm.fontsizes);
   x1 = nda0[comm.lastotu-1].x;
   y1 = nda0[comm.lastotu-1].y - (double) comm.fontsizes/2.0 -comm.tsy;
   x2 = nda0[comm.lastotu-1].x - comm.tsend/comm.tstime*comm.tsheight* comm.dxunt;   
   y2 = y1;
   printf("x1 y1 x2 y2 %f %f %f %f\n",x1,y1,x2,y2);
   fprintf(fp,"%f %f %f %f %f lndrw\n",comm.slinew,x1,y1,x2,y2);


    printf("comm.slinew=%f\n",comm.slinew);
   for(i=0; i <= comm.ntsint ; i++){
     dw = i;
     x1 = nda0[comm.lastotu-1].x - (comm.tsint/comm.tstime)*dw*comm.tsheight*comm.dxunt;
     printf("i=%d x1=%f\n",i,x1);
     fprintf(fp,"%f %f %f %f %f lndrw\n",comm.slinew,x1,y1+comm.tsintw,x1,y1-comm.tsintw);
   }

     x1 = nda0[comm.lastotu-1].x - (comm.tsend/comm.tstime)*comm.tsheight*comm.dxunt;
     fprintf(fp,"%f %f %f %f %f lndrw\n",comm.slinew,x1,y1+comm.tsintw,x1,y1-comm.tsintw);

   for(i=0; i< comm.ntimelab ; i++){
     dw = i;
     dw1 = comm.timelab[i];
     printf("timelab %d\n",comm.timelab[i]);
     dw2 = comm.tstime;
     x1 = nda0[comm.lastotu-1].x - comm.tsheight*(dw1/dw2)*comm.dxunt;
     drwnames(fp,x1,y1-comm.fontsizes-comm.tsly,comm.timelab[i]);
   }

   x1 = nda0[comm.lastotu-1].x;
   drwnamesr(fp,x1+comm.fontsizes,y1-comm.fontsizes-comm.tsly,comm.tsname);
   return(0);
}



drwtitle(fp)
FILE *fp;
{

int i;
double dy,dx;

    drwnamet(fp,comm.xtitle,comm.ytitle,comm.title);

return(0);
}




drwsbnm()
{
int i,j,n1,n2;
double y1,y2;

 printf("comm.nsb1=%d comm.nsb2=%d comm.nsb3=%d\n",comm.nsb1,comm.nsb2,comm.nsb3);
 for(i=0; i<comm.nsb1; i++){
    n1 = comm.sbnum1[i][0];
    n2 = comm.sbnum1[i][1];
    printf("n1=%d n2-%d\n",n1,n2); fflush(stdout);
    iswap(&n1,&n2);
   
    if( n1 != n2 ){
      y1 = nda[n1-1].y;
      y2 = nda[n2-1].y;
      dswap(&y1,&y2);
      printf("drwname i=%d x=%f %f %f %s\n",i,comm.sbx1,y1,y2,comm.sbname1[i]);
      fflush(stdout);
      drwpname(comm.fps,comm.sbx1,y1,y2,comm.sbname1[i]);
    }else{
      y1 = nda[n1-1].y;
      drwname(comm.fps,comm.sbx1+comm.dwn,y1-comm.dwnv,comm.sbname1[i]);
    }

  }


 for(i=0; i<comm.nsb2; i++){

    n1 = comm.sbnum2[i][0];
    n2 = comm.sbnum2[i][1];
    iswap(&n1,&n2);
    printf("i=%d comm.nsb=%d n1=%d n2=%d %f\n",i,comm.nsb2,n1,n2,comm.sbx2);
    if( n1 != n2 ){
      y1 = nda[n1-1].y;
      y2 = nda[n2-1].y;
      dswap(&y1,&y2);
      printf("drwname i=%d x=%f %f %f %s\n",i,comm.sbx2,y1,y2,comm.sbname2[i]);
      fflush(stdout);
      drwpname(comm.fps,comm.sbx2,y1,y2,comm.sbname2[i]);
    }else{
      y1 = nda[n1-1].y;
      drwname(comm.fps,comm.sbx2+comm.dwn,y1-comm.dwnv,comm.sbname2[i]);
    }

  }

 for(i=0; i<comm.nsb3; i++){
    n1 = comm.sbnum3[i][0];
    n2 = comm.sbnum3[i][1];
    iswap(&n1,&n2);
    if( n1 != n2 ){
      y1 = nda[n1-1].y;
      y2 = nda[n2-1].y;
      dswap(&y1,&y2);
      
      drwpname(comm.fps,comm.sbx3,y1,y2,comm.sbname3[i]);
    }else{
      y1 = nda[n1-1].y;
      drwname(comm.fps,comm.sbx3+comm.dwn,y1-comm.dwnv,comm.sbname3[i]);
    }

  }

  return(0);
}




drwpname(fp,x,y1,y2,name)
FILE *fp;
double x,y1,y2;
char name[];
{
  double dint;
 
  dint = comm.fontsize;
  dint /= 2.0;
 drwnamesb(fp,comm.dwn+x,(y1+y2)/2.0-comm.dwnv,name);
 fprintf(fp,"%f %f moveto\n",x,y1);
 fprintf(fp,"%f %f rlineto\n",-dint,0.0);
 fprintf(fp,"%f %f moveto\n",x,y2);
 fprintf(fp,"%f %f rlineto\n",-dint,0.0);
 fprintf(fp,"%f %f moveto\n",x,y1);
 fprintf(fp,"%f %f lineto\n",x,y2);
 return(0);
}






dswap(y1,y2)
double *y1,*y2;
 {
double dw;
if( *y1 > *y2 ){
   dw = *y1;
   *y1 = *y2;
   *y2 = dw;
 }
return(0);
}



iswap(y1,y2)
int *y1,*y2;
 {
int dw;
if( *y1 > *y2 ){
   dw = *y1;
   *y1 = *y2;
   *y2 = dw;
 }
return(0);
}





main(argc,argv)
int argc;
char **argv;
{
struct nds *cur,*anc;
FILE *fpi,*fpo=stdout,*fpt=stdin,*fps0;
float fw;
char font[20];
int i,j,k,l,rn,ifc,itc,iw,outflg,n1,n2,nbst,maxnm;
int dop=0,outgroup=0,noutg,*outg/*[MAXOTU]*/,nfnode,*fnode/*[MAXOTU]*/;
int ntitle,nw;
char title[NTITLE][100];
double xtitle[NTITLE],ytitle[NTITLE];
double *blen/*[2*MAXOTU-2]*/,xscale=1.0,yscale=1.0,linew=0.5;
double dw,dw1,db,dn,dw2,dw3,dwt,dwb,dwl,dwr;
char fps[200];
char cw;
extern int *ivector();
extern char *cvector(),**cmatrix();
extern unsigned char **ucmatrix();
extern double *dvector();
extern struct nds *ndsvector(), **ndspvector();
dflg=0;
noutg=0;
nfnode=0;

ifc = 0;
outflg=0;
ntitle=0;
/*printf("start\n"); fflush(stdout);*/
for(i=0; i<100 ; i++) fps[i]=0;
for(j=0; j<NTITLE ; j++){
    xtitle[j]=ytitle[j]=0.;
    for(i=0; i<100 ; i++) title[j][i]=0;
}
comm.ntimelab=0;;

/*printf("cominit\n"); fflush(stdout);*/
cominit();
printf("cominit tmag=%f\n",comm.tmag); fflush(stdout);
strcpy(font,"Times-Roman");

        if( argc == 1 ){
            printf("postree  inputfile -o [outgroup] -s[scalebar length]");
            printf(" -v[#col paper] -h[#row paper]");
            printf(" -mb[bottom margin]  -mt[top margin] -ml[left margin] -mr[right margin]");
            printf(" -nb[bottom margin1] -nt[top margin1] -nl[left margin1] -nr[right margin1]");
           printf(" -w[line width] -f[font] -p[fontsize] -pb[fontsizeb]  -i[show node ID] -b[bootstrap number]  -d(debug flag)\n");
            exit(1);
	  }
        for(i=1; i<argc; i++){
           if(argv[i][0] == '-' ){
              if( strcmp(argv[i]+1,"root" ) == 0 ){
               continue;
              }
              if( strcmp(argv[i]+1,"sbx1" ) == 0 ){
                i++;
                continue;
              }                
              if( strcmp(argv[i]+1,"sbx2" ) == 0 ){
                i++;
                continue;
              }                
              if( strcmp(argv[i]+1,"sbx3" ) == 0 ){
                i++;
                continue;
              }                
              if( strcmp(argv[i]+1,"psb" ) == 0 ){
                i++;
                continue;
              }                

              if( strcmp(argv[i]+1,"vs" ) == 0 ){
                i++;
                continue;
              }                

              if( strcmp(argv[i]+1,"bsty1" ) == 0 ){
                i++;
                continue;
              }                

              if( strcmp(argv[i]+1,"bsty2" ) == 0 ){
                i++;
                continue;
              }                
              if( strcmp(argv[i]+1,"tscaley" ) == 0 ){
                i++;
                continue;
              }                
              if( strcmp(argv[i]+1,"nscaley" ) == 0 ){
                i++;
                continue;
              }                

              if( strcmp(argv[i]+1,"sb1") == 0 ){
                 for(j=i+1; j <argc ; j += 3){
                    if( argv[j][0] == '-' ) break;
                    i += 3;
		  }

                  continue;
	       }
              if( strcmp(argv[i]+1,"sb2") == 0 ){
                 for(j=i+1; j <argc ; j += 3){
                    if( argv[j][0] == '-' ) break;
		    /*
                    strcpy(comm.sbname2[comm.nsb2],argv[j]);
                    sscanf(argv[j+1],"%d",&comm.sbnum2[comm.nsb2][0]);
                    sscanf(argv[j+2],"%d",&comm.sbnum2[comm.nsb2][1]);
                    comm.nsb2++;
		    */
                    i += 3;
		  }
                  continue;
	       }

              if( strcmp(argv[i]+1,"sb3") == 0 ){
                 for(j=i+1; j <argc ; j += 3){
                    if( argv[j][0] == '-' ) break;
		    /*
                    strcpy(comm.sbname3[comm.nsb1],argv[j]);
                    sscanf(argv[j+1],"%d",&comm.sbnum3[comm.nsb3][0]);
                    sscanf(argv[j+2],"%d",&comm.sbnum3[comm.nsb3][1]);
                    comm.nsb3++;
		    */
                    i += 3;
		  }
                  continue;
	       }

              if( strcmp(argv[i]+1,"tsend") == 0 ){
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tsint") == 0 ){
                 i++;
                  continue;
	       }

              if( strcmp(argv[i]+1,"ntsint") == 0 ){
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tsheight") == 0 ){
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tstime") == 0 ){
                 i++;
                  continue;
	       }
	    
              if( strcmp(argv[i]+1,"tsintw") == 0 ){
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tsy") == 0 ){
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tsly") == 0 ){
                 i++;
                 continue;
	       }

              if( strcmp(argv[i]+1,"tsnx") == 0 ){
                 i++;
                  continue;
	       }

              if( strcmp(argv[i]+1,"tsny") == 0 ){
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tsname") == 0 ){
                 i++;
                  continue;
	       }
              if( strcmp(argv[i]+1,"tslab") == 0 ){

                 for(j=i+1 ; j<argc ; j++){
                   if( argv[j][0] == '-' ) break;
		   /* sscanf(argv[j],"%d",&comm.timelab[comm.ntimelab]);*/

                   i++;
                 }
                  continue;
	       }
              switch(argv[i][1]){
        	   case 'l': 
                             if( argv[i][2] == 'o' && argv[i][3] == 'w' ){
                                sscanf(argv[i]+4,"%d",&comm.lowlim);
                                break;
			      }
                             nfnode=0;
                             if( argv[i][2] >= '0' && argv[i][2] <= '9' ){
			       /*  sscanf(argv[i]+2,"%d",&fnode[nfnode]);*/
                                  nfnode=1;
				}
                             for(j=i+1 ; j<argc ; j++){
                              if( argv[j][0] > '9' || argv[j][0] < '0' ) break;
			      /* sscanf(argv[j],"%d",&fnode[nfnode]);*/
                                nfnode++;
				/*
                                if( nfnode> MAXOTU-2 ){
                                     printf("too many flipnode %d\n",nfnode);
                                     exit(1);
				   }
				*/
                                i++;
			     }
                             break;
        	   case 'o': 
                             noutg=0;
                             if( argv[i][2] >= '0' && argv[i][2] <= '9' ){
			       /*    sscanf(argv[i]+2,"%d",&outg[noutg]);*/
                                  noutg=1;
				}
                             for(j=i+1 ; j<argc ; j++){
                              if( argv[j][0] > '9' || argv[j][0] < '0' ) break;

			      /*    sscanf(argv[j],"%d",&outg[noutg]);*/
                                noutg++;
				/*
                                if( noutg > MAXOTU ){
                                     printf("too many outgroup %d\n",noutg);
                                     exit(1);
				   }
				*/
                                i++;
			     }
                            if( noutg == 0 ){
                                 printf("no outgroup");
                                 exit(1);
			       }
                             printf("outgroup =%d\n",noutg); fflush(stdout);
                             break;

                   case 'd' : sscanf(argv[i]+2,"%d",&dflg);
                              break;
                   case 'c' : 
                              comm.rootlcn=1;
                              break;
                   case 'v' : sscanf(argv[i]+2,"%d",&comm.npcol);
                              break;
                   case 'h' : sscanf(argv[i]+2,"%d",&comm.nprow);
                              break;
                   case 'f' : sscanf(argv[i]+2,"%s",font);
                              break;
                   case 'p' : if( argv[i][2] == 'b' ){
                                 sscanf(argv[i]+3,"%d",&comm.fontsizeb);
                                 break;
			       }
                              if( argv[i][2] == 't' ){
                                 sscanf(argv[i]+3,"%d",&comm.fontsizet);
                                 break;
			       }
                              if( argv[i][2] == 's' && argv[i][3] == 'b' ){
                                 sscanf(argv[i]+4,"%d",&comm.fontsizesb);
                                 break;
			       }
                              if( argv[i][2] == 's' ){
                                 sscanf(argv[i]+3,"%d",&comm.fontsizes);
                                 break;
			       }
                              sscanf(argv[i]+2,"%d",&comm.fontsize);
                              break;
                   case 's' : if( argv[i][2] >= '0' && argv[i][2] <= '9' || argv[i][2] == '.' )  {
                              sscanf(argv[i]+2,"%s",comm.sscale);
                              sscanf(argv[i]+2,"%f",&fw);
                              comm.dscale = fw;
			    } 
                              if( argv[i][2] == 'l' ){
                                  sscanf(argv[i]+3,"%f",&fw);
                                  comm.slinew=fw;
				}
                              if( argv[i][2] == 'x' ){
                                  sscanf(argv[i]+3,"%f",&fw);
                                  comm.xscale=fw;
				}
                              if( argv[i][2] == 'y' ){
                                  sscanf(argv[i]+3,"%f",&fw);
                                  comm.yscale=fw;
				}
                              if( argv[i][2] == 'w' ){
                                  sscanf(argv[i]+3,"%f",&fw);
                                  comm.scalew=fw;
				}
                              if( argv[i][2] == 't' ){
                                  sscanf(argv[i]+3,"%s",comm.tscale);
				}
                              break;
                   case 't' :  if( argv[i][2] == 'i' ){
                                   strcpy(title[ntitle],argv[i+1]);
                                   i++;
                                   ntitle++;
                                   break;
				 }
                               if( argv[i][2] == 'x' ) {
                                   sscanf(argv[i]+3,"%f",&fw);
                                   xtitle[ntitle-1]=fw;
                                   break;
				 }
                               if( argv[i][2] == 'y' ) {
                                   sscanf(argv[i]+3,"%f",&fw);
                                   ytitle[ntitle-1]=fw;
                                   break;
				 }

                              comm.treeord=1;
                              break;
                   case 'i' : comm.idnflg=1;
                              break;
                   case 'e' : comm.ext=1;
                              break;
                   case 'r' : comm.rotate=1;
                              break;
                   case 'b' : sscanf(argv[i]+2,"%d",&comm.lowlim);
                              break;
                   case 'w' : sscanf(argv[i]+2,"%f",&fw);
                              linew = fw;
                              break;
                   case 'm' : switch(argv[i][2]){
                                case 'b': sscanf(argv[i]+3,"%f",&fw);
                                          comm.bmag=fw;
                                           break;
                                case 't': sscanf(argv[i]+3,"%f",&fw);
                                          comm.tmag=fw;
                                           break;
                                case 'l': sscanf(argv[i]+3,"%f",&fw);
                                          comm.lmag=fw;
                                           break;
                                case 'r': sscanf(argv[i]+3,"%f",&fw);
                                          comm.rmag=fw;
                                           break;
                                default: printf("invalid argument\n");
                                         exit(1);
                                         break;
				}
                               break;

                   case 'n' : switch(argv[i][2]){
                                case 'd': 
                                          sscanf(argv[i]+3,"%d",&iw);
                                          strcpy(comm.ndlab[iw],argv[i+1]);
                                          i++;
                                          break;                             
                                case 'b': sscanf(argv[i]+3,"%f",&fw);
                                          comm.bmag1=fw;
                                           break;
                                case 't': sscanf(argv[i]+3,"%f",&fw);
                                          comm.tmag1=fw;
                                           break;
                                case 'l': sscanf(argv[i]+3,"%f",&fw);
                                          comm.lmag1=fw;
                                           break;
                                case 'r': sscanf(argv[i]+3,"%f",&fw);
                                          comm.rmag1=fw;
                                           break;
                                default: printf("invalid argument\n");
                                         exit(1);
                                         break;
				}
                               break;

			   }
               }else{
                         if((fpt = fopen(argv[i],"r")) == NULL ){
                                 printf("Can't open file %s arg %d\n",argv[i],i);
                                 exit(1);
			       }
                         nw = strlen(argv[i]);
			 /*  printf("%d %s\n",nw,argv[i]);*/
			 /*
                         for(j=0; j< nw ; j++){
                          if( argv[i][j] == '.' ) {
                             nw = j;
                             break;
                          }
                          fps[j]=argv[i][j];

                         }
			 */
			 /* printf("nw=%d %s\n",nw,argv[i]);*/
			 strcat(fps,argv[i]);
                         strcat(fps,".ps");
			 /* printf("%s\n",argv[i]);*/
                         ifc=i;
		       }


	 }


    if( ifc == 0 ){
       printf("topology file is not specified\n");
       exit(1);
    }
  chktv(fpt,&(comm.nseq),&maxnm);
  fclose(fpt);

  /*   printf("end of chktv maxnm=%d tmag=%f\n",maxnm,comm.tmag); fflush(stdout);*/
  if( noutg > 0 ) outg = ivector(noutg);
  else {
    outg = ivector(2);
    outg[0]=1;
  }
  if( fnode > 0 ) fnode = ivector(nfnode);
  blen = dvector(comm.nseq*2-2);
  nda = ndsvector(comm.nseq*2-2);
  adpart = ndspvector(comm.nseq-2);
  comm.part = ucmatrix(comm.nseq-2, (comm.nseq-1)/8+1);
  comm.fl = cmatrix(comm.nseq,maxnm+1);
  comm.ndlab = cmatrix(comm.nseq*2,40);
  comm.bstnb = ivector(comm.nseq*2-3);
  comm.conflvl = dvector(2*comm.nseq-3);
  comm.nll = ivector(comm.nseq);
  comm.nlr = ivector(comm.nseq);

for(i=0; i<2*comm.nseq; i++){
   for(j=0; j<40 ; j++) comm.ndlab[i][j]=0;
 }
    
/*  printf("%s\n",argv[ifc]);*/
  chkarg(comm.nseq,argc,argv,nfnode,noutg,outg,fnode);
  /*  printf("chkarg\n"); fflush(stdout);*/

  if((fpt = fopen(argv[ifc],"r")) == NULL ){
        printf("Can't open file %s arg %d\n",argv[ifc],ifc);
        exit(1);
    }


  rdtv(fpt,&(comm.nseq),comm.fl,nda,blen,maxnm);
  fclose(fpt);
for(i=0; i<noutg ; i++){
   if( outg[i] > comm.nseq ) {
      printf("invalid outgroup %d\n",outg[i]);
      exit(1);
    }
 }

for(i=0; i<noutg-1 ; i++){
   for(j=i+1; j<noutg ; j++){
     if( outg[i] > outg[j] ){
        iw = outg[i];
        outg[i]=outg[j];
        outg[j]=iw;
      }
   }
 }

for(i=0; i<(comm.nseq-1)/8+1 ; i++){
  for(j=0; j<comm.nseq-2; j++) comm.part[j][i]=0;
}
if( comm.rotate == 1 ){
    dw = comm.vsize;
    comm.vsize = comm.hsize;
    comm.hsize = dw;

    dwt = comm.tmag;
    dwb = comm.bmag;
    dwl = comm.lmag;
    dwr = comm.rmag;
    comm.lmag = dwt;
    comm.tmag = dwl;
  }
fprintf(fpo,"topology file %s: nseq=%d bstflg=%d\n",argv[ifc],comm.nseq,comm.bstflg);
 if( comm.bstflg == 4 ) fprintf(fpo,"ntietree=%d\n",comm.ntietree);
 fflush(stdout);

if( noutg > 0 ){
   fprintf(fpo,"outgroup:");
   for(i=0; i<noutg ; i++) fprintf(fpo,"  %d %s",outg[i],comm.fl[outg[i]-1]);
   fprintf(fpo,"\n");
   fflush(fpo);
 }
fprintf(fpo,"ncol=%d nrow=%d  margin b %f t %f l %f r %f\n",comm.npcol,comm.nprow,comm.bmag,comm.tmag,comm.lmag,comm.rmag);
fprintf(fpo,"   margin1 b %f t %f l %f r %f lowlim=%d\n",comm.bmag1,comm.tmag1,comm.lmag1,comm.rmag1,comm.lowlim);
if( comm.rotate == 1 ) printf("landscape\n");
if( comm.rootlcn == 0 ) printf("root upper\n");
if( comm.rootlcn == 1 ) printf("root lower\n");
fflush(stdout);


      comm.npc=0;
     
      comm.dmax= -999.0;
      printf("outchk noutg=%d\n",noutg);
      if( noutg > 0 ){
         if( noutg > 1 ){
           comm.npc=0;
           partition(&nda[0],nda[0].b);
/*           prpart(); */
           rn=outchk(comm.nseq,noutg,outg,&cur,&anc);
           if( rn != 0 ){
            printf("outgroup error\n");
            exit(1);
          }
           comm.bt1=anc;
           comm.bt2=cur;
         }else{
            comm.bt1 = &nda[outg[0]-1];
            comm.bt2 = nda[outg[0]-1].b;
            
	  }
       }else{
            dsmax();
            comm.bt1 = comm.a1;
            comm.bt2 = comm.a2;
            printf("maxp %d %d dmax=%f\n",comm.maxp[0]->nkey,comm.maxp[1]->nkey,comm.dmax); fflush(stdout);
            printf("bt %d %d\n",comm.bt1->nkey,comm.bt2->nkey); fflush(stdout);

	  }

      comm.upflg=0;
      comm.dhmax=-990.0;
      comm.nlc=0;
      comm.bt2->height=0.0;
      comm.bt1->height=0.0;
      dwnarg(comm.bt1,comm.bt2);
      printf("dwnarg1 end  hmax %f smax %d\n",comm.dhmax,comm.seqhmax);
      comm.dhmax1 = comm.dhmax;
      comm.seqhmax1 = comm.seqhmax;
      printf("dwnarg dhmax %f\n",comm.dhmax);
      fflush(stdout);
      comm.dhmax=-990.0;
      comm.nlc=0;
      comm.dw = comm.dbt1;
      comm.bt2->height=0.0;
      comm.bt1->height=0.0;
      dwnarg(comm.bt2,comm.bt1);
      comm.dhmax2 = comm.dhmax;
      comm.seqhmax2 = comm.seqhmax;
      db = *(comm.bt2->bbx);
      if( db < 0.0 ) db=0.0;
      printf("dwnarg end\n");
      printf("dhmax1 %d %f %f  dhmax2 %d %f %f db=%f\n",comm.seqhmax1,comm.dhmax1,nda[comm.seqhmax1-1].height, comm.seqhmax2,comm.dhmax,nda[comm.seqhmax2-1].height,db);
      fflush(stdout);
      dw = (db + nda[comm.seqhmax1-1].height + nda[comm.seqhmax2-1].height )/2.0;
      if( dw > comm.dhmax1 && dw > comm.dhmax2 ){
          comm.dbt1 = (db+nda[comm.seqhmax2-1].height-nda[comm.seqhmax1-1].height)/2.0;
          comm.dbt2 = (db+nda[comm.seqhmax1-1].height-nda[comm.seqhmax2-1].height)/2.0;
          n1 = strlen(comm.fl[comm.seqhmax1-1]);
          n2 = strlen(comm.fl[comm.seqhmax2-1]);
          dn = n1;
          if( n1 < n2 ) dn =n2;
          dw1 = comm.fontsize;
          dw1 /= comm.hvcrto;
          dw2 = comm.hsize-comm.rmag-comm.lmag-comm.rmag1-comm.lmag1;
          dw2 *= comm.nprow;
          dw3 = comm.vsize-comm.tmag-comm.bmag-comm.tmag1-comm.bmag1-dw1;
          dw3 *= comm.npcol;
          comm.dxunt = (dw2-comm.dwn-dn*dw1)/dw;
          comm.dyint = dw3;
          comm.dyint /= comm.nseq;

         }else{
          
          if( db + comm.dhmax1 <= comm.dhmax2  ){
            if( db > comm.dhmax2/comm.rootrto*2.0 ) {
              comm.dbt2 =  comm.dhmax2/comm.rootrto;
              comm.dbt1 = db - comm.dbt2;
            }else{
              comm.dbt2 = db/2.0;
              comm.dbt1 = db/2.0;
            }
              dw = nda[comm.seqhmax2-1].height+ comm.dbt2;
              n1 = strlen(comm.fl[comm.seqhmax2-1]);
              dn=n1;
              dw1 = comm.fontsize;
              dw1 /= comm.hvcrto;
              dw2 = comm.hsize-comm.rmag-comm.lmag-comm.rmag1-comm.lmag1;
              dw2 *= comm.nprow;
              dw3 = comm.vsize-comm.tmag-comm.bmag-comm.tmag1-comm.bmag1;
              dw3 *= comm.npcol;
              comm.dxunt = (dw2-comm.dwn-dn*dw1)/dw;
              comm.dyint = dw3;
              comm.dyint /= comm.nseq;
	 }
         if( db +  comm.dhmax2 <= comm.dhmax1 ){
            if( db > comm.dhmax1/comm.rootrto*2.0 ) {
              comm.dbt1 =  comm.dhmax1/comm.rootrto;
              comm.dbt2 = db - comm.dbt1;
            }else{
              comm.dbt2 = db/2.0;
              comm.dbt1 = db/2.0;
            }
            dw = nda[comm.seqhmax1-1].height+ comm.dbt1;
            n1 = strlen(comm.fl[comm.seqhmax1-1]);
            dn=n1;
            dw1 = comm.fontsize;
            dw1 /= comm.hvcrto;
            dw2 = comm.hsize-comm.rmag-comm.lmag-comm.rmag1-comm.lmag1;
            dw2 *= comm.nprow;
            dw3 = comm.vsize-comm.tmag-comm.bmag-comm.tmag1-comm.bmag1;
            dw3 *= comm.npcol;
            comm.dxunt = (dw2-comm.dwn-dn*dw1)/dw;
            comm.dyint = dw3;
            comm.dyint /= comm.nseq;
	 }
         if( db+comm.dhmax1 > comm.dhmax2 && db+comm.dhmax2 > comm.dhmax1 ){
          comm.dbt1=db/2.0;
          comm.dbt2=db/2.0;
          dw = nda[comm.seqhmax1-1].height+db/2.0;
          n1 = strlen(comm.fl[comm.seqhmax1-1]);
          if( comm.dhmax1 < comm.dhmax2 ) {
             dw = nda[comm.seqhmax2-1].height+db/2.0;
             n1 = strlen(comm.fl[comm.seqhmax2-1]);
	   }
          dn=n1;
          dw1 = comm.fontsize;
          dw1 /= comm.hvcrto;
          dw2 = comm.hsize-comm.rmag-comm.lmag-comm.rmag1-comm.lmag1;
          dw2 *= comm.nprow;
          dw3 = comm.vsize-comm.tmag-comm.bmag-comm.tmag1-comm.bmag1;
          dw3 *= comm.npcol;
          comm.dxunt = (dw2-comm.dwn-dn*dw1)/dw;
          comm.dyint = dw3;
          comm.dyint /= comm.nseq;
	}
	}
      if( (comm.fps = fopen("TEMPPS","w")) == NULL ){
         printf("Can't open TEMPPS\n");
         exit(1);
       }
      setps0(comm.fps,font,comm.fontsize,linew);
      printf("setps %s\n",font);
      fflush(stdout);
      comm.nlc=0;
      printf("seq %d hmax=%f dxunit=%f\n",comm.seqhmax,nda[comm.seqhmax-1].height,comm.dxunt); fflush(stdout);
      if( comm.rootlcn == 0 && comm.treeord == 1){
         comm.upkey = comm.bt2->nkey;
       }
      printf("bt2=%d\n",comm.bt2->nkey); fflush(stdout);
      if( comm.rootlcn == 1 && comm.treeord == 1){
         comm.upkey = -999;
       }
      if( comm.treeord == 0 ){
          comm.upkey = -999;
          if( comm.bt2->rc != NULL )  comm.upkey = comm.bt2->rc->nkey;
	}
      printf("bt2=%d\n",comm.bt2->nkey); fflush(stdout);
/*      printf("dwnarg1 start\n"); fflush(stdout); */
      comm.upflg=1;
      dwnarg1(comm.bt1,comm.bt2);
      comm.upflg=0;
      dwnarg1(comm.bt2,comm.bt1);
      printf("dwnarg1 end nfnode=%d rootlcn=%d\n",nfnode,comm.rootlcn); fflush(stdout);
      for(i=0; i<nfnode ; i++){
        flpnode(&nda[fnode[i]-1]);
      }
      comm.nlc=0;
      if( comm.rootlcn == 0 ){
          comm.upflg=0;
          comm.dbw = comm.dbt1;
          drwarg(comm.bt1,comm.bt2);
	  /*   printf("drwargr1 end\n"); fflush(stdout);*/
          comm.upflg=0;
          comm.dbw = comm.dbt2;
          drwarg(comm.bt2,comm.bt1);
	  /*  printf("drwargr2 end\n"); fflush(stdout);*/
	}

      if( comm.rootlcn == 1 ){
          comm.upflg=0;
          comm.dbw = comm.dbt2;
          drwarg(comm.bt2,comm.bt1);
          comm.upflg=0;
          comm.dbw = comm.dbt1;
          drwarg(comm.bt1,comm.bt2);
	}

      printf("drwarg end comm.bstflg=%d\n",comm.bstflg); 
      fflush(stdout);
/*      connect(comm.fps,comm.rmag,(comm.bt1->y+comm.bt2->y)/2.0,comm.bt1->x,comm.bt1->y, 
       comm.bt2->x,comm.bt2->y); */
      connect(comm.fps,comm.lmag1,(comm.bt1->y+comm.bt2->y)/2.0,comm.bt1->x,comm.bt1->y,
       comm.bt2->x,comm.bt2->y);
         if( comm.bstflg == 2 && comm.ext == 1  ){
          if( comm.bt1->nkey <= comm.nseq  ){
              nbst = *(comm.bt1->bstbx);
              if( nbst >= comm.lowlim ){
                 dw1 = comm.fontsizeb;
                 dw1 /= 2.0;
                 drwidn1(comm.fps,nbst,0+ (comm.bt1->x)/2.0,comm.bt1->y+dw1);
	       }
	    }
          if( comm.bt2->nkey <= comm.nseq  ){
              nbst = *comm.bt2->bstbx;
              if( nbst >= comm.lowlim ){
               dw1 = comm.fontsizeb;
                dw1 /= 2.0;
                drwidn1(comm.fps,nbst,0+ (comm.bt2->x)/2.0,comm.bt2->y+dw1);
	     }
	    }
	}
         if( comm.bstflg == 3 ){
          if( comm.bt1->nkey <= comm.nseq  ){
              nbst = *(comm.bt1->bstbx);
              if( nbst >= comm.lowlim ){
                 dw1 = comm.fontsizeb;
                 dw1 /= 2.0;
                 drwidn(comm.fps,nbst,comm.bt2->x- dw/2.0,comm.bt2->y+dw);
	       }
	    }
          if( comm.bt2->nkey <= comm.nseq  ){
              nbst = *comm.bt2->bstbx;
              if( nbst >= comm.lowlim ){
               dw1 = comm.fontsizeb;
                dw1 /= 2.0;
                drwidn(comm.fps,nbst,comm.bt1->x- dw/2.0,comm.bt1->y+dw);
	     }
	    }
	}
       if( comm.bstflg == 1 || comm.bstflg == 2 || comm.bstflg == 3 ){
          if( comm.bt1->nkey > comm.nseq && comm.bt2->nkey > comm.nseq ){
              iw = *comm.bt2->bstbx;
              if( iw >= comm.lowlim ){
                 dw = comm.fontsizeb;
                dw /= 2.0;
                drwidn(comm.fps,iw,comm.bt1->x- dw/2.0,comm.bt1->y+dw);
	       }
	    }
	}
       if( comm.dscale > 0.0 ) drwscale(comm.fps,nda);
       /*       if( comm.title[0] != 0 ) {
         drwnamet(com.fps,comm.xtitle,comm.ytitle,comm.title);
       }
       */
       if( ntitle != 0 ) {
	 for(i=0; i<ntitle ; i++){
           drwnamet(comm.fps,xtitle[i],ytitle[i],title[i]);
	 }
       }

       if( comm.nsb1 > 0 ) drwsbnm();
       printf("ntimelab=%d\n",comm.ntimelab);
       if( comm.ntimelab > 0 ) timescale(comm.fps,nda);
       closeps0(comm.fps);

       if( (fps0 = fopen(fps,"w")) == NULL ){
          fprintf(fpo,"Can't open file %s\n",fps);
          exit(1);
      }  
      
   
       wrtps(fps0);


exit(0);
}


