/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package codeinfer.LoaderRunner;

import codeinfer.Inferists.CLASS_ResolveClassStructUnion;
import codeinfer.Super.Info;
import codeinfer.Inferists.CLASS_ResolveMain;
import codeinfer.Inferists.HEADER_PreProcessorDirectiveRemove;
import codeinfer.Inferists.IO_CoutConvert;
import codeinfer.PreProcessing.SourcePreProcessor;
import codeinfer.Inferists.IO_CinConvert;
import codeinfer.PreProcessing.Util;
import java.util.ArrayList;

/**
 *
 * @author soumen
 */
public class Run
{
	private static ArrayList<String> CppSource;
	private static StringBuffer CppSourceBuffer = new StringBuffer();
	private static SourcePreProcessor spp = new SourcePreProcessor();
	public static String DOCUMENT_ROOT_;
	public static String SELECTED_FILE_PART_NAME;
	public static String SELECTED_FILE_PART_OUTPUT_JAVA;
	
	public static final int CIN = 0;
	public static final int FILE_R = 1;
	public static boolean[] _imports = {false, false};
	public static String home;
	
	protected static void run(SourcePreProcessor sourcePreProcessor)
	{
		/////////////// INIT - s/////////////////////
		//spp = new SourcePreProcessor(SELECTED_FILE_PART_NAME);
		
		spp = sourcePreProcessor;
		CppSourceBuffer = Util.nullTrimBuffer(new StringBuffer(spp.getSourceCodeBuffer()));
		spp.setSourceCodeBuffer(CppSourceBuffer);
		
		spp.tokenizer();
		CppSource = spp.getSrcList();
		////////////// INIT - e//////////////////////
		
		////////////// DATATYPES - s/////////////////
		
		boolean thisIsMain = false;
		
		CppSourceBuffer = spp.getSourceCodeBuffer();
		
		// step 1
		IO_CoutConvert IO_COUT = new IO_CoutConvert();
		// CppSourceBuffer = IO_COUT.patchCPPStrings(CppSourceBuffer,INFO.STRINGS_LIST);
		try
		{
			CppSource = IO_COUT.doCoutConvert(CppSource);
		}
		catch (Exception e)
		{
//			Util.log(CppSource.toString(), false);
			e.printStackTrace();
		}
		
		// step 2
		IO_CinConvert IO_CIN = new IO_CinConvert(spp, CppSource);
		try
		{
			CppSource = IO_CIN.doCinConvert();
		}
		catch (Exception e)
		{
	//		Util.log(CppSource.toString(), false);
			e.printStackTrace();
		}
		
		// step 3
		CLASS_ResolveClassStructUnion x = new CLASS_ResolveClassStructUnion(spp, CppSource);
		try
		{
			CppSource = x.doResolveClassStructUnion();
		}
		catch (Exception e)
		{
	//		Util.log(CppSource.toString(), false);
			e.printStackTrace();
		}
		
		// step 4
		if (spp.IsContainMain())
		{
			Util.log("Going to resolve main...", false);
			Info.MAIN_FILE_NAME = spp.getFileName() + ".java";
			Info.EXISTS_MAIN = true;
			
			CLASS_ResolveMain RM = new CLASS_ResolveMain();
			CppSource = RM.doResolveMain(CppSource);// Resolving Main
			HEADER_PreProcessorDirectiveRemove HPR_MAIN = new HEADER_PreProcessorDirectiveRemove(spp.arrayListToStringBuffer(CppSource));
			CppSourceBuffer = HPR_MAIN.getSource();
			thisIsMain = true;
		}
		else
		{
			Util.log(spp.getFileName() + " Dosen't contain main", false);
		}
		
		// step last
		if (!thisIsMain)
		{
			HEADER_PreProcessorDirectiveRemove HPR =
				new HEADER_PreProcessorDirectiveRemove(spp.arrayListToStringBuffer(CppSource));
			HPR.CaptureRemovePreProcessors();
			// HPR.resolvePreProcessors();
			CppSourceBuffer = HPR.getSource();
		}
		
		Util.SaveFile(	Run.SELECTED_FILE_PART_OUTPUT_JAVA,
							new StringBuffer(Util.nullTrimBuffer(CppSourceBuffer)), false);
	}

	/**
	 * 
	 */
	public static void run()
	{
		// TODO Auto-generated method stub
		
	}
	
}
