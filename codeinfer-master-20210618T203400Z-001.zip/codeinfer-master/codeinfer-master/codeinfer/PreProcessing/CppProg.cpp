#include<stdio.h>
#define MAX 16
#define ADD(a+b) (a)+(b)
int m(){
    return 0;
}



class Day
{
    signed int count;
    int month;
public:
    int total()
    {
        return count;
    }
    struct Man
    {
        char name;
    private:
        float gotok;
        float f;
    };
    
private:
    float holy()
    {
        return month;
    }
};


class Hour
{
    int count;
    int month;
public:
    int total()
    {
        return count;
    }
    struct Man
    {
        char name;
    private:
        float gotok;
        float f;
    };
private:
    float holy()
    {
        return month;
    }
};


int main()
{
    
}


union gooh
{
private:
    int x,y;
    float hello()
    {        
        cin>>x>>y;
        
        cout<<"Hello \" Balocks"<<x<<"jkoiu"<<superd(5,6);
        return x;
    }
    float f;
};


