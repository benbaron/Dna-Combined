package codeinfer.PreProcessing;

import java.io.BufferedReader;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class CreateClass {
	ArrayList<String> classNameList = new ArrayList();
	private String src[];
	private String srcFilename;
	private File file;
	
	CreateClass(String f1){
		file=new File(f1);
	} 
	// call splitter first.
   // read File over here.store it in src[];
	//for()
	
	
}
