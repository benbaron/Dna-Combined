#include<stdio.h>
#include<conio.h>
#include<iostream.h>
#define ADD(a,b) ((a)+(b))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define s 23
int main()
{

    cout<<"Sum is"<<ADD(5,6);
    cout<<"MAX value is: "<<ADD(ADD(2,3),ADD(2,3));
    FILE * fp = fopen("hshs.txt","r");
    cout<<"\n";
    return 0;
    
}

int x()
{
    cout<<"Sum is"<<ADD(5,6);
    cout<<"MAX value is: "<<ADD(ADD(2,3),ADD(2,3));
    cout<<"Sum is"<<ADD(5,6);
    cout<<"MAX value is: "<<ADD(ADD(2,3),ADD(2,3));
    cout<<"Sum is"<<ADD(5,6);
    cout<<"MAX value is: "<<ADD(ADD(2,3),ADD(2,3));
    FILE * fp = fopen("hshs.txt","r");
    cout<<"\n";
    return 0;    
}

class x{
    
};

