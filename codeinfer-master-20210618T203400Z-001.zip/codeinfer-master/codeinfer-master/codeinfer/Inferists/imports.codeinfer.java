package codeinfer.Inferists;

import java.util.Scanner;
import java.io.InputStreamReader;
