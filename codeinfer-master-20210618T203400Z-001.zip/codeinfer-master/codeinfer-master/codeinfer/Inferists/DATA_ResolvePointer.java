package codeinfer.Inferists;

import java.util.ArrayList;

public class DATA_ResolvePointer
{
	ArrayList<String> srcList = new ArrayList<String>();
	

}
