package codeinfer.starter;

// ~--- non-JDK imports --------------------------------------------------------

import codeinfer.Inferists.CLASS_GlobalResolve;
import codeinfer.LoaderRunner.Run;
import codeinfer.PreProcessing.DataTypes;
import codeinfer.PreProcessing.KeyWords;

import codeinfer.PreProcessing.SliceFile;
import codeinfer.PreProcessing.SourcePreProcessor;
import codeinfer.PreProcessing.Util;
import codeinfer.RegEx.Expression;
import codeinfer.Super.Info;
import codeinferfui.ProjectBundle;

// ~--- JDK imports ------------------------------------------------------------

import java.io.File;
import java.util.ArrayList;

/**
 *
 * @author soumen
 */
enum OS {
	Windows, Other
}


public class Codeinfer extends Run
{
	private static String InputDIR;
	private static String OutputDIR;
	private static SliceFile SF;
	private ProjectBundle PB;
	
	
	public Codeinfer(ProjectBundle Codeinfer)
	{
		PB = new ProjectBundle(Codeinfer);
		if (Init())
		{
			Infer();
			ResolveGlobal();
			Combine();
			RestoreStrings();
			CleanUP();
		}
		
	}
	
	private static void ResolveGlobal()
	{
		CLASS_GlobalResolve CGR = new CLASS_GlobalResolve(Info.SLICED_FILES_NAMES);
		ArrayList<String> globals = CGR.doResolveGlobals();
		
		Info.GLOBAL_AVAILABLE = CGR.getResolvedStatus();
		if (Info.GLOBAL_AVAILABLE)
		{
			Info.GLOBAL_CLASS_FILE = Info.TEMPORARY_OUTPUT_DIRECTORY +	Info.DIRECTORY_SYMBOL +
												CLASS_GlobalResolve.GLOBAL_CLASS + ".java";
			Info.PARTS += 1;
			Util.SaveFile(Info.GLOBAL_CLASS_FILE, globals, false);
		}
		
	}
	
	private boolean Init()
	{
		Util.sopln("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
		Info.OS = System.getProperty("os.name");
		Info.DIRECTORY_SYMBOL = Util.getDirectorySymbol(Util.getOS());
		
		double wait = 0000;
		try
		{
			Thread.sleep((long) wait);
		}
		catch (InterruptedException ex)
		{
			System.out.println(ex);
		}
		
		InputDIR = PB.getCPP_FILE();
		OutputDIR = PB.getOUTPUT_DIR() + Info.DIRECTORY_SYMBOL + PB.getPROJECT_NAME();
		Info.INPUT_FILE = InputDIR;
		Info.OUTPUT_DIRECTORY = OutputDIR;
		Info.INPUT_FILE_NAME = new File(Info.INPUT_FILE).getName();
		Info.INPUT_FILE_NAME_ONLY = Util.extructFileNameOnly(new File(Info.INPUT_FILE).getName());
		Info.OUTPUT_FILE_NAME = Info.OUTPUT_DIRECTORY + Info.DIRECTORY_SYMBOL +
										Info.INPUT_FILE_NAME_ONLY + ".java";
		Info.PROJECT_ROOT = System.getProperty("user.dir");
		Info.DOCUMENT_ROOT = new File(Info.INPUT_FILE).getParent();
		
		
		Info.TEMPORARY_TEMP_DIRECTORY = Info.OUTPUT_DIRECTORY + Info.DIRECTORY_SYMBOL + "TEMP";// Contains
																															// all
																															// sliced
																															// cpp
																															// files
		Info.TEMPORARY_OUTPUT_DIRECTORY = Info.OUTPUT_DIRECTORY + Info.DIRECTORY_SYMBOL + "OUTPUT";// Contains
																																	// all
																																	// Infered
																																	// java
																																	// files
		Info.IMPORTS_PATH = Info.TEMPORARY_OUTPUT_DIRECTORY + Info.DIRECTORY_SYMBOL +
									"imports.codeinfer.unique";
		Info.WORKING_FILE = Info.TEMPORARY_OUTPUT_DIRECTORY + "/W" + Info.INPUT_FILE_NAME;// This file
																														// will go
																														// to
																														// infer
		
		boolean returnValue = true;
		
		Util.log("Input Directory: " + new File(Info.INPUT_FILE).getParent(), false);
		Util.log("Output Directory: " + Info.OUTPUT_DIRECTORY, false);
		Util.log("File name: " + new File(Info.INPUT_FILE).getName(), true);
		Util.log("Working file name: " + Info.WORKING_FILE, false);
		Util.log("Document root: " + Info.DOCUMENT_ROOT, false);
		Util.log("Operating System: " + Info.OS, false);
		
		Util.log("Calling KeyWords...", false);
		Info.KEYWORDS = KeyWords.getKeyWordsList();
		Util.log("Keyword Listed.", false);
		
		
		File TEMPORARY_PROCESS_DIR = new File(Info.TEMPORARY_TEMP_DIRECTORY);
		
		
		if (!TEMPORARY_PROCESS_DIR.exists())
		{
			if (!TEMPORARY_PROCESS_DIR.mkdirs())
			{
				Util.log("[CODEINFER-MAIN-CCTD]Cannot Create temporary " +
							Info.TEMPORARY_TEMP_DIRECTORY, false);
				returnValue = false;
			}
			
		}
		
		if (Util.createDirectory(Info.OUTPUT_DIRECTORY))
		{
			if (Util.createDirectory(Info.TEMPORARY_OUTPUT_DIRECTORY))
			{
				returnValue = true;
			}
			
		}
		
		Util.SaveFile(Info.IMPORTS_PATH, "", false);    // Empty Up Info.IMPOERTS_PATH
		
		Info.sourcePreprocessor = new SourcePreProcessor(InputDIR);
		StringBuffer sbf = Info.sourcePreprocessor.getSourceCodeBuffer();
		StringBuffer sbfstrR = Info.sourcePreprocessor.stringCapture_Replace(sbf);// it will capture
																											// anad replace all
																											// strings and
																											// return
																											// StringBuffer
		Info.STRINGS_LIST = Info.sourcePreprocessor.getStringTokens();
		Info.sourcePreprocessor.setSourceCodeBuffer(sbfstrR);
		
		Info.sourcePreprocessor.tokenizer();
		
		Info.sourcePreprocessor.setSrcList(DataTypes.rewritePrimitiveDataTypes(DataTypes.processPrimitiveType(Info.sourcePreprocessor.getSrcList())));
		
		Info.sourcePreprocessor.setSourceCodeBuffer(Info.sourcePreprocessor.arrayListToStringBuffer(Info.sourcePreprocessor.getSrcList()));
		
		Info.CPP_SOURCE_SB = Info.sourcePreprocessor.getSourceCodeBuffer();
		
		Util.SaveFile(Info.WORKING_FILE, Util.nullTrimBuffer(Info.CPP_SOURCE_SB), false);
		// Eating all white spaces and save the file to process further
		
		Info.sourcePreprocessor = new SourcePreProcessor(Info.WORKING_FILE);
		// //Info.sourcePreprocessor.createListOf_CPP_Class_Structure_Union_Enum();
		return returnValue;
	}
	
	private static void Infer()
	{
		File fin = new File(InputDIR);
		int i = 0;
		Util.log("Callig SliceFile... " + Info.WORKING_FILE, false);
		SF = new SliceFile(Info.WORKING_FILE);
		Info.SLICED_FILES_NAMES = SlicedFilesNames();
		Info.PARTS = SF.getTotalParts();
		Util.log("Source file Sliced Up.", false);
		
		////////////////// Start /////////////////////////
		
		while (i < SF.getTotalParts())
		{
			Run.SELECTED_FILE_PART_NAME = Info.TEMPORARY_TEMP_DIRECTORY +	Info.DIRECTORY_SYMBOL +
													SliceFile.SLICED_PART_NAME_PREFIX + i + ".cpp";
			Run.SELECTED_FILE_PART_OUTPUT_JAVA = Info.TEMPORARY_OUTPUT_DIRECTORY +
																Info.DIRECTORY_SYMBOL +
																SliceFile.SLICED_PART_NAME_PREFIX + i + ".cpp.java";
			Util.log("\n\nSelected part to resolve `" + Run.SELECTED_FILE_PART_NAME + "`", false);
			Run.run();
			i++;
		}
		
		////////////////// end /////////////////////////
	}
	
	public static void Combine()
	{
		Util.log("Strart combining...", false);
		
		if (Info.PARTS == 0)
		{
			Util.log("Nothing to combine!!!", false);
			return;
		}
		
		String SlicedFilesPathList[] = new String[Info.PARTS + 1];
		
		SlicedFilesPathList[0] = Info.IMPORTS_PATH;
		int i = 1;
		
		while (i < SlicedFilesPathList.length)
		{
			SlicedFilesPathList[i] = Info.TEMPORARY_OUTPUT_DIRECTORY +	Info.DIRECTORY_SYMBOL +
												SliceFile.SLICED_PART_NAME_PREFIX + (i - 1) + ".cpp.java";
			Util.sopln(SlicedFilesPathList[i]);
			i++;
		}
		
		if (Info.GLOBAL_AVAILABLE)
		{
			i--;
			SlicedFilesPathList[i] = Info.GLOBAL_CLASS_FILE;
			Util.sopln(SlicedFilesPathList[i]);
		}
		
		Util.mergeFiles(Info.OUTPUT_FILE_NAME, SlicedFilesPathList);
	}
	
	public static String[] SlicedFilesNames()
	{
		String SlicedFilesPathList[] = new String[SF.getTotalParts()];
		int i = 0;
		
		while (i < SlicedFilesPathList.length)
		{
			SlicedFilesPathList[i] = Info.TEMPORARY_OUTPUT_DIRECTORY +	Info.DIRECTORY_SYMBOL +
												SliceFile.SLICED_PART_NAME_PREFIX + i + ".cpp.java";
			i++;
		}
		
		return SlicedFilesPathList;
	}
	
	private static void ResolveOutlineToInline()
	{
		// CLASS_OutlineToInline COI = new CLASS_OutlineToInline();
		// CLASS_OutlineToInlineNew COI = new CLASS_OutlineToInlineNew();
		// Info.CPP_SOURCE_AR = COI.doOutlineToInline(Info.CPP_SOURCE_AR,
		// Info.sourcePreprocessor.getClassNamesList());
		// Util.SaveFile(Info.WORKING_FILE, Info.CPP_SOURCE_AR, false);
	}
	
	private static void CleanUP()
	{
		File OUT = new File(Info.TEMPORARY_OUTPUT_DIRECTORY);
		String[] OUT_FILE_LIST = OUT.list();
		for (String outputDirs : OUT_FILE_LIST)
		{
			File currentFile = new File(OUT.getPath(), outputDirs);
			Util.log(currentFile.getAbsolutePath() + " file is deleted.", false);
			currentFile.delete();
		}
		
		OUT.deleteOnExit();
		Util.log(OUT.getAbsolutePath() + " dir is deleted.", false);
		
		File TEMP = new File(Info.TEMPORARY_TEMP_DIRECTORY);
		String[] entries1 = TEMP.list();
		for (String s : entries1)
		{
			File currentFile = new File(TEMP.getPath(), s);
			Util.log(currentFile.getAbsolutePath() + " file is deleted.", false);
			currentFile.delete();
		}
		
		TEMP.deleteOnExit();
		Util.log(TEMP.getAbsolutePath() + " dir is deleted.", false);
	}
	
	private static void RestoreStrings()
	{
		Util.show(Info.STRINGS_LIST.toString());
		SourcePreProcessor spp = new SourcePreProcessor(Info.OUTPUT_FILE_NAME);
		String exceptStrings[] = spp	.getSourceCodeBuffer().toString()
												.split(Expression.CODEINFER_STRING_SPLIT);
		String finalCode = new String();
		int i = 0;
		do
		{
			finalCode += exceptStrings[i] + Info.STRINGS_LIST.get(i);
			i++;
		}
		while (i < Info.STRINGS_LIST.size());
		
		finalCode += exceptStrings[i];
		Util.sopln(Util.nullTrimBuffer(new StringBuffer(finalCode)).toString());
		Util.SaveFile(Info.OUTPUT_FILE_NAME, Util.nullTrimBuffer(new StringBuffer(finalCode)), false);
	}
	
}

