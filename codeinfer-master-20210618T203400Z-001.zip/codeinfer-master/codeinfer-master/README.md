codeinfer
=========

C++ to JAVA code converter

`copyright 2013-2019 (c) int soumen`
