#ifndef EH_TACO
#define EH_TACO

#include <antlr3.h>
#include <eif_cecil.h>

EIF_REFERENCE eh_dispose_error_string();
void eh_lexer_displayRecognitionError(pANTLR3_BASE_RECOGNIZER recognizer, pANTLR3_UINT8 * tokenNames);
void eh_parser_displayRecognitionError(pANTLR3_BASE_RECOGNIZER recognizer, pANTLR3_UINT8 * tokenNames);

#endif
