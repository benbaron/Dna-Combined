package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import java.util.Set;
import java.util.TreeSet;

import Autosomal_Segment_Analyzer.CompareUtil;
import Autosomal_Segment_Analyzer.RUMapV3ValuesLine;
import dna.Dna23AndMeReader;
import dna.DnaFrame;
import dna.DnaFrame.ProgressBarStatus;
import dna.Person;
import dna.XBitSet;
import object.DistanceHolder;
import object.DistanceObject;
import object.Node;
import object.Tree;
import tools.Util;

/**
 * class Main
 * 
 * @see <a href=
 * "https://academic.oup.com/bioinformatics/article/33/7/1021/2559429">RentPlus</a>
 * 
 * @author benba
 */

public class Main
{
	public static int NUM_TAXA;
	public static Set<Short> overallSplit;
	public static List<Integer> positions;
	private static int[][] bestRegions;
	private static BitMatrix compatibleMatrix = null;
	// private List<float[][]> distanceMatrices = new ArrayList<float[][]>();
	private static DistanceHolder distanceHolder;
	
	private static Set<Integer> indicesToRemove;
	private static Tree[] guideTrees;
	private static double[] localTreeLengths;
	
	private static Tree[] localTrees;
	private static List<Set<Short>> originalSplits;
	private static String outputName;
	private static XBitSet[] personSiteMatrix;
	
	private static XBitSet root;
	
	/** rows with a unique column i.e. site */
	private static Set<Integer> singletons;
	
	private static float theta;
	private static double[] timeTreeLengths;
	private static float TOTAL_SEQ_LENGTH = 0;
	private static double[] trueTreeLengths;
	
	private static Tree[] trueTrees;
	private static final double UPGMA_RANGE_CHECK = 1;
	private static final double UPGMA_THRESHOLD = 0.2;
	private static int WINDOW_SIZE = 5;
	
	private static final int LEFT = 0;
	private static final int RIGHT = 0;
	private static final int CHNUM_TO_DO = 0;
	/**
	 * constructor Main - Instantiated from main(). This does most of the work
	 * 
	 * @param args - argv.
	 * 
	 * @throws Exception
	 */
	public Main(String args[]) throws Exception
	{
		List<String> argsList = new ArrayList<String>();
		for (int i = 0 ; i < args.length ; i++)
		{
			argsList.add(args[i]);
		}
		
		boolean needHelp = false;
		if (args.length == 0)
		{
			needHelp = true;
		}
		else
		{
			for (int i = 0 ; i < args.length ; i++)
			{
				if (argsList.get(i).contains("-h") || argsList.get(i).contains("-help"))
				{
					needHelp = true;
					break;
				}
				
				if (argsList.get(i).contains("-l"))
				{
					TOTAL_SEQ_LENGTH = Float.valueOf(args[i + 1]);
					argsList.remove(i + 1);
					argsList.remove(i);
					break;
				}
				
			}
			
		}
		
		if (needHelp)
		{
			try
			{
				InputStreamReader in = new InputStreamReader(Util.load("/help.txt"));
				BufferedReader br = new BufferedReader(in);
				String line = br.readLine();
				while (line != null)
				{
					System.out.println(line);
					line = br.readLine();
				}
				
				br.close();
			}
			catch (FileNotFoundException e)
			{
				e.printStackTrace();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
			
			return;
		}
		
		if (argsList.get(0).equals("-t"))
		{
			Util.BRANCH_LENGTH = true;
			argsList.remove(0);
		}
		
		// default - argv[0] is output file name
		outputName = argsList.get(0);
		
		Date startTime = new Date();
		System.out.println("Start Time: " + startTime);
		
		DnaFrame.setProgressBarIndeterminate();
		
		overallSplit = new HashSet<Short>();
		originalSplits = new ArrayList<Set<Short>>();
		singletons = new HashSet<Integer>();
		
		// ------------------------------------
		// read data lines (line 1-n)
		// buildDataFromHapMatrix(argsList.get(0));
		System.out.println("Build Data From Hap Matrix");
		buildDataFromHapMatrix();
		
		NUM_TAXA = personSiteMatrix.length;
		
		distanceHolder = new DistanceHolder(NUM_TAXA);
		
		System.out.println("Initiating TMRCAs");
		for (int i = 0 ; i < personSiteMatrix.length ; i++)
		{
			overallSplit.add((short) (i + 1));
		}
		
		timeTreeLengths = new double[personSiteMatrix[0].length()];
		trueTreeLengths = new double[personSiteMatrix[0].length()];
		localTreeLengths = new double[personSiteMatrix[0].length()];
		
		if (WINDOW_SIZE > personSiteMatrix[0].length())
		{
			WINDOW_SIZE = personSiteMatrix[0].length();
		}
		
		// ---------------------------------------
		// read positions from input file (line 0)
		System.out.println("Reading positions");
		// positions = getPositionArrayFromInputFile(argsList.get(0));
		
		
		positions = getPositionArrayFromInputFile();
		
		// ----------------
		// Calculating theta
		
		float sum = 0;
		for (int i = 1 ; i <= personSiteMatrix.length - 1 ; i++)
		{
			sum += 1.0 / i;
		}
		
		theta = personSiteMatrix[0].length() / sum;
		
		
		// ----------------
		makeDistanceMatrices();
		
		// ----------------
		makeGuideTrees();
		
		distanceHolder = null;
		
		// ----------------
		buildNewRoot();
		
		localTrees = initializeTrees();
		double[] sortedTreeLengths = new double[localTrees.length];
		for (int i = 0 ; i < sortedTreeLengths.length ; i++)
		{
			sortedTreeLengths[i] = timeTreeLengths[i];
		}
		
		bestRegions = new int[localTrees.length][2];
		Arrays.sort(sortedTreeLengths);
		
		// -----------
		// The main method of rules
		buildLocalTrees();
		
		// --------------------
		if (Util.BRANCH_LENGTH)
		{
			inferBranchLengths();
		}
		
		// ----------------
		guideTrees = null;
		Date endTime = new Date();
		if (argsList.size() > 1 && argsList.get(1) != null)
		{
			System.out.println("Reading MS files");
			getTrueTreesFromMsFile(argsList.get(1));
			getDistanceMatricesForTrueTrees();
			compareAllTrees(positions);
			System.out.println("-----------------------");
			outputTreesSeparate(trueTrees, outputName, "True");
		}
		else
		{
			outputInferredTrees(positions);
		}
		
		outputTreesSeparate(localTrees, outputName, "");
		outputTMRCAs(outputName);
		System.out.println(	"Running Time: " +
									(double) (endTime.getTime() - startTime.getTime()) / 1000 + " Seconds");
		
		DnaFrame.unsetProgressBarIndeterminate();
		
		logMemory();
	}
	
	/**
	 * main - calls Main for most of the work
	 * 
	 * @param args input arguments
	 */
	public static void main(String[] args)
	{
		// if (args.length == 0) {
		// String file = "15x20x720x720-ms-1";
		//// String file = "30x20x720x720-ms-1";
		//// String file = "100x20x720x720-ms-1";
		//// String file = "200x20x720x720-ms-1";
		//// String file = "500x20x720x720-ms-1";
		//// String file = "1000x20x720x720-ms-1";
		//
		// String url = "res/" + file + ".dat";
		// String urlMs = "res/" + file + ".trace";
		//
		//// args = new String[] {url};
		// args = new String[] {"-l", "1000000", url, urlMs};
		//// args = new String[] {"-h"};
		//// args = new String[] {"-t", url, urlMs};
		// args = new String[] {"res/example-ms-n15-t15-r10-2.dat"};
		// args = new String[] {"res/test2.txt"};
		// }
		// args = new String[] {"res/seqfile.rentFormat"};
		
		try
		{
			new Main(args);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	/**
	 * reverse a split set
	 * 
	 * @param split : set of short
	 * 
	 * @return reverseSplit set
	 */
	public static Set<Short> reverseSplit(Set<Short> split)
	{
		Set<Short> reverseSplit = new HashSet<Short>();
		for (Short splitNum : overallSplit)
		{
			if (!split.contains(splitNum))
			{
				reverseSplit.add(splitNum);
			}
			
		}
		
		return reverseSplit;
	}
	
	/**
	 * Least Common Ancestor
	 * 
	 * @param root : node
	 * @param a : node
	 * @param b : node
	 * 
	 * @return LCA node
	 */
	public Node LCA(Node root, Node a, Node b)
	{
		if (root == null)
		{
			return null;
		}
		
		// If the root is one of a or b, then it is the LCA
		if (root == a || root == b)
		{
			return root;
		}
		
		List<Node> childrenCheck = new ArrayList<Node>();
		for (Node child : root.getChildren())
		{
			childrenCheck.add(LCA(child, a, b));
		}
		
		List<Node> validNodes = new ArrayList<Node>();
		for (Node node : childrenCheck)
		{
			if (node != null)
			{
				validNodes.add(node);
			}
			
		}
		
		if (validNodes.size() > 1)
		{
			return root;
		}
		else if (validNodes.size() == 0)
		{
			return null;
		}
		else
		{
			return validNodes.get(0);
		}
		
	}
	
	/**
	 * Add Split to tree only
	 * 
	 * @param index 
	 * @param tree tree to add to
	 * @param addedSplit split added (set of short)
	 * 
	 * @return
	 */
	private int addSplitToTreeOnly(int index, Tree tree, Set<Short> addedSplit)
	{
		int counter = 0;
		if (tree.containsSplit(addedSplit) || tree.containsSplit(reverseSplit(addedSplit)))
		{
			return -1;
		}
		else
		{
			Set<Short> bestSplit = new HashSet<Short>();
			if (!isCompatible(addedSplit, tree))
			{
				return -1;
			}
			else
			{
				bestSplit = tree.getBestSplitNode(addedSplit).getSplit();
				Node splitNode = tree.getExactNodeForSplit(bestSplit);
				List<Node> nodesToRemove = new ArrayList<Node>();
				for (Node child : splitNode.getChildren())
				{
					if (addedSplit.containsAll(child.getSplit())) nodesToRemove.add(child);
				}
				
				int capacity = 0;
				for (Node node : nodesToRemove)
				{
					capacity += node.getSplit().size();
				}
				
				Node newNode = new Node(capacity);
				newNode.setParent(splitNode);
				splitNode.getChildren().removeAll(nodesToRemove);
				splitNode.getChildren().add(newNode);
				newNode.getChildren().addAll(nodesToRemove);
				for (Node node : nodesToRemove)
				{
					node.setParent(newNode);
					newNode.addToSplit(node.getSplit());
				}
				
				tree.addNode(newNode);
				tree.addSplit(newNode.getSplit());
				counter++;
			}
			
		}
		
		return counter;
	}
	
	// private float getDistanceOfClusters(List<Short> list, List<Short> list2,
	// int position) {
	// float distance = 0.0F;
	// for (Short i : list) {
	// for (Short j : list2) {
	// distance += distanceHolder.getdistance(i-1, j-1, position);
	// }
	// }
	// return distance/(list.size()*list2.size());
	// }
	
	/**
	 * Add split to tree only old
	 * 
	 * @param index
	 * @param tree
	 * @param addedSplit
	 * 
	 * @return
	 */
	@SuppressWarnings("unused")
	private int addSplitToTreeOnlyOld(int index, Tree tree, Set<Short> addedSplit)
	{
		int counter = 0;
		if (tree.containsSplit(addedSplit) || tree.containsSplit(reverseSplit(addedSplit)))
		{
			return -1;
		}
		else
		{
			Set<Short> bestSplit = new HashSet<Short>();
			bestSplit = tree.getRoot().getSplit();
			boolean compatible = true;
			
			// checking compatibility of the split
			for (Set<Short> split : tree.getSplits())
			{
				if (split.size() < addedSplit.size())
				{
					List<Short> copyList = new ArrayList<Short>();
					copyList.addAll(split);
					copyList.retainAll(addedSplit);
					if (copyList.size() > 0 && copyList.size() < split.size())
					{
						compatible = false;
						break;
					}
					
				}
				else
				{
					List<Short> copyList = new ArrayList<Short>();
					copyList.addAll(split);
					copyList.retainAll(addedSplit);
					if (0 < copyList.size() && copyList.size() < addedSplit.size())
					{
						compatible = false;
						break;
					}
					else if (copyList.size() == addedSplit.size())
					{
						if (split.size() < bestSplit.size())
						{
							bestSplit = split;
						}
						
					}
					
				}
				
			}
			
			if (compatible)
			{
				Node splitNode = tree.getExactNodeForSplit(bestSplit);
				List<Node> nodesToRemove = new ArrayList<Node>();
				for (Node child : splitNode.getChildren())
				{
					if (addedSplit.containsAll(child.getSplit())) nodesToRemove.add(child);
				}
				
				int capacity = 0;
				for (Node node : nodesToRemove)
				{
					capacity += node.getSplit().size();
				}
				
				Node newNode = new Node(capacity);
				newNode.setParent(splitNode);
				splitNode.getChildren().removeAll(nodesToRemove);
				splitNode.getChildren().add(newNode);
				newNode.getChildren().addAll(nodesToRemove);
				for (Node node : nodesToRemove)
				{
					node.setParent(newNode);
					newNode.addToSplit(node.getSplit());
				}
				
				tree.addNode(newNode);
				tree.addSplit(newNode.getSplit());
				counter++;
			}
			else
			{
				return -1;
			}
			
		}
		
		return counter;
	}
	
	/**
	 * Add Split to tree
	 * 
	 * @param index
	 * @param tree
	 * @param addedSplit
	 * @param propagate
	 * @param eligibilityCheck
	 * @param normalPropagation
	 * 
	 * @return
	 */
	private int addSplitToTree(int index, Tree tree, Set<Short> addedSplit, boolean propagate,
				boolean eligibilityCheck, boolean normalPropagation)
	{
		int counter = 0;
		if (tree.containsSplit(addedSplit) || tree.containsSplit(reverseSplit(addedSplit)))
		{
			return -1;
		}
		else
		{
			if (!isCompatible(addedSplit, tree))
			{
				return -1;
			}
			else
			{
				Set<Short> bestSplit = tree.getBestSplitNode(addedSplit).getSplit();
				boolean valid = true;
				if (eligibilityCheck)
				{
					valid = isTimeEligible(index, tree, addedSplit);
				}
				
				if (valid)
				{
					Node splitNode = tree.getExactNodeForSplit(bestSplit);
					List<Node> nodesToRemove = new ArrayList<Node>();
					for (Node child : splitNode.getChildren())
					{
						if (addedSplit.containsAll(child.getSplit())) nodesToRemove.add(child);
					}
					
					int capacity = 0;
					for (Node node : nodesToRemove)
					{
						capacity += node.getSplit().size();
					}
					
					Node newNode = new Node(capacity);
					newNode.setParent(splitNode);
					splitNode.getChildren().removeAll(nodesToRemove);
					splitNode.getChildren().add(newNode);
					newNode.getChildren().addAll(nodesToRemove);
					for (Node node : nodesToRemove)
					{
						node.setParent(newNode);
						newNode.addToSplit(node.getSplit());
					}
					
					tree.addNode(newNode);
					tree.addSplit(newNode.getSplit());
					counter++;
					if (propagate)
					{
						if (normalPropagation)
						{
							counter += propagateSplit(index, addedSplit);
						}
						else
						{
							counter += propagateSplitHeight(index, addedSplit);
						}
						
					}
					
				}
				
			}
			
		}
		
		return counter;
	}
	
	/**
	 * Add Split to tree old
	 * 
	 * @param index
	 * @param tree
	 * @param addedSplit
	 * @param propagate
	 * @param eligibilityCheck
	 * @param normalPropagation
	 * 
	 * @return
	 */
	private int addSplitToTreeOld(int index, Tree tree, Set<Short> addedSplit, boolean propagate,
				boolean eligibilityCheck, boolean normalPropagation)
	{
		int counter = 0;
		if (tree.containsSplit(addedSplit) || tree.containsSplit(reverseSplit(addedSplit)))
		{
			return -1;
		}
		else
		{
			Set<Short> bestSplit = new HashSet<Short>();
			bestSplit = tree.getRoot().getSplit();
			boolean compatible = true;
			// checking compatibility of the split
			for (Set<Short> split : tree.getSplits())
			{
				if (split.size() < addedSplit.size())
				{
					List<Short> copyList = new ArrayList<Short>();
					copyList.addAll(split);
					copyList.retainAll(addedSplit);
					if (copyList.size() > 0 && copyList.size() < split.size())
					{
						compatible = false;
						break;
					}
					
				}
				else
				{
					List<Short> copyList = new ArrayList<Short>();
					copyList.addAll(split);
					copyList.retainAll(addedSplit);
					if (0 < copyList.size() && copyList.size() < addedSplit.size())
					{
						compatible = false;
						break;
					}
					else if (copyList.size() == addedSplit.size())
					{
						if (split.size() < bestSplit.size())
						{
							bestSplit = split;
						}
						
					}
					
				}
				
			}
			
			if (compatible)
			{
				boolean valid = true;
				if (eligibilityCheck)
				{
					valid = isTimeEligible(index, tree, addedSplit);
				}
				
				if (valid)
				{
					Node splitNode = tree.getExactNodeForSplit(bestSplit);
					List<Node> nodesToRemove = new ArrayList<Node>();
					for (Node child : splitNode.getChildren())
					{
						if (addedSplit.containsAll(child.getSplit())) nodesToRemove.add(child);
					}
					
					int capacity = 0;
					for (Node node : nodesToRemove)
					{
						capacity += node.getSplit().size();
					}
					
					Node newNode = new Node(capacity);
					newNode.setParent(splitNode);
					splitNode.getChildren().removeAll(nodesToRemove);
					splitNode.getChildren().add(newNode);
					newNode.getChildren().addAll(nodesToRemove);
					for (Node node : nodesToRemove)
					{
						node.setParent(newNode);
						newNode.addToSplit(node.getSplit());
					}
					
					tree.addNode(newNode);
					tree.addSplit(newNode.getSplit());
					counter++;
					if (propagate)
					{
						if (normalPropagation)
						{
							counter += propagateSplit(index, addedSplit);
						}
						else
						{
							counter += propagateSplitHeight(index, addedSplit);
						}
						
					}
					
				}
				
			}
			
		}
		
		return counter;
	}
	
	
	/**
	 * Parse Matches into the personSiteMatrix - all lines after the first
	 */
	private void buildDataFromHapMatrix()
	{
		System.out.println("build data from hap matrix");
		
		// here each element of the array is a row.
		indicesToRemove = new HashSet<Integer>();
		
		Set<Entry<String, Person>> recs = Dna23AndMeReader.getPersonMap().entrySet();
		
		int rowsize = recs.size();
		
		// personSiteMatrix (array) of [rows][columns]
		personSiteMatrix = new XBitSet[rowsize];
		
		for (int row = 0 ; row < rowsize ; row++)
		{
			personSiteMatrix[row] = new XBitSet();
		}
		
		System.out.println("do person records hap matrix");
		int row = 0;
		// For each Person record
		for (Map.Entry<String, Person> entry : Dna23AndMeReader.getPersonMap().entrySet())
		{
			Person p = entry.getValue();
			
			System.out.print(".");
			
			
			XBitSet mb = p.matchBits.get(CHNUM_TO_DO);
			
			try
			{
				personSiteMatrix[row] = mb;
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
			// pbs1.barDone();
			row++;
		}
		
		System.out.println("");
		
		// DnaFrame.ProgressBarStatus pbs1 = new DnaFrame.ProgressBarStatus(23);
		// pbs1.barDone();
		
		System.out.println("build personSiteMatrix");
		try
		{
			root = buildRoot(personSiteMatrix);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		System.out.println("Done building personSiteMatrix");
	}
	
	/**
	 * Parse input file into the personSiteMatrix - all lines after the first
	 * 
	 * @param url : file source - path string, not literally a url
	 * 
	 * @throws Exception
	 */
	private void buildDataFromHapMatrix(String url) throws Exception
	{
		System.out.println("Reading Hap Matrix from input file");
		try
		{
			List<String> rows = null;
			rows = readHapFileLines(url);
			
			// here each element of the array is a row.
			indicesToRemove = new HashSet<Integer>();
			
			// for each char in a row, assuming all rows are the
			// length of the first row.
			for (int column = 0 ; column < rows.get(0).length() ; column++)
			{
				// for the first row, scan each char
				char firstRowCharI = rows.get(0).charAt(column);
				boolean hasInfo = false;
				
				// for each row 1-n
				for (int row = 1 ; row < rows.size() ; row++)
				{
					// if j-th row, i-th char !=
					// 1st row, ith char the column 'hasInfo'
					// in other words, compress out any column that
					// has no variation.
					if (firstRowCharI != rows.get(row).charAt(column))
					{
						hasInfo = true;
					}
					
				}
				
				// If all data same in this column,
				// remove this column
				if (!hasInfo)
				{
					indicesToRemove.add(column);
				}
				
			} // for each column
			
			this.indicesToRemove = indicesToRemove;
			List<StringBuilder> builders = new ArrayList<StringBuilder>();
			
			// for all rows, including 0th
			for (int row = 0 ; row < rows.size() ; row++)
			{
				builders.add(new StringBuilder());
			}
			
			// for 0th row.
			for (int column = 0 ; column < rows.get(0).length() ; column++)
			{
				// remove unnecessary distance figures.
				if (!indicesToRemove.contains(column))
				{
					for (int j = 0 ; j < builders.size() ; j++)
					{
						builders.get(j).append(rows.get(j).charAt(column));
					}
					
				}
				
			}
			
			// dust the existing rows
			rows.clear();
			
			// refill the rows list (why don't we just use a different variable
			// here?)
			for (int idx = 0 ; idx < builders.size() ; idx++)
			{
				rows.add(builders.get(idx).toString());
			}
			
			// personSiteMatrix (array) of [rows][columns]
			personSiteMatrix = new XBitSet[rows.size()];
			for (int row = 0 ; row < personSiteMatrix.length ; row++)
			{
				for (int column = 0 ; column < personSiteMatrix[0].length() ; column++)
				{
					int v = Integer.valueOf(rows.get(row).substring(column, column + 1));
					personSiteMatrix[row].assign(column, v);
				}
				
			}
			
			root = buildRoot(personSiteMatrix);
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
	}
	
	/**
	 * @param url
	 * 
	 * @return
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private List<String> readHapFileLines(String url) throws FileNotFoundException, IOException
	{
		// reading input file saving as samples
		FileInputStream fis = new FileInputStream(url);
		InputStreamReader reader = new InputStreamReader(fis);
		BufferedReader br = new BufferedReader(reader);
		
		String line = br.readLine(); // read line 0 (and toss it)
		
		List<String> rows = new ArrayList<String>();
		
		line = br.readLine(); // read line 1
		
		// fill rows from strings
		while (line != null && !line.isEmpty())
		{
			rows.add(line);
			line = br.readLine();
		}
		
		br.close();
		return rows;
	}
	
	/**
	 * Build a map of distance to root for the input tree
	 * 
	 * @param tree : tree to map
	 * 
	 * @return map<Node, Double> of distances
	 */
	private Map<Node, Double> buildDistanceToRootMap(Tree tree)
	{
		Map<Node, Double> distanceToRootMap = new HashMap<Node, Double>();
		for (Node node : tree.getNodes())
		{
			calculatedDistance(distanceToRootMap, node);
		}
		
		return distanceToRootMap;
	}
	
	// private void scaleTimes(double[] times) {
	// double avg = 0;
	// for (double d : times) {
	// avg += d;
	// }
	// avg = avg/times.length;
	// double multiplier = 2/avg;
	// for (int i = 0; i < times.length; i++) {
	// times[i] = times[i]*multiplier;
	// }
	// }
	
	/**
	 * Build Local Trees
	 * 
	 * @return Array of trees
	 */
	private Tree[] buildLocalTrees()
	{
		fullyCompatibleWithCheckNew();
		fullyCompatibleRegionRuleNew();
		timeSplitOverrideRule();
		propagationRuleNew();
		propagationHeightRule();
		propagationRule();
		guideTreeSplitsRule();
		propagationRule();
		RefineNonBinaryNodes();
		
		return localTrees;
	}
	
	/**
	 * Build new root
	 * 
	 * @throws Exception
	 */
	private void buildNewRoot() throws Exception
	{
		System.out.println("Assigning Local Tree roots");
		
		for (int j = 0 ; j < personSiteMatrix[0].length() ; j++)
		{
			Tree timeTree = guideTrees[j];
			Set<Short> zeroSplit = new HashSet<Short>();
			Set<Short> oneSplit = new HashSet<Short>();
			zeroSplit.addAll(reverseSplit(originalSplits.get(j)));
			oneSplit.addAll(originalSplits.get(j));
			
			Node zeroNode = timeTree.getBestSplitNode(zeroSplit);
			Node oneNode = timeTree.getBestSplitNode(oneSplit);
			double zeroHeight = zeroNode	.getChildren()
													.isEmpty() ?	Double.valueOf(zeroNode.getBranchLength()) :
																	Double.valueOf(zeroNode.getInfo());
			double oneHeight = oneNode	.getChildren()
												.isEmpty() ?	Double.valueOf(oneNode.getBranchLength()) :
																Double.valueOf(oneNode.getInfo());
			if (zeroHeight > oneHeight)
			{
				root.assign(j, 0);
			}
			else
			{
				root.assign(j, 1);
			}
			
		}
		
	}
	
	/**
	 * Build root
	 * 
	 * @param input personSiteMatrix
	 * 
	 * @return root array
	 * 
	 * @throws Exception
	 */
	private XBitSet buildRoot(XBitSet[] personSiteMatrix2) throws Exception
	{
		XBitSet root = new XBitSet();
		System.out.println(" buildRoot matrix ");
		
		ProgressBarStatus.setProgressBarStatus(personSiteMatrix2[0].length());
		
		for (int column = 0 ; column < personSiteMatrix2[0].length() ; column++)
		{
			ProgressBarStatus.barNextCount();
			
			int zeroCounter = 0;
			int oneCounter = 0;
			int zeroValue = 0;
			int oneValue = 0;
			
			Set<Short> originalSplit = new HashSet<Short>();
			
			for (int row = 0 ; row < personSiteMatrix2.length ; row++)
			{
				if (personSiteMatrix2[row].getInt(column) == 0)
				{
					zeroCounter++;
					zeroValue = column + 1; // BEN
				}
				else
				{
					originalSplit.add((short) (row + 1));
					
					oneCounter++;
					oneValue = column + 1; // BEN
				}
				
			}
			
			// if only 1 row had the column mentioned,
			// this is a singleton
			if (zeroCounter == 1 || oneCounter == 1)
			{
				originalSplits.add(new HashSet<Short>());
				// add this column to the list of singleton columns
				singletons.add(zeroCounter == 1 ? zeroValue : oneValue);
			}
			else
			{
				originalSplits.add(originalSplit);
				// singletons.add(0);
			}
			
			if (oneCounter > zeroCounter)
			{
				root.assign(column, 1);
			}
			
		}
		
		ProgressBarStatus.barDone();
		System.out.println(" buildRoot done ");
		return root;
	}
	
	/**
	 * Calculated distance
	 * 
	 * @param distanceToRootMap
	 * @param node
	 */
	private void calculatedDistance(Map<Node, Double> distanceToRootMap, Node node)
	{
		if (distanceToRootMap.get(node) != null) return;
		if (distanceToRootMap.get(node.getParent()) == null)
		{
			if (node.getParent() == null)
			{
				// node is root
				distanceToRootMap.put(node, 0.0);
				return;
			}
			else
			{
				calculatedDistance(distanceToRootMap, node.getParent());
			}
			
		}
		
		distanceToRootMap.put(node, Double.valueOf(node.getBranchLength()) +
												distanceToRootMap.get(node.getParent()));
	}
	
	/**
	 * compareAllTrees
	 * 
	 * @param positions2 - list of integers
	 */
	private void compareAllTrees(List<Integer> positions2)
	{
		int numTotalSplits = 0;
		int numTotalInfered = 0;
		int numTimeSplits = 0;
		int numArgSplits = 0;
		int numMargSplits = 0;
		int numSharedSplits = 0;
		int counter = 0;
		int notShareCounter = 0;
		
		int numInferedSplits = 0;
		for (int i = 0 ; i < localTrees.length ; i++)
		{
			// Tree timeTree = timeTrees[i];
			
			Tree localTree = localTrees[i];
			Tree trueTree = trueTrees[i];
			Set<Set<Short>> realTrueSplits = new HashSet<Set<Short>>();
			Set<Set<Short>> realTimeSplits = new HashSet<Set<Short>>();
			Set<Set<Short>> realLocalSplits = new HashSet<Set<Short>>();
			Set<Set<Short>> realArgSplits = new HashSet<Set<Short>>();
			Set<Set<Short>> realMargSplits = new HashSet<Set<Short>>();
			for (Set<Short> split : trueTree.getSplits())
			{
				if (1 < split.size() && split.size() < trueTree.getRoot().getSplit().size() - 1 &&
						!realTrueSplits.contains(reverseSplit(split)))
				{
					realTrueSplits.add(split);
				}
				
			}
			
			numTotalSplits += realTrueSplits.size();
			for (Set<Short> split : localTree.getSplits())
			{
				if (1 < split.size() && split.size() < overallSplit.size() - 1 &&
						!realLocalSplits.contains(reverseSplit(split)))
				{
					realLocalSplits.add(split);
				}
				
			}
			
			numTotalInfered += realLocalSplits.size();
			
			// for (Set<Short> split : timeTree.getSplits()) {
			// if (1 < split.size()
			// && split.size() < timeTree.getRoot().getSplit().size() - 1
			// && !realTimeSplits.contains(reverseSplit(split))) {
			// realTimeSplits.add(split);
			// }
			// }
			
			Set<Set<Short>> tmpLocalSplit = new HashSet<Set<Short>>();
			Set<Set<Short>> tmpTimeSplit = new HashSet<Set<Short>>();
			Set<Set<Short>> tmpArgSplit = new HashSet<Set<Short>>();
			Set<Set<Short>> tmpMargSplit = new HashSet<Set<Short>>();
			for (Set<Short> set : realLocalSplits)
			{
				if (realTrueSplits.contains(set) || realTrueSplits.contains(reverseSplit(set)))
				{
					tmpLocalSplit.add(set);
				}
				
			}
			
			for (Set<Short> set : realTimeSplits)
			{
				if (realTrueSplits.contains(set) || realTrueSplits.contains(reverseSplit(set)))
				{
					tmpTimeSplit.add(set);
				}
				
			}
			
			for (Set<Short> set : realArgSplits)
			{
				if (realTrueSplits.contains(set) || realTrueSplits.contains(reverseSplit(set)))
				{
					tmpArgSplit.add(set);
				}
				
			}
			
			for (Set<Short> set : realMargSplits)
			{
				if (realTrueSplits.contains(set) || realTrueSplits.contains(reverseSplit(set)))
				{
					tmpMargSplit.add(set);
				}
				
			}
			
			Set<Set<Short>> sharedSplits = new HashSet<Set<Short>>();
			for (Set<Short> set : tmpTimeSplit)
			{
				if (tmpLocalSplit.contains(set) || tmpLocalSplit.contains(reverseSplit(set)))
				{
					sharedSplits.add(set);
				}
				
			}
			
			numInferedSplits += tmpLocalSplit.size();
			numTimeSplits += tmpTimeSplit.size();
			numArgSplits += tmpArgSplit.size();
			numMargSplits += tmpMargSplit.size();
			numSharedSplits += sharedSplits.size();
			
			String split = originalSplits.get(i).isEmpty() ?	getSingleMutation(i) :
																			originalSplits.get(i).toString();
			System.out.println(	"(1)At index " +	(i) + ", " + tmpLocalSplit.size() + " (Inf), and " +
										tmpTimeSplit.size() + " (time)" + " of " + realTrueSplits.size() +
										" total splits are inferred.  Shared: " + sharedSplits.size() +
										" ---  Inferred Tree: " + localTree.toString() + " [" +
										localTreeLengths[i] + "]"
										
										// + " UPGMA Tree: " + timeTree.toString() + " ["
										// + timeTreeLengths[i]+ "]"
										
										+ "  True Tree: " + trueTree + " [" + trueTreeLengths[i] + "]"
										
										// + " Best Compatible Region: [" +
										// bestRegions[i][0] + ","
										// + bestRegions[i][RIGHT] + "]"
										
										+ " {" + positions2.get(i) + "}" + " Original Split: " + split);
			if (tmpLocalSplit.size() < tmpTimeSplit.size())
			{
				counter += tmpTimeSplit.size() - tmpLocalSplit.size();
			}
			
			if (sharedSplits.size() < tmpTimeSplit.size() &&
					sharedSplits.size() < tmpLocalSplit.size())
			{
				notShareCounter += tmpTimeSplit.size()
											<= sharedSplits.size() ? tmpTimeSplit.size() - sharedSplits.size() : tmpLocalSplit.size() - sharedSplits.size();
			}
			
		}
		
		System.out.println(	"Inferred: " + numInferedSplits + " out of " + numTotalSplits +
									" splits = %" +
									(double) numInferedSplits * 100.0 / (double) numTotalSplits);
		// System.out.println("Time: " + numTimeSplits + " out of "
		// + numTotalSplits + " splits = %" + (double) numTimeSplits
		// * 100.0 / (double) numTotalSplits);
	}
	
	/**
	 * compareAllTreesRooted
	 * 
	 * @param positions
	 */
	private void compareAllTreesRooted(List<Integer> positions)
	{
		int numTotalClades = 0;
		int numTotalInfered = 0;
		int numInferedSplits = 0;
		int numTimeSplits = 0;
		int numSharedSplits = 0;
		int counter = 0;
		int notShareCounter = 0;
		for (int i = 0 ; i < localTrees.length ; i++)
		{
			Tree localTree = localTrees[i];
			Tree timeTree = guideTrees[i];
			Tree trueTree = trueTrees[i];
			Set<Set<Short>> realTrueClades = new HashSet<Set<Short>>();
			Set<Set<Short>> realTimeClades = new HashSet<Set<Short>>();
			Set<Set<Short>> realLocalClades = new HashSet<Set<Short>>();
			for (Set<Short> clade : trueTree.getClades())
			{
				if (1 < clade.size())
				{
					realTrueClades.add(clade);
				}
				
			}
			
			numTotalClades += realTrueClades.size();
			for (Set<Short> clade : localTree.getClades())
			{
				if (1 < clade.size())
				{
					realLocalClades.add(clade);
				}
				
			}
			
			numTotalInfered += realLocalClades.size();
			for (Set<Short> clade : timeTree.getClades())
			{
				if (1 < clade.size())
				{
					realTimeClades.add(clade);
				}
				
			}
			
			Set<Set<Short>> tmpLocalClades = new HashSet<Set<Short>>();
			Set<Set<Short>> tmpTimeClades = new HashSet<Set<Short>>();
			for (Set<Short> set : realLocalClades)
			{
				if (realTrueClades.contains(set))
				{
					tmpLocalClades.add(set);
				}
				
			}
			
			for (Set<Short> set : realTimeClades)
			{
				if (realTrueClades.contains(set))
				{
					tmpTimeClades.add(set);
				}
				
			}
			
			Set<Set<Short>> sharedClades = new HashSet<Set<Short>>();
			for (Set<Short> set : tmpTimeClades)
			{
				if (tmpLocalClades.contains(set))
				{
					sharedClades.add(set);
				}
				
			}
			
			numInferedSplits += tmpLocalClades.size();
			numTimeSplits += tmpTimeClades.size();
			numSharedSplits += sharedClades.size();
			String split = originalSplits.get(i).isEmpty() ?	getSingleMutation(i) :
																			originalSplits.get(i).toString();
			System.out.println(	"(2)At index " +	(i) + ", " + tmpLocalClades.size() + " (Inf), and " +
										tmpTimeClades.size() + " (time)" + " of " + realTrueClades.size() +
										" total clades are inferred.  Shared: " + sharedClades.size() +
										" ---  Inferred Tree: " + localTree.toString() + " [" +
										localTreeLengths[i] + "]"
										// + " UPGMA Tree: " + timeTree.toString() + " ["
										// + timeTreeLengths[i]+ "]"
										+ "  True Tree: " + trueTree + " [" + trueTreeLengths[i] + "]" +
										" {" + positions.get(i) + "}" + " Original Split: " + split);
			if (tmpLocalClades.size() < tmpTimeClades.size())
			{
				counter += tmpTimeClades.size() - tmpLocalClades.size();
			}
			
			if (sharedClades.size() < tmpTimeClades.size() &&
					sharedClades.size() < tmpLocalClades.size())
			{
				notShareCounter += tmpTimeClades.size()
											<= sharedClades.size() ? tmpTimeClades.size() - sharedClades.size() : tmpLocalClades.size() - sharedClades.size();
			}
			
		}
		
		System.out.println(	"Inf: " +	numInferedSplits + " out of " + numTotalClades + " clades = %" +
									(double) numInferedSplits * 100.0 / (double) numTotalClades);
		// System.out.println("Time: " + numTimeSplits + " out of "
		// + numTotalClades + " clades = %" + (double) numTimeSplits
		// * 100.0 / (double) numTotalClades);
	}
	
	/**
	 * 
	 * @param validNodesToContactMap
	 * @param clusters
	 * @param i
	 * 
	 * @return
	 */
	private LinkedHashMap<Set<Node>, Float> findBestPairs(
				Map<Set<Node>, Float> validNodesToContactMap, HashMap<Node, List<Short>> clusters,
				int i)
	{
		int index = 1;
		LinkedHashMap<Set<Node>, Float> sortedMap = new LinkedHashMap<Set<Node>, Float>();
		while (validNodesToContactMap.size()	> 1 &&
					(i + index < positions.size() || i - index >= 0) &&
					index < UPGMA_RANGE_CHECK * positions.size())
		{
			List<Set<Node>> iterationList = new ArrayList<Set<Node>>();
			iterationList.addAll(validNodesToContactMap.keySet());
			for (Set<Node> set : iterationList)
			{
				Set<Short> combinedSplit = new HashSet<Short>();
				for (Node node : set)
				{
					combinedSplit.addAll(clusters.get(node));
				}
				
				List<Node> nodes = new ArrayList<Node>();
				nodes.addAll(set);
				if (i - index >= 0 && !isCompatible(originalSplits.get(i - index), combinedSplit))
				{
					sortedMap.put(set, validNodesToContactMap.get(set));
					validNodesToContactMap.remove(set);
					if (validNodesToContactMap.size() == 1)
					{
						break;
					}
					
				}
				else if (i +	index <= positions.size() - 1 &&
							!isCompatible(originalSplits.get(i + index), combinedSplit))
				{
					sortedMap.put(set, validNodesToContactMap.get(set));
					validNodesToContactMap.remove(set);
					if (validNodesToContactMap.size() == 1)
					{
						break;
					}
					
				}
				
			}
			
			index++;
		}
		
		if (validNodesToContactMap.size() > 1)
		{
			Set<Entry<Set<Node>, Float>> entryList = new TreeSet<
						Entry<Set<Node>, Float>>(new Comparator<Entry<Set<Node>, Float>>()
						{
							@Override
							public int compare(Entry<Set<Node>, Float> o1, Entry<Set<Node>, Float> o2)
							{
								if (o1.getValue().equals(o2.getValue()))
								{
									return 1;
								}
								else
								{
									return o2.getValue().compareTo(o1.getValue());
								}
								
							}
							
						});
			entryList.addAll(validNodesToContactMap.entrySet());
			for (Entry<Set<Node>, Float> entry : entryList)
			{
				sortedMap.put(entry.getKey(), entry.getValue());
			}
			
		}
		else
		{
			sortedMap.putAll(validNodesToContactMap);
		}
		
		return sortedMap;
	}
	
	/**
	 * 
	 * @param nodes
	 * @param clusters
	 * @param i
	 * 
	 * @return
	 */
	private Short findCompatibleDistance(Node[] nodes, HashMap<Node, List<Short>> clusters, int i)
	{
		int index = 1;
		short counter = 0;
		Set<Short> combinedSplit = new HashSet<Short>();
		for (Node node : nodes)
		{
			combinedSplit.addAll(clusters.get(node));
		}
		
		while ((i + index < positions.size() || i - index >= 0) &&
					index < UPGMA_RANGE_CHECK * positions.size())
		{
			if (i - index >= 0 && isCompatible(originalSplits.get(i - index), combinedSplit))
			{
				counter++;
			}
			// else{
			// break;
			// }
			else if (i - index >= 0)
			{
				break;
			}
			
			if (i +	index <= positions.size() - 1 &&
					isCompatible(originalSplits.get(i + index), combinedSplit))
			{
				counter++;
			}
			// else{
			// break;
			// }
			else if (i + index <= positions.size() - 1)
			{
				break;
			}
			
			index++;
		}
		
		return counter;
	}
	
	/**
	 * 
	 * @param nodes
	 * @param combinedSplit
	 * @param i
	 * 
	 * @return
	 */
	private short[] findCompatibleRegion(Node[] nodes, Set<Short> combinedSplit, int i)
	{
		int index = 1;
		short minIndex = (short) i;
		short maxIndex = (short) i;
		while (i - index >= 0 && index < UPGMA_RANGE_CHECK * positions.size())
		{
			if (i - index >= 0 && isCompatible(originalSplits.get(i - index), combinedSplit))
			{
				minIndex = (short) (i - index);
			}
			else
			{
				break;
			}
			
			index++;
		}
		
		index = 1;
		while (i + index < positions.size() && index < UPGMA_RANGE_CHECK * positions.size())
		{
			if (i +	index <= positions.size() - 1 &&
					isCompatible(originalSplits.get(i + index), combinedSplit))
			{
				maxIndex = (short) (i + index);
			}
			else
			{
				break;
			}
			
			index++;
		}
		
		return new short[]{minIndex, maxIndex};
	}
	
	/**
	 * 
	 */
	private void fullyCompatibleRegionRuleNew()
	{
		System.out.print("Fully Compatible Rule");
		Date startDate = new Date();
		List<Set<Set<Short>>> splitsToAdd = new ArrayList<Set<Set<Short>>>();
		for (int positionNum = 0 ; positionNum < localTrees.length ; positionNum++)
		{
			// finding the best region that fits the index
			
			int[] bestRegion = new int[2];
			
			bestRegion[LEFT] = positionNum;
			bestRegion[RIGHT] = positionNum;
			int r = 1;
			boolean compatible = true;
			while (compatible)
			{
				if (positionNum + r < positions.size())
				{
					for (int j = bestRegion[LEFT] ; j <= bestRegion[RIGHT] ; j++)
					{
						if (!compatibleMatrix.get(j, positionNum + r))
						{
							compatible = false;
							break;
						}
						
					}
					
					if (compatible)
					{
						bestRegion[RIGHT]++;
					}
					
				}
				else
				{
					compatible = false;
				}
				
				if (positionNum - r >= 0)
				{
					for (int j = bestRegion[LEFT] ; j <= bestRegion[RIGHT] ; j++)
					{
						if (!compatibleMatrix.get(positionNum - r, j))
						{
							compatible = false;
							break;
						}
						
					}
					
					if (compatible)
					{
						bestRegion[LEFT]--;
					}
					
				}
				else
				{
					compatible = false;
				}
				
				r++;
			}
			
			// finding splits to add
			Set<Set<Short>> splitSet = new LinkedHashSet<Set<Short>>();
			int index = 0;
			if (positionNum - bestRegion[LEFT] > bestRegion[RIGHT] - positionNum)
			{
				index = positionNum - bestRegion[LEFT];
			}
			else
			{
				index = bestRegion[RIGHT] - positionNum;
			}
			
			for (int j = 1 ; j <= index ; j++)
			{
				Set<Set<Short>> prevSplitSet = new LinkedHashSet<Set<Short>>();
				if (bestRegion[LEFT] <= positionNum - j && positionNum - j >= 0)
				{
					Set<Set<Short>> splits = localTrees[positionNum - j].getSplits();
					prevSplitSet.addAll(splits);
				}
				
				if (positionNum + j <= bestRegion[RIGHT] && positionNum - j < root.length())
				{
					Set<Set<Short>> splits = localTrees[positionNum + j].getSplits();
					Set<Set<Short>> splitsToRemove = new LinkedHashSet<Set<Short>>();
					Set<Set<Short>> addedSplits = new LinkedHashSet<Set<Short>>();
					for (Set<Short> split : splits)
					{
						if (prevSplitSet.isEmpty())
						{
							splitSet.addAll(splits);
							break;
						}
						
						for (Set<Short> prevSplit : prevSplitSet)
						{
							if (!isCompatible(split, prevSplit))
							{
								if (isCompatible(split, localTrees[positionNum]) &&
										isCompatible(split, guideTrees[positionNum]))
								{
									addedSplits.add(split);
									splitsToRemove.add(prevSplit);
								}
								
							}
							
						}
						
					}
					
					prevSplitSet.removeAll(splitsToRemove);
					prevSplitSet.addAll(addedSplits);
					prevSplitSet.addAll(splits);
				}
				
				splitSet.addAll(prevSplitSet);
			}
			
			splitsToAdd.add(splitSet);
			bestRegions[positionNum] = bestRegion;
		}
		
		int counter = 0;
		for (int i = 0 ; i < splitsToAdd.size() ; i++)
		{
			Set<Set<Short>> splitSet = splitsToAdd.get(i);
			for (Set<Short> split : splitSet)
			{
				counter += addSplitToTree(i, localTrees[i], split, false, true, false);
			}
			
		}
		
		System.out.println(	" [" +	(double) (new Date().getTime() - startDate.getTime()) / 1000 +
									" Seconds] ");
		// System.out.println("(" + counter + ")");
	}
	
	/**
	 * 
	 */
	private void fullyCompatibleWithCheckNew()
	{
		System.out.print("Fully Compatible Rule using Guide Trees");
		Date startDate = new Date();
		initiateCompatibleMatrix();
		List<Set<Set<Short>>> splitsToAdd = new ArrayList<Set<Set<Short>>>();
		for (int i = 0 ; i < localTrees.length ; i++)
		{
			// finding the best region that fits the index
			int[] bestRegion = new int[2];
			bestRegion[LEFT] = i;
			bestRegion[RIGHT] = i;
			int r = 1;
			boolean compatible = true;
			while (compatible)
			{
				if (i + r < positions.size())
				{
					for (int j = bestRegion[LEFT] ; j <= bestRegion[RIGHT] ; j++)
					{
						if (!compatibleMatrix.get(j, i + r))
						{
							compatible = false;
							break;
						}
						
					}
					
					if (compatible)
					{
						bestRegion[RIGHT]++;
					}
					
				}
				else
				{
					compatible = false;
				}
				
				if (i - r >= 0)
				{
					for (int j = bestRegion[LEFT] ; j <= bestRegion[RIGHT] ; j++)
					{
						if (!compatibleMatrix.get(i - r, j))
						{
							compatible = false;
							break;
						}
						
					}
					
					if (compatible)
					{
						bestRegion[LEFT]--;
					}
					
				}
				else
				{
					compatible = false;
				}
				
				r++;
			}
			
			// finding splits to add
			Set<Set<Short>> splitSet = new LinkedHashSet<Set<Short>>();
			int index = 0;
			if (i - bestRegion[LEFT] > bestRegion[RIGHT] - i)
			{
				index = i - bestRegion[LEFT];
			}
			else
			{
				index = bestRegion[RIGHT] - i;
			}
			
			for (int j = 1 ; j <= index ; j++)
			{
				Set<Set<Short>> prevSplitSet = new LinkedHashSet<Set<Short>>();
				if (bestRegion[LEFT] <= i - j && i - j >= 0)
				{
					Set<Set<Short>> splits = localTrees[i - j].getSplits();
					prevSplitSet.addAll(splits);
				}
				
				if (i + j <= bestRegion[RIGHT] && i - j < root.length())
				{
					Set<Set<Short>> splits = localTrees[i + j].getSplits();
					Set<Set<Short>> splitsToRemove = new LinkedHashSet<Set<Short>>();
					Set<Set<Short>> addedSplits = new LinkedHashSet<Set<Short>>();
					for (Set<Short> split : splits)
					{
						if (prevSplitSet.isEmpty())
						{
							splitSet.addAll(splits);
							break;
						}
						
						for (Set<Short> prevSplit : prevSplitSet)
						{
							if (!isCompatible(split, prevSplit))
							{
								if (isCompatible(split, localTrees[i]) &&
										isCompatible(split, guideTrees[i]))
								{
									addedSplits.add(split);
									splitsToRemove.add(prevSplit);
								}
								
							}
							
						}
						
					}
					
					prevSplitSet.removeAll(splitsToRemove);
					prevSplitSet.addAll(addedSplits);
					prevSplitSet.addAll(splits);
				}
				
				splitSet.addAll(prevSplitSet);
			}
			
			splitsToAdd.add(splitSet);
			bestRegions[i] = bestRegion;
		}
		
		for (int i = 0 ; i < splitsToAdd.size() ; i++)
		{
			Set<Set<Short>> splitSet = splitsToAdd.get(i);
			for (Set<Short> split : splitSet)
			{
				// if (isCompatible(split, timeTrees[i])) {
				if (guideTrees[i].containsSplit(split))
				{
					addSplitToTree(i, localTrees[i], split, false, true, false);
				}
				
			}
			
		}
		
		System.out.println(	" [" +	(double) (new Date().getTime() - startDate.getTime()) / 1000 +
									" Seconds] ");
	}
	
	/**
	 * 
	 */
	private void getDistanceMatricesForTrueTrees()
	{
		for (int i = 0 ; i < trueTrees.length ; i++)
		{
			Node taxa = new Node(0);
			for (Node node : trueTrees[i].getNodes())
			{
				if (node.isLeaf())
				{
					taxa = node;
				}
				
			}
			
			Map<Node, Double> distanceToRootMap = new HashMap<Node, Double>();
			calculatedDistance(distanceToRootMap, taxa);
			trueTreeLengths[i] = distanceToRootMap.get(taxa);
		}
		
	}
	
	/**
	 * @param list
	 * @param list2
	 * @param distanceMatrix
	 * 
	 * @return
	 */
	private float getDistanceOfClusters(List<Short> list, List<Short> list2,
				float[][] distanceMatrix)
	{
		float distance = 0.0F;
		for (Short i : list)
		{
			for (Short j : list2)
			{
				distance += distanceMatrix[i - 1][j - 1];
			}
			
		}
		
		return distance / (list.size() * list2.size());
	}
	
	
	/**
	 * getPositionArrayFromInputFile : Get the first line of input
	 * file which is SNP positions
	 *
	 * @return List<Integer> - list<Integer> of SNP positions
	 */
	private List<Integer> getPositionArrayFromInputFile() // unused
	{
		// list of SNP positions
		List<Integer> positions = new ArrayList<Integer>();
		ProgressBarStatus.setProgressBarStatus(CompareUtil.getRUMapV3Values()[CHNUM_TO_DO].size());
		
		for (RUMapV3ValuesLine vl : CompareUtil.getRUMapV3Values()[CHNUM_TO_DO])
		{
			ProgressBarStatus.barNextCount();
			
			try
			{
				positions.add(Math.toIntExact(vl.siteLocation));
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
		ProgressBarStatus.barDone();
		
		// then total up sequence length
		if (TOTAL_SEQ_LENGTH == 0)
		{
			TOTAL_SEQ_LENGTH = positions.get(positions.size() - 1) + 1;
		}
		
		// remove extraneous positions
		List<Integer> temPositions = new ArrayList<Integer>();
		ProgressBarStatus.setProgressBarStatus(positions.size());
		for (int i = 0 ; i < positions.size() ; i++)
		{
			ProgressBarStatus.barNextCount();
			if (!indicesToRemove.contains(i))
			{
				temPositions.add(positions.get(i));
			}
			
		}
		
		ProgressBarStatus.barDone();
		
		// clear and rebuild the positions list.
		positions.clear();
		positions.addAll(temPositions);
		
		return positions;
	}
	
	
	/**
	 * getPositionArrayFromInputFile : Get the first line of input
	 * file which is SNP positions
	 * 
	 * @param url - input filename (unused)
	 * 
	 * @return List<Integer> - list<Integer> of SNP positions
	 */
	private List<Integer> getPositionArrayFromInputFile(String url) // unused
	{
		// list of SNP positions
		List<Integer> positions = new ArrayList<Integer>();
		
		try
		{
			// Open file
			FileInputStream fis = new FileInputStream(url);
			InputStreamReader reader = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(reader);
			
			// read first line
			String line = br.readLine();
			
			processPositionArrayLine(positions, line);
			
			br.close();
		}
		
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		return positions;
	}
	
	
	/**
	 * Process a position array line
	 * 
	 * @param positions
	 * @param line
	 * 
	 * @throws NumberFormatException
	 */
	private void processPositionArrayLine(List<Integer> positions, String line)
				throws NumberFormatException
	{
		// if line is xxxx[2-9]xxxx (so not simply 1/0) or contains decimal
		if (line.matches(".*[2-9].*") || line.contains("."))
		{
			System.out.println("percentage sequences");
			
			if (TOTAL_SEQ_LENGTH == 0)
			{
				String[] positionStrings = line.split(" ");
				int maxLength = Integer.MIN_VALUE;
				
				// if decimal values
				if (positionStrings[0].contains("."))
				{
					System.out.println("fractional values");
					
					// scan for maximum length of position strings.
					for (int i = 0 ; i < positionStrings.length ; i++)
					{
						if (positionStrings[i].length() > maxLength)
						{
							maxLength = positionStrings[i].length();
						}
						
					}
					
					// form double = stringvalue * 10^(len-2)
					for (int i = 0 ; i < positionStrings.length ; i++)
					{
						double pos = Double.valueOf(positionStrings[i]) * Math.pow(10, (maxLength - 2));
						positions.add((int) pos);
					}
					
					System.out.println("percentage sequences max is " + maxLength);
				}
				
				// else whole integer values
				else
				{
					// add integers to positions
					for (int i = 0 ; i < positionStrings.length ; i++)
					{
						positions.add(Integer.valueOf(positionStrings[i]));
					}
					
				}
				
				// then total up sequence length
				if (TOTAL_SEQ_LENGTH == 0)
				{
					TOTAL_SEQ_LENGTH = positions.get(positions.size() - 1) + 1;
				}
				
				// remove extraneous positions
				List<Integer> temPositions = new ArrayList<Integer>();
				for (int i = 0 ; i < positions.size() ; i++)
				{
					if (!indicesToRemove.contains(i))
					{
						temPositions.add(positions.get(i));
					}
					
				}
				
				// clear and rebuild the positions list.
				positions.clear();
				positions.addAll(temPositions);
			}
			else
			// TOTAL_SEQ_LENGTH > 0 - not sure how this occurs
			{
				String[] positionStrings = line.split(" ");
				
				// build integer values
				for (String string : positionStrings)
				{
					positions.add((int) (Float.valueOf(string) * TOTAL_SEQ_LENGTH));
				}
				
			}
			
		}
		else
		// no position line provided, just manufacture whole number values.
		{ // positions are manufactured whole number values
			System.out.println("whole number sequences");
			for (int i = 0 ; i < localTrees.length ; i++)
			{
				positions.add((i + 1) * 10);
			}
			
			TOTAL_SEQ_LENGTH = positions.get(localTrees.length * 10);
		}
		
	}
	
	
	/**
	 * @param url
	 * 
	 * @return
	 */
	private List<Integer> getPositionArrayFromMSFile(String url)
	{
		List<Integer> positions = new ArrayList<Integer>();
		try
		{
			FileInputStream fis = new FileInputStream(url);
			InputStreamReader reader = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(reader);
			String line = br.readLine();
			String recombLengthString = "1";
			if (line.contains("-r"))
			{
				recombLengthString = line.split("-r")[1].split(" ")[2];
			}
			
			float recombLength = Float.valueOf(recombLengthString);
			TOTAL_SEQ_LENGTH = recombLength;
			while (line != null)
			{
				if (line.contains("positions"))
				{
					String[] positionStrings = line.split(":")[1].substring(1).split(" ");
					
					for (int i = 0 ; i < positionStrings.length ; i++)
					{
						double position = Double.valueOf(positionStrings[i]) * recombLength;
						positions.add((int) position);
					}
					
				}
				
				line = br.readLine();
			}
			
			if (positions.isEmpty())
			{
				int divider = (int) recombLength / (localTrees.length + 1);
				
				for (int i = 0 ; i < localTrees.length ; i++)
				{
					positions.add((i + 1) * divider);
				}
				
			}
			else
			{
				List<Integer> temPositions = new ArrayList<Integer>();
				
				for (int i = 0 ; i < positions.size() ; i++)
				{
					if (!indicesToRemove.contains(i))
					{
						temPositions.add(positions.get(i));
					}
					
				}
				
				positions.clear();
				positions.addAll(temPositions);
			}
			
			br.close();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		return positions;
	}
	
	/**
	 * 
	 * @param column
	 * 
	 * @return
	 */
	private String getSingleMutation(int column)
	{
		int zero = -1;
		int one = -1;
		
		for (int row = 0 ; row < personSiteMatrix.length ; row++)
		
		{
			if (personSiteMatrix[row].getInt(column) == 0)
			{
				if (zero == -1)
				{
					zero = row;
				}
				else
				{
					if (one != -1)
					{
						return String.valueOf(one + 1);
					}
					
				}
				
			}
			else
			{
				if (one == -1)
				{
					one = row;
				}
				else
				{
					if (zero != -1)
					{
						return String.valueOf(zero + 1);
					}
					
				}
				
			}
			
		}
		
		return String.valueOf(personSiteMatrix.length);
	}
	
	/**
	 * 
	 * @param url
	 */
	private void getTrueTreesFromMsFile(String url)
	{
		List<Integer> positions = new ArrayList<Integer>();
		List<Tree> trees = new ArrayList<Tree>();
		try
		{
			FileInputStream fis = new FileInputStream(url);
			InputStreamReader reader = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(reader);
			String line = br.readLine();
			String recombLengthString = line.split("-r")[1].split(" ")[2];
			double recombLength = Double.valueOf(recombLengthString);
			line = br.readLine();
			
			while (line != null)
			{
				if (line.contains(";"))
				{
					String positionString = line.split("]")[0].substring(1);
					if (positions.isEmpty())
					{
						positions.add(Integer.valueOf(positionString));
					}
					else
					{
						positions.add(	positions.get(positions.size() - 1) +
											Integer.valueOf(positionString));
					}
					
					String treeString = line.split("]")[1];
					Tree tree = Util.getTreeFromNewickWithTime(treeString);
					trees.add(tree);
				}
				
				if (line.contains("positions"))
				{
					String[] positionArray = line.split(":")[1].substring(1).split(" ");
					trueTrees = new Tree[positionArray.length];
					for (int i = 0 ; i < positionArray.length ; i++)
					{
						double truePosition = Double.valueOf(positionArray[i]) * recombLength;
						int index = 0;
						for (int j = 0 ; j < positions.size() ; j++)
						{
							if (truePosition < positions.get(j))
							{
								index = j;
								break;
							}
							
						}
						
						trueTrees[i] = trees.get(index);
					}
					
				}
				
				line = br.readLine();
			}
			
			for (Tree tree : trueTrees)
			{
				tree.updateSplits();
			}
			
			br.close();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 
	 */
	private void guideTreeSplitsRule()
	{
		System.out.print("Adding Guide Tree Splits");
		Date startDate = new Date();
		for (int i = 0 ; i < guideTrees.length ; i++)
		{
			Tree tree = guideTrees[i];
			for (Set<Short> split : tree.getSplits())
			{
				addSplitToTree(i, localTrees[i], split, false, false, false);
			}
			
		}
		
		System.out.println(	" [" +	(double) (new Date().getTime() - startDate.getTime()) / 1000 +
									" Seconds] ");
	}
	
	/**
	 * inferBranchLengths()
	 */
	private void inferBranchLengths()
	{
		Set<Set<Short>> currentSplit = localTrees[0].getSplits();
		List<int[]> regions = new ArrayList<int[]>();
		int[] region = new int[2];
		region[0] = 0;
		for (int i = 1 ; i < localTrees.length ; i++)
		{
			if (!localTrees[i].getSplits().equals(currentSplit))
			{
				region[RIGHT] = i - 1;
				regions.add(region);
				region = new int[2];
				region[0] = i;
				currentSplit = localTrees[i].getSplits();
			}
			
		}
		
		for (int i = 0 ; i < timeTreeLengths.length ; i++)
		{
			localTreeLengths[i] = timeTreeLengths[i];
		}
		
		// scaleTimes(timeTreeLengths);
		region[RIGHT] = localTrees.length - 1;
		regions.add(region);
		Map<Set<Short>, Double> splitMap = new HashMap<Set<Short>, Double>();
		for (int[] r : regions)
		{
			Tree tree = localTrees[r[0]];
			splitMap.clear();
			double scaledHeight = 0.0;
			for (int i = r[0] ; i <= r[RIGHT] ; i++)
			{
				scaledHeight += timeTreeLengths[i];
			}
			
			scaledHeight = scaledHeight / (r[RIGHT] - r[0] + 1);
			for (Set<Short> split : tree.getSplits())
			{
				double height = 0.0;
				if (split.size() != 1)
				{
					for (int i = r[0] ; i <= r[RIGHT] ; i++)
					{
						height += Double.valueOf(guideTrees[i].getBestSplitNode(split).getInfo());
					}
					
				}
				
				height = height / (r[RIGHT] - r[0] + 1);
				splitMap.put(split, height);
			}
			
			for (int i = r[0] ; i <= r[RIGHT] ; i++)
			{
				tree = localTrees[i];
				Tree timeTree = guideTrees[i];
				double multiplier = timeTreeLengths[i] / localTreeLengths[i];
				for (Node node : timeTree.getNodes())
				{
					double branchLength = Double.valueOf(node.getBranchLength());
					double height = Double.valueOf(node.getInfo());
					node.setBranchLength(String.format("%.2f", (branchLength) * multiplier));
					node.setInfo(String.format("%.2f", (height) * multiplier));
				}
				
				double treeHeight = splitMap.get(overallSplit);
				// multiplier *= localTreeLengths[i]/treeHeight;
				multiplier = scaledHeight / treeHeight;
				for (Node node : tree.getNodes())
				{
					double height = 0;
					if (node.getSplit().size() != 1)
					{
						height = splitMap.get(node.getSplit());
					}
					
					double parentHeight = 0;
					if (node.getParent() != null)
					{
						parentHeight = splitMap.get(node.getParent().getSplit());
						node.setBranchLength(String.format(	"%.2f",
																		(parentHeight > height ? parentHeight -
																											height :
																										0) *
																					multiplier));
					}
					else
					{
						node.setBranchLength("0");
						localTreeLengths[i] = height * multiplier;
					}
					
					if (height > parentHeight)
					{
						height = parentHeight;
					}
					
					node.setInfo(String.format("%.2f", height * multiplier));
				}
				
			}
			
		}
		
		// scaleTimes(localTreeLengths);
	}
	
	/**
	 * @return
	 */
	private Tree[] initializeTrees()
	{
		System.out.println("Initializing Trees");
		
		{
			Tree[] localTrees = new Tree[personSiteMatrix[0].length()];
			int counter = 0;
			originalSplits = new ArrayList<Set<Short>>();
			for (int column = 0 ; column < personSiteMatrix[0].length() ; column++)
			{
				Tree tree = new Tree();
				Node rootNode = new Node(NUM_TAXA);
				rootNode.setId("root " + column);
				tree.setRoot(rootNode);
				tree.addNode(rootNode);
				if (isInformative(column))
				{
					counter++;
					Node inputSplitNode = new Node(2);
					inputSplitNode.setParent(rootNode);
					tree.addNode(inputSplitNode);
					for (int row = 0 ; row < personSiteMatrix.length ; row++)
					{
						Node node = new Node(1);
						node.setId(String.valueOf((short) (row + 1)));
						node.addToSplit((short) (row + 1));
						rootNode.addToSplit((short) (row + 1));
						tree.addNode(node);
						if (personSiteMatrix[row].getInt(column) == root.getInt(column))
						{
							rootNode.getChildren().add(node);
							node.setParent(rootNode);
						}
						else
						{
							inputSplitNode.getChildren().add(node);
							node.setParent(inputSplitNode);
							inputSplitNode.addToSplit((short) (row + 1));
						}
						
						tree.addSplit(node.getSplit());
					}
					
					rootNode.getChildren().add(inputSplitNode);
					tree.addSplit(inputSplitNode.getSplit());
					Set<Short> originalSplit = new HashSet<Short>();
					originalSplit.addAll(inputSplitNode.getSplit());
					originalSplits.add(originalSplit);
				}
				else
				{
					for (int j = 0 ; j < personSiteMatrix.length ; j++)
					{
						Node node = new Node(1);
						node.setId(String.valueOf(j + 1));
						node.addToSplit((short) (j + 1));
						rootNode.addToSplit((short) (j + 1));
						rootNode.getChildren().add(node);
						node.setParent(rootNode);
						tree.addNode(node);
						tree.addSplit(node.getSplit());
					}
					
					originalSplits.add(new HashSet<Short>());
				}
				
				localTrees[column] = tree;
				tree.addSplit(rootNode.getSplit());
			}
			
		}
		
		// System.out.println("(" + counter + ")");
		return localTrees;
	}
	
	/**
	 * 
	 */
	private void initiateCompatibleMatrix()
	{
		compatibleMatrix = new BitMatrix(root.length(), root.length());
		for (int i = 0 ; i < root.length() - 1 ; i++)
		{
			for (int j = i + 1 ; j < root.length() ; j++)
			{
				boolean compatible = isCompatible(originalSplits.get(i), originalSplits.get(j));
				compatibleMatrix.assign(i, j, compatible);
			}
			
		}
		
	}
	
	/**
	 * 
	 * @param split1
	 * @param split2
	 * 
	 * @return
	 */
	private boolean isCompatible(Set<Short> split1, Set<Short> split2)
	{
		if (split1.size() <= 1 ||	split2.size() <= 1 ||
				split1.size() >= overallSplit.size() - 1 ||
				split2.size() >= overallSplit.size() - 1)
		{
			return true;
		}
		
		boolean share = false;
		boolean coverAll = true;
		int size = 0;
		if (split1.size() <= split2.size())
		{
			size = split2.size();
			for (Short integer : split1)
			{
				boolean contains = split2.contains(integer);
				if (!contains)
				{
					size++;
				}
				
				share = share | contains;
				coverAll = coverAll & contains;
			}
			
		}
		else
		{
			size = split1.size();
			for (Short integer : split2)
			{
				boolean contains = split1.contains(integer);
				if (!contains)
				{
					size++;
				}
				
				share = share | contains;
				coverAll = coverAll & contains;
			}
			
		}
		
		return coverAll || !share || (size == overallSplit.size() && share);
	}
	
	/**
	 * 
	 * @param concatenatedSplit
	 * @param tree
	 * 
	 * @return
	 */
	private boolean isCompatible(Set<Short> concatenatedSplit, Tree tree)
	{
		boolean compatible = true;
		// checking compatibility of the split
		for (Set<Short> split : tree.getSplits())
		{
			if (!isCompatible(concatenatedSplit, split))
			{
				compatible = false;
				break;
			}
			
		}
		
		return compatible;
	}
	
	/**
	 * 
	 * @return is informative (t/f)
	 */
	private boolean isInformative(int column)
	{
		return !(singletons.contains(column));
	}
	
	/**
	 * 
	 * @param index
	 * @param tree
	 * @param addedSplit
	 * 
	 * @return
	 */
	private boolean isTimeEligible(int index, Tree tree, Set<Short> addedSplit)
	{
		// double mrcaTime = 0;
		// List<Integer> split = new ArrayList<>();
		// split.addAll(addedSplit);
		// for (int i = 0; i < split.size()-1; i++) {
		// for (int j = i+1; j < split.size(); j++) {
		// double time = distanceMatrices.get(index)[i][j];
		// if (time > mrcaTime) {
		// mrcaTime = time;
		// }
		// }
		// }
		// if (mrcaTime/2 > treeLengths[index]*0.8) {
		// return false;
		// }
		return true;
	}
	
	/**
	 * 
	 */
	private void logMemory()
	{
		System.out.println("-------------------------");
		System.out.println(	"Used Memory: " + (Runtime.getRuntime().totalMemory() -
																Runtime.getRuntime().freeMemory()) /
															1024 / 1024 +
									"MB");
		System.out.println(	"Total Memory: " +	Runtime.getRuntime().totalMemory() / 1024 / 1024 +
									"MB");
		System.out.println("-------------------------");
	}
	
	/**
	 * makeDistanceMatrices()
	 */
	
	// initializing indexP, countFP, countWIP, and count WP
	private static int indexP = 0;
	private static int indexM = 0;
	
	// number of mutations from i (column2) to indexP and indexM
	private static int countFP = 0;
	private static int countFM = 0;
	
	// number of informative mutations within the window size
	private static int countWIP = 0;
	private static int countWIM = 0;
	
	// number of mutations within the window size including
	// singletons
	private static int countWP = 0;
	private static int countWM = 0;
	
	private static boolean selfInformative = false;
	private static boolean selfNonInformative = false;
	
	/**
	 * makeDistanceMatrices()
	 */
	// @formatter:off
	private void makeDistanceMatrices()
	{
		// initiating all distance matrices for all sites
		System.out.print("Making Distance Matrices");
		Date startDate = new Date();
		
		// for (int i = 1; i <= positions.size(); i++) {
		// float[][] distanceMatrix = new
		// float[personSiteMatrix.length][personSiteMatrix.length];
		// distanceMatrices.add(distanceMatrix);
		// }
		for (int j = 0 ; j < personSiteMatrix.length - 1 ; j++)
		{
			if (j % 1000 == 0)
				System.out.println ("1:" + j + "<" + personSiteMatrix.length);
			
			for (int j2 = j + 1 ; j2 < personSiteMatrix.length ; j2++)
			{
				if (j2 % 1000 == 0)
					System.out.println ("2:" + j2 + "<" + personSiteMatrix.length);
				// initializing indexP, countFP, countWIP, and count WP
				
				// indices for next or previous non informative site with
				// different values for j and j2	
				int indexP = 0;
				int indexM = 0;

				// number of mutations from i to indexP and indexM
				int countFP = 0;
				int countFM = 0;
				
				// number of informative mutations within the window size
				int countWIP = 0;
				int countWIM = 0;
				
				// number of mutations within the window size including
				// singletons
				int countWP = 0;
				int countWM = 0;
				
				boolean selfInformative = false;
				boolean selfNonInformative = false;
				
				int i2 = 1;
				int i2old = 0;
				int sz = positions.size();
				while (i2 <= sz - 1)
				{
					assert(i2old != i2);
					
					if (personSiteMatrix[j].getInt(i2) + 
							personSiteMatrix[j2].getInt(i2) == 1)
					{
						if (isInformative(i2))
						{
							indexP = i2;
							if (i2 <= WINDOW_SIZE)
							{
								countWIP++;
							}
							else
							{
								countFP++;
								System.out.println ("i2" + i2 + "> WINDOW_SIZE");
								break;         // while
							}
							
						}
						
						if (i2 <= WINDOW_SIZE)
						{
							countWP++;
						}
						
						countFP++;
					}
					else
					{
						if(i2 % 1000 == 0)
							 System.out.println( "3:" + i2 + ">" + sz +  "-" + 1);
					}
					
					
					i2old = i2;
					i2++;
				}
				
				
				// at this point i2 == WINDOW_SIZE 
				
				if (personSiteMatrix[j].getInt(0) + 
					 personSiteMatrix[j2].getInt(0) == 1)
				{
					if (isInformative(0))
					{
						selfInformative = true;
					}
					else
					{
						selfNonInformative = true;
					}
					
				}
				
				// calculating distance for index 0
				float distance = 0;
				if (countWIP > 0 || selfInformative)
				{
					if (selfInformative || selfNonInformative)
					{
						distance = (countWP + 1) / (float) positions.get(WINDOW_SIZE - 1);
					}
					else
					{
						distance = (countWP) / (float) positions.get(WINDOW_SIZE - 1);
					}
					
				}
				else
				{
					if (selfNonInformative)
					{
						distance = (countFP + 1) / (float) positions.get(indexP);
					}
					else
					{
						distance = countFP / (float) positions.get(indexP);
					}
					
					distance = countFP / (float) positions.get(indexP);
				}
				
				// distanceMatrices.get(0)[j][j2] = distance;
				// distanceMatrices.get(0)[j2][j] = distance;
				
				distanceHolder.addDistance(j, j2, 0, distance);
				int size = positions.size();
				int i;
				for (i = 1 ; i < size ; i++)
				{
					if (i%1000 == 0)
						System.out.println("4: " + i + "<" + size);
					
					selfInformative = false;
					selfNonInformative = false;
					if (personSiteMatrix[j].getInt(i) + 
							personSiteMatrix[j2].getInt(i) == 1)
					{
						if (isInformative(i))
						{
							selfInformative = true;
						}
						else
						{
							selfNonInformative = true;
						}
						
					}
					

					if (personSiteMatrix[j].getInt(i - 1) + 
							personSiteMatrix[j2].getInt(i - 1) == 1)
					{
						if (isInformative(i - 1))
						{
							countWIM++;
						}
						
						countWM++;
						countFM++;
					}

					
					if (i - WINDOW_SIZE - 1 >= 0)
					{
						if (personSiteMatrix[j].getInt(i - WINDOW_SIZE - 1) +
								personSiteMatrix[j2].getInt(i - WINDOW_SIZE - 1) == 1)
						{
							countWM--;
							if (isInformative(i - WINDOW_SIZE - 1))
							{
								countWIM--;
								indexM = i - WINDOW_SIZE - 1;
								countFM = countWM + 1;
							}
							
						}
						
					}
					else 
					{
						if (i%1000 == 0)
							System.out.println("5:" + i + "-" + WINDOW_SIZE +  "-" + 1 + "<" + 0);
					}
					
					if (personSiteMatrix[j].getInt(i) + 
						 personSiteMatrix[j2].getInt(i) == 1)
					{
						if (isInformative(i))
						{
							countWIP--;
						}
						
						countWP--;
						countFP--;
					}
					
					if (i + WINDOW_SIZE <= positions.size() - 1)
					{
						if (personSiteMatrix[j].getInt(i + WINDOW_SIZE) +	
							 personSiteMatrix[j2].getInt(i + WINDOW_SIZE)
								== 1)
						{
							if (isInformative(i + WINDOW_SIZE))
							{
								countWIP++;
							}
							
							countWP++;
						}
						
					}
					
					if (indexP <= i + WINDOW_SIZE)
					{
						i2 = 1;
						i2old = 0;
						while (i + WINDOW_SIZE + i2 <= positions.size() - 1)
						{
							assert(i2old != i2);
							if (i+WINDOW_SIZE+i2 % 1000 == 0)
								System.out.println("6:" + i + WINDOW_SIZE + i2 +  "<=" +  positions.size() + "-" + 1);
							if (personSiteMatrix[j].getInt(i + WINDOW_SIZE + i2) +
								 personSiteMatrix[j2].getInt(i + WINDOW_SIZE + i2) == 1)
							{
								countFP++;
								if (isInformative(i + WINDOW_SIZE + i2))
								{
									indexP = i + WINDOW_SIZE + i2;
									break;  // while
								}
								
							}
							
							i2old = i2;
							i2++;
							if (i + WINDOW_SIZE + i2 == positions.size() - 1)
							{
								indexP = positions.size() - 1;
							}
							
						}
						System.out.println("end while 2:");
						
					}
					else
					{
						if (i2 % 1000 == 0)
							System.out.println("3:" + indexP + ">" + i + "+" + WINDOW_SIZE);
					}
					
					// Calculating the distances
					int minTravel = 0;
					int totalCount = 0;
					if (countWIM >= 1 || selfInformative)
					{
						minTravel = Math.max(0, i - WINDOW_SIZE);
						totalCount = countWM;
					}
					else
					{
						minTravel = indexM;
						totalCount = countFM;
					}
					
					int maxTravel = 0;
					if (countWIP >= 1 || selfInformative)
					{
						maxTravel = Math.min(i + WINDOW_SIZE, positions.size() - 1);
						totalCount += countWP;
					}
					else
					{
						maxTravel = indexP;
						totalCount += countFP;
					}
					
					if (selfNonInformative || selfInformative)
					{
						totalCount++;
					}
					
					int lowestPosition = 0;
					int highestPosition = 0;
					float score;
					if (minTravel == 0)
					{
						lowestPosition = 0;
					}
					else
					{
						lowestPosition = (positions.get(minTravel) + 
									positions.get(minTravel - 1)) / 2;
					}
					
					if (maxTravel >= positions.size() - 1)
					{
						highestPosition = (int) TOTAL_SEQ_LENGTH;
					}
					else
					{
						highestPosition = (positions.get(maxTravel) + 
									positions.get(maxTravel + 1)) / 2;
					}
					
					if (highestPosition == lowestPosition)
					{
						score = 1;
					}
					else
					{
						// score = (double)totalCount/(double)(highestPosition -
						// lowestPosition);
						
						score = (float) totalCount /
									(theta * (float) (highestPosition - lowestPosition) / TOTAL_SEQ_LENGTH);
					}
					
					// distanceMatrices.get(i)[j][j2] = score;
					// distanceMatrices.get(i)[j2][j] = score;
					
					distanceHolder.addDistance(j, j2, i, score);
					
					
				} // for i
				System.out.println("End for i");
			} // for j1
			System.out.println("End for j1");
		} // for j
		
		System.out.println(	" [" +	(double) (new Date().getTime() - startDate.getTime()) / 1000 +
									" Seconds] ");
	}
	// @formatter:on
	
	
	/**
	 * makeGuideTrees
	 */
	private void makeGuideTrees()
	{
		System.out.print("Making Guide Trees");
		Date startDate = new Date();
		
		guideTrees = new Tree[positions.size()];
		
		Map<Set<Short>, short[]> compatibleRegionMap = new HashMap<Set<Short>, short[]>();
		ProgressBarStatus.setProgressBarStatus(guideTrees.length);
		ProgressBarStatus.barNextCount();
		
		for (int i = 0 ; i < guideTrees.length ; i++)
		{
			Tree upgmaTree = new Tree();
			
			// float[][] distanceMatrix = distanceMatrices.get(i);
			
			float[][] distanceMatrix = distanceHolder.getDistanceMatrixforPosition(i);
			
			HashMap<Node, List<Short>> clusters = new LinkedHashMap<Node, List<Short>>();
			
			TreeSet<DistanceObject> distanceSet = new TreeSet<
						DistanceObject>(new Comparator<DistanceObject>()
						{
							@Override
							public int compare(DistanceObject o1, DistanceObject o2)
							{
								return o1.getDistance() < o2.getDistance() ? -1 : 1;
							}
							
						});
			
			TreeSet<DistanceObject> compatibleDistanceSet = new TreeSet<
						DistanceObject>(new Comparator<DistanceObject>()
						{
							@Override
							public int compare(DistanceObject o1, DistanceObject o2)
							{
								return o1.getCompatibleRange() <= o2.getCompatibleRange() ? 1 : -1;
							}
							
						});
			
			Set<Node> removedNodes = new HashSet<Node>();
			
			// initiating clusters
			for (int j = 0 ; j < personSiteMatrix.length ; j++)
			{
				Node node = new Node(1); // splitsize=1
				node.setId(String.valueOf(j + 1));
				node.setInfo("0.0");
				List<Short> taxaCovering = new ArrayList<Short>();
				taxaCovering.add((short) (j + 1));
				clusters.put(node, taxaCovering);
				
				// List<DistanceObject> distanceObjects = new
				// ArrayList<DistanceObject>();
				// nodeDistanceObjectMap.put(node, distanceObjects);
			}
			
			//
			List<Node> clusterNodes = new ArrayList<Node>();
			clusterNodes.addAll(clusters.keySet());
			Node[] nodesToConcat = new Node[2];
			
			// Making the initial TreeMap with the distances sorted
			for (int j = 0 ; j < clusterNodes.size() - 1 ; j++)
			{
				for (int j2 = j + 1 ; j2 < clusterNodes.size() ; j2++)
				{
					System.out.print(";");
					Node node1 = clusterNodes.get(j);
					Node node2 = clusterNodes.get(j2);
					Set<Short> combinedSplit = new HashSet<Short>();
					combinedSplit.addAll(clusters.get(node1));
					combinedSplit.addAll(clusters.get(node2));
					if (isCompatible(originalSplits.get(i), combinedSplit))
					{
						Node[] pair = new Node[2];
						pair[0] = node1;
						pair[RIGHT] = node2;
						Float distance;
						distance = getDistanceOfClusters(clusters.get(node1), clusters.get(node2),
																	distanceMatrix);
						// distance = getDistanceOfClusters(clusters.get(node1),
						// clusters.get(node2), i);
						DistanceObject distanceObject = new DistanceObject();
						distanceObject.setNodes(pair);
						distanceObject.setDistance(distance);
						distanceObject.setCompatibleRange((short) 0);
						distanceSet.add(distanceObject);
						
						// nodeDistanceObjectMap.get(node1).add(distanceObject);
						// nodeDistanceObjectMap.get(node2).add(distanceObject);
					}
					
				}
				
				System.out.println(";");
			}
			
			while (clusters.keySet().size() > 1)
			{
				// Making the second Map sorted by the compatible distance
				DistanceObject firstElement = distanceSet.first();
				while (removedNodes.contains(firstElement.getNodes()[0]) ||
							removedNodes.contains(firstElement.getNodes()[RIGHT]))
				{
					distanceSet.pollFirst();
					firstElement = distanceSet.first();
				}
				
				for (DistanceObject key : distanceSet)
				{
					if (!removedNodes.contains(key.getNodes()[0]) &&
							!removedNodes.contains(key.getNodes()[RIGHT]))
					{
						if (key.getDistance() == 0.0)
						{
							key.setCompatibleRange(Short.MAX_VALUE);
							compatibleDistanceSet.add(key);
						}
						else if (key.getDistance() <= firstElement.getDistance() * (1 + UPGMA_THRESHOLD))
						{
							if (key.getCompatibleRange() == 0)
							{
								Set<Short> coveringSet = new HashSet<
											Short>(clusters.get(key.getNodes()[0]));
								coveringSet.addAll(clusters.get(key.getNodes()[RIGHT]));
								short[] range = compatibleRegionMap.get(coveringSet);
								short compatipleDistance = 0;
								if (range != null && range[0] <= i && i <= range[RIGHT])
								{
									if (range[0] == 0)
									{
										compatipleDistance = (short) (range[RIGHT] - i);
									}
									else if (range[RIGHT] == positions.size() - 1)
									{
										compatipleDistance = (short) (i - range[0]);
									}
									else
									{
										compatipleDistance = (short) Math.min(range[RIGHT] - i, i - range[0]);
									}
									
									// compatipleDistance = (short) (range[RIGHT] - range[0]
									// + 1);
								}
								else
								{
									range = findCompatibleRegion(key.getNodes(), coveringSet, i);
									if (range[0] == 0)
									{
										compatipleDistance = (short) (range[RIGHT] - i);
									}
									else if (range[RIGHT] == positions.size() - 1)
									{
										compatipleDistance = (short) (i - range[0]);
									}
									else
									{
										compatipleDistance = (short) Math.min(range[RIGHT] - i, i - range[0]);
									}
									
									// compatipleDistance = (short) (range[RIGHT] - range[0]
									// + 1);
									compatibleRegionMap.put(coveringSet, range);
								}
								
								// short compatipleDistance =
								// findCompatibleDistance(key.getNodes(), clusters, i);
								key.setCompatibleRange(compatipleDistance);
								compatibleDistanceSet.add(key);
							}
							
						}
						else
						{
							break;
						}
						
					}
					
				}
				
				DistanceObject firstConcatObject = compatibleDistanceSet.first();
				while (removedNodes.contains(firstConcatObject.getNodes()[0]) ||
							removedNodes.contains(firstConcatObject.getNodes()[RIGHT]))
				{
					compatibleDistanceSet.pollFirst();
					firstConcatObject = compatibleDistanceSet.first();
				}
				
				nodesToConcat = firstConcatObject.getNodes();
				int capacity = nodesToConcat[0].getSplit().size() +
									nodesToConcat[RIGHT].getSplit().size();
				Node newNode = new Node(capacity);
				newNode.getChildren().add(nodesToConcat[0]);
				newNode.getChildren().add(nodesToConcat[RIGHT]);
				
				List<Short> coveringTaxa = new ArrayList<Short>();
				newNode.setInfo(String.valueOf(firstConcatObject.getDistance() / 2));
				for (Node node : nodesToConcat)
				{
					node.setParent(newNode);
					double branchLength = (firstConcatObject.getDistance() / 2) -
													Double.valueOf(node.getInfo());
					node.setBranchLength(String.valueOf(branchLength));
					coveringTaxa.addAll(clusters.get(node));
					clusters.remove(node);
					removedNodes.add(node);
					
					// for (DistanceObject dObject : nodeDistanceObjectMap.get(node))
					// {
					// distanceSet.remove(dObject);
					// compatibleDistanceSet.remove(dObject);
					// }
				}
				
				// nodeDistanceObjectMap.put(newNode, new
				// ArrayList<DistanceObject>());
				for (Node node : clusters.keySet())
				{
					// Set<Short> newCovering = new HashSet<Short>();
					// if (isInformative(i)) {
					// newCovering.addAll(coveringTaxa);
					// newCovering.addAll(clusters.get(node));
					// }
					// if (isCompatible(newCovering, originalSplits.get(i))) {
					
					Float newDistance = getDistanceOfClusters(coveringTaxa, clusters.get(node),
																			distanceMatrix);
					
					// Float newDistance = getDistanceOfClusters(coveringTaxa,
					// clusters.get(node), i);
					
					Node[] newPair = new Node[2];
					newPair[0] = node;
					newPair[RIGHT] = newNode;
					DistanceObject newObject = new DistanceObject();
					newObject.setNodes(newPair);
					newObject.setDistance(newDistance);
					newObject.setCompatibleRange((short) 0);
					distanceSet.add(newObject);
					
					// nodeDistanceObjectMap.get(node).add(newObject);
					// nodeDistanceObjectMap.get(newNode).add(newObject);
					// }
				}
				
				clusters.put(newNode, coveringTaxa);
			}
			
			upgmaTree.setRoot(clusters.keySet().iterator().next());
			upgmaTree.updateNodes();
			upgmaTree.updateSplits();
			guideTrees[i] = upgmaTree;
			Map<Node, Double> distanceToRootMap = buildDistanceToRootMap(upgmaTree);
			timeTreeLengths[i] = distanceToRootMap.get(upgmaTree.getTaxa().get(0));
		}
		
		ProgressBarStatus.barDone();
		System.out.println(	" [" +	(double) (new Date().getTime() - startDate.getTime()) / 1000 +
									" Seconds] ");
	}
	
	/**
	 * 
	 * @param positions2
	 */
	private void outputInferredTrees(List<Integer> positions2)
	{
		for (int i = 0 ; i < localTrees.length ; i++)
		
		{
			Tree localTree = localTrees[i];
			// Tree timeTree = timeTrees[i];
			String split = originalSplits.get(i).isEmpty() ?	getSingleMutation(i) :
																			originalSplits.get(i).toString();
			
			System.out.println(	"" +	"(3)At index " + (i) + ", " + " Inferred Tree: " +
										localTree.toString() + " TreeLengths: [" + localTreeLengths[i] + "]" +
										" {" + positions2.get(i) + "}" + " Original Split: " + split);
			
			// System.out.println(""
			// + "(3)At index " + (i) + ", " + " Inferred Tree: " +
			// localTree.toString() + " TreeLengths: ["
			// + localTreeLengths[i] + "]"
			
			// + " UPGMA Tree: " + timeTree.toString() + " [" + timeTreeLengths[i]+
			// "]"
			// + " Best Compatible Region: [" + bestRegions[i][0] + ","
			// + bestRegions[i][RIGHT] + "]"
			
			// + " {" + positions.get(i) + "}"
			// + " Original Split: " + split);
		}
		
	}
	
	/**
	 * 
	 * @param inputUrl
	 */
	private void outputTimes(String inputUrl)
	{
		try
		{
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(inputUrl +
																																".times")));
			for (double d : timeTreeLengths)
			{
				writer.write(String.valueOf(d));
				writer.newLine();
			}
			
			writer.flush();
			writer.close();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 
	 * @param inputUrl
	 */
	private void outputTMRCAs(String inputUrl)
	{
		try
		{
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(inputUrl +
																																".Tmrcas")));
			for (int i = 0 ; i < localTreeLengths.length ; i++)
			{
				writer.write(String.valueOf(localTreeLengths[i]));
				writer.newLine();
			}
			
			writer.flush();
			writer.close();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
	}
	
	/**
	 * outputTreesSeparate Output trees to FileOutputStream
	 * 
	 * @param trees
	 * @param inputUrl
	 * @param level
	 */
	private void outputTreesSeparate(Tree[] trees, String inputUrl, String level)
	{
		try
		{
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(inputUrl +
																																".trees" +
																																level)));
			for (int i = 0 ; i < trees.length ; i++)
			{
				Tree localTree = trees[i];
				String position = String.valueOf(positions.get(i));
				writer.write(position + "\t" + localTree.toString());
				writer.newLine();
				localTree.setUpdateFlag(true);
			}
			
			writer.flush();
			writer.close();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 
	 * @param index
	 * @param addedSplit
	 * 
	 * @return
	 */
	private int propagateSplit(int index, Set<Short> addedSplit)
	{
		int i = index;
		if (index < root.length() - 1)
		{
			index++;
			while (addSplitToTreeOnly(index, localTrees[index], addedSplit) >= 0)
			{
				if (index == root.length() - 1)
				{
					break;
				}
				
				index++;
			}
			
		}
		
		index = i;
		if (index > 0)
		{
			index--;
			while (addSplitToTreeOnly(index, localTrees[index], addedSplit) >= 0)
			{
				if (index == 0)
				{
					break;
				}
				
				index--;
			}
			
		}
		
		return 0;
	}
	
	/**
	 * 
	 * @param index
	 * @param addedSplit
	 * 
	 * @return
	 */
	private int propagateSplit3(int index, Set<Short> addedSplit)
	{
		int i = index;
		if (index < root.length() - 1)
		{
			index++;
			while (guideTrees[index].containsSplit(addedSplit) &&
						addSplitToTreeOnly(index, localTrees[index], addedSplit) >= 0)
			{
				if (index == root.length() - 1)
				{
					break;
				}
				
				index++;
			}
			
		}
		
		index = i;
		if (index > 0)
		{
			index--;
			while (guideTrees[index].containsSplit(addedSplit) &&
						addSplitToTreeOnly(index, localTrees[index], addedSplit) >= 0)
			{
				if (index == 0)
				{
					break;
				}
				
				index--;
			}
			
		}
		
		return 0;
	}
	
	/**
	 * propagateSplitHeight
	 * 
	 * @param index
	 * @param addedSplit
	 * 
	 * @return
	 */
	private int propagateSplitHeight(int index, Set<Short> addedSplit)
	{
		int i = index;
		double ratio = 0;
		if (index < root.length() - 1)
		{
			ratio = Double.valueOf(guideTrees[index + 1].getBestSplitNode(addedSplit).getInfo()) /
						Double.valueOf(guideTrees[index].getBestSplitNode(addedSplit).getInfo());
			index++;
			while (ratio	< 1.5 && ratio > 0.75 &&
						addSplitToTreeOnly(index, localTrees[index], addedSplit) >= 0)
			{
				if (index == root.length() - 1)
				{
					break;
				}
				
				ratio = Double.valueOf(guideTrees[index + 1].getBestSplitNode(addedSplit).getInfo()) /
							Double.valueOf(guideTrees[index].getBestSplitNode(addedSplit).getInfo());
				index++;
			}
			
		}
		
		index = i;
		if (index > 0)
		{
			ratio = Double.valueOf(guideTrees[index - 1].getBestSplitNode(addedSplit).getInfo()) /
						Double.valueOf(guideTrees[index].getBestSplitNode(addedSplit).getInfo());
			index--;
			while (ratio	< 1.5 && ratio > 0.75 &&
						addSplitToTreeOnly(index, localTrees[index], addedSplit) >= 0)
			{
				if (index == 0)
				{
					break;
				}
				
				ratio = Double.valueOf(guideTrees[index - 1].getBestSplitNode(addedSplit).getInfo()) /
							Double.valueOf(guideTrees[index].getBestSplitNode(addedSplit).getInfo());
				index--;
			}
			
		}
		
		return 0;
	}
	
	private void propagationHeightRule()
	{
		System.out.print("Propagation Rule using Guide Tree TMRCAs");
		Date startDate = new Date();
		int counter = 0;
		for (int i = 0 ; i < localTrees.length ; i++)
		{
			Tree localTree = localTrees[i];
			for (Set<Short> split : localTree.getSplits())
			{
				if (split.size() > 1 && split.size() < overallSplit.size() - 1)
				{
					counter += propagateSplitHeight(i, split);
				}
				
			}
			
		}
		
		System.out.println(	" [" +	(double) (new Date().getTime() - startDate.getTime()) / 1000 +
									" Seconds] ");
	}
	
	private void propagationRule()
	{
		System.out.print("Propagation Rule ");
		Date startDate = new Date();
		for (int i = 0 ; i < localTrees.length ; i++)
		{
			Tree localTree = localTrees[i];
			for (Set<Short> split : localTree.getSplits())
			{
				if (split.size() > 1 && split.size() < NUM_TAXA - 1)
				{
					propagateSplit(i, split);
				}
				
			}
			
		}
		
		System.out.println(	" [" +	(double) (new Date().getTime() - startDate.getTime()) / 1000 +
									" Seconds] ");
	}
	
	/**
	 * propagationRuleNew
	 */
	private void propagationRuleNew()
	{
		System.out.print("Propagation Rule using Guide Tree Topologies");
		Date startDate = new Date();
		for (int i = 0 ; i < localTrees.length ; i++)
		{
			Tree localTree = localTrees[i];
			for (Set<Short> split : localTree.getSplits())
			{
				if (split.size() > 1 && split.size() < localTree.getRoot().getSplit().size() - 1)
				{
					propagateSplit3(i, split);
				}
				
			}
			
		}
		
		System.out.println(	" [" +	(double) (new Date().getTime() - startDate.getTime()) / 1000 +
									" Seconds] ");
	}
	
	/**
	 * RefineNonBinaryNodes
	 */
	private void RefineNonBinaryNodes()
	{
		for (int i = 0 ; i < localTrees.length ; i++)
		{
			Tree tree = localTrees[i];
			Tree upgmaTree = guideTrees[i];
			List<Node> nodesToBreak = new ArrayList<Node>();
			for (Node node : tree.getNodes())
			{
				if (node.getChildren().size() > 2)
				{
					nodesToBreak.add(node);
				}
				
			}
			
			while (!nodesToBreak.isEmpty())
			{
				Node node = nodesToBreak.remove(0);
				Node upgmaNode = upgmaTree.getBestSplitNode(node.getSplit());
				Set<Short> split1 = upgmaNode.getChildren().get(0).getSplit();
				Set<Short> split2 = upgmaNode.getChildren().get(1).getSplit();
				Set<Short> tmp;
				// Assuming split1 is the bigger one
				if (split1.size() < split2.size())
				{
					tmp = split2;
					split2 = split1;
					split1 = tmp;
				}
				
				Set<Node> set1 = new HashSet<Node>();
				Set<Node> set2 = new HashSet<Node>();
				// Check if splits fits better for split1 or split2
				Node worstNode = null;
				double worstrate = 0;
				for (Node child : node.getChildren())
				{
					Set<Short> childSplit = child.getSplit();
					int count = 0;
					for (Short integer : childSplit)
					{
						if (split1.contains(integer))
						{
							count++;
						}
						
					}
					
					if (count * 2 >= childSplit.size())
					{
						if (worstNode == null)
						{
							worstNode = child;
							worstrate = (double) count / (double) childSplit.size();
						}
						else
						{
							if ((double) count / (double) childSplit.size() < worstrate)
							{
								worstrate = (double) count / (double) childSplit.size();
								worstNode = child;
							}
							
						}
						
						set1.add(child);
					}
					else
					{
						if (worstNode == null)
						{
							worstNode = child;
							worstrate = (double) count / (double) childSplit.size();
						}
						else
						{
							if ((double) count / (double) childSplit.size() < worstrate)
							{
								worstrate = (double) count / (double) childSplit.size();
								worstNode = child;
							}
							
						}
						
						set2.add(child);
					}
					
				}
				
				if (set2.size() == 0)
				{
					set2.add(worstNode);
					set1.remove(worstNode);
				}
				
				if (set1.size() == 0)
				{
					set1.add(worstNode);
					set2.remove(worstNode);
				}
				
				// Dividing the node;
				if (set1.size() > 1)
				{
					int capacity = 0;
					for (Node node_ : set1)
					{
						capacity += node_.getSplit().size();
					}
					
					Node node1 = new Node(capacity);
					node1.getChildren().addAll(set1);
					for (Node n : set1)
					{
						n.setParent(node1);
						node1.addToSplit(n.getSplit());
					}
					
					node1.setParent(node);
					tree.addNode(node1);
					tree.addSplit(node1.getSplit());
					if (node1.getChildren().size() > 2)
					{
						nodesToBreak.add(node1);
					}
					
					node.getChildren().removeAll(set1);
					node.getChildren().add(node1);
				}
				
				if (set2.size() > 1)
				{
					int capacity = 0;
					for (Node node_ : set1)
					{
						capacity += node_.getSplit().size();
					}
					
					Node node2 = new Node(capacity);
					node2.getChildren().addAll(set2);
					for (Node n : set2)
					{
						n.setParent(node2);
						node2.addToSplit(n.getSplit());
					}
					
					node2.setParent(node);
					tree.addNode(node2);
					tree.addSplit(node2.getSplit());
					if (node2.getChildren().size() > 2)
					{
						nodesToBreak.add(node2);
					}
					
					node.getChildren().removeAll(set2);
					node.getChildren().add(node2);
				}
				
			}
			
		}
		
	}
	
	/**
	 * resolveConflict
	 * 
	 * @param i
	 * @param j
	 * 
	 * @return
	 */
	private int resolveConflict(int i, int j)
	{
		Set<Short> split1 = originalSplits.get(i);
		Set<Short> split2 = originalSplits.get(j);
		int counter = 0;
		for (int k = i + 1 ; k < j ; k++)
		{
			if (guideTrees[k].containsSplit(split1))
			{
				counter += addSplitToTree(k, localTrees[k], split1, false, false, true);
			}
			else if (guideTrees[k].containsSplit(split2))
			{
				counter += addSplitToTree(k, localTrees[k], split2, false, false, true);
			}
			
		}
		
		return counter;
	}
	
	/**
	 * timeSplitOverrideRule
	 */
	private void timeSplitOverrideRule()
	{
		System.out.print("Incompatible Region Rule");
		Date startDate = new Date();
		int counter = 0;
		for (int i = 0 ; i < guideTrees.length - 1 ; i++)
		{
			Set<Short> split1 = originalSplits.get(i);
			if (!split1.isEmpty())
			{
				HashMap<Set<Short>, Integer> passedSplits = new LinkedHashMap<Set<Short>, Integer>();
				for (int j = i + 1 ; j < guideTrees.length ; j++)
				{
					Set<Short> split2 = originalSplits.get(j);
					if (!split2.isEmpty())
					{
						if (split1.equals(split2) || split1.equals(reverseSplit(split2)))
						{
							break;
						}
						else if (!isCompatible(originalSplits.get(i), originalSplits.get(j)))
						{
							Set<Set<Short>> keySet = passedSplits.keySet();
							List<Set<Short>> keyList = new ArrayList<Set<Short>>();
							keyList.addAll(keySet);
							boolean takenCareOf = false;
							for (int k = keyList.size() - 1 ; k >= 0 ; k--)
							{
								Set<Short> split = keyList.get(k);
								if (!isCompatible(split, split2))
								{
									counter += resolveConflict(passedSplits.get(split), j);
									takenCareOf = true;
									break;
								}
								
							}
							
							if (!takenCareOf)
							{
								counter += resolveConflict(i, j);
							}
							
							break;
						}
						else
						{
							Set<Set<Short>> keySet = passedSplits.keySet();
							List<Set<Short>> keyList = new ArrayList<Set<Short>>();
							keyList.addAll(keySet);
							for (int k = keyList.size() - 1 ; k >= 0 ; k--)
							{
								Set<Short> split = keyList.get(k);
								if (!isCompatible(split, split2))
								{
									counter += resolveConflict(passedSplits.get(split), j);
									passedSplits.remove(split);
								}
								
							}
							
							passedSplits.remove(reverseSplit(split2));
							passedSplits.put(split2, j);
						}
						
					}
					
				}
				
			}
			
		}
		
		System.out.println(	" [" +	(double) (new Date().getTime() - startDate.getTime()) / 1000 +
									" Seconds] ");
		// System.out.println("(" + counter + ")");
	}
	
}
