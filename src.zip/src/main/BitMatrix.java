/**
 * BitMatrix
 */
package main;

import dna.XBitSet;

/**
 * @author benba
 *
 */
public class BitMatrix
{
	XBitSet[] b;
	BitMatrix(int rows, int cols)
	{
		b = new XBitSet[rows];
		for (int row=0; row < rows; row++)
		{
			b[row] = new XBitSet(cols);
		}
	}
	
	void assign(int row, int col, int val) throws Exception
	{
		b[row].assign(col, val);
	}
	
	void assign(int row, int col, boolean val)
	{
		b[row].assign(col, val);
	}
	
	boolean get(int row, int col)
	{
		return b[row].get(col);
	}
	
	int getInt(int row, int col)
	{
		return b[row].getInt(col);
	}
}
