
package dna;

import java.awt.EventQueue;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.io.Serializable;
import java.lang.System;

import Autosomal_Segment_Analyzer.DefaultMatchBits;

public class Dna implements Serializable
{
	static final long serialVersionUID = 1;
	static final String preferencesNode = "dna.prefs";
	public static DefaultMatchBits dmb = new DefaultMatchBits();
	
	/**
	 * Launch the application.
	 * 
	 * @param args - arguments
	 */
	public static void main(String[] args)
	{
		DnaPreferences.loadPreferences();
		
		// reassign output
		// maybe get default file path?
		try
		{
			System.setOut(new PrintStream(new File("outputfile.txt")));
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				// create window and make visible
				DnaFrame.initialize();
			}
		});
	}
	
	/**
	 * Constructor
	 */
	public Dna()
	{
		// create the window contents, make visible and run
		DnaFrame.initialize();
	}
}
