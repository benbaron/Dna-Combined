/**
 * DNAPainterMatch
 */
package dna;

import org.apache.commons.csv.CSVRecord;

/**
 * @author  benba
 */
public class DNAPainterMatch
{
	private String Chr;
	private Long Start;
	private Long End;
	private Float cM;
	private Long SNPs;
	private String Match;
	private String Confidence;
	private String Group;
	private String Side;
	private String Notes;
	private String Colour;
	private String Ancestor;
	
	/**
	 * Constructor
	 * @param line to parse
	 */
	public DNAPainterMatch(CSVRecord aLine)
	{
		Chr = aLine.get(0);
		Start = Long.parseLong(aLine.get(1).replaceAll(",",""));
		End = Long.parseLong(aLine.get(2).replaceAll(",",""));
		cM = Float.parseFloat(aLine.get(3));
		SNPs = Long.parseLong(aLine.get(4).replaceAll(",",""));
		Match = aLine.get(5);        // i.e. person name
		Confidence = aLine.get(6);
		Group = aLine.get(7);        // text group name
		Side = aLine.get(8);
		Notes = aLine.get(9);
		Colour = aLine.get(10);
		Ancestor = aLine.get(10);
	}

	/**
	 * @return dna painter match
	 */
	public DNAPainterMatch get()
	{
		return this;
	}

	/**
	 * @return name : String
	 */
	public String getName()
	{
		return Match;
	}

	/**
	 * @return centimorgans: Float
	 */
	public Float getCm()
	{
		return cM;
	}

	/**
	 * @return group string : String
	 */
	public String getGroup()
	{
		return this.Group;
	}

}