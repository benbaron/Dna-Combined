package dna;

import org.apache.commons.csv.CSVRecord;

import dna.Match.MatchSegment;

/**
 * class ParsedCSVLine
 * 
 * @author benba
 */
class ParsedCSVLine
{
	PersonInfo p;
	Match m;
	MatchSegment ms;
	
	// @formatter:off
	
	/**
	 * Constructor
	 * parse 23 and me match data
	 * @param aLine - aline
	 */
	public ParsedCSVLine()
	{
		try
		{	
			this.p = new PersonInfo();
			this.m = new Match();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Ingest a 23andMe ICW file line
	 * @param aLine : CSV line to ingest
	 */
	void ingestRecord(CSVRecord aLine)
	{
		try
		{
			p.DisplayName = aLine.get(0);
			p.Surname = aLine.get(1);

			// Each Record contains a duplicate version
			// of the person info and a further match
			
			// split the 2 parts, to allow deduplicating
			// the redundant information
			
			// if there is a match portion of the record (some records
			// do not mention a match).
			if (aLine.get(2) != "")
			{
				ms.ChromosomeNumber = Match.toChNum(aLine.get(2));
				ms.ChromosomeStartPoint = Long.parseLong(aLine.get(3));
				ms.ChromosomeEndPoint = Long.parseLong(aLine.get(4));
				ms.GeneticDistance = Double.parseDouble(aLine.get(5));
				ms.NumSNPs = Long.parseLong(aLine.get(6));
				m.Valid = true;
			}

			p.FullIBD = aLine.get(7);
			p.LinktoProfilePage = aLine.get(8);
			p.Sex = aLine.get(9);
			p.BirthYear = aLine.get(10);
			p.SetRelationship = aLine.get(11);
			p.PredictedRelationship = aLine.get(12);
			p.RelativeRange = aLine.get(13);
			p.PercentDNAShared = aLine.get(14);
			p.NumSegmentsShared = Long.parseLong(aLine.get(15));
			p.MaternalSide = aLine.get(16);
			p.PaternalSide = aLine.get(17);
			p.MaternalHaplogroup = aLine.get(18);
			p.PaternalHaplogroup = aLine.get(19);
			p.FamilySurnames = aLine.get(20);
			p.FamilyLocations = aLine.get(21);
			p.MaternalGrandmotherBirthCountry = aLine.get(22);
			p.MaternalGrandfatherBirthCountry = aLine.get(23);
			p.PaternalGrandmotherBirthCountry = aLine.get(24);
			p.PaternalGrandfatherBirthCountry = aLine.get(25);
			p.Notes = aLine.get(26);
			p.SharingStatus = aLine.get(27);
			p.ShowingAncestryResults = aLine.get(28);
			p.FamilyTreeURL = aLine.get(29);

		}
		catch (NumberFormatException e)
		{
			// in the case of an incomplete record.
			m.Valid = false;
		}

	}
	
	public Match getMatch()
	{
		return m;
	}

	public PersonInfo getPersonInfo()
	{
		return p;
	}

} // class parsedCsvLine