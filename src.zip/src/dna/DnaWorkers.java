package dna;

import java.io.File;
import java.util.Properties;

import javax.swing.SwingWorker;

import Autosomal_Segment_Analyzer.*;
import main.Main;

/**
 * https://docs.oracle.com/javase/7/docs/api/javax/swing/SwingWorker.html
 * 
 * @author benba
 * 
 * java.lang.Object
 * 
 * javax.swing.SwingWorker<T,V>
 * 
 * Type Parameters:
 * T - the result type returned by this SwingWorker's doInBackground():T and get():T methods
 * V - the type used for carrying out intermediate results by this SwingWorker's publish():V and process():V methods
 * 
 * Before the doInBackground method is invoked on a worker thread, 
 * 1. SwingWorker notifies any PropertyChangeListeners about the state property change to StateValue.STARTED. 
 * 2. After the doInBackground():T method is finished the done(): method is executed. 
 * 3. Then SwingWorker notifies any PropertyChangeListeners about the state property change to StateValue.DONE.
 * 
 * There are three threads involved in the life cycle of a SwingWorker :

Current thread: The execute() method is called on this thread. It schedules SwingWorker for 
the execution on a worker thread and returns immediately. One can wait for the SwingWorker 
to complete using the get methods.

Worker thread: The doInBackground() method is called on this thread. 
This is where all background activities should happen. 
To notify PropertyChangeListeners about bound properties changes use the 
firePropertyChange() and getPropertyChangeSupport() methods. 
By default there are two bound properties available: 
state and progress.

Event Dispatch Thread: All Swing related activities occur on this thread. 
SwingWorker invokes the process() and done() methods and notifies any PropertyChangeListeners on this thread.

Often, the Current thread is the Event Dispatch Thread.

Before the doInBackground() method is invoked on a worker thread, 
SwingWorker notifies any PropertyChangeListeners about the state property change to StateValue.STARTED. 
After the doInBackground() method is finished the done() method is executed. 
Then SwingWorker notifies any PropertyChangeListeners about the state property change to StateValue.DONE.
 */


public class DnaWorkers
{
	/****************************************************************/
	/**
	 * inner class ParseDNAPainter
	 * @author benba
	 *
	 */
	//                                                       <T, V>
	public static class ParseDNAPainter extends SwingWorker<Object, Object>
	{
		static ParseDNAPainter task;
		static File dnaPainterFile;
		
		/**-
		 * doParseDNAPainter
		 * @param DNAPainterFile file to parse
		 * --> On actionPerformed()
		 */
		public static void doParseDNAPainter(File dnaPainterFile)
		{
			task = new ParseDNAPainter(dnaPainterFile);
			task.execute();
		}
		
		/**
		 * Constructor
		 * @param dnaPainterFile
		 */
		public ParseDNAPainter(File dnaPainterFile)
		{
			ParseDNAPainter.dnaPainterFile = dnaPainterFile;
		}

		
		@Override
		/**
		 * @return T
		 */
		protected Object doInBackground() throws Exception
		{
			parseDNAPainterWorker(dnaPainterFile);
			return null;
		}
		
		/**
		 * @param dnaPainterFile
		 */
		public static void parseDNAPainterWorker(File dnaPainterFile)
		{
			try
			{
				DnaDNAPainterReader.dnaReadCsvDNAPainterUsingParser(dnaPainterFile);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
		}

	}
		
	
	/****************************************************************/
	/**
	 * inner class ParseICW
	 * @author benba
	 *
	 */
	//                                              <T, V>
	public static class ParseICW extends SwingWorker<Object, Object>
	{
		static ParseICW task;
		static File iCWFile;
		
		/**
		 * doParseICW
		 * --> On actionPerformed()
		 * @param iCWFile ICW filename
		 */
		public static void doParseICW(File iCWFile)
		{
			task = new ParseICW(iCWFile);
			task.execute();
		}
		
		
		/**
		 * Constructor
		 * @param iCWFile
		 */
		public ParseICW(File iCWFile)
		{
			ParseICW.iCWFile = iCWFile;
		}

		@Override
		/**
		 * @return T
		 */
		protected Object doInBackground() throws Exception
		{
			parseICWWorker(iCWFile);
			return null;
		}
		
		/**
		 * @param iCWFile
		 */
		public static void parseICWWorker(File iCWFile)
		{
			try
			{
				System.out.println("Load Maps");
				CompareUtil.loadMaps();
				
				System.out.println("Build Distances");
				CompareUtil.buildDistancesFile();
				
				System.out.println("Create default bits");
				CompareUtil.setDefaultMatchBits();
				
				System.out.println("Read CSV File " + iCWFile.toString());
				Dna23AndMeReader.dnaReadCsvUsingParser(iCWFile);
			
				System.out.println("Match SNPs " + iCWFile.toString());
				Dna23AndMeReader.matchRecordsToSNPs();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
		}

	}
		
	
	/****************************************************************/
	/**
	 * LoadMaps
	 * @author benba
	 */
	public static class LoadMaps extends SwingWorker<Object, Object>
	{
		static LoadMaps task;
		/**
		 * doLoadMaps
		 * --> On actionPerformed()
		 */
		public static void doLoadMaps()
		{
			task = new LoadMaps();
			task.execute();
		}
		
		@Override
		protected Object doInBackground() throws Exception
		{
			loadMapsWorker();
			return null;
		}
		
		public static void loadMapsWorker()
		{
			/// load dna snp data
			try
			{
				CompareUtil.loadMaps();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
	}
	
	/****************************************************************/
	/**
	 * BuildDistancesFiles
	 * @author benba
	 */
	public static class BuildDistancesFiles extends SwingWorker<Object, Object>
	{
		static BuildDistancesFiles task;
		
		/**
		 * doBuildDistancesFiles()
		 * --> On actionPerformed()
		 */
		public static void doBuildDistancesFiles()
		{
			task = new BuildDistancesFiles();
			task.execute();
		}
		
		@Override
		protected Object doInBackground() throws Exception
		{
			BuildDistancesFilesWorker();
			return null;
		}
		
		public static void BuildDistancesFilesWorker()
		{
			/// load dna snp data
			try
			{
				CompareUtil.loadMaps();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
			try
			{
				CompareUtil.buildDistancesFile();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}

		}
			
	}
	
	/****************************************************************/
	/**
	 * OutputHapMatrix
	 * @author benba
	 *
	 */
	public static class OutputHapMatrix extends SwingWorker<Object, Object>
	{
		static OutputHapMatrix task;
		/**
		 * doOutputHapMatrix()
		 * --> On actionPerformed()
		 */
		public static void doOutputHapMatrix()
		{
			task = new OutputHapMatrix();
			task.execute();
		}
		
		@Override
		protected Object doInBackground() throws Exception
		{
			OutputHapMatrixWorker();
			return null;
		}
		
		public static void OutputHapMatrixWorker()
		{
			try
			{
				String hapFileName = DnaPreferences.getHapFilename();
				DNAPainterHapMatrix.writeHapMatrix(hapFileName);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
		}
	}
	
	/****************************************************************/
	/**
	 * RunRentPlus
	 * @author benba
	 *
	 */
	public static class RunRentPlus extends SwingWorker<Object, Object>
	{
		static RunRentPlus task;
		/**
		 * doRunRentPlus()
		 * --> On actionPerformed()
		 */
		public static void doRunRentPlus()
		{
			task = new RunRentPlus();
			task.execute();
		}
		
		@Override
		protected Object doInBackground() throws Exception
		{
			RunRentPlusWorker();
			return null;
		}
		
		public static void RunRentPlusWorker()
		{
			try
			{
				Properties p = System.getProperties();
				String args[] = {	p.getProperty("user.dir") + "\\" + "rentout.txt"};
				new Main(args);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
		}
	}
	
}
