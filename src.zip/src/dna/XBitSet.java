/**
 * XBitSet
 */
package dna;

import java.util.BitSet;

/**
 * @author benba
 *
 */
public class XBitSet extends BitSet
{	
	/**
	 * long
	 */
	private static final long serialVersionUID = 1L;
	private int maxLength;
	
	public XBitSet()
	{
		super(); // BitSet constructor
		maxLength = 0;
	}

	public XBitSet(int nbits)
	{
		super(nbits);
		maxLength = nbits;
	}
	
	/**
	 * Returns the maximum index (counting both 0s and 1s) seen by
	 * the set/clear methods. This differs from the base class
	 * which only regards 1s.
	 */
	public int length()
	{
		return maxLength;
	}
	
	static final Exception e = new Exception("Bad assign index");
	
	/**
	 * @param bitIndex bit index to assign
	 * @param b value 0/1
	 */
	public void assign(int bitIndex, boolean b)
	{
		if (b == true)
		{
			set(bitIndex);
		}
		else
		{
			clear(bitIndex);
		}
	}
	
	
	public void assign(int bitIndex, int i) throws Exception
	{
		switch (i)
		{
			case 0:
				clear(bitIndex);
				break;
			case 1:
				set(bitIndex);
				break;
			default:
				throw(e);
		}
	}
	
	/**
	 * Return value of bit as integer (super class returns boolean,
	 * for reasons that are obscure)
	 * @param bitIndex bit position i.e. index of bit
	 * @return integer value of boolean bit
	 */
	public int getInt(int bitIndex)
	{
		return super.get(bitIndex) == true ? 1 : 0;
	}
	
	public void clear(int bitIndex)
	{
		super.clear(bitIndex);
		if (bitIndex > maxLength)
		{
			maxLength = bitIndex;
		}
	}
	
	public void set(int bitIndex)
	{
		super.set(bitIndex);
		if (bitIndex > maxLength)
		{
			maxLength = bitIndex;
		}
	}
	
	/** 
	 * Concatinate XBitSets.
	 * This is optimized to only set bits, since the default bits are 0.
	 * @param b
	 * @return new XBitSet
	 */
	public XBitSet concat(XBitSet b)
	{
		XBitSet outBitSet = (XBitSet) this.clone();
		int index = this.maxLength;
	
		int bIndex = 0;
		while((bIndex = b.nextSetBit(bIndex)) != -1) 
		{
			outBitSet.set(index+bIndex);
			outBitSet.maxLength = this.maxLength + b.maxLength;
		}
		return outBitSet;
		
	}

	
}


