/**
 * PopulationSorter
 */
package dna;

import java.util.Map;
import java.util.TreeMap;

/**
 * @author benba
 *
 */
public class PopulationSorter
{
	
	public static TreeMap<DistanceMetric, Person> ancestorList = new TreeMap<DistanceMetric, Person>();
	
	public class DistanceMetric
	{
		
	}
	
	void sortFamily()
	{
		for (Map.Entry<String, Person> entry : Dna23AndMeReader.getPersonMap().entrySet())
		{
			Person p = entry.getValue();
			
			DistanceMetric d = calcDistanceMetric(p);
			
			ancestorList.put(d,p);
		}
		
				
		while (true)
		{
			
		}
			
	}

	/**
	 * @param p
	 * @return distance metric
	 */
	private DistanceMetric calcDistanceMetric(Person p)
	{
		// TODO Auto-generated method stub
		return null;
	}

	
}
