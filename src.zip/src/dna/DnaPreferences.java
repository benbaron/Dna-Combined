package dna;

import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

public class DnaPreferences
{
	private static String ICWFilename = "";
	private static String SNPFilename = "";
	private static String defaultDir = "";
	private static String HapFilename = "";
	private static String RentFilename = "";
	private static String DNAPFilename = "";
	
	public static void deletePreferencesNode()
	{
		Preferences appPrefs = Preferences.userRoot().node(Dna.preferencesNode);
		try
		{
			appPrefs.removeNode(); // deletes all the preferences
		}
		catch (BackingStoreException e)
		{
			e.printStackTrace();
		}
		
	}
	
	public static void loadPreferences()
	{
		Preferences appPrefs = Preferences.userRoot().node(Dna.preferencesNode);
		DnaPreferences.defaultDir = appPrefs.get("defaultDir", "");
		DnaPreferences.SNPFilename = appPrefs.get("SNPFilename", "");
		DnaPreferences.ICWFilename = appPrefs.get("ICWFilename", "");	
		DnaPreferences.HapFilename = appPrefs.get("HapFilename", "");
		DnaPreferences.RentFilename = appPrefs.get("RentFilename", "");
		DnaPreferences.DNAPFilename = appPrefs.get("DNAPFilename", "");
	}
	
	public static void savePreferences()
	{
		Preferences appPrefs = Preferences.userRoot().node(Dna.preferencesNode);
		appPrefs.put("defaultDir", defaultDir);
		appPrefs.put("SNPFilename", SNPFilename);
		appPrefs.put("ICWFilename", ICWFilename);
		appPrefs.put("HapFilename", HapFilename);
		appPrefs.put("RentFilename", RentFilename);
		appPrefs.put("DNAPFilename", DNAPFilename);
	
		try
		{
			appPrefs.flush();
		}
		catch (BackingStoreException e)
		{
			e.printStackTrace();
		}
	}

	//// GETTERS ////
	public static String getDefaultDir()
	{
		DnaPreferences.loadPreferences();
		return DnaPreferences.defaultDir;
	}
	
	public static String getICWFilename()
	{
		DnaPreferences.loadPreferences();
		return DnaPreferences.ICWFilename;
	}

	public static String getSNPFilename()
	{
		DnaPreferences.loadPreferences();
		return DnaPreferences.SNPFilename;
	}
	
	public static String getHapFilename()
	{
		DnaPreferences.loadPreferences();
		return DnaPreferences.HapFilename;
	}

	public static String getDNAPFilename()
	{
		DnaPreferences.loadPreferences();
		return DnaPreferences.DNAPFilename;
	}
	
	//// SETTERS ////
	
	public static void setSNPFilename(String string)
	{
		DnaPreferences.SNPFilename = string;
		DnaPreferences.savePreferences();		
	}

	public static void setICWFilename(String string)
	{
		DnaPreferences.ICWFilename = string;
		DnaPreferences.savePreferences();		
	}

	public static void setDefaultDir(String defaultDir)
	{		
		DnaPreferences.defaultDir = defaultDir;
		DnaPreferences.savePreferences();		
	}
	
	public static void setHapFilename(String string)
	{
		DnaPreferences.HapFilename = string;
		DnaPreferences.savePreferences();	
	}
	public static void setDNAPFilename(String string)
	{
		DnaPreferences.DNAPFilename = string;
		DnaPreferences.savePreferences();		
	}

	

	

}