/**
 * PreferencesDialog
 */
package dna;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.GridBagLayout;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

/**
 * @author benba
 *
 */
public class PreferencesDialog extends JDialog
{
	/**
	 * long serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private static PreferencesDialog dialog;
	String DefaultDirString = "";
	
	/**
	 * Launch the application.
	 */
	public static void createPreferencesDialog()
	{
		try
		{
			dialog = new PreferencesDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setIconImage(Toolkit.getDefaultToolkit()
												.getImage("C:\\Users\\benba\\eclipse-workspace\\dna_combine\\pngtree-vector-dna-icon-png-image_4247671.jpg"));
			dialog.setTitle("Preferences");
			dialog.setVisible(true);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Create the dialog.
	 */
	public PreferencesDialog()
	{
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		GridBagLayout gbl_contentPanel = new GridBagLayout();
		gbl_contentPanel.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPanel.rowHeights = new int[]{0, 0};
		gbl_contentPanel.columnWeights = new double[]{	1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
																		Double.MIN_VALUE};
		gbl_contentPanel.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		contentPanel.setLayout(gbl_contentPanel);
		{
			JTextArea txtrDoesNothingFor = new JTextArea();
			txtrDoesNothingFor.setText("Does nothing for now");
			GridBagConstraints gbc_txtrDoesNothingFor = new GridBagConstraints();
			gbc_txtrDoesNothingFor.insets = new Insets(0, 0, 0, 5);
			gbc_txtrDoesNothingFor.fill = GridBagConstraints.BOTH;
			gbc_txtrDoesNothingFor.gridx = 0;
			gbc_txtrDoesNothingFor.gridy = 0;
			contentPanel.add(txtrDoesNothingFor, gbc_txtrDoesNothingFor);
		}
		
		// Button Pane
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			
			// Apply
			{
				JButton okButton = new JButton("Apply");
				okButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						DnaPreferences.setDefaultDir(DefaultDirString);
					}
				});
				okButton.setActionCommand("Apply");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			
			// Cancel
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						dialog.dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
			
		}
		
	}
	
}
