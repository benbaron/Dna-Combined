package dna;

/**
 * class PersonInfoDnaPainter
 * 
 * @author benba
 */
class PersonInfo
{
	String DisplayName;
	String Surname;
	String FullIBD;
	String LinktoProfilePage;
	String Sex;
	String BirthYear;
	String SetRelationship;
	String PredictedRelationship;
	String RelativeRange;
	String PercentDNAShared;
	long NumSegmentsShared;
	String MaternalSide;
	String PaternalSide;
	String MaternalHaplogroup;
	String PaternalHaplogroup;
	String FamilySurnames;
	String FamilyLocations;
	String MaternalGrandmotherBirthCountry;
	String MaternalGrandfatherBirthCountry;
	String PaternalGrandmotherBirthCountry;
	String PaternalGrandfatherBirthCountry;
	String Notes;
	String SharingStatus;
	String ShowingAncestryResults;
	String FamilyTreeURL;

	public String toString()
	{
		String s = DisplayName + ";" +
						Surname + ";" +
						FullIBD + ";" +
						LinktoProfilePage + ";" +
						Sex + ";" +
						BirthYear + ";" +
						SetRelationship + ";" +
						PredictedRelationship + ";" +
						RelativeRange + ";" +
						PercentDNAShared + ";" +
						NumSegmentsShared + ";" +
						MaternalSide + ";" +
						PaternalSide + ";" +
						MaternalHaplogroup + ";" +
						PaternalHaplogroup + ";" +
						FamilySurnames + ";" +
						FamilyLocations + ";" +
						MaternalGrandmotherBirthCountry + ";" +
						MaternalGrandfatherBirthCountry + ";" +
						PaternalGrandmotherBirthCountry + ";" +
						PaternalGrandfatherBirthCountry + ";" +
						Notes + ";" +
						SharingStatus + ";" +
						ShowingAncestryResults + ";" +
						FamilyTreeURL + ";";
		return s;
	}

	public void print()
	{
		String s = toString();
		// doc.insertString(doc.getLength(), s, null);

		DnaFrame.TextAreaOutputStream.getTextArea().append(s);
		DnaFrame.TextAreaOutputStream.getTextArea().append("------------------------------------\n");
	}

	public String getName()
	{
		return this.DisplayName;
	}

} //personInfo