package dna;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;

import Autosomal_Segment_Analyzer.CompareUtil;

import javax.swing.JProgressBar;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import java.awt.Toolkit;

/**
 * DnaFrame - DNA package visible window
 * 
 * @author benba
 */
public class DnaFrame extends JFrame
{
	static File SNPFile;
	static File ICWFile;
	static File hapFile;
	static File dnaPainterFile;
	
	/**
	 * long
	 */
	private static final long serialVersionUID = 1L;
	
	
	/*********************************************************************/
	/**
	 * @author benba
	 *
	 */
	public static class ProgressBarStatus
	{
		private static int counter = 0;
		private static int percentDone = 0;
		private static int htsize = 0;
		
		/**
		 * @param htsize total number of iterations
		 */
		public static void setProgressBarStatus(int htsize)
		{
			DnaFrame.unsetProgressBarIndeterminate();
			ProgressBarStatus.counter = 0;
			ProgressBarStatus.htsize = htsize;
			DnaFrame.setProgressBar(0);
		}
		
		/**
		 * 
		 */
		public static void barNextCount()
		{
			percentDone = (counter++ * 100) / htsize;
			DnaFrame.setProgressBar(percentDone);
		}
		
		public static void barDone()
		{
			DnaFrame.setProgressBar(100);
			DnaFrame.setProgressBarIndeterminate();
		}
		
		public static void barDone(int value)
		{
			DnaFrame.setProgressBar(100);
			DnaFrame.setProgressBarIndeterminateValue(value);
		}

		public static void barDone(boolean stop)
		{
			DnaFrame.setProgressBar(0);
		}

	}
	
	/**
	 * JFrame dnaFrame
	 */
	protected static JFrame dnaFrame;
	
	protected static JProgressBar progressBar;
	protected static JProgressBar progressBar_1;
	/**
	 * 
	 */
	public static void refreshDnaFrame()
	{
		dnaFrame.revalidate();
		dnaFrame.repaint();
	}
	
	static final Color red = new Color(255, 0, 0); // see
																	 // https://www.rapidtables.com/web/color/RGB_Color.html
	static final Color green = new Color(34, 139, 34); // see
																		 // https://www.rapidtables.com/web/color/RGB_Color.html
	
	public static void setProgressBar(int value)
	{
		if (value < 100)
		{
			progressBar.setForeground(red);
		}
		else
		{
			progressBar.setForeground(green);
		}
		
		progressBar.setValue(value);
		progressBar.setStringPainted(true);
		String s = Integer.toString(value);
		progressBar.setString(s + "%");
	}
	
	public static void setProgressBarIndeterminate()
	{
		progressBar.setIndeterminate(true);
	}
	
	public static void setProgressBarIndeterminateValue(int value)
	{
		progressBar.setIndeterminate(true);
		progressBar.setValue(value);
	}
	
	
	public static void unsetProgressBarIndeterminate()
	{
		progressBar.setIndeterminate(false);
	}
	
	/**
	 * @param value - bar value
	 */
	public static void setMinorBar(int value)
	{
		if (value % 100 == 0)
		{
			System.out.println(value);
			progressBar_1.setValue(1);
			String s = Integer.toString(value);
			progressBar_1.setString(s);
		}
		
	}
	
	
	
	/*********************************************************************/
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void initialize()
	{
		System.setProperty("file.encoding", "UTF-8");
		
		// initialize from preferences
		dnaPainterFile = new File(DnaPreferences.getDNAPFilename());
		ICWFile 			= new File(DnaPreferences.getICWFilename());
		SNPFile 			= new File(DnaPreferences.getSNPFilename());
		hapFile 			= new File(DnaPreferences.getHapFilename());
		
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch (ClassNotFoundException | InstantiationException | IllegalAccessException
					| UnsupportedLookAndFeelException e1)
		{
			e1.printStackTrace();
		}
		
		dnaFrame = new JFrame();
		dnaFrame.setIconImage(Toolkit	.getDefaultToolkit()
												.getImage("C:\\Users\\benba\\eclipse-workspace\\dna_combine\\pngtree-vector-dna-icon-png-image_4247671.jpg"));
		dnaFrame.setTitle("DnaCombined");
		
		dnaFrame.addWindowListener(new WindowAdapter()
		{
			@Override
			public void windowClosed(WindowEvent e)
			{
				System.exit(0);
			}
			
			@Override
			public void windowClosing(WindowEvent e)
			{
				try
				{
					DNAPainterHapMatrix.closeWriter();
					CompareUtil.closeWriter();
				}
				catch (IOException e1)
				{
					e1.printStackTrace();
				}
				
				DnaPreferences.savePreferences();
				System.exit(0);
			}
			
		});
		
		
		dnaFrame.setBounds(100, 100, 582, 526);
		dnaFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		////////////////////////////////////////////
		///////////////// MENU BAR /////////////////
		JMenuBar menuBar = new JMenuBar();
		dnaFrame.setJMenuBar(menuBar);
		
		///////////////////////////////////////
		////////////////// FILE ///////////////
		JMenu mnMenuFile = new JMenu("File");
		menuBar.add(mnMenuFile);
		
		///////////////// FILE->OPEN //////////////
		JMenu mnMenuFile_Open = new JMenu("Open");
		mnMenuFile.add(mnMenuFile_Open);
		
		///////////////// FILE->OPEN->DNA PAINTER_FILE //////////////
		JMenuItem mntmOpen_DNAPainter_FileMenuItem = new JMenuItem("choose input DNA Painter Matches file");
		mnMenuFile_Open.add(mntmOpen_DNAPainter_FileMenuItem);
		mntmOpen_DNAPainter_FileMenuItem.addActionListener(new OpenFileActionListener(mntmOpen_DNAPainter_FileMenuItem, 
		                                                                              dnaPainterFile));
		
		///////////////// FILE->OPEN->ICW_FILE //////////////
		JMenuItem mntmOpen_ICW_FileMenuItem = new JMenuItem("choose input 23AndMe ICW file");
		mnMenuFile_Open.add(mntmOpen_ICW_FileMenuItem);
		mntmOpen_ICW_FileMenuItem.addActionListener(new OpenFileActionListener(mntmOpen_ICW_FileMenuItem, 
		                                                                       ICWFile));
		
		///////////////// FILE->OPEN->SNP_MATCHED_FILE //////////////
		JMenuItem mntmOpen_SNPMatched23AndMeMenuItem = new JMenuItem("choose output SNP matched 23AndMe ICW");
		mnMenuFile_Open.add(mntmOpen_SNPMatched23AndMeMenuItem);
		mntmOpen_SNPMatched23AndMeMenuItem.addActionListener(new OpenFileActionListener(mntmOpen_SNPMatched23AndMeMenuItem,
		                                                                                SNPFile));
		
		///////////////// FILE->OPEN->HAP_MATCHED_FILE //////////////
		JMenuItem mntmOpen_File_MatchedMenuItem = new JMenuItem("choose output Hap matched 23AndMe ICW");
		mnMenuFile_Open.add(mntmOpen_File_MatchedMenuItem);
		mntmOpen_File_MatchedMenuItem.addActionListener(new OpenFileActionListener(mntmOpen_File_MatchedMenuItem,
		                                                                           hapFile));
		
		
		///////////////// ACTIONS //////////////
		JMenu mnMenu_Actions = new JMenu("Actions");
		menuBar.add(mnMenu_Actions);
		
		///////////////// ACTIONS->PARSE ICW FILE //////////////
		JMenuItem mntmAction_MatchSNPs = new JMenuItem("Parse ICW File");
		mntmAction_MatchSNPs.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				DnaWorkers.ParseICW.doParseICW(ICWFile);
			}
			
		});
		mnMenu_Actions.add(mntmAction_MatchSNPs);
		
		///////////////// ACTIONS->PARSE DNA PAINTER FILE //////////////
		JMenuItem mntmAction_DNAPainter = new JMenuItem("Parse DNAPainter File");
		mntmAction_DNAPainter.addActionListener(new ActionListener()
		{
			
			public void actionPerformed(ActionEvent e)
			{
				DnaWorkers.ParseDNAPainter.doParseDNAPainter(dnaPainterFile);
			}
			
		});
		mnMenu_Actions.add(mntmAction_DNAPainter);
		
		
		///////////////// ACTIONS->LOAD MAPS //////////////
		JMenuItem mntmAction_LoadMaps = new JMenuItem("Load Maps");
		mntmAction_LoadMaps.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				DnaWorkers.LoadMaps.doLoadMaps();
			}
			
		});
		mnMenu_Actions.add(mntmAction_LoadMaps);
		
		///////////////// ACTIONS->BUILD DISTANCE FILE //////////////
		JMenuItem mntmAction_BuildDistanceFile = new JMenuItem("Build Distance File");
		mntmAction_BuildDistanceFile.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				DnaWorkers.BuildDistancesFiles.doBuildDistancesFiles();
			}
			
		});
		mnMenu_Actions.add(mntmAction_BuildDistanceFile);
		
		///////////////// ACTIONS->HAP MATRIX FILE //////////////
		JMenuItem mntmAction_HapMatrix = new JMenuItem("Output DNAPainterHapMatrix");
		mntmAction_HapMatrix.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				DnaWorkers.OutputHapMatrix.doOutputHapMatrix();
			}
			
		});
		mnMenu_Actions.add(mntmAction_HapMatrix);
		
		
		///////////////// ACTIONS->RUN_RENT_PLUS //////////////
		JMenuItem mntmAction_RunRentPlus = new JMenuItem("Run RentPlus");
		mntmAction_RunRentPlus.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				DnaWorkers.RunRentPlus.doRunRentPlus();
			}
			
		});
		mnMenu_Actions.add(mntmAction_RunRentPlus);
		
		////////// PREFERENCES MENU //////////////
		JMenu mnNewMenu = new JMenu("Properties");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Properties");
		mntmNewMenuItem.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				PreferencesDialog.createPreferencesDialog();
			}
			
		});
		mntmNewMenuItem.setSelected(true);
		mnNewMenu.add(mntmNewMenuItem);
		
		/////////////////////////////////////
		/////////// PROGRESS BAR ////////////
		progressBar = new JProgressBar();
		dnaFrame.getContentPane().add(progressBar, BorderLayout.NORTH);
		progressBar.setValue(0);
		
		////////////////////////////////////
		/////////// TEXT AREA //////////////
		JScrollPane scrollPane = new JScrollPane();
		dnaFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
		
		JTextArea jTextArea1 = new JTextArea();
		jTextArea1.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
		
		jTextArea1.addInputMethodListener(new InputMethodListener()
		{
			public void caretPositionChanged(InputMethodEvent event)
			{
			}
			
			public void inputMethodTextChanged(InputMethodEvent event)
			{
			}
			
		});
		
		scrollPane.setViewportView(jTextArea1);
		
		// set output stream to the out window
		setupOutputStream(jTextArea1);
		
		progressBar_1 = new JProgressBar();
		scrollPane.setColumnHeaderView(progressBar_1);
		
		/// SET FRAME VISIBLE ///
		dnaFrame.setVisible(true);
	} // initialize
	
	
	/**
	 * get Frame
	 * 
	 * @return dnaFrame
	 */
	public static JFrame getFrame()
	{
		return dnaFrame;
	}
	
	/**
	 * point stdout, stderr to textArea
	 * 
	 * @param textArea output stream text area
	 */
	public static void setupOutputStream(JTextArea textArea)
	{
		//		@formatter:off
		PrintStream outStream = new PrintStream(
		     new TextAreaOutputStream(textArea, 1000));
		
		//		@formatter:on
		System.setOut(outStream);
		System.setErr(outStream);
	}
	
	/*********************************************************************/
	/**
	 * @author benba
	 */
	private static final class OpenFileActionListener implements ActionListener
	{
		private final JMenuItem menuItem;
		private File file;
		private JFileChooser fc;
		
		/**
		 * Constructor
		 * @param menuItem menu item
		 * @param action listener file
		 */
		private OpenFileActionListener(JMenuItem menuItem, File file)
		{
			this.menuItem = menuItem;
			this.file = file;
		}
		
		/**
		 * menu item performed (clicked)
		 * @param action event
		 */
		public void actionPerformed(ActionEvent evt)
		{
			// input files
			if (this.file == ICWFile)
			{
				fc = DnaPreferences.getICWFilename() != "" ? new JFileChooser(ICWFile) :
																			new JFileChooser();
				FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV files","csv");
				fc.setFileFilter(filter);
				
			}
			else if (this.file == dnaPainterFile)
			{
				fc = DnaPreferences.getDNAPFilename() != "" ? new JFileChooser(dnaPainterFile) :
																			new JFileChooser();
				FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV files","csv");
				fc.setFileFilter(filter);
			}
			
			// output files
			else if (this.file == hapFile)
			{
				fc = DnaPreferences.getHapFilename() != "" ? new JFileChooser(hapFile) :
																			new JFileChooser();
			}
			else if (this.file == SNPFile)
			{
				fc = DnaPreferences.getSNPFilename() != "" ? new JFileChooser(SNPFile) :
																			new JFileChooser();
			}
						
			// Handle open button action.
			if (evt.getSource() == menuItem)
			{
				// show open dialog
				int returnVal = fc.showOpenDialog(null);
				
				fc.addPropertyChangeListener(new OpenFilePropertyChangeListener(fc, this.file));
				
				// Approve option
				if (returnVal == JFileChooser.APPROVE_OPTION)
				{
					File selectedFile = fc.getSelectedFile();
					
					// if file does not exist, create it.
					if (selectedFile.exists() == false)
					{
						try
						{
							selectedFile.createNewFile();
							JOptionPane.showMessageDialog(null, selectedFile + " does not exist. Creating it.");
						}
						catch (IOException e1)
						{
							e1.printStackTrace();
						} 
						
					}
					
					// else if selected file already exists do nothing
					
					if (this.file == hapFile)
					{
						DnaPreferences.setHapFilename(selectedFile.toString());
						// create a new File representing the selected file path
						this.file = new File(selectedFile.toString());
					}
					else if (this.file == SNPFile)
					{
						DnaPreferences.setSNPFilename(selectedFile.toString());
						// create a new File representing the selected file path
						this.file = new File(selectedFile.toString());
					}
					else if (this.file == ICWFile)
					{
						DnaPreferences.setICWFilename(selectedFile.toString());
						// create a new File representing the selected file path
						this.file = new File(selectedFile.toString());
						
						System.out.println("Opened " + this.file);
					}
					else if (this.file == dnaPainterFile)
					{
						DnaPreferences.setDNAPFilename(selectedFile.toString());
					// create a new File representing the selected file path
						this.file = new File(selectedFile.toString());
					}
					
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Open command cancelled by user." + "\n");
				}
				
			}
			
		}
		/**
		 * @author benba
		 * inner class
		 */
		private static final class OpenFilePropertyChangeListener implements PropertyChangeListener
		{
			File file;
			JFileChooser fc;
			
			/**
			 * Constructor
			 * @param fc   		file chooser
			 * @param file			file to watch
			 */
			
			OpenFilePropertyChangeListener(JFileChooser fc, File file)
			{
				this.file = file;
			}
			
			@Override
			public void propertyChange(PropertyChangeEvent evt)
			{
				if (evt.getPropertyName() == JFileChooser.SELECTED_FILE_CHANGED_PROPERTY)
				{
					this.file = fc.getSelectedFile();
					System.out.println("filename is now " + this.file);
				}
				
			}
			
		}
		
		
		
	}
	
	/*********************************************************************/
	/**
	 * class TextAreaOutputStream
	 * 
	 * @author benba
	 */
	public static class TextAreaOutputStream extends OutputStream
	{
		private static JTextArea jTextArea1;
		private static int size;
		private static int ctr;
		/**
		 * Creates a new instance of TextAreaOutputStream which writes to the
		 * specified instance of javax.swing.JTextArea control.
		 *
		 * @param textArea
		 * A reference to the javax.swing.JTextArea control to
		 * which the output must be redirected to.
		 */
		public TextAreaOutputStream(JTextArea textArea, int size)
		{
			TextAreaOutputStream.size = size;
			TextAreaOutputStream.ctr = size;
			jTextArea1 = textArea;
		}
		
		public void cls() 
		{
			jTextArea1.setText("");			
		}
		public void write(int b) throws IOException
		{
			if (ctr-- == 0)
			{
				cls();
			}
			ctr = size;
			
			jTextArea1.append(String.valueOf((char) b));
			jTextArea1.setCaretPosition(jTextArea1.getDocument().getLength());
		}
		
		public void write(char[] cbuf, int off, int len) throws IOException
		{
			if (ctr-- == 0)
			{
				cls();
			}
			ctr = size;
			jTextArea1.append(new String(cbuf, off, len));
			jTextArea1.setCaretPosition(jTextArea1.getDocument().getLength());
		}
		
		public static JTextArea getTextArea()
		{
			return jTextArea1;
		}
		
	}
	
	
}
