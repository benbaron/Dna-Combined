/**
 * DnaDNAPainterReader
 */
package dna;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

/**
 * @author benba
 *
 */
public class DnaDNAPainterReader
{
	/**
	 * dnaReadCsvDNAPainterUsingParser
	 * 
	 * @param inputFile - file parameter
	 */
	public static void dnaReadCsvDNAPainterUsingParser(File inputFile)
	{
		CSVParser parser;
		
		System.out.println("Opening: " + inputFile.getAbsolutePath() + "\n");
		
		try
		{
			// Parse all CSV records
			int i = 0; // skip header line
			parser = CSVParser.parse(inputFile, Charset.defaultCharset(), CSVFormat.RFC4180);
			
			for (CSVRecord csvRecord : parser)
			{
				if (i++ > 0)
				{
					ingestDNAPainterMatchLine(csvRecord);
				}
				
			}
			
			System.out.println("imported " +  i + " records");
		}
		
		// parsing CSV records
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	} // readCsvUsingParser
	
	/**
	 * @param csvRecord record line
	 */
	private static void ingestDNAPainterMatchLine(CSVRecord csvRecord)
	{
		DNAPainterMatch dnapMatch = new DNAPainterMatch(csvRecord);
		DNAPainterMatchGroups.addMatch(dnapMatch);
	}
	
}
