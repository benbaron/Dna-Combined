/**
 * FamilyTree
 */
package dna;

import java.util.HashSet;

/**
 * @author benba
 *
 */
public class FamilyTree
{
	FTPerson root;
	FamilyTree(String nodeName)
	{
		FTPerson n = new FTPerson(nodeName);
	}
	
	class FTPerson
	{
		String nodeName;
		HashSet<FTPerson> ancestors;
		HashSet<FTPerson> descendants;
		
		FTPerson(String nodeName)
		{
			this.nodeName = nodeName;
			this.ancestors = null;
			this.descendants = null;
		}
		
		boolean isLeaf(FTPerson node)
		{
			return (ancestors == null);		
		}
		
		HashSet<FTPerson> getAncestors(FTPerson n)
		{
			return this.ancestors;
		}
		
		void addAncestorTo(FTPerson node, FTPerson ancestor)
		{
			// is this 
			
		}
		
	}

	
}

