package dna;

import java.util.ArrayList;

/**
 * class Person
 * 
 * @author benba
 */
public class Person
{
	private static final Exception MATCHBITS_0 = new Exception();
	PersonInfo pi;
	private ArrayList<Match> matches;
	public ArrayList<XBitSet> matchBits = new ArrayList<XBitSet>();
	
	
	/**
	 * toString()
	 */
	public String toString()
	{
		String s = "PersonInfoDnaPainter:[" + pi.toString() + "] ";
		s += "Matches:[";
		for (Match m : getMatches())
		{
			s += m.toString() + "] [";
		}
		s += "]";
		return s;
	}

	
	/**
	 * Person constructor
	 * @param pi person info
	 * @throws Exception generalexception
	 */
	public Person(PersonInfo pi) throws Exception
	{
		this.pi = pi;
		this.setMatches(new ArrayList<Match>());
		
		// get default match bits
		for (int chNum=0; chNum<23; chNum++)
		{
			if(Dna.dmb.getDmbInitialized(chNum) == false)
			{
				System.out.println("init false - cannot initialize default bits for i=" + chNum);
				throw(MATCHBITS_0);
			}
			
			if (Dna.dmb.getDmbLength(chNum) == 0)
			{
				System.out.println("size 0 - cannot initialize default bits for i=" + chNum);
				throw(MATCHBITS_0);
			}
		 	
			XBitSet xbs = (XBitSet) Dna.dmb.getDefaultMatchBits(chNum).clone();
			assert(xbs.length() > 0);
			this.matchBits.add(xbs);
		}
	}
	

	/**
	 * add a match
	 * @param m : Match
	 */
	public void addMatch(Match m)
	{
		this.getMatches().add(m);
	}


	/**
	 * @param splitMatches : matches (1 or more) to add
	 */
	public void addMatches(ArrayList<Match> splitMatches)
	{
		this.getMatches().addAll(splitMatches);
	}
	
	
	/**
	 * @return the matches
	 */
	public ArrayList<Match> getMatches()
	{
		return matches;
	}

	
	/**
	 * @param matches : the matches to set
	 */
	public void setMatches(ArrayList<Match> matches)
	{
		this.matches = matches;
	}


	/**
	 * @param chNum : chromosome number
	 * @param i : integer index to set
	 * @param b : boolean bit 0/1
	 */
	public void assignMatchBits(int chNum, int i, boolean b)
	{
		this.matchBits.get(chNum).assign(i, b);
	}



} 