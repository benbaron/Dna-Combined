/**
 * DNAPainterHapMatrix
 */
package dna;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import java.util.ArrayList;
import java.util.TreeMap;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import dna.DnaFrame.ProgressBarStatus;

/**
 * @author benba
 *
 */
public class DNAPainterHapMatrix
{
	static BufferedWriter writer = null;
	
	static BiTreeMap<String, String, Integer> map;
	
	DNAPainterHapMatrix()
	{
		map = new BiTreeMap<String, String, Integer>();
	}
	
	public static void closeWriter() throws IOException
	{
		if (writer != null) writer.close();
	}
	
	
	/**
	 * Bidimensional TreeMap.
	 * 
	 * @author benba
	 *
	 * @param <K1> key 1
	 * @param <K2> key 2
	 * @param <V>  value
	 */
	public static class BiTreeMap<K1,K2,V>
	{
		private final Map<K1, Map<K2, V>> mMap;
		
		public BiTreeMap()
		{
			mMap = new TreeMap<K1, Map<K2, V>>();
		}
		
		/**
		 * Associates the specified value with the specified keys in this map (optional operation). If
		 * the map previously contained a mapping for the key, the old value is
		 * replaced by the specified value.
		 * 
		 * @param key1
		 * the first key
		 * @param key2
		 * the second key
		 * @param value
		 * the value to be set
		 * 
		 * @return the value previously associated with (key1,key2), or <code>null</code> if none
		 * 
		 * @see Map#put(Object, Object)
		 */
		public V put(K1 key1, K2 key2, V value)
		{
			Map<K2, V> map;
			if (mMap.containsKey(key1))     // contains row
			{
				map = mMap.get(key1);        // get row
			}
			else
			{
				map = new TreeMap<K2, V>();
				mMap.put(key1, map);         // create row
			}
			
			return map.put(key2, value);    // put value in row
		}
		
		/**
		 * Returns the value to which the specified key is mapped, or <code>null</code> if this map
		 * contains no mapping for the key.
		 * 
		 * @param key1
		 * the first key whose associated value is to be returned
		 * @param key2
		 * the second key whose associated value is to be returned
		 * 
		 * @return the value to which the specified key is mapped, or <code>null</code> if this map
		 * contains no mapping for the key
		 * 
		 * @see Map#get(Object)
		 */
		public V get(K1 key1, K2 key2)
		{
			if (mMap.containsKey(key1))          // map contains row
			{
				return mMap.get(key1).get(key2);  // get column in row, or null
			}
			else
			{
				return null;                      // no such row
			}
		}
		
		/**
		 * Returns <code>true</code> if this map contains a mapping for the specified keypair
		 * 
		 * @param key1
		 * the first key whose presence in this map is to be tested
		 * @param key2
		 * the second key whose presence in this map is to be tested
		 * 
		 * @return Returns true if this map contains a mapping for the specified key pair
		 * 
		 * @see Map#containsKey(Object)
		 */
		public boolean containsKeys(K1 key1, K2 key2)
		{
			return mMap.containsKey(key1) && mMap.get(key1).containsKey(key2);
		}
		
		public void clear()
		{
			mMap.clear();
		}
		
	}
	
	/**
	 * BiTreeMap
	 * usage: BiTreeMap<String,String,String> bigBoard = new BiTreeMap<String,String,String>();
	 * 
	 * @author benba
	 *
	 * @param <T> pair type
	 */
	static class Pair<T>
	{
		T p1, p2;
		Pair()
		{
			// default constructor
		}
		void setValue(T p12, T p22)
		{
			this.p1 = p12;
			this.p2 = p22;
		}
		Pair<T> getValue()
		{
			return this;
		}
		
	}
	
	
	/**
	 * Write the HAP matrix from the ingested CSV file.
	 * 
	 * @param baseFilename output hap matrix file name
	 * 
	 * @throws IOException
	 */
	public static void writeHapMatrix(String baseFilename) throws IOException
	{
		map = new BiTreeMap<String, String, Integer>();
		
		File fileToZip = new File(baseFilename + ".csv");
		// open file
		baseFilename += ".zip";
		
		DnaFrame.setProgressBar(0);
		System.out.println("opening: " + baseFilename);
		
		try
		{
			File zipFile = new File(baseFilename);
			zipFile.createNewFile(); // if file already exists will do nothing
			FileOutputStream fos = new FileOutputStream(zipFile, false);
			ZipOutputStream zos = new ZipOutputStream(fos);
			writer = new BufferedWriter(new OutputStreamWriter(zos));			
			ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
			zos.putNextEntry(zipEntry);
			
			try
			{
				// get the name and group keysets
				Set<String> names = DNAPainterMatchGroups.byMatchName.keySet();
				Set<String> groups = DNAPainterMatchGroups.byMatchGroup.keySet();
				
				// for each
				for (String group : groups)
				{
					ArrayList<DNAPainterMatch> matchesList =
								DNAPainterMatchGroups.byMatchGroup.get(group);
					
					// build ordered pairs
					for (int i = 0 ; i < matchesList.size() ; i++)
					{
						DNAPainterMatch match1 = matchesList.get(i);
						String name1 = match1.getName();
						
						for (int j = i + 1 ; j < matchesList.size() ; j++)
						{
							DNAPainterMatch match2 = matchesList.get(j);
							String name2 = match2.getName();
							
							// add the match pair, adding one to the number of
							// matches for this [x,y]
							Integer numberOfMatches = map.get(name1, name2);
							if (numberOfMatches != null)
							{
								numberOfMatches++;
								System.out.println("found match " + "[" + name1 + 
								                   "][" + name2 + "] : " + numberOfMatches);
							}
							else
							{
								numberOfMatches = 1;
							}
							
							map.put(name1, name2, numberOfMatches);
							map.put(name2, name1, numberOfMatches);
						}
						
					}
					
				}
				
				// header row
				writer.write("Name, Shared Centimorgans");
				
				for (String name : names)
				{
					writer.write("," + name);
				}
				
				writer.write("\n");
				
				// subsequent rows
				// name, shared cm, matches
				for (String rowname : names)
				{
					ArrayList<DNAPainterMatch> match = DNAPainterMatchGroups.byMatchName.get(rowname);
					String name = match.get(0).getName();
					Float cM = match.get(0).getCm();
					
					writer.write(name + "," + cM);
					
					for (String colname : names)
					{
						Integer i = map.get(rowname, colname);
						if (i == null)
						{
							i=0;
						}
									
						// get row, col value and print it.
						writer.write("," + i);
					}
					
					writer.write("\n");
				}
				
				// close file
				writer.close();
				fos.close();
				
				System.out.println("wrote file " + baseFilename);
				ProgressBarStatus.barDone(true);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}
