/**
 * DNAPainterMatchGroups
 */
package dna;

import java.util.ArrayList;
import java.util.Hashtable;

/**
 * @author benba
 *
 */
public class DNAPainterMatchGroups
{
	public static Hashtable<String, ArrayList<DNAPainterMatch>> byMatchGroup= new Hashtable<String, ArrayList<DNAPainterMatch>>();
	public static Hashtable<String, ArrayList<DNAPainterMatch>> byMatchName = new Hashtable<String, ArrayList<DNAPainterMatch>>();

	/**
	 * Add a match pair to both maps.
	 * @param m match to add
	 */
	public static void addMatch(DNAPainterMatch m)
	{
		if (byMatchGroup.containsKey(m.getGroup()))
		{
			byMatchGroup.get(m.getGroup()).add(m);
		}
		else
		{
			 ArrayList<DNAPainterMatch> al = new ArrayList<DNAPainterMatch>();
			 al.add(m); // add match to list
			 byMatchGroup.put(m.getGroup(), al);
		}
		
		if (byMatchName.containsKey(m.getName()))
		{
			byMatchName.get(m.getName()).add(m);
		}
		else
		{
			 ArrayList<DNAPainterMatch> al = new ArrayList<DNAPainterMatch>();
			 al.add(m); // add match to list
			 byMatchName.put(m.getName(), al);
		}
	}
}
