/**
 * StringSupport
 */
package Autosomal_Segment_Analyzer;

/**
 * @author benba
 *
 */
public class StringSupport
{

	/**
	 * @param string
	 * @param string2
	 * @return
	 */
	public static boolean equals(String string, String string2)
	{
		// TODO Auto-generated method stub
		return false;
	}
	
}
