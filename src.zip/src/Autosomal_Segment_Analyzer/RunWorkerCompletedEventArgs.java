package Autosomal_Segment_Analyzer;

public class RunWorkerCompletedEventArgs
{
	
}
