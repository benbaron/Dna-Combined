package Autosomal_Segment_Analyzer.System.Windows;

public class Forms
{

	public class Label
	{
		
	}
	
}
