//
// Translated by CS2J (http://www.cs2j.com): 3/31/2021 8:47:20 PM
//

package Autosomal_Segment_Analyzer;

import Autosomal_Segment_Analyzer.Program;

public class Program   
{
    /**
    * The main entry point for the application.
    */
    public static void main(String[] args) throws Exception {
        Program.Main();
    }

    static void Main() throws Exception {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new AtCmpFrm());
    }

}


