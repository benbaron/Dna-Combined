//
// Translated by CS2J (http://www.cs2j.com): 3/31/2021 8:47:20 PM
//

package Autosomal_Segment_Analyzer;




public class OpenFilesFrm //extends Form
{
}

//	
//	private boolean _matchNoCalls = false;
//	private int _errorRadius = -1;
//	private int _snpThreshold = 200;
//	private double _cMThreshold = 1.0;
//	private String _fileFile = "";
//	private String _secondFile = "";
//	
//	public String getFirstFile() throws Exception
//	{
//		return _fileFile;
//	}
//	
//	public String getSecondFile() throws Exception
//	{
//		return _secondFile;
//	}
//	
//	public OpenFilesFrm() throws Exception
//	{
//		initializeComponent();
//	}
//	
//	private void btnOK_Click(Object sender, EventArgs e) throws Exception 
//	{
//        _fileFile = txtFirstFile.getText();
//        _secondFile = txtSecondFile.getText();
//        _matchNoCalls = cbMatchNoCalls.isSelected();
//        _snpThreshold = Integer.Parse(txtSNP.Text);
//        _errorRadius = Integer.Parse(txtErrRadius.Text);
//        _cMThreshold = Double.Parse(txtcM.Text);
//        CompareUtil.IGNORE_UNIVERSAL_MATCHING_SNPS = cbIgUniMatchSNPs.isSelected();
//        CompareUtil.UNIVERSAL_MATCH_SNP_THRESHOLD = Double.Parse(tbUniMatchThreshold.Text);
//        this.isVisible() = false;
//    }
//	
//	private void button1_Click(Object sender, EventArgs e) throws Exception
//	{
//		if (openFileDialog1.ShowDialog() == DialogResult.OK)
//		{
//			txtFirstFile.Text = openFileDialog1.FileName;
//		}
//		
//	}
//	
//	private void button2_Click(Object sender, EventArgs e) throws Exception
//	{
//		if (openFileDialog1.ShowDialog() == DialogResult.OK)
//		{
//			txtSecondFile.Text = openFileDialog1.FileName;
//			if (rb1M.isSelected())
//				CompareUtil.SEX_1 = 'M';
//			else if (rb1F.isSelected())
//				CompareUtil.SEX_1 = 'F';
//			else
//				CompareUtil.SEX_1 = 'U';
//			//
//			if (rb2M.isSelected())
//				CompareUtil.SEX_2 = 'M';
//			else if (rb2F.isSelected())
//				CompareUtil.SEX_2 = 'F';
//			else
//				CompareUtil.SEX_2 = 'U';
//		}
//		
//	}
//	
//	private void btnCancel_Click(Object sender, EventArgs e) throws Exception
//	{
//		_fileFile = "";
//		_secondFile = "";
//	//	this.setVisible(false);
//	}
//	
//	public boolean getMatchNoCalls() throws Exception
//	{
//		return _matchNoCalls;
//	}
//	
//	public int getErrorRadius() throws Exception
//	{
//		return _errorRadius;
//	}
//	
//	public int getSNP_Threshold() throws Exception
//	{
//		return _snpThreshold;
//	}
//	
//	public double getcM_Threshold() throws Exception
//	{
//		return _cMThreshold;
//	}
//	
//	/**
//	 * Required designer variable.
//	 */
////	private Container components = null;
//	
//	/**
//	 * Clean up any resources being used.
//	 * 
//	 * @param disposing true if managed resources should be disposed; otherwise,
//	 * false.
//	 */
//	//protected void dispose(boolean disposing) throws Exception
////	{
////		if (disposing && (components != null))
////		{
////			components.Dispose();
//	//	}
//		
/////		super.Dispose(disposing);
////	}
//	
//	/**
//	 * Required method for Designer support - do not modify the contents of this
//	 * method with the code editor.
//	 */
//	private void initializeComponent() throws Exception
//	{
//		this.label1 = new Label();
//		this.label2 = new Label();
//		this.txtFirstFile = new TextArea();
//		this.txtSecondFile = new TextArea();
//		this.button1 = new Button();
//		this.button2 = new Button();
//		this.btnOK = new Button();
//		this.btnCancel = new Button();
//		this.openFileDialog1 = new OpenFileDialog();
//		this.HBox1 = new HBox();
//		this.rb1F = new RadioButton();
//		this.rb1M = new RadioButton();
//		this.rb1U = new RadioButton();
//		this.HBox2 = new HBox();
//		this.rb2F = new RadioButton();
//		this.rb2M = new RadioButton();
//		this.rb2U = new RadioButton();
//		this.tbUniMatchThreshold = new TextArea();
//		this.label6 = new Label();
//		this.cbIgUniMatchSNPs = new CheckBox();
//		this.txtcM = new TextArea();
//		this.txtSNP = new TextArea();
//		this.label5 = new Label();
//		this.label4 = new Label();
//		this.label3 = new Label();
//		this.label7 = new Label();
//		this.txtErrRadius = new TextArea();
//		this.label8 = new Label();
//		this.cbMatchNoCalls = new CheckBox();
//		this.HBox1.SuspendLayout();
//		this.HBox2.SuspendLayout();
//		this.SuspendLayout();
//		//
//		// label1
//		//
//		this.label1.AutoSize = true;
//		this.label1.Location = new System.Drawing.Point(10, 13);
//		this.label1.Margin = new Padding(2, 0, 2, 0);
//		this.label1.Name = "label1";
//		this.label1.Size = new System.Drawing.Size(83, 13);
//		this.label1.TabIndex = 0;
//		this.label1.Text = "Select Input file:";
//		//
//		// label2
//		//
//		this.label2.AutoSize = true;
//		this.label2.Location = new System.Drawing.Point(281, 13);
//		this.label2.Margin = new Padding(2, 0, 2, 0);
//		this.label2.Name = "label2";
//		this.label2.Size = new System.Drawing.Size(90, 13);
//		this.label2.TabIndex = 1;
//		this.label2.Text = "Select Target file:";
//		//
//		// txtFirstFile
//		//
//		this.txtFirstFile.Location = new System.Drawing.Point(11, 36);
//		this.txtFirstFile.Margin = new Padding(2);
//		this.txtFirstFile.Name = "txtFirstFile";
//		this.txtFirstFile.ReadOnly = true;
//		this.txtFirstFile.Size = new System.Drawing.Size(186, 20);
//		this.txtFirstFile.TabIndex = 2;
//		//
//		// txtSecondFile
//		//
//		this.txtSecondFile.Location = new System.Drawing.Point(284, 36);
//		this.txtSecondFile.Margin = new Padding(2);
//		this.txtSecondFile.Name = "txtSecondFile";
//		this.txtSecondFile.ReadOnly = true;
//		this.txtSecondFile.Size = new System.Drawing.Size(186, 20);
//		this.txtSecondFile.TabIndex = 3;
//		//
//		// button1
//		//
//		this.button1.Location = new System.Drawing.Point(200, 34);
//		this.button1.Margin = new Padding(2);
//		this.button1.Name = "button1";
//		this.button1.Size = new System.Drawing.Size(22, 22);
//		this.button1.TabIndex = 4;
//		this.button1.Text = "..";
//		this.button1.UseVisualStyleBackColor = true;
//		this.button1.Click += new System.EventHandler(this.button1_Click);
//		//
//		// button2
//		//
//		this.button2.Location = new System.Drawing.Point(473, 35);
//		this.button2.Margin = new Padding(2);
//		this.button2.Name = "button2";
//		this.button2.Size = new System.Drawing.Size(22, 22);
//		this.button2.TabIndex = 5;
//		this.button2.Text = "..";
//		this.button2.UseVisualStyleBackColor = true;
//		this.button2.Click += new System.EventHandler(this.button2_Click);
//		//
//		// btnOK
//		//
//		this.btnOK.Location = new System.Drawing.Point(392, 405);
//		this.btnOK.Margin = new Padding(2);
//		this.btnOK.Name = "btnOK";
//		this.btnOK.Size = new System.Drawing.Size(88, 26);
//		this.btnOK.TabIndex = 6;
//		this.btnOK.Text = "&OK";
//		this.btnOK.UseVisualStyleBackColor = true;
//		this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
//		//
//		// btnCancel
//		//
//		this.btnCancel.Location = new System.Drawing.Point(290, 405);
//		this.btnCancel.Margin = new Padding(2);
//		this.btnCancel.Name = "btnCancel";
//		this.btnCancel.Size = new System.Drawing.Size(82, 26);
//		this.btnCancel.TabIndex = 7;
//		this.btnCancel.Text = "&Cancel";
//		this.btnCancel.UseVisualStyleBackColor = true;
//		this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
//		//
//		// openFileDialog1
//		//
//		this.openFileDialog1.Filter = "All files|*.*";
//		//
//		// HBox1
//		//
//		this.HBox1.Controls.Add(this.rb1F);
//		this.HBox1.Controls.Add(this.rb1M);
//		this.HBox1.Controls.Add(this.rb1U);
//		this.HBox1.Location = new System.Drawing.Point(11, 61);
//		this.HBox1.Name = "HBox1";
//		this.HBox1.Size = new System.Drawing.Size(211, 38);
//		this.HBox1.TabIndex = 8;
//		this.HBox1.TabStop = false;
//		//
//		// rb1F
//		//
//		this.rb1F.AutoSize = true;
//		this.rb1F.Location = new System.Drawing.Point(137, 15);
//		this.rb1F.Name = "rb1F";
//		this.rb1F.Size = new System.Drawing.Size(59, 17);
//		this.rb1F.TabIndex = 0;
//		this.rb1F.Text = "Female";
//		this.rb1F.UseVisualStyleBackColor = true;
//		//
//		// rb1M
//		//
//		this.rb1M.AutoSize = true;
//		this.rb1M.Location = new System.Drawing.Point(83, 15);
//		this.rb1M.Name = "rb1M";
//		this.rb1M.Size = new System.Drawing.Size(48, 17);
//		this.rb1M.TabIndex = 0;
//		this.rb1M.Text = "Male";
//		this.rb1M.UseVisualStyleBackColor = true;
//		//
//		// rb1U
//		//
//		this.rb1U.AutoSize = true;
//		this.rb1U.isSelected() = true;
//		this.rb1U.Location = new System.Drawing.Point(6, 15);
//		this.rb1U.Name = "rb1U";
//		this.rb1U.Size = new System.Drawing.Size(71, 17);
//		this.rb1U.TabIndex = 0;
//		this.rb1U.TabStop = true;
//		this.rb1U.Text = "Unknown";
//		this.rb1U.UseVisualStyleBackColor = true;
//		//
//		// HBox2
//		//
//		this.HBox2.Controls.Add(this.rb2F);
//		this.HBox2.Controls.Add(this.rb2M);
//		this.HBox2.Controls.Add(this.rb2U);
//		this.HBox2.Location = new System.Drawing.Point(284, 62);
//		this.HBox2.Name = "HBox2";
//		this.HBox2.Size = new System.Drawing.Size(211, 38);
//		this.HBox2.TabIndex = 9;
//		this.HBox2.TabStop = false;
//		//
//		// rb2F
//		//
//		this.rb2F.AutoSize = true;
//		this.rb2F.Location = new System.Drawing.Point(137, 15);
//		this.rb2F.Name = "rb2F";
//		this.rb2F.Size = new System.Drawing.Size(59, 17);
//		this.rb2F.TabIndex = 0;
//		this.rb2F.Text = "Female";
//		this.rb2F.UseVisualStyleBackColor = true;
//		//
//		// rb2M
//		//
//		this.rb2M.AutoSize = true;
//		this.rb2M.Location = new System.Drawing.Point(83, 15);
//		this.rb2M.Name = "rb2M";
//		this.rb2M.Size = new System.Drawing.Size(48, 17);
//		this.rb2M.TabIndex = 0;
//		this.rb2M.Text = "Male";
//		this.rb2M.UseVisualStyleBackColor = true;
//		//
//		// rb2U
//		//
//		this.rb2U.AutoSize = true;
//		this.rb2U.isSelected() = true;
//		this.rb2U.Location = new System.Drawing.Point(6, 15);
//		this.rb2U.Name = "rb2U";
//		this.rb2U.Size = new System.Drawing.Size(71, 17);
//		this.rb2U.TabIndex = 0;
//		this.rb2U.TabStop = true;
//		this.rb2U.Text = "Unknown";
//		this.rb2U.UseVisualStyleBackColor = true;
//		//
//		// tbUniMatchThreshold
//		//
//		this.tbUniMatchThreshold.Location = new System.Drawing.Point(137, 297);
//		this.tbUniMatchThreshold.Margin = new Padding(2);
//		this.tbUniMatchThreshold.Name = "tbUniMatchThreshold";
//		this.tbUniMatchThreshold.Size = new System.Drawing.Size(76, 20);
//		this.tbUniMatchThreshold.TabIndex = 28;
//		this.tbUniMatchThreshold.Text = "0.90";
//		//
//		// label6
//		//
//		this.label6.Location = new System.Drawing.Point(14, 297);
//		this.label6.Margin = new Padding(2, 0, 2, 0);
//		this.label6.Name = "label6";
//		this.label6.Size = new System.Drawing.Size(126, 34);
//		this.label6.TabIndex = 27;
//		this.label6.Text = "Universal SNP Match Probability Threshold";
//		//
//		// cbIgUniMatchSNPs
//		//
//		this.cbIgUniMatchSNPs.Location = new System.Drawing.Point(16, 251);
//		this.cbIgUniMatchSNPs.Name = "cbIgUniMatchSNPs";
//		this.cbIgUniMatchSNPs.Size = new System.Drawing.Size(279, 34);
//		this.cbIgUniMatchSNPs.TabIndex = 26;
//		this.cbIgUniMatchSNPs.Text = "Ignore SNPs which are Universal Matches among populations:";
//		this.cbIgUniMatchSNPs.UseVisualStyleBackColor = true;
//		//
//		// txtcM
//		//
//		this.txtcM.Location = new System.Drawing.Point(102, 222);
//		this.txtcM.Margin = new Padding(2);
//		this.txtcM.Name = "txtcM";
//		this.txtcM.Size = new System.Drawing.Size(76, 20);
//		this.txtcM.TabIndex = 23;
//		this.txtcM.Text = "1";
//		//
//		// txtSNP
//		//
//		this.txtSNP.Location = new System.Drawing.Point(102, 192);
//		this.txtSNP.Margin = new Padding(2);
//		this.txtSNP.Name = "txtSNP";
//		this.txtSNP.Size = new System.Drawing.Size(76, 20);
//		this.txtSNP.TabIndex = 22;
//		this.txtSNP.Text = "150";
//		//
//		// label5
//		//
//		this.label5.AutoSize = true;
//		this.label5.Location = new System.Drawing.Point(17, 225);
//		this.label5.Margin = new Padding(2, 0, 2, 0);
//		this.label5.Name = "label5";
//		this.label5.Size = new System.Drawing.Size(75, 13);
//		this.label5.TabIndex = 21;
//		this.label5.Text = "cM Threshold:";
//		//
//		// label4
//		//
//		this.label4.AutoSize = true;
//		this.label4.Location = new System.Drawing.Point(17, 194);
//		this.label4.Margin = new Padding(2, 0, 2, 0);
//		this.label4.Name = "label4";
//		this.label4.Size = new System.Drawing.Size(82, 13);
//		this.label4.TabIndex = 20;
//		this.label4.Text = "SNP Threshold:";
//		//
//		// label3
//		//
//		this.label3.Location = new System.Drawing.Point(17, 350);
//		this.label3.Margin = new Padding(2, 0, 2, 0);
//		this.label3.Name = "label3";
//		this.label3.Size = new System.Drawing.Size(291, 32);
//		this.label3.TabIndex = 19;
//		this.label3.Text = "Note: Error radius is the number of matching SNPs\r\nbetween two non-matching SNPs." +
//					" Enter -1 to disable.";
//		//
//		// label7
//		//
//		this.label7.AutoSize = true;
//		this.label7.Location = new System.Drawing.Point(182, 162);
//		this.label7.Margin = new Padding(2, 0, 2, 0);
//		this.label7.Name = "label7";
//		this.label7.Size = new System.Drawing.Size(34, 13);
//		this.label7.TabIndex = 18;
//		this.label7.Text = "SNPs";
//		//
//		// txtErrRadius
//		//
//		this.txtErrRadius.Location = new System.Drawing.Point(102, 160);
//		this.txtErrRadius.Margin = new Padding(2);
//		this.txtErrRadius.Name = "txtErrRadius";
//		this.txtErrRadius.Size = new System.Drawing.Size(76, 20);
//		this.txtErrRadius.TabIndex = 17;
//		this.txtErrRadius.Text = "-1";
//		//
//		// label8
//		//
//		this.label8.AutoSize = true;
//		this.label8.Location = new System.Drawing.Point(17, 163);
//		this.label8.Margin = new Padding(2, 0, 2, 0);
//		this.label8.Name = "label8";
//		this.label8.Size = new System.Drawing.Size(68, 13);
//		this.label8.TabIndex = 16;
//		this.label8.Text = "Error Radius:";
//		//
//		// cbMatchNoCalls
//		//
//		this.cbMatchNoCalls.AutoSize = true;
//		this.cbMatchNoCalls.isSelected() = true;
//		this.cbMatchNoCalls.CheckState = CheckState.isSelected();
//		this.cbMatchNoCalls.Location = new System.Drawing.Point(17, 131);
//		this.cbMatchNoCalls.Margin = new Padding(2);
//		this.cbMatchNoCalls.Name = "cbMatchNoCalls";
//		this.cbMatchNoCalls.Size = new System.Drawing.Size(95, 17);
//		this.cbMatchNoCalls.TabIndex = 15;
//		this.cbMatchNoCalls.Text = "Match no-calls";
//		this.cbMatchNoCalls.UseVisualStyleBackColor = true;
//		//
//		// OpenFilesFrm
//		//
//		this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
//		this.AutoScaleMode = AutoScaleMode.Font;
//		this.ClientSize = new System.Drawing.Size(509, 455);
//		this.ControlBox = false;
//		this.Controls.Add(this.tbUniMatchThreshold);
//		this.Controls.Add(this.label6);
//		this.Controls.Add(this.cbIgUniMatchSNPs);
//		this.Controls.Add(this.txtcM);
//		this.Controls.Add(this.txtSNP);
//		this.Controls.Add(this.label5);
//		this.Controls.Add(this.label4);
//		this.Controls.Add(this.label3);
//		this.Controls.Add(this.label7);
//		this.Controls.Add(this.txtErrRadius);
//		this.Controls.Add(this.label8);
//		this.Controls.Add(this.cbMatchNoCalls);
//		this.Controls.Add(this.HBox2);
//		this.Controls.Add(this.HBox1);
//		this.Controls.Add(this.btnCancel);
//		this.Controls.Add(this.btnOK);
//		this.Controls.Add(this.button2);
//		this.Controls.Add(this.button1);
//		this.Controls.Add(this.txtSecondFile);
//		this.Controls.Add(this.txtFirstFile);
//		this.Controls.Add(this.label2);
//		this.Controls.Add(this.label1);
//		this.FormBorderStyle = FormBorderStyle.FixedSingle;
//		this.Margin = new Padding(2);
//		this.Name = "OpenFilesFrm";
//		this.ShowIcon = false;
//		this.ShowInTaskbar = false;
//		this.StartPosition = FormStartPosition.Manual;
//		this.Text = "Open Autosomal Files";
//		this.HBox1.ResumeLayout(false);
//		this.HBox1.PerformLayout();
//		this.HBox2.ResumeLayout(false);
//		this.HBox2.PerformLayout();
//		this.ResumeLayout(false);
//		this.PerformLayout();
//	}
//	
//	private Label label1 = new Label();
//	private Label label2 = new Label();
//	private TextArea txtFirstFile = new TextArea();
//	private TextArea txtSecondFile = new TextArea();
//	private Button button1 = new Button();
//	private Button button2 = new Button();
//	private Button btnOK = new Button();
//	private Button btnCancel = new Button();
//	private OpenFileDialog openFileDialog1 = new OpenFileDialog();
//	private HBox HBox1 = new HBox();
//	private RadioButton rb1F = new RadioButton();
//	private RadioButton rb1M = new RadioButton();
//	private RadioButton rb1U = new RadioButton();
//	private HBox HBox2 = new HBox();
//	private RadioButton rb2F = new RadioButton();
//	private RadioButton rb2M = new RadioButton();
//	private RadioButton rb2U = new RadioButton();
//	private TextArea tbUniMatchThreshold = new TextArea();
//	private Label label6 = new Label();
//	private CheckBox cbIgUniMatchSNPs = new CheckBox();
//	private TextArea txtcM = new TextArea();
//	private TextArea txtSNP = new TextArea();
//	private Label label5 = new Label();
//	private Label label4 = new Label();
//	private Label label3 = new Label();
//	private Label label7 = new Label();
//	private TextArea txtErrRadius = new TextArea();
//	private Label label8 = new Label();
//	private CheckBox cbMatchNoCalls = new CheckBox();
//	public Object StartPosition;
//}
//
