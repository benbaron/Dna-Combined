package Autosomal_Segment_Analyzer;

public class Application
{

	public static final String ProductName = null;
	public static final String ProductVersion = null;

	public static void EnableVisualStyles()
	{
		// TODO Auto-generated method stub
		
	}

	public static void SetCompatibleTextRenderingDefault(boolean b)
	{
		// TODO Auto-generated method stub
		
	}

	public static void Run(AtCmpFrm atCmpFrm)
	{
		// TODO Auto-generated method stub
		
	}
	
}
