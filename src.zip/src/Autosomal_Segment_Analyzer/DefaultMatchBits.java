/**
 * DefaultMatchBits
 */
package Autosomal_Segment_Analyzer;

import dna.XBitSet;

/**
 * class
 * 
 * @author benba
 *
 */
public class DefaultMatchBits
{
	/**
	 * defaultMatchBits
	 */
	private static XBitSet[] defaultMatchBits = new XBitSet[23];
	private static Boolean[] dmbInitialized = new Boolean[23];
	private static Integer[] length = new Integer[23];
	
	/**
	 * constructor
	 */
	public DefaultMatchBits()
	{
		for (int i = 0 ; i < 23 ; i++)
		{
			defaultMatchBits[i] = new XBitSet();
			dmbInitialized[i] = false;
			length[i] = 0;
		}
		
	}
	
	/**
	 * @param i
	 * 
	 * @return the dmbInitialized
	 */
	public Boolean getDmbInitialized(int i)
	{
		return dmbInitialized[i];
	}
	
	/**
	 * @param int : chromosome #
	 */
	public void setDmbInitialized(int i)
	{
		dmbInitialized[i] = true;
	}
	
	/**
	 * @param i : bitset number
	 * 
	 * @return the defaultMatchBits
	 */
	public XBitSet getDefaultMatchBits(int i)
	{
		return defaultMatchBits[i];
	}
	
	/**
	 * @param i
	 * @param j
	 * @param b
	 */
	public void setDefaultMatchBit(int i, int pos, boolean b)
	{
		try 
		{
			//System.out.println("set bits" + i + pos + b);
			defaultMatchBits[i].set(pos, b);
			
			assert(defaultMatchBits[i].length() > 0);
			
		}
		catch (Exception e)
		{
			System.out.println("failed setting bit" + i + " " + pos + " " + b);
			e.printStackTrace();
		}
	}
	
	/**
	 * @param i
	 * @param length
	 */
	public int getDmbLength(int i)
	{
		return length[i];
	}
	
	/**
	 * @param i
	 * @param length
	 */
	public void setDmbLength(int i, int l)
	{
		length[i] = l;
	}
}
///
