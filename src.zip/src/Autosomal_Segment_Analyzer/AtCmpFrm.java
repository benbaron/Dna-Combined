//
// Translated by CS2J (http://www.cs2j.com): 3/31/2021 8:47:20 PM
//

package Autosomal_Segment_Analyzer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.TreeMap;

import Autosomal_Segment_Analyzer.AtCmpFrm;

public class AtCmpFrm // extends Form
{
	OpenFilesFrm open_frm = null;
	
	// parameters
	static String f1 = null;
	static String f2 = null;
	
	static boolean match_nocall = false;
	static int error_radius = -1;
	// -1 disables it, 120 is default
	static int snp_threshold = 200;
	static int match_not_tested = CompareUtil.NOT_TESTED_MATCH_BY_ADDING;
	static double cM_threshold = 1;
	
	static ArrayList<String> output_text = new ArrayList<String>();
	
	static StringBuilder ca_output_text = new StringBuilder();
	static StringBuilder sb_result = new StringBuilder();
	
	static TreeMap<Integer, ArrayList<String>>[][] chr1 = null;
	static TreeMap<Integer, ArrayList<String>>[][] chr2 = null;
	
	static int mchr = 0;
	static int mstart = 0;
	static int mstop = 0;
	static boolean normalized = false;
	static private Object statusLbl1;
	static private Object sgmt;
	
	// public AtCmpFrm() throws Exception
	// {
	// initializeComponent();
	// }
	//
	
//	private void exitToolStripMenuItem_Click(Object sender, EventArgs e)
//				throws Exception
//	{
//		System.exit(0);
//	}
	
	// private void openFilesToolStripMenuItem_Click(Object sender, EventArgs e)
	// throws Exception
	// {
	// statusLbl1.Text = "Open Files ...";
	// if (open_frm == null)
	// {
	// open_frm = new OpenFilesFrm();
	// open_frm.StartPosition = FormStartPosition.CenterParent;
	// }
	//
	// open_frm.ShowDialog(this);
	// if (StringSupport.equals(open_frm.getFirstFile(), "") ||
	// StringSupport.equals(open_frm.getSecondFile(), ""))
	// {
	// statusLbl1.Text = "No files selected";
	// return;
	// }
	//
	// f1 = open_frm.getFirstFile();
	// f2 = open_frm.getSecondFile();
	// match_nocall = open_frm.getMatchNoCalls();
	// error_radius = open_frm.getErrorRadius();
	// snp_threshold = open_frm.getSNP_Threshold();
	// cM_threshold = open_frm.getcM_Threshold();
	//
	// sgmt.Columns[2].HeaderText = Path.GetFileNameWithoutExtension(f1);
	// sgmt.Columns[3].HeaderText = Path.GetFileNameWithoutExtension(f2);
	//
	// normalized = false;
	// splitContainer1.Visible = true;
	//
	// if (!bgWorker.IsBusy)
	// {
	// dgv.Rows.Clear();
	// sgmt.Rows.Clear();
	// statusLbl1.Text = "Comparing ...[this may take a while]";
	// this.Cursor = Cursors.WaitCursor;
	// bgWorker.RunWorkerAsync();
	// }
	// else
	// {
	// statusLbl1.Text = "Background worker is busy";
	// MessageBox.Show("Background worker is busy!\r\nPlease try later...");
	// this.Cursor = Cursors.Default;
	// }
	//
	// }
	
	
	public static void compareFiles()
	// private void bgWorker_DoWork(Object sender, DoWorkEventArgs e)
	// throws Exception
	// {
	// output_text.clear();
	// ca_output_text.clear();
	// ca_output_text.Append("RSID,CHROMOSOME,POSITION,RESULT\r\n");
	{
		if (!normalized)
		{
			try
			{
				chr1 = CompareUtil.normalizeData(f1);
			}
			catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try
			{
				chr2 = CompareUtil.normalizeData(f2);
			}
			catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			normalized = true;
		}
		
		double total_shared_cm = 0;
		ArrayList<Integer> chr_rm = new ArrayList<Integer>();
		for (int i = 0 ; i < 22 ; i++)
		{
			if (chr1[0][i] == null || chr2[0][i] == null)
				continue;
			
			chr_rm.clear();
			ArrayList<Integer> keys = new ArrayList<Integer>(chr1[0][i].keySet());
			for (int position : keys)
			{
				if (!chr2[0][i].containsKey(position))
					// these SNPs are not tested.. on the other match
					chr_rm.add(position);
			}
			
			if (!match_nocall)
				match_not_tested = CompareUtil.NOT_TESTED_DONT_MATCH;
			
			if (match_not_tested == CompareUtil.NOT_TESTED_MATCH_BY_REMOVING)
			{
				for (int position : chr_rm)
				{
					chr1[0][i].remove(position);
				}
				
			}
			else if (match_not_tested == CompareUtil.NOT_TESTED_MATCH_BY_ADDING)
			{
				for (Integer position : chr_rm)
				{
					chr2[0][i].put(position, chr1[0][i].get(position));
				}
				
			}
			else if (match_not_tested == CompareUtil.NOT_TESTED_DONT_MATCH)
			{
				for (int position : chr_rm)
				{
					chr2[0][i].put(position, new ArrayList<String>());
					
				}
				
			}
			
		}
		
		int segment_start = 0;
		int segment_end = 0;
		double total_cm = 0;
		int total_mb = 0;
		int snp_count = 0;
		ArrayList<String> genotype1 = new ArrayList<String>();
		ArrayList<String> genotype2 = new ArrayList<String>();
		ArrayList<Integer> keys = null;
		int last_error = 0;
		String[] sharedDNA = null;
		int no_of_segments = 0;
		ArrayList<String> rsid = null;
		int last_success_position = 0;
		double probability = 1.0;
		double segment_probability = 1.0;
		
		StringBuilder sbTmp = new StringBuilder();
		
		for (int i = 0 ; i < 22 ; i++)
		{
			if (chr1[0][i] == null ||
				 chr2[0][i] == null)
				continue;
			//
			snp_count = 0;
			last_error = 0;
			
			keys = new ArrayList<Integer>(chr1[0][i].keySet());
			
			segment_start = -1;
			last_success_position = 0;
			for (int position : keys)
			{
				if (chr1[0][i] == null ||
						chr2[0][i] == null)
					continue;
				
				// doesn't exist in file.
				genotype1 = chr1[0][i].get(position);
				genotype2 = chr2[0][i].get(position);
				rsid = chr1[1][i].get(position);
				
				try
				{
					if (CompareUtil.isShared(genotype1, genotype2, match_nocall))
					{
						// each position recorded is a snp
						if (checkUniversalSNPMatch(genotype1, rsid.get(0).toString()))
						{
							if (segment_start == -1)
								segment_start = position;
							
							snp_count++;
							probability = _getProbability(genotype1.get(0).toString(),
																	rsid.get(0).toString());
							
							if (probability != 0)
								segment_probability *= probability;
							
							sharedDNA = CompareUtil.getSharedDNA(	rsid,
																				genotype1,
																				genotype2,
																				i + 1,
																				position);
							
							if (!StringSupport.equals(sharedDNA[3], ""))
								sbTmp.append(	"\"" +
													sharedDNA[0] +
													"\",\"" +
													sharedDNA[1] +
													"\",\"" +
													sharedDNA[2] +
													"\",\"" +
													sharedDNA[3] +
													"\"\r\n");
							
						}
						
						last_success_position = position;
						
					}
					else
					{
						if ((snp_count - last_error)	>= error_radius &&
								error_radius != -1)
						{
							last_error = snp_count;
							if (checkUniversalSNPMatch(genotype1,
																rsid.get(0).toString()))
							{
								if (segment_start == -1)
									segment_start = position;
								
								snp_count++;
								probability =
											_getProbability(	genotype1.get(0).toString(),
																	rsid.get(0).toString());
								
								if (probability != 0)
									segment_probability *= probability;
								
								sharedDNA = CompareUtil.getSharedDNA(	rsid,
																					genotype1,
																					genotype2,
																					i + 1,
																					position);
								
								if (!StringSupport.equals(sharedDNA[3], ""))
									
									sbTmp.append(	"\"" +
														sharedDNA[0] +
														"\"" +
														sharedDNA[1] +
														"\",\"" +
														sharedDNA[2] +
														"\",\"" +
														sharedDNA[3] +
														"\"\r\n");
							}
							
							last_success_position = position;
							
						}
						else
						{
							if (segment_start != -1)
							{
								segment_end = last_success_position;
								total_cm = CompareUtil.get_cM((i + 1),
																		segment_start,
																		segment_end,
																		CompareUtil.SEX_1,
																		CompareUtil.SEX_2);
								
								total_mb = segment_end - segment_start;
								if (snp_count > snp_threshold)
								{
									if (total_cm > cM_threshold)
									{
										output_text.add(	(i + 1) +	"," +
																segment_start + "," +
																segment_end + "," +
																snp_count + "," +
																
																CompareUtil.get_cM(	(i + 1),
																							segment_start,
																							segment_end,
																							CompareUtil.SEX_1,
																							CompareUtil.SEX_2) +
																
																" cM, " +
																((total_mb) / 1000000.00) +
																" Mb, " +
																
																segment_probability);
										
										total_shared_cm += total_cm;
										no_of_segments++;
										ca_output_text.append(sbTmp.toString());
										
									}
									
								}
								
							}
							
							segment_start = -1;
							snp_count = 0;
							last_error = 0;
							segment_probability = 1.0;
							
						}
						
					}
					
				}
				catch (Exception e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
				
			}
			
			/**
			* 
			*/
			if (segment_start != -1)
			{
				segment_end = last_success_position;
				try
				{
					total_cm = CompareUtil.get_cM((i + 1),
															segment_start,
															keys.get(keys.size() - 1),
															CompareUtil.SEX_1,
															CompareUtil.SEX_2);
					
				}
				catch (Exception e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
				
				total_mb = keys.get(keys.size() - 1) - segment_start;
				if (snp_count > snp_threshold)
				{
					try
					{
						if (CompareUtil.get_cM(	(i + 1),
														segment_start,
														segment_end,
														CompareUtil.SEX_1,
														CompareUtil.SEX_2)
								> cM_threshold)
						{
							output_text.add(	(i + 1) +	"," +
													segment_start + "," +
													segment_end + "," +
													snp_count + "," +
													
													CompareUtil.get_cM(	(i + 1),
																				segment_start,
																				segment_end,
																				CompareUtil.SEX_1,
																				CompareUtil.SEX_2) +
													
													" cM, " +
													
													((total_mb) / 1000000.00) +
													" Mb, " +
													segment_probability);
							
							total_shared_cm += total_cm;
							no_of_segments++;
							ca_output_text.append(sbTmp.toString());
							
							// sbTmp.clear();
						}
						
					}
					catch (Exception e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
						
					}
					
				}
				
			}
			
			snp_count = 0;
			last_error = 0;
			segment_probability = 1.0;
			
		}
		
		/**
		* 
		*/
		
		if (total_shared_cm != 0)
		{
			sb_result.append(	"Total Shared  = " +
									total_shared_cm + " cM");
			double percent = total_shared_cm * 100.0 / CompareUtil.TOTAL_CM;
			sb_result.append(
									"Shared DNA : " + percent + " %");
			sb_result.append("Shared Segments : " + no_of_segments);
			
		}
		
		//
		if (no_of_segments == 0)
		{
			sb_result.append("No matching segments found.");
			
		}
		
	}
	
	private static boolean checkUniversalSNPMatch(ArrayList<String> genotype1,
				String rsid) throws Exception
	{
		if (CompareUtil.IGNORE_UNIVERSAL_MATCHING_SNPS)
		{
			boolean flag = true;
			for (String gt1 : genotype1)
			{
				if (_getProbability(	gt1,
											rsid)
						>= CompareUtil.UNIVERSAL_MATCH_SNP_THRESHOLD)
				{
					flag = false;
					
				}
				
			}
			
			return flag;
			
		}
		else
			return true;
		
	}
	
	private boolean checkUniversalSNPMatch(String gt, String rsid)
				throws Exception
	{
		if (CompareUtil.IGNORE_UNIVERSAL_MATCHING_SNPS)
		{
			boolean flag = true;
			if (_getProbability(	gt,
										rsid)
					>= CompareUtil.UNIVERSAL_MATCH_SNP_THRESHOLD)
			{
				flag = false;
				
			}
			
			return flag;
			
		}
		else
			return true;
		
	}
	
	// private void bgWorker_ProgressChanged(Object sender,
	// ProgressChangedEventArgs e) throws Exception
	// {
	// statusLbl1.Text = e.UserState.ToString();
	// }
	//
	// private void bgWorker_RunWorkerCompleted(Object sender,
	// RunWorkerCompletedEventArgs e) throws Exception
	// {
	// dgv.Rows.Clear();
	// for (Object __dummyForeachVar6 : output_text)
	// {
	// String line = (String) __dummyForeachVar6;
	// dgv.Rows.Add(line.Split(",".ToCharArray()));
	// }
	//
	// this.Cursor = Cursors.Default;
	// MessageBox.Show(sb_result.ToString());
	// }
	//
	// private void dgv_SelectionChanged(Object sender, EventArgs e)
	// throws Exception
	// {
	// if (dgv.SelectedRows.Count > 0)
	// {
	// this.Cursor = Cursors.WaitCursor;
	// mchr = Integer.Parse((String) dgv.SelectedRows.get(0).Cells["Chr"].Value);
	// mstart = Integer
	// .Parse((String) dgv.SelectedRows.get(0).Cells["Start"].Value);
	// mstop = Integer
	// .Parse((String) dgv.SelectedRows.get(0).Cells["Stop"].Value);
	// // MessageBox.Show(chr+";"+start+";"+stop);
	// sgmt.Rows.Clear();
	// statusLbl1.Text = "Loading Chr " + mchr + ", Position [" + mstart +
	// " to " + mstop + "] ...";
	// // timer1.Start();
	// populateSegmentDetails();
	// this.Cursor = Cursors.Default;
	// }
	//
	// }
	
	private void populateSegmentDetails() throws Exception
	{
		TreeMap<Integer,ArrayList<String>> kv1 = chr1[0][mchr - 1];
		TreeMap<Integer,ArrayList<String>> kv2 = chr2[0][mchr - 1];
		
		String snp1 = "";
		String snp2 = "";
		String match = "";
		
		double segment_probability = 1.0;
		double probability = 1.0;
		for (int i = mstart ; i <= mstop ; i++)
		{
			if (kv1.containsKey(i))
			{
				if (kv1.get(i).size() > 0)
					snp1 = kv1.get(i).get(0);
				else
					snp1 = "";
				
			}
			else
				snp1 = "";
			
			//
			if (kv2.containsKey(i))
			{
				if (kv2.get(i).size() > 0)
					snp2 = kv2.get(i).get(0);
				else
					snp2 = "";
				
			}
			else
				snp2 = "";
			
			if (!StringSupport.equals(snp1, "") && !StringSupport.equals(snp2, ""))
			{
				if (StringSupport.equals(snp1, snp2) ||
						StringSupport.equals(snp1, CompareUtil.reverse(snp2)))
					match = snp1;
				else if (snp1.charAt(0) == snp2.charAt(0))
					match = snp1.charAt(0) + "";
				else if (snp1.charAt(0) == snp2.charAt(1))
					match = snp1.charAt(0) + "";
				else if (snp1.charAt(1) == snp2.charAt(0))
					match = snp1.charAt(1) + "";
				else if (snp1.charAt(1) == snp2.charAt(1))
					match = snp1.charAt(1) + "";
				else
					match = "-";
				if (chr1[1][mchr - 1].containsKey(i) &&
						chr2[1][mchr - 1].containsKey(i))
				{
					
					String x = chr1[1][mchr - 1].get(i).get(0);
					if (StringSupport.equals(	(String) chr1[1][mchr - 1]	.get(i)
																							.get(0),
														(String) chr2[1][mchr - 1]	.get(i)
																							.get(0)))
					{
						// last confirmation
						if (checkUniversalSNPMatch(snp1,
															(String) chr1[1][mchr -
																					1]	.get(i)
																						.get(0)))
						{
							probability = _getProbability(snp1,
																	(String) chr1[1][mchr -
																							1]	.get(i)
																								.get(0));
							
							if (probability != 0)
								segment_probability *= probability;
							
							// sgmt.Rows.add(new String[] {
							// (String) chr1[1][mchr - 1].get(i).get(0),
							// String.valueOf(i),
							// snp1, snp2, match,
							// getProbability(snp1,(String) chr1[1][mchr -
							// 1].get(i).get(0)) });
						}
						
					}
					
				}
				else if (chr1[1][mchr - 1].containsKey(i) &&
							!chr2[1][mchr - 1].containsKey(i))
				{
					if (checkUniversalSNPMatch(snp1,
														(String) chr1[1][mchr - 1]	.get(i)
																							.get(0)))
					{
						probability = _getProbability(snp1,
																(String) chr1[1][mchr -
																						1]	.get(i)
																							.get(0));
						
						if (probability != 0)
							segment_probability *= probability;
						
						// sgmt.Rows.Add(new String[] {
						// (String) chr1[1][mchr - 1].get(i).get(0),
						// String.valueOf(i),
						// snp1,
						// "-",
						// match,
						// getProbability(snp1,
						// (String) chr1[1][mchr - 1].get(i).get(0))
						// });
					}
					
				}
				
			}
			
		}
		
		if (segment_probability < 1 / Math.pow(10, 15))
			// collision every million billion (1000 trillion) which is impossible
			statusLbl1 =
						"Accidental match cannnot occur in this segment. IBS compound or IBD segment but not IBS noise.";
		else
			statusLbl1 = "Accidental match every " +
								(long) (1 / segment_probability) +
								" people. [Probability = " +
								segment_probability + "]";
			
		// if (sgmt.RowCount > 0)
		// sgmt.Rows[0].Selected = true;
		
	}
	
	private String getProbability(String snp, String rsid) throws Exception
	{
		double prob = _getProbability(snp, rsid);
		if (prob != 0)
			return String.format("%f", prob);
		else
			return " ";
	}
	
	/**
	 * _getProbability
	 * 
	 * @param  snp
	 * @param  rsid
	 * @return           probability - double
	 * @throws Exception
	 */
	private static double _getProbability(String snp, String rsid)
				throws Exception
	{
		try
		{
			double prob = 0;
			TreeMap<String, Double> map = CompareUtil.getOpenSNP_Freq().get(rsid);
			if (map != null)
			{
				if (map.containsKey(snp))
					prob = map.get(snp);
				
				if (map.containsKey(reverse(snp)) &&
						!StringSupport.equals(reverse(snp), snp))
					prob = prob + map.get(reverse(snp));
				
				return prob;
				
			}
			
		}
		catch (Exception __dummyCatchVar0)
		{
			
		}
		
		return 0;
	}
	
	/**
	 * reverse string
	 * 
	 * @param  string
	 *                      to reverse
	 * @return           reversed string
	 * @throws Exception
	 */
	public static String reverse(String s) throws Exception
	{
		char[] charArray = s.toCharArray();
		Collections.reverse(Arrays.asList(charArray));
		return new String(charArray);
	}
	
	
	// private void sgmt_CellFormatting(Object sender,
	// DataGridViewCellFormattingEventArgs e) throws Exception
	// {
	// if (e.ColumnIndex == 4 && StringSupport.equals(e.Value.ToString(), "-"))
	// e.CellStyle.BackColor = Color.Red;
	//
	// }
	//
	
	
	// private void aboutToolStripMenuItem_Click(Object sender, EventArgs e)
	// throws Exception
	// {
	// MessageBox.Show("Autosomal Segment Analyzer " +
	// Application.ProductVersion +
	// "\r\n\r\nDeveloper: Felix Chandrakumar <i@fc.id.au>\r\nWebsite:
	// y-str.org\r\n\r\nReference Data:\r\n - http://compgen.rutgers.edu/maps\r\n
	// -
	// http://www.opensnp.org",
	// "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
	// }
	//
	// private void atCmpFrm_Load(Object sender, EventArgs e) throws Exception
	// {
	// this.Text = Application.ProductName.ToString() + " v" +
	// Application.ProductVersion.ToString();
	// statusLbl1.Text = "Loading Rutgers Map v.3 ...";
	// this.Enabled = false;
	// bgMapLoader.RunWorkerAsync();
	// }
	//
	// private void websiteToolStripMenuItem_Click(Object sender, EventArgs e)
	// throws Exception
	// {
	// Process.Start(
	// "http://www.y-str.org/2013/08/autosomal-segment-analyzer.html");
	// }
	//
	
	private void bgMapLoader_DoWork(Object sender, DoWorkEventArgs e)
				throws Exception
	{
		CompareUtil.loadMaps();
	}
}

//
// private void bgMapLoader_RunWorkerCompleted(Object sender,
// RunWorkerCompletedEventArgs e) throws Exception
// {
// this.Enabled = true;
// statusLbl1.Text = "Done.";
// }

// private void sgmt_SelectionChanged(Object sender, EventArgs e)
// throws Exception
// {
// if (sgmt.SelectedRows.Count > 0)
// {
// String rsid = sgmt.SelectedRows[0].Cells["RSID"].Value.ToString();
// Dictionary<String, Double> rsid_freq = CompareUtil.OpenSNP_Freq[rsid];
// ArrayList<String> x_val = new ArrayList<String>();
// ArrayList<Double> y_val = new ArrayList<Double>();
// for (String gt : rsid_freq.Keys)
// {
// if (StringSupport.equals(gt, "--") ||
// StringSupport.equals(gt, "-") ||
// StringSupport.equals(gt, "00") ||
// StringSupport.equals(gt, "0"))
// continue;
//
// x_val.add(gt);
// y_val.add(rsid_freq[gt]);
// }
//
// double[] yValues = y_val.toArray();
// String[] xValues = x_val.toArray();
// chart1.Series["GT"].Points.DataBindXY(xValues, yValues);
// chart1.Series["GT"].ChartType = SeriesChartType.Pie;
// chart1.Series["GT"]["PieLabelStyle"] = "Disabled";
// chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
// chart1.Legends[0].Enabled = true;
// }
//
// }
//
// private void saveCommonAncestorToolStripMenuItem_Click(Object sender,
// EventArgs e) throws Exception
// {
// SaveFileDialog f = new SaveFileDialog();
// f.Filter = "CSV Files|*.csv";
// if (f.ShowDialog() == DialogResult.OK)
// {
// File.WriteAllText(f.FileName, ca_output_text.toString());
// statusLbl1.Text = "Matching genotypes file saved at " + f.FileName;
// }
//
// }


// /**
// * Required designer variable.
// */
// private System.ComponentModel.IContainer components = null;
//
// /**
// * Clean up any resources being used.
// *
// * @param disposing true if managed resources should be disposed; otherwise,
// * false.
// */
// protected void dispose(boolean disposing) throws Exception
// {
// if (disposing && (components != null))
// {
// components.Dispose();
// }
//
// super.Dispose(disposing);
// }
//
/*
 * // /** // * Required method for Designer support - do not modify the contents
 * of this/ // * method with the code editor. //
 */
// private void initializeComponent() throws Exception
// {
// System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new
// System.Windows.Forms.DataGridViewCellStyle();
// System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new
// System.Windows.Forms.DataVisualization.Charting.ChartArea();
// System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new
// System.Windows.Forms.DataVisualization.Charting.Legend();
// System.Windows.Forms.DataVisualization.Charting.Series series1 = new
// System.Windows.Forms.DataVisualization.Charting.Series();
// System.Windows.Forms.DataVisualization.Charting.Title title1 = new
// System.Windows.Forms.DataVisualization.Charting.Title();
// System.ComponentModel.ComponentResourceManager resources = new
// System.ComponentModel.ComponentResourceManager(
// AtCmpFrm.class);

// this.menuStrip1 = new System.Windows.Forms.MenuStrip();

// this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
// this.openFilesToolStripMenuItem = new
// System.Windows.Forms.ToolStripMenuItem();
// this.saveCommonAncestorToolStripMenuItem = new
// System.Windows.Forms.ToolStripMenuItem();
// this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
// this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
// this.websiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
// this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();

// this.statusStrip1 = new System.Windows.Forms.StatusStrip();
// this.statusLbl1 = new System.Windows.Forms.ToolStripStatusLabel();
// this.bgWorker = new System.ComponentModel.BackgroundWorker();
// this.splitContainer1 = new System.Windows.Forms.SplitContainer();

// this.dgv = new System.Windows.Forms.DataGridView();
// this.chr = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.start = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.stop = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.snps = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.shared = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.Mb = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.segprobability = new System.Windows.Forms.DataGridViewTextBoxColumn();

// this.splitContainer2 = new System.Windows.Forms.SplitContainer();

// this.sgmt = new System.Windows.Forms.DataGridView();

// this.rsid = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.position = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.file1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.file2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.match = new System.Windows.Forms.DataGridViewTextBoxColumn();
// this.prob = new System.Windows.Forms.DataGridViewTextBoxColumn();

// this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();

// this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();

// this.bgMapLoader = new System.ComponentModel.BackgroundWorker();

// this.menuStrip1.SuspendLayout();
// this.statusStrip1.SuspendLayout();
// ((System.ComponentModel.ISupportInitialize) (this.splitContainer1))
// .BeginInit();
// this.splitContainer1.Panel1.SuspendLayout();
// this.splitContainer1.Panel2.SuspendLayout();
// this.splitContainer1.SuspendLayout();
// ((System.ComponentModel.ISupportInitialize) (this.dgv)).BeginInit();
// ((System.ComponentModel.ISupportInitialize) (this.splitContainer2))
// .BeginInit();
// this.splitContainer2.Panel1.SuspendLayout();
// this.splitContainer2.Panel2.SuspendLayout();
// this.splitContainer2.SuspendLayout();
// ((System.ComponentModel.ISupportInitialize) (this.sgmt)).BeginInit();
// ((System.ComponentModel.ISupportInitialize) (this.chart1)).BeginInit();

// this.SuspendLayout();
// //
// // menuStrip1
// //
// this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
// this.fileToolStripMenuItem, this.helpToolStripMenuItem });
// this.menuStrip1.Location = new System.Drawing.Point(0, 0);
// this.menuStrip1.Name = "menuStrip1";
// this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
// this.menuStrip1.Size = new System.Drawing.Size(846, 24);
// this.menuStrip1.TabIndex = 0;
// this.menuStrip1.Text = "menuStrip1";
// //
// // fileToolStripMenuItem
// //
// this.fileToolStripMenuItem.DropDownItems
// .AddRange(new System.Windows.Forms.ToolStripItem[] {
// this.openFilesToolStripMenuItem,
// this.saveCommonAncestorToolStripMenuItem,
// this.exitToolStripMenuItem });
// this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
// this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
// this.fileToolStripMenuItem.Text = "&File";
// //
// // openFilesToolStripMenuItem
// //
// this.openFilesToolStripMenuItem.Name = "openFilesToolStripMenuItem";
// this.openFilesToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
// this.openFilesToolStripMenuItem.Text = "&Open Files";
// this.openFilesToolStripMenuItem.Click += new System.EventHandler(
// this.openFilesToolStripMenuItem_Click);
// //
// // saveCommonAncestorToolStripMenuItem
// //
// this.saveCommonAncestorToolStripMenuItem.Name =
// "saveCommonAncestorToolStripMenuItem";
// this.saveCommonAncestorToolStripMenuItem.Size = new System.Drawing.Size(
// 211, 22);
// this.saveCommonAncestorToolStripMenuItem.Text = "Save Matching Genotypes";
// this.saveCommonAncestorToolStripMenuItem.Click += new System.EventHandler(
// this.saveCommonAncestorToolStripMenuItem_Click);
// //
// // exitToolStripMenuItem
// //
// this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
// this.exitToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
// this.exitToolStripMenuItem.Text = "E&xit";
// this.exitToolStripMenuItem.Click += new System.EventHandler(
// this.exitToolStripMenuItem_Click);
// //
// // helpToolStripMenuItem
// //
// this.helpToolStripMenuItem.DropDownItems
// .AddRange(new System.Windows.Forms.ToolStripItem[] {
// this.websiteToolStripMenuItem,
// this.aboutToolStripMenuItem });
// this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
// this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
// this.helpToolStripMenuItem.Text = "&Help";
// //
// // websiteToolStripMenuItem
// //
// this.websiteToolStripMenuItem.Name = "websiteToolStripMenuItem";
// this.websiteToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
// this.websiteToolStripMenuItem.Text = "&Website";
// this.websiteToolStripMenuItem.Click += new System.EventHandler(
// this.websiteToolStripMenuItem_Click);
// //
// // aboutToolStripMenuItem
// //
// this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
// this.aboutToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
// this.aboutToolStripMenuItem.Text = "&About";
// this.aboutToolStripMenuItem.Click += new System.EventHandler(
// this.aboutToolStripMenuItem_Click);
// //
// // statusStrip1
// //
// this.statusStrip1.Items.AddRange(
// new System.Windows.Forms.ToolStripItem[] { this.statusLbl });
// this.statusStrip1.Location = new System.Drawing.Point(0, 551);
// this.statusStrip1.Name = "statusStrip1";
// this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
// this.statusStrip1.Size = new System.Drawing.Size(846, 22);
// this.statusStrip1.TabIndex = 1;
// this.statusStrip1.Text = "statusStrip1";
// //
// // statusLbl
// //
// this.statusLbl1.Name = "statusLbl";
// this.statusLbl1.Size = new System.Drawing.Size(38, 17);
// this.statusLbl1.Text = "Done.";
// //
// // bgWorker
// //
// this.bgWorker.WorkerReportsProgress = true;
// this.bgWorker.WorkerSupportsCancellation = true;
// this.bgWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(
// this.bgWorker_DoWork);
// this.bgWorker.ProgressChanged += new
// System.ComponentModel.ProgressChangedEventHandler(
// this.bgWorker_ProgressChanged);
// this.bgWorker.RunWorkerCompleted += new
// System.ComponentModel.RunWorkerCompletedEventHandler(
// this.bgWorker_RunWorkerCompleted);
// //
// // splitContainer1
// //
// this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
// this.splitContainer1.Location = new System.Drawing.Point(0, 24);
// this.splitContainer1.Margin = new System.Windows.Forms.Padding(2);
// this.splitContainer1.Name = "splitContainer1";
// //
// // splitContainer1.Panel1
// //
// this.splitContainer1.Panel1.Controls.Add(this.dgv);
// //
// // splitContainer1.Panel2
// //
// this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
// this.splitContainer1.Size = new System.Drawing.Size(846, 527);
// this.splitContainer1.SplitterDistance = 432;
// this.splitContainer1.SplitterWidth = 3;
// this.splitContainer1.TabIndex = 3;
// this.splitContainer1.Visible = false;
// //
// // dgv
// //
// this.dgv.AllowUserToAddRows = false;
// this.dgv.AllowUserToDeleteRows = false;
// this.dgv.ColumnHeadersHeightSizeMode =
// System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
// this.dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
// this.chr, this.start, this.stop, this.snps, this.shared, this.Mb,
// this.segprobability });
// this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
// this.dgv.Location = new System.Drawing.Point(0, 0);
// this.dgv.Margin = new System.Windows.Forms.Padding(2);
// this.dgv.MultiSelect = false;
// this.dgv.Name = "dgv";
// this.dgv.ReadOnly = true;
// this.dgv.RowTemplate.Height = 24;
// this.dgv.SelectionMode =
// System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
// this.dgv.ShowCellErrors = false;
// this.dgv.ShowCellToolTips = false;
// this.dgv.ShowEditingIcon = false;
// this.dgv.ShowRowErrors = false;
// this.dgv.Size = new System.Drawing.Size(432, 527);
// this.dgv.TabIndex = 1;
// this.dgv.SelectionChanged += new System.EventHandler(
// this.dgv_SelectionChanged);
// //
// // chr
// //
// this.chr.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.chr.HeaderText = "Chr";
// this.chr.Name = "chr";
// this.chr.ReadOnly = true;
// //
// // start
// //
// this.start.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.start.HeaderText = "Start";
// this.start.Name = "start";
// this.start.ReadOnly = true;
// //
// // stop
// //
// this.stop.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.stop.HeaderText = "Stop";
// this.stop.Name = "stop";
// this.stop.ReadOnly = true;
// //
// // snps
// //
// this.snps.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.snps.HeaderText = "SNPs";
// this.snps.Name = "snps";
// this.snps.ReadOnly = true;
// //
// // shared
// //
// this.shared.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.shared.HeaderText = "Shared cM";
// this.shared.Name = "shared";
// this.shared.ReadOnly = true;
// //
// // Mb
// //
// this.Mb.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.Mb.HeaderText = "Shared Mb";
// this.Mb.Name = "Mb";
// this.Mb.ReadOnly = true;
// //
// // segprobability
// //
// dataGridViewCellStyle1.NullValue = null;
// this.segprobability.DefaultCellStyle = dataGridViewCellStyle1;
// this.segprobability.HeaderText = "Segment Probability";
// this.segprobability.Name = "segprobability";
// this.segprobability.ReadOnly = true;
// //
// // splitContainer2
// //
// this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
// this.splitContainer2.Location = new System.Drawing.Point(0, 0);
// this.splitContainer2.Name = "splitContainer2";
// this.splitContainer2.Orientation =
// System.Windows.Forms.Orientation.Horizontal;
// //
// // splitContainer2.Panel1
// //
// this.splitContainer2.Panel1.Controls.Add(this.sgmt);
// //
// // splitContainer2.Panel2
// //
// this.splitContainer2.Panel2.Controls.Add(this.chart1);
// this.splitContainer2.Size = new System.Drawing.Size(411, 527);
// this.splitContainer2.SplitterDistance = 327;
// this.splitContainer2.TabIndex = 3;
// //
// // sgmt
// //
// this.sgmt.AllowUserToAddRows = false;
// this.sgmt.AllowUserToDeleteRows = false;
// this.sgmt.ColumnHeadersHeightSizeMode =
// System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
// this.sgmt.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
// this.rsid, this.position, this.file1, this.file2, this.match,
// this.prob });
// this.sgmt.Dock = System.Windows.Forms.DockStyle.Fill;
// this.sgmt.Location = new System.Drawing.Point(0, 0);
// this.sgmt.Margin = new System.Windows.Forms.Padding(2);
// this.sgmt.Name = "sgmt";
// this.sgmt.ReadOnly = true;
// this.sgmt.RowTemplate.Height = 24;
// this.sgmt.SelectionMode =
// System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
// this.sgmt.Size = new System.Drawing.Size(411, 327);
// this.sgmt.TabIndex = 2;
// this.sgmt.CellFormatting += new
// System.Windows.Forms.DataGridViewCellFormattingEventHandler(
// this.sgmt_CellFormatting);
// this.sgmt.SelectionChanged += new System.EventHandler(
// this.sgmt_SelectionChanged);
// //
// // rsid
// //
// this.rsid.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.rsid.HeaderText = "RSID";
// this.rsid.Name = "rsid";
// this.rsid.ReadOnly = true;
// //
// // position
// //
// this.position.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.position.HeaderText = "Position";
// this.position.Name = "position";
// this.position.ReadOnly = true;
// //
// // file1
// //
// this.file1.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.file1.HeaderText = "File1";
// this.file1.Name = "file1";
// this.file1.ReadOnly = true;
// //
// // file2
// //
// this.file2.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.file2.HeaderText = "File2";
// this.file2.Name = "file2";
// this.file2.ReadOnly = true;
// //
// // match
// //
// this.match.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.match.HeaderText = "Match";
// this.match.Name = "match";
// this.match.ReadOnly = true;
// //
// // prob
// //
// this.prob.AutoSizeMode =
// System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
// this.prob.HeaderText = "GenoType Probability";
// this.prob.Name = "prob";
// this.prob.ReadOnly = true;
// //
// // chart1
// //
// chartArea1.Name = "ChartArea1";
// this.chart1.ChartAreas.Add(chartArea1);
// this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
// legend1.Name = "Legend1";
// this.chart1.Legends.Add(legend1);
// this.chart1.Location = new System.Drawing.Point(0, 0);
// this.chart1.Name = "chart1";
// series1.ChartArea = "ChartArea1";
// series1.Legend = "Legend1";
// series1.Name = "GT";
// this.chart1.Series.Add(series1);
// this.chart1.Size = new System.Drawing.Size(411, 196);
// this.chart1.TabIndex = 0;
// this.chart1.Text = "chart1";
// title1.Name = "Title1";
// title1.Text = "Genotype Distribution in Populations";
// this.chart1.Titles.Add(title1);
// //
// // saveFileDialog1
// //
// this.saveFileDialog1.Filter = "Text Files|*.txt";
// //
// // bgMapLoader
// //
// this.bgMapLoader.DoWork += new System.ComponentModel.DoWorkEventHandler(
// this.bgMapLoader_DoWork);
// this.bgMapLoader.RunWorkerCompleted += new
// System.ComponentModel.RunWorkerCompletedEventHandler(
// this.bgMapLoader_RunWorkerCompleted);
// //
// // AtCmpFrm
// //
// this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
// this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
// this.ClientSize = new System.Drawing.Size(846, 573);
// this.Controls.Add(this.splitContainer1);
// this.Controls.Add(this.statusStrip1);
// this.Controls.Add(this.menuStrip1);
// this.Icon = ((System.Drawing.Icon) (resources.GetObject("$this.Icon")));
// this.MainMenuStrip = this.menuStrip1;
// this.Margin = new System.Windows.Forms.Padding(2);
// this.Name = "AtCmpFrm";
// this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
// this.Text = "Autosomal Segment Analyzer";
// this.Load += new System.EventHandler(this.AtCmpFrm_Load);
// this.menuStrip1.ResumeLayout(false);
// this.menuStrip1.PerformLayout();
// this.statusStrip1.ResumeLayout(false);
// this.statusStrip1.PerformLayout();
// this.splitContainer1.Panel1.ResumeLayout(false);
// this.splitContainer1.Panel2.ResumeLayout(false);
// ((System.ComponentModel.ISupportInitialize) (this.splitContainer1))
// .EndInit();
// this.splitContainer1.ResumeLayout(false);
// ((System.ComponentModel.ISupportInitialize) (this.dgv)).EndInit();
// this.splitContainer2.Panel1.ResumeLayout(false);
// this.splitContainer2.Panel2.ResumeLayout(false);
// ((System.ComponentModel.ISupportInitialize) (this.splitContainer2))
// .EndInit();
// this.splitContainer2.ResumeLayout(false);
// ((System.ComponentModel.ISupportInitialize) (this.sgmt)).EndInit();
// ((System.ComponentModel.ISupportInitialize) (this.chart1)).EndInit();
// this.ResumeLayout(false);
// this.PerformLayout();
// }
//
// private System.Windows.Forms.MenuStrip menuStrip1 = new
// System.Windows.Forms.MenuStrip();
// private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem = new
// System.Windows.Forms.ToolStripMenuItem();
// private System.Windows.Forms.ToolStripMenuItem openFilesToolStripMenuItem =
// new System.Windows.Forms.ToolStripMenuItem();
// private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem = new
// System.Windows.Forms.ToolStripMenuItem();
// private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem = new
// System.Windows.Forms.ToolStripMenuItem();
// private System.Windows.Forms.StatusStrip statusStrip1 = new
// System.Windows.Forms.StatusStrip();
// private System.Windows.Forms.ToolStripStatusLabel statusLbl = new
// System.Windows.Forms.ToolStripStatusLabel();
// private System.ComponentModel.BackgroundWorker bgWorker = new
// System.ComponentModel.BackgroundWorker();
// private System.Windows.Forms.ToolStripMenuItem websiteToolStripMenuItem = new
// System.Windows.Forms.ToolStripMenuItem();
// private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem = new
// System.Windows.Forms.ToolStripMenuItem();
// private System.Windows.Forms.SplitContainer splitContainer1 = new
// System.Windows.Forms.SplitContainer();
// private System.Windows.Forms.DataGridView dgv = new
// System.Windows.Forms.DataGridView();
// private System.Windows.Forms.DataGridView sgmt = new
// System.Windows.Forms.DataGridView();
// private System.Windows.Forms.SaveFileDialog saveFileDialog1 = new
// System.Windows.Forms.SaveFileDialog();
// private System.ComponentModel.BackgroundWorker bgMapLoader = new
// System.ComponentModel.BackgroundWorker();
// private System.Windows.Forms.DataGridViewTextBoxColumn chr = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn start = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn stop = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn snps = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn shared = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn Mb = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn segprobability = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn rsid = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn position = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn file1 = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn file2 = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn match = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.DataGridViewTextBoxColumn prob = new
// System.Windows.Forms.DataGridViewTextBoxColumn();
// private System.Windows.Forms.SplitContainer splitContainer2 = new
// System.Windows.Forms.SplitContainer();
// private System.Windows.Forms.DataVisualization.Charting.Chart chart1 = new
// System.Windows.Forms.DataVisualization.Charting.Chart();
// private System.Windows.Forms.ToolStripMenuItem
// saveCommonAncestorToolStripMenuItem = new
// System.Windows.Forms.ToolStripMenuItem();
// */

