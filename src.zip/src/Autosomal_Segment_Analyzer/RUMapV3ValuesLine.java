/**
 * RUMapV3ValuesLine
 */
package Autosomal_Segment_Analyzer;

/**
 * Inner class RUMapV3ValuesLine
 * @author benba
 *
 */
public class RUMapV3ValuesLine
{
	public final long siteLocation;
	public final Double dB;
	public final Double dC;
	public final Double dD;
	
	RUMapV3ValuesLine(long lA, Double dB, Double dC, Double dD)
	{
		this.siteLocation = lA;
		this.dB = dB;
		this.dC = dC;
		this.dD = dD;
	}
	
	 RUMapV3ValuesLine get()
	 {
		 return this;
	 }
	 
	 public String toString()
	 {
		 return 	 "[" + Long.toString(siteLocation) + " " + 
					 Double.toString(dB) + " " + 
					 Double.toString(dC) + " " + 
					 Double.toString(dD) + "]";		 
	 }
	
}