//
// Translated by CS2J (http://www.cs2j.com): 3/31/2021 8:47:20 PM
//

package Autosomal_Segment_Analyzer;
import Autosomal_Segment_Analyzer.AtCmpFrm;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import java.nio.file.*;
import java.util.*;

import dna.Dna;
import dna.DnaFrame;

/**
 * CompareUtil
 * 
 * @author benba
 */
// also http://compgen.rutgers.edu/downloads

// private void aboutToolStripMenuItem_Click(Object sender, EventArgs e)
// throws Exception
// {
// MessageBox.Show("Autosomal Segment Analyzer " +
// Application.ProductVersion +
// "\r\n\r\nDeveloper: Felix Chandrakumar <i@fc.id.au>\r\nWebsite:
// y-str.org\r\n\r\nReference Data:\r\n - http://compgen.rutgers.edu/maps\r\n
// -
// http://www.opensnp.org",
// "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
// }
//
// private void atCmpFrm_Load(Object sender, EventArgs e) throws Exception
// {
// this.Text = Application.ProductName.ToString() + " v" +
// Application.ProductVersion.ToString();
// statusLbl1.Text = "Loading Rutgers Map v.3 ...";
// this.Enabled = false;
// bgMapLoader.RunWorkerAsync();
// }
//
// private void websiteToolStripMenuItem_Click(Object sender, EventArgs e)
// throws Exception
// {
// Process.Start(
// "http://www.y-str.org/2013/08/autosomal-segment-analyzer.html");
// }
//
public class CompareUtil
{
	
	private static TreeMap<String, String[]> RUMapV3 = new TreeMap<String, String[]>();
	
	private static TreeMap<String,
				TreeMap<String, Double>> OpenSNP_Freq = new TreeMap<String, TreeMap<String, Double>>();
	
	@SuppressWarnings("unchecked")
	private static ArrayList<RUMapV3ValuesLine>[] RUMapV3Values = new ArrayList[23];
	
	/**
	 * gzip writer
	 */
	static BufferedWriter writer = null;
	
	/**
	 * zipFilePath
	 */
	static final String zipFilePath[] = {	"fn1", "fn2", "fn3", "fn4", "fn5", "fn6", "fn7", "fn8",
														"fn9", "fn10", "fn11", "fn12", "fn13", "fn14", "fn15",
														"fn16", "fn17", "fn18", "fn19", "fn20", "fn21", "fn22",
														"fn23"};
	
	/**
	 * System properties
	 */
	static Properties p = System.getProperties();
	
	
	// fields enum
	public static enum RUMapv3Fields {
		Marker_name(0), Type(1), Alias(2), Informative_meioses(3),
		
		Heterozygosity(4),
		
		Build37_start_physical_position(5), Sex_averaged_start_map_position(6),
		Female_start_map_position(7), Male_start_map_position(8),
		
		Build37_end_physical_position(9), Sex_averaged_end_map_position(10),
		Female_end_map_position(11), Male_end_map_position(12),
		
		Backbone_Interpolated(13), rsID_UniSTS(14);
		
		private final int val;
		
		/**
		 * Constructor
		 * 
		 * @param val
		 */
		RUMapv3Fields(int val)
		{
			this.val = val;
		}
		
		/**
		 * @return the val
		 */
		public int getVal()
		{
			return val;
		}
		
	}
	
	/**
	 * @return the openSNP_Freq
	 */
	public static TreeMap<String, TreeMap<String, Double>> getOpenSNP_Freq()
	{
		return OpenSNP_Freq;
	}
	
	/**
	 * @param openSNP_Freq the openSNP_Freq to set
	 */
	public static void setOpenSNP_Freq(TreeMap<String, TreeMap<String, Double>> openSNP_Freq)
	{
		OpenSNP_Freq = openSNP_Freq;
	}
	
	/**
	 * @return the rUMapV3Values
	 */
	public static ArrayList<RUMapV3ValuesLine>[] getRUMapV3Values()
	{
		return RUMapV3Values;
	}
	
	/**
	 * @param rUMapV3Values the rUMapV3Values to set
	 */
	public static void setRUMapV3Values(ArrayList<RUMapV3ValuesLine>[] rUMapV3Values)
	{
		RUMapV3Values = rUMapV3Values;
	}
	
	/**
	 * close writer file
	 * 
	 * @throws IOException
	 */
	public static void closeWriter() throws IOException
	{
		if (writer != null)
		{
			writer.close();
		}
		
	}

	
	
	/**
	 * Build default bits for each chromosome.
	 */
	public static void setDefaultMatchBits()
	{
		if (getRUMapV3Values().length == 0)
		{
			System.out.println("need to load map files first");
			return;
		}
		
		DnaFrame.setProgressBar(0);
	
		for (int i = 1 ; i <= 23 ; i++)
		{
			DnaFrame.setProgressBar(i * 4);
			
			int length = 0;
			
			// get tree for this chromosome
			
			for (RUMapV3ValuesLine vl : getRUMapV3Values()[i - 1])
			{
				try
				{
					// write the match bit for this site to 0
					Dna.dmb.setDefaultMatchBit(i - 1, length++, false);
					
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
				
			}
			
			Dna.dmb.setDmbLength(i - 1, length);
			Dna.dmb.setDmbInitialized(i - 1);
		}
		
		DnaFrame.setProgressBar(100);
	}
	
	/**
	 * Build a distances file for each chromosome.
	 */
	public static void buildDistancesFile()
	{
		if (getRUMapV3Values().length == 0)
		{
			System.out.println("need to load map files first");
			return;
		}
		
		// write site numbers to gz files
		DnaFrame.setProgressBar(0);
		
		for (int i = 1 ; i <= 23 ; i++)
		{
			DnaFrame.setProgressBar(i * 4);
			String resolvedPath = p.getProperty("user.dir") + "\\" + zipFilePath[i - 1] + ".gz";
			
			System.out.println("opening: " + resolvedPath);
			try
			{
				// open output file
				File yourFile = new File(resolvedPath);
				yourFile.createNewFile(); // if file already exists will do nothing
				FileOutputStream oFile = new FileOutputStream(yourFile, false);
				
				writer = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(oFile)));
				try
				{
					// get tree for this chromosome
					for (RUMapV3ValuesLine vl : getRUMapV3Values()[i - 1])
					{
						Long site = vl.siteLocation;
						// write out the site to a file
						writer.write(site.toString() + " ");
					}
					
					System.out.println("built distance line " + i);
					writer.close();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
				
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
			}
			
		}
		
		DnaFrame.setProgressBar(100);
	}
	
	/**
	 * Read from fnX.gz, write to <outputfile>
	 * 
	 * @param writer
	 * 
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public static void writeDistanceLines(BufferedWriter writer)
				throws FileNotFoundException, IOException
	{
		for (int i = 1 ; i <= 23 ; i++)
		{
			String resolvedPath = p.getProperty("user.dir") + "\\" + zipFilePath[i - 1] + ".gz";
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(resolvedPath))));
			
			int c;
			while ((c = reader.read()) != -1)
			{
				writer.write(c);
			}
			
			reader.close();
		}
		
	}
	
	/**
	 * Loads RUMapv3 reading gzip for each chromosome
	 * 
	 * @param none
	 * 
	 * @return none
	 * 
	 * @throws Exception exception
	 */
	public static void loadMaps() throws Exception
	{
		String line = null;
		String[] data = null;
		
		DnaFrame.setProgressBar(0);
		
		// -------------------
		// populate RUMapV3
		if (RUMapV3.size() == 0)
		{
			// read the 23 RUMaps
			for (int i = 1 ; i <= 23 ; i++)
			{
				getRUMapV3Values()[i - 1] = new ArrayList<RUMapV3ValuesLine>();
				
				DnaFrame.setProgressBar(i * 4);
				String resolvedPath = "";
				int linenum = 0;
				
				try
				{
					String zipFilePath[] = {"filtered_RUMapv3_B137_chr1.txt",
													"filtered_RUMapv3_B137_chr2.txt",
													"filtered_RUMapv3_B137_chr3.txt",
													"filtered_RUMapv3_B137_chr4.txt",
													"filtered_RUMapv3_B137_chr5.txt",
													"filtered_RUMapv3_B137_chr6.txt",
													"filtered_RUMapv3_B137_chr7.txt",
													"filtered_RUMapv3_B137_chr8.txt",
													"filtered_RUMapv3_B137_chr9.txt",
													"filtered_RUMapv3_B137_chr10.txt",
													"filtered_RUMapv3_B137_chr11.txt",
													"filtered_RUMapv3_B137_chr12.txt",
													"filtered_RUMapv3_B137_chr13.txt",
													"filtered_RUMapv3_B137_chr14.txt",
													"filtered_RUMapv3_B137_chr15.txt",
													"filtered_RUMapv3_B137_chr16.txt",
													"filtered_RUMapv3_B137_chr17.txt",
													"filtered_RUMapv3_B137_chr18.txt",
													"filtered_RUMapv3_B137_chr19.txt",
													"filtered_RUMapv3_B137_chr20.txt",
													"filtered_RUMapv3_B137_chr21.txt",
													"filtered_RUMapv3_B137_chr22.txt",
													"filtered_RUMapv3_B137_chr23.txt"};
					
					// Open the Ith file
					Properties p = System.getProperties();
					// p.forEach((k, v) -> System.out.println(k + "\t:\t" + v)); //
					// Java 8
					
					resolvedPath = p.getProperty("user.dir") + "\\" + zipFilePath[i - 1] + ".gz";
					
					System.out.println("opening: " + resolvedPath);
					DnaFrame.refreshDnaFrame();
					
					// @formatter:off
					BufferedReader reader = new BufferedReader(
				                        new InputStreamReader(
				                        new GZIPInputStream(
				                        new FileInputStream(resolvedPath))));
					// @formatter:on
					
					// read all file lines.
					
					// ignore first...
					reader.readLine(); // blow off header line
					
					linenum = 0;
					while ((line = reader.readLine()) != null)
					{
						if ((linenum % 10000) == 0) System.out.println("line " + linenum);
						
						linenum++;
						data = line.split("\t");
						
						// ---------------------------------
						// Build37_start_physical_position(5),
						// Sex_averaged_start_map_position(6),
						// Female_start_map_position(7),
						// Male_start_map_position(8),
						
						long lA = !(data[5].equals("NA")) ? Long.parseLong(data[5]) : -1;
						Double dB = !(data[6].equals("NA")) ? Double.parseDouble(data[6]) : -1;
						Double dC = !(data[7].equals("NA")) ? Double.parseDouble(data[7]) : -1;
						Double dD = !(data[8].equals("NA")) ? Double.parseDouble(data[8]) : -1;
						
						RUMapV3ValuesLine vl = new RUMapV3ValuesLine(lA, dB, dC, dD);
						getRUMapV3Values()[i - 1].add(vl);
						
						// start position : avg, female, male
						// https://stackoverflow.com/questions/13318733/get-closest-value-to-a-number-in-array
						
						// start position : avg, female, male
						if (!RUMapV3.containsKey(i + ":" + data[5]))
						{
							// https://stackoverflow.com/questions/13318733/get-closest-value-to-a-number-in-array
							
							// ---------------------------------
							// Build37_start_physical_position(5),
							// Sex_averaged_start_map_position(6),
							// Female_start_map_position(7),
							// Male_start_map_position(8),
							
							// key is chr#:startPos
							RUMapV3.put(i +	":" + data[5],                        	// key
											new String[]{data[6], data[7], data[8]});  	// values
						}
						
					}
					
					reader.close();
				}
				catch (Exception e)
				{
					System.out.println(	"at line " +	linenum + " exception on file: " + resolvedPath +
												" : " + e.toString());
					System.out.println(	"values: " +	data[5] + " " + data[6] + " " + data[7] + " " +
												data[8]);
				}
				
			}
			
		}
		
		// -------------------------
		// populate OpenSNP_Freq
		if (getOpenSNP_Freq().size() == 0)
		{
			String resolvedPath = "";
			
			try
			{
				String filePath = "opensnp_snps.freq";
				
				// Path path = FileSystems.getDefault().getPath(filePath);
				// String resolvedPath = path.toString();
				
				Properties p = System.getProperties();
				// p.forEach((k, v) -> System.out.println(k + "\t:\t" + v)); //
				// Java 8
				
				
				resolvedPath = p.getProperty("user.dir") + "\\" + filePath + ".gz";
				
				System.out.println("opening: " + resolvedPath);
				BufferedReader reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(resolvedPath))));
				
				String[] data2 = null;
				TreeMap<String, Double> freq = null;
				int total = 0;
				
				while ((line = reader.readLine()) != null)
				{
					data = line.split(",");
					
					if (!getOpenSNP_Freq().containsKey(data[0]))
					{
						freq = new TreeMap<String, Double>();
						
						total = 0;
						for (String kvp : data[1].split("\\|"))
						{
							data2 = kvp.split("=");
							if (StringSupport.equals(data2[0], "--") ||
									StringSupport.equals(data2[0], "-") ||
									StringSupport.equals(data2[0], "00") ||
									StringSupport.equals(data2[0], "0"))
								continue;
							
							freq.put(data2[0], Double.parseDouble(data2[1]));
							total = total + Integer.parseInt(data2[1]);
						}
						
						ArrayList<String> keys = new ArrayList<>(freq.keySet());
						for (String gt : keys)
						{
							double d = freq.get(gt);
							freq.put(gt, d / total);
						}
						
						getOpenSNP_Freq().put(data[0], freq);
					}
					
				}
				
				reader.close();
			}
			catch (Exception e)
			{
				System.out.println("file exception on " + resolvedPath + ":" + e.toString());
				e.printStackTrace();
			}
			
		}
		
		DnaFrame.setProgressBar(100);
		System.out.println("done loading maps");
	}
	
	/////////////////////////////////////////////////////////
	
	public static final long TOTAL_BP = 2877000000L;
	public static final long TOTAL_CM = 3384;
	// sex
	public static final int GENDER_MALE = 0;
	public static final int GENDER_FEMALE = 1;
	public static final int GENDER_UNKNOWN = 2;
	// method
	public static final int MB_METHOD = 0;
	public static final int CM_METHOD = 1;
	// how to handle not tested / avaliable
	public static final int NOT_TESTED_MATCH_BY_REMOVING = 0;
	public static final int NOT_TESTED_MATCH_BY_ADDING = 1;
	public static final int NOT_TESTED_DONT_MATCH = 2;
	
	public static char SEX_1 = 'U';
	public static char SEX_2 = 'U';
	public static boolean IGNORE_UNIVERSAL_MATCHING_SNPS = false;
	public static double UNIVERSAL_MATCH_SNP_THRESHOLD = 0.90;
	
	
	/**
	 * get centimorgans : subtract stop - start
	 * 
	 * @param chr - chromosome #
	 * @param start - range start
	 * @param end - range end
	 * @param sex1
	 * @param sex2
	 * 
	 * @return centimorgans - double ; or 0 if start or end was not found
	 * 
	 * @throws Exception
	 */
	public static double get_cM(int chr, int start, int end, char sex1, char sex2) throws Exception
	{
		// get start and end key i.e. string
		String key_start = getKey(chr, start);
		String key_stop = getKey(chr, end);
		
		// If either start or end was not found in map, return 0
		if (key_start == null || key_stop == null) return 0;
		
		String[] mstart = RUMapV3.get(key_start);
		String[] mstop = RUMapV3.get(key_stop);
		
		// both females - return female map position
		if (sex1 == 'F' &&	sex2 == 'F' &&
				!StringSupport.equals(mstop[1], "NA") &&
				!StringSupport.equals(mstart[1], "NA"))
			return Double.parseDouble(mstop[1]) - Double.parseDouble(mstart[1]);
		
		// both males - return male map position
		else if (sex1	== 'M' &&	sex2 == 'M' &&
					!StringSupport.equals(mstop[2], "NA") &&
					!StringSupport.equals(mstart[2], "NA"))
			return Double.parseDouble(mstop[2]) - Double.parseDouble(mstart[2]);
		
		// else return general map position
		else
			return Double.parseDouble(mstop[0]) - Double.parseDouble(mstart[0]);
	}
	
	/**
	 * getKey
	 * return chr#:startPos if
	 * key is in map, null otherwise
	 * 
	 * @param chr - chromosome number
	 * @param start - snp start position
	 * 
	 * @return key - String
	 * 
	 * @throws Exception
	 */
	private static String getKey(int chr, int start) throws Exception
	{
		for (int i = start ; i < start + 1000000 ; i++)
		{
			// key is chr#:startPos
			if (RUMapV3.containsKey(chr + ":" + i))
			{
				return chr + ":" + i;
			}
			
		}
		
		return null;
	}
	
	/**
	 * isShared
	 * are SNPs shared
	 * 
	 * @param g1 - genome 1
	 * @param g2 - genome 2
	 * @param treat_nocall_match t/f
	 * 
	 * @return true/false
	 * 
	 * @throws Exception
	 */
	public static boolean isShared(ArrayList<String> g1, ArrayList<String> g2,
				boolean treat_nocall_match) throws Exception
	{
		for (String genotype1 : g1)
		{
			for (String genotype2 : g2)
			{
				if (StringSupport.equals(genotype1, "00") || StringSupport.equals(genotype2, "00") ||
						StringSupport.equals(genotype1, "DD") ||
						StringSupport.equals(genotype2, "DD") ||
						StringSupport.equals(genotype1, "mm") ||
						StringSupport.equals(genotype2, "mm") ||
						StringSupport.equals(genotype1, "??") ||
						StringSupport.equals(genotype2, "??") ||
						StringSupport.equals(genotype1, "--") ||
						StringSupport.equals(genotype2, "--") ||
						StringSupport.equals(genotype1, "---") ||
						StringSupport.equals(genotype2, "---"))
				{
					if (treat_nocall_match) return true;
					else
						return false;
				}
				
				if (StringSupport.equals(genotype1, genotype2)) return true;
				
				if (StringSupport.equals(genotype1, reverse(genotype2))) return true;
				
				if (genotype1.charAt(0) == genotype2.charAt(0)) return true;
				
				if (genotype1.charAt(1) == genotype2.charAt(1)) return true;
				
				if (genotype1.charAt(0) == genotype2.charAt(1)) return true;
				
				if (genotype1.charAt(1) == genotype2.charAt(0)) return true;
				
				if (treat_nocall_match)
				{
					if (genotype1.charAt(0) == '?' ||	genotype1.charAt(0) == '-' ||
							genotype1.charAt(0) == 'm' ||
							genotype1.charAt(0) == 'D')
						return true;
					
					if (genotype1.charAt(1) == '?' ||	genotype1.charAt(1) == '-' ||
							genotype1.charAt(1) == 'm' ||
							genotype1.charAt(1) == 'D')
						return true;
					
					if (genotype2.charAt(0) == '?' ||	genotype2.charAt(0) == '-' ||
							genotype2.charAt(0) == 'm' ||
							genotype2.charAt(0) == 'D')
						return true;
					
					if (genotype2.charAt(1) == '?' ||	genotype2.charAt(1) == '-' ||
							genotype2.charAt(1) == 'm' ||
							genotype2.charAt(1) == 'D')
						return true;
				}
				
			}
			
		}
		
		return false;
	}
	
	/**
	 * reverse()
	 * reverse a string
	 * 
	 * @param s - string to reverse
	 * 
	 * @return reversed string
	 */
	public static String reverse(String s)
	{
		char[] charArray = s.toCharArray();
		Collections.reverse(Arrays.asList(charArray));
		return new String(charArray);
	}
	
	/**
	 * normalizeData
	 * 
	 * @param file : TreeMap input
	 * 
	 * @return TreeMap of normalized data
	 * 
	 * @throws Exception
	 */
	@SuppressWarnings("null")
	public static TreeMap<Integer, ArrayList<String>>[][] normalizeData(String file) throws Exception
	{
		String[] data = null;
		String line1 = null;
		List<String> list1 = new ArrayList<String>();
		
		Path path = FileSystems.getDefault().getPath(file);
		if (path.endsWith(".gz"))
		{
			String resolvedPath = path.toString();
			
			// @formatter:off
			BufferedReader reader = new BufferedReader(
			                        new InputStreamReader(
											new GZIPInputStream(
							            new FileInputStream(resolvedPath))));
			
			// @formatter:on
			while ((line1 = reader.readLine()) != null)
			{
				// add line to list
				list1.add(line1);
			}
			
			reader.close();
			data = list1.toArray(data);
		}
		else
		{
			Path path1 = FileSystems.getDefault().getPath(file);
			list1 = Files.readAllLines(path1);
		}
		
		// does file look like FamilyTree dna?
		boolean ftdna = false;
		
		TreeMap<Integer, ArrayList<String>>[][] chr = null;
		
		if (StringSupport.equals(data[0].trim(), "RSID,CHROMOSOME,POSITION,RESULT")) ftdna = true;
		
		String line = null;
		String[] ldata = null;
		int chromosome = -1;
		int position = -1;
		
		for (String d : data)
		{
			// FamilyTree DNA
			if (ftdna)
			{
				// blow off header line
				if (d.startsWith("RSID")) continue;
				
				// replace quote with nothing
				line = d.replace("\"", "");
				// replace blank with comma
				line = line.replace(" ", ",");
			}
			
			// Some other company - not sure which
			else
			{
				if (d.startsWith("#")) continue;
				
				// tab separated - make it comma separated
				line = d.replace("\t", ",");
			}
			
			// split line around ,
			ldata = line.split(",");
			if (StringSupport.equals(ldata[1], "X") ||	StringSupport.equals(ldata[1], "Y") ||
					StringSupport.equals(ldata[1], "XY") ||
					StringSupport.equals(ldata[1], "MT"))
				continue;
			
			// chromosome# in field 1
			chromosome = Integer.parseInt(ldata[1]);
			if (chromosome == 0) continue;
			
			// position in field 2
			position = Integer.parseInt(ldata[2]);
			
			if (chr[0][chromosome - 1] == null)
				chr[0][chromosome - 1] = new TreeMap<Integer, ArrayList<String>>();
			
			if (chr[1][chromosome - 1] == null)
				chr[1][chromosome - 1] = new TreeMap<Integer, ArrayList<String>>();
			
			ArrayList<String> list = null;
			
			if (!chr[0][chromosome - 1].containsKey(position))
			{
				list = new ArrayList<String>();
				list.add(ldata[3]); // result field
				chr[0][chromosome - 1].put(position, list); // add key POSITION:
																			 // value RESULT
			}
			else
			{
				list = chr[0][chromosome - 1].get(position);
				chr[0][chromosome - 1].remove(position);
				list.add(ldata[3]);
				chr[0][chromosome - 1].put(position, list);
			}
			
			// rsid - pos map
			ArrayList<String> list2 = null;
			if (!chr[1][chromosome - 1].containsKey(position))
			{
				list2 = new ArrayList<String>();
				list2.add(ldata[0]); // RSID field
				chr[1][chromosome - 1].put(position, list2); // POSITION : RSID
			}
			else
			{
				list2 = chr[1][chromosome - 1].get(position);
				chr[1][chromosome - 1].remove(position);
				list2.add(ldata[0]);
				chr[1][chromosome - 1].put(position, list2);
			}
			
		}
		
		return chr;
	}
	
	
	/**
	 * getSharedDNA
	 * 
	 * @param rsid
	 * @param genotype1
	 * @param genotype2
	 * @param chr
	 * @param pos
	 * 
	 * @return array of strings of shared dna
	 * 
	 * @throws Exception
	 */
	// @formatter:off
	public static String[] getSharedDNA(ArrayList<String> rsid,
				                           ArrayList<String> genotype1,
				                           ArrayList<String> genotype2, 
				                           int chr, 
				                           int pos) throws Exception
	// @formatter:on
	{
		// # rsid ; chromosome; position; genotype
		String[] dna_row = new String[4];
		
		dna_row[0] = rsid.get(0);
		dna_row[1] = Integer.toString(chr);
		dna_row[2] = Integer.toString(pos);
		
		boolean found = false;
		String allele = "";
		for (String g1 : genotype1)
		{
			for (String g2 : genotype2)
			{
				if (StringSupport.equals(g1, g2))
				{
					allele = g1;
					found = true;
					break;
				}
				else if (StringSupport.equals(g1, reverse(g2)))
				{
					allele = g1;
					found = true;
					break;
				}
				
				for (int i = 0 ; i < g1.length() ; i++)
				{
					for (int j = 0 ; j < g2.length() ; j++)
					{
						if (g1.charAt(i) == g2.charAt(j))
						{
							allele = g1.charAt(i) + "" + g1.charAt(i);
							break;
						}
						
					}
					
					if (found) break;
				}
				
				if (found) break;
			}
			
			if (found) break;
		}
		
		dna_row[3] = allele;
		return dna_row;
	}

	
	
}
