package Autosomal_Segment_Analyzer;

public class bgMapLoader
{

	public static void RunWorkerAsync()
	{
		// TODO Auto-generated method stub
		
	}
	
}
