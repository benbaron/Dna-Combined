package tools;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import object.Node;
import object.Tree;

/**
 * 
 * @author benba
 *
 */
public class Util
{
	public static boolean BRANCH_LENGTH = false;
	
	public static String getAString(Node node)
	{
		String result = "";
		if (node.isLeaf())
		{
			result = node.getId();
		}
		else if (node.getChildren().size() > 1)
		{
			result = "(";
			List<String> childStrings = new ArrayList<String>();
			
			// get left child then right child
			for (Node child : node.getChildren())
			{
				String childString = getString(child);
				childStrings.add(childString);
			}
			
			Collections.sort(childStrings);
			for (String childString : childStrings)
			{
				result = result + childString + ",";
			}
			
			result = result.substring(0, result.length() - 1);
			result += ")";
		}
		else
		{
			result = getString(node.getChildren().get(0));
		}
		
		return result;
	}
	
	/**
	 * 
	 * @param node
	 * @return
	 */
	public static String getString(Node node)
	{
		return traversePreOrder(node);
	}
	
	/**
	 * 
	 * @param root
	 * @return
	 */
	public static String traversePreOrder(Node root)
	{
		if (root == null)
		{
			return "<tree null>";
		}
		
		StringBuilder sb = new StringBuilder();
		
		// print myself
		sb.append("\n" + root.getId());
		List<Node> children = root.getChildren();
		Node left = null;
		Node right = null;
		switch (children.size())
		{
			case 0:
				// print self
				return sb.toString();
			
			case 1:
				left = children.get(0);
				// only left, right is null
				break;
			
			case 2:
				left = children.get(0);
				right = children.get(1);
				break;
			
			default:
				System.out
						.println("unexpected number of children: " + children.size());
				return "huh?";
		}
		
		// get left child then right child
		// left if not last child = fork, else if last child end
//		String pointerLeft = (right != null) ? "├──" : "└──";
//		String pointerRight = "└──";
		String pointerLeft = (right != null) ? "|--" : "`--";
		String pointerRight = "`--";
		
		// print left child
		traverseNodes(sb, "", pointerLeft, left, right != null); // left child may
																					// have a lower
																					// neighbor
		
		// print right child
		traverseNodes(sb, "", pointerRight, right, false); // right child has no
																			// lower neighbor
		
		return sb.toString();
	}
	
	/**
	 * // Next, we'll create another method for child nodes as traverseNodes.
	 * // Additionally, we will add a new parameter hasRightSibling to implement the
	 * // preceding lines correctly:
	 * @param sb
	 * @param padding
	 * @param pointer
	 * @param node
	 * @param hasRightSibling
	 */
	
	public static void traverseNodes(StringBuilder sb, String padding,
			String pointer, Node node, boolean hasRightSibling)
	{
		if (node != null)
		{
			// Print self
			sb.append("\n");
			sb.append(padding);
			sb.append(pointer);
			if (node.getId() != null)
			{
				sb.append(node.getId()); // getId
			}
			else
			{
				sb.append("null id");
			}
			
			List<Node> children = node.getChildren();
			Node left = null;
			Node right = null;
			switch (children.size())
			{
				case 0:
					// print self
					return;
				
				case 1:
					left = children.get(0);
					// only left, right is null
					break;
				
				case 2:
					left = children.get(0);
					right = children.get(1);
					break;
				
				default:
					System.out.println(
							"unexpected number of children: " + children.size());
			}
			
			StringBuilder paddingBuilder = new StringBuilder(padding);
			if (hasRightSibling)
			{
//				paddingBuilder.append("│  ");
				paddingBuilder.append("|  ");
			}
			else
			{
				paddingBuilder.append("   ");
			}
			
			String paddingForBoth = paddingBuilder.toString();
			
//			String pointerLeft = (right != null) ? "├──" : "└──";
//			String pointerRight = "└──";

			String pointerLeft = (right != null) ? "|--" : "`--";
			String pointerRight = "`--";
			
			// print left child
			// recursive
			traverseNodes(sb, paddingForBoth, pointerLeft, left, right != null); // left
																										// child
																										// may
																										// have
																										// a
																										// lower
																										// neighbor
			
			// print right child
			traverseNodes(sb, paddingForBoth, pointerRight, right, false); // right
																								// child
																								// never
																								// has a
																								// lower
																								// neighbor
		}
		
		// else parent was a leaf node
		return;
	}
	
//	Also, we need a small change in our print method:
// public void print(PrintStream os) {
//	    os.print(traversePreOrder(tree));
// }
	
	/**
	 * 
	 * @param node
	 * @param map
	 * @return
	 */
	public static String getString(Node node, HashMap<Node, String> map)
	{
//		if (node.getId().equals("5397")) {
//			System.err.println();
//		}
		if (map.get(node) != null)
		{
			return map.get(node);
		}
		
		String result = "";
		if (node.isLeaf())
		{
			result = node.getId();
		}
		else if (node.getChildren().size() > 1)
		{
			result = "(";
			List<String> childStrings = new ArrayList<String>();
			for (Node child : node.getChildren())
			{
				String childString = getString(child, map);
				childStrings.add(childString);
			}
			
			Collections.sort(childStrings);
			for (String childString : childStrings)
			{
				result = result + childString + ",";
			}
			
			result = result.substring(0, result.length() - 1);
			result += ")";
		}
		else
		{
			result = getString(node.getChildren().get(0), map);
		}
		
		map.put(node, result);
		return result;
	}
	
	/**
	 * 
	 * @param node
	 * @return
	 */
	public static String getStringWithBranchLengths(Node node)
	{
		String result = "";
		if (node.isLeaf())
		{
			if (node.getBranchLength() != null &&
					!node.getBranchLength().isEmpty())
			{
				result = node.getId() + ":" + node.getBranchLength();
			}
			else
			{
				result = node.getId();
			}
			
		}
		else
		{
			result = "(";
			for (Node child : node.getChildren())
			{
				result = result + getStringWithBranchLengths(child) + ",";
			}
			
			result = result.substring(0, result.length() - 1);
			result += ")";
			if (node.getBranchLength() != null &&
					!node.getBranchLength().isEmpty())
			{
				result += ":" + node.getBranchLength();
			}
			
		}
		
		return result;
	}
	
	/**
	 * 
	 * @param matrix
	 * @param root
	 * @return
	 */
	private static int[][] sortMatrix(int[][] matrix, int[] root)
	{
		int[] countingArray = new int[matrix[0].length];
		for (int i = 0; i < countingArray.length; i++)
		{
			for (int j = 0; j < matrix.length; j++)
			{
				if (matrix[j][i] != root[i])
				{
					countingArray[i]++;
				}
				
			}
			
		}
		
		int[] sortedArray = new int[countingArray.length];
		for (int i = 0; i < countingArray.length; i++)
		{
			int max = -1;
			int maxCol = 0;
			for (int j = 0; j < countingArray.length; j++)
			{
				if (countingArray[j] > max)
				{
					max = countingArray[j];
					maxCol = j;
				}
				
			}
			
			countingArray[maxCol] = -1;
			sortedArray[i] = maxCol;
		}
		
		int[][] result = new int[matrix.length][matrix[0].length];
		for (int i = 0; i < sortedArray.length; i++)
		{
			for (int j = 0; j < result.length; j++)
			{
				result[j][i] = matrix[j][sortedArray[i]];
			}
			
		}
		
		return result;
	}
	
	/**
	 * https://en.wikipedia.org/wiki/Newick_format
	 * @param s
	 * @return
	 */
	public static Tree getTreeFromNewickWithTime(String s)
	{
		Tree tree = new Tree();
		List<Node> stack = new ArrayList<Node>();
		int i = 0;
		String[] array = s.split("\\)");
		s = s.replace(array[array.length - 1], "");
		s = s.replaceAll("\\;", "");
		char previousChar = ',';
		while (i < s.length())
		{
			int j = i;
			while (',' != s.charAt(j) && ')' != s.charAt(j))
			{
				if ('(' == s.charAt(j))
				{
					stack.add(null);
				}
				
				j++;
			}
			
			String temp = s.substring(i, j).replaceAll("\\(", "")
					.replaceAll("\\)", "").replaceAll(",", "");
//			if (temp.length() > 0 && !"".equals(temp.split(":")[0])){
			if (temp.length() > 0 && ',' == previousChar)
			{
				Node node = new Node(1);
				node.setId(temp.split(":")[0]);
				node.setBranchLength(temp.split(":")[1]);
				stack.add(node);
				tree.addNode(node);
			}
			
//			if ("".equals(temp.split(":")[0])) {
			if (')' == previousChar)
			{
				stack.get(stack.size() - 1).setBranchLength(temp.split(":")[1]);
			}
			
			if (')' == s.charAt(j))
			{
				List<Node> children = new ArrayList<Node>();
				int capacity = 0;
				while (stack.get(stack.size() - 1) != null)
				{
					Node child = stack.remove(stack.size() - 1);
					children.add(child);
					capacity += child.getSplit().size();
				}
				
				Node parent = new Node(capacity);
				parent.getChildren().addAll(children);
				for (Node node : children)
				{
					node.setParent(parent);
				}
				
				stack.remove(stack.size() - 1);
				stack.add(parent);
				tree.addNode(parent);
			}
			
			previousChar = s.charAt(j);
			i = j + 1;
		}
		
		Node parent = stack.remove(stack.size() - 1);
		tree.addNode(parent);
		tree.setRoot(parent);
		return tree;
	}
	
	/**
	 * https://en.wikipedia.org/wiki/Newick_format
	 * @param s
	 * @return
	 */
	public static Tree getTreeFromNewick(String s)
	{
		Tree tree = new Tree();
		ArrayList<Node> stack = new ArrayList<Node>();
		int i = 0;
		s = s.replaceAll("\\;", "");
		while (i < s.length())
		{
			int j = i;
			while (',' != s.charAt(j) && ')' != s.charAt(j))
			{
				if ('(' == s.charAt(j))
				{
					stack.add(null);
				}
				
				j++;
			}
			
			String temp = s.substring(i, j).replaceAll("\\(", "")
					.replaceAll("\\)", "").replaceAll(",", "");
			if (temp.length() > 0)
			{
				Node node = new Node(1);
				node.setId(temp);
				stack.add(node);
				tree.addNode(node);
			}
			
			if (')' == s.charAt(j))
			{
				List<Node> children = new ArrayList<Node>();
				int capacity = 0;
				while (stack.get(stack.size() - 1) != null)
				{
					Node child = stack.remove(stack.size() - 1);
					children.add(child);
					capacity += child.getSplit().size();
				}
				
				Node parent = new Node(capacity);
				parent.getChildren().addAll(children);
				for (Node node : children)
				{
					node.setParent(parent);
				}
				
				stack.remove(stack.size() - 1);
				stack.add(parent);
				tree.addNode(parent);
			}
			
			i = j + 1;
		}
		
		Node parent = stack.remove(stack.size() - 1);
		tree.addNode(parent);
		tree.setRoot(parent);
		return tree;
	}
	
	/**
	 * 
	 * @param path
	 * @return
	 */
	public static InputStream load(String path)
	{
		InputStream input = Util.class.getResourceAsStream(path);
		if (input == null)
		{
			input = Util.class.getResourceAsStream("/" + path);
		}
		
		return input;
	}
}
